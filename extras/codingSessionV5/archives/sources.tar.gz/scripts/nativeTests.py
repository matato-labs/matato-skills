"""Native integration regressions; mocked generation only, never real credentials/providers."""
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from common import agentArgs, digest, owned, save, scratch
from nativeTrial import ActivationEvent, auditActivation, baseline, freezePackage, nativeArgs, nativeEnvironment, packageFiles, prepareNative, primarySkill
from sandboxTrial import Sandbox, sandbox


def activationEvents(expected: bytes) -> list[ActivationEvent]:
    return [
        {'type': 'entry_appended', 'entry': {'customType': 'v5NativeActivation',
         'data': {'phase': 'before', 'run': 1, 'sha256': digest(expected), 'valid': True}}},
        {'type': 'agent_start'},
        {'type': 'entry_appended', 'entry': {'customType': 'v5NativeActivation',
         'data': {'phase': 'context', 'run': 1,
                  'sha256': digest(b'<ponytail>\n' + expected + b'\n</ponytail>'), 'valid': True}}},
    ]


class NativeTests(unittest.TestCase):
    def setUp(self):
        owned(scratch / 'tests')
        self.temporary = tempfile.TemporaryDirectory(prefix='native', dir=scratch / 'tests')
        self.root = Path(self.temporary.name)
        self.package = baseline / 'upstream'
        self.profile = (self.package / primarySkill).read_bytes()

    def tearDown(self):
        self.temporary.cleanup()

    def testNativeArgsKeepFixedControls(self):
        pi = Path('/tools/pi')
        text = agentArgs(pi)
        native = agentArgs(pi, True)
        self.assertEqual(native, text[:-2])
        self.assertNotIn('--append-system-prompt', native)
        self.assertEqual(nativeArgs(), ['-e', '/experiment/package/pi-extension/index.js',
                         '--skill', '/experiment/package/skills', '-e', '/experiment/nativeTrace.ts'])

    def testSnapshotExactAndVariantMechanism(self):
        private = self.root / 'private'
        private.mkdir()
        snapshot = freezePackage(self.package, self.profile, private, self.root)
        files = packageFiles(snapshot, self.profile)
        self.assertEqual(len(files), 49)
        self.assertEqual(json.loads((self.root / 'package.json').read_text())['arm'], 'nativePonytail')
        for name, data in files.items():
            self.assertEqual(data, (self.package / name).read_bytes())
        narrative = b'---\nname: ponytail\ndescription: Native narrative ablation.\n---\nNarrative instructions.\n'
        (snapshot / primarySkill).write_bytes(narrative)
        packageFiles(snapshot, narrative)
        with self.assertRaisesRegex(ValueError, 'exactly match'):
            packageFiles(snapshot, self.profile)
        hook = snapshot / 'hooks/ponytail-instructions.js'
        hook.write_bytes(hook.read_bytes() + b'\n// changed mechanism\n')
        with self.assertRaisesRegex(ValueError, 'mechanism differs'):
            packageFiles(snapshot, narrative)

    def testVariantRunsSameNativeFactory(self):
        package = self.root / 'variant'
        shutil.copytree(self.package, package)
        narrative = b'---\nname: ponytail\ndescription: Same metadata for a native ablation.\n---\nNarrative instructions.\n'
        (package / primarySkill).write_bytes(narrative)
        private, evidence, workspace = [self.root / name for name in ['private', 'evidence', 'workspace']]
        for path in [private, evidence, workspace, workspace / '.git']:
            path.mkdir()
        spec = Sandbox(workspace, package, private / 'runtime', Path('/usr/bin/true'))
        prepareNative(spec, package, narrative, private, evidence)
        self.assertEqual(json.loads((evidence / 'package.json').read_text())['arm'], 'nativeVariant')
        expected = 'PONYTAIL MODE ACTIVE — level: full\n\nNarrative instructions.\n'
        self.assertEqual((evidence / 'nativeInstructions.txt').read_text(), expected)
        self.assertEqual(spec.inputs, [])
        proof = json.loads((evidence / 'nativeProof.json').read_text())
        self.assertEqual(proof['kind'], 'offlineNativeFactoryAndObserverMock')
        self.assertFalse(proof['piRuntimeInjectionProven'])

    def testMissingSkillAndChangedScriptsRejected(self):
        copied = self.root / 'copy'
        shutil.copytree(self.package, copied)
        (copied / primarySkill).unlink()
        with self.assertRaises(FileNotFoundError):
            packageFiles(copied, self.profile)
        (copied / primarySkill).write_bytes(self.profile)
        cleanup = copied / 'scripts/uninstall.js'
        cleanup.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError, 'scripts/uninstall.js'):
            packageFiles(copied, self.profile)

    def testReadonlyMountsAndIsolatedConfig(self):
        stage = self.root / 'stage'
        env = nativeEnvironment(stage)
        spec = Sandbox(self.root, self.root, self.root, Path('/usr/bin/true'))
        spec.package = self.package
        spec.nativeTrace = Path(__file__).with_name('nativeTrace.ts')
        spec.nativeInstructions = self.root / 'instructions'
        spec.nativeInstructions.touch()
        args = sandbox(spec, stage)
        for source, target in [(self.package, Path('/experiment/package')),
                               (spec.nativeTrace, Path('/experiment/nativeTrace.ts')),
                               (spec.nativeInstructions, Path('/experiment/nativeInstructions.txt')),
                               (stage / 'config/ponytail', stage / 'config/ponytail')]:
            start = args.index(str(source))
            self.assertEqual(args[start - 1:start + 2], ['--ro-bind', str(source), str(target)])
        self.assertEqual(env['PONYTAIL_DEFAULT_MODE'], 'full')
        self.assertEqual(json.loads((stage / 'config/ponytail/config.json').read_text())['defaultMode'], 'full')
        self.assertNotIn('OPENAI_API_KEY', env)

    def testAuditActivationCounterexamples(self):
        expected = b'full transformed instructions'
        events = activationEvents(expected) + [{'type': 'message_end', 'message': {'role': 'assistant'}}]
        raw = self.root / 'raw'
        raw.write_text(''.join(json.dumps(event) + '\n' for event in events))
        self.assertTrue(auditActivation(raw, expected)['valid'])
        for change in ['missingAll', 'missingBefore', 'missingContext', 'wrongHash', 'inactive',
                       'wrongRun', 'missingLaterContext', 'missingLaterBefore']:
            changed = json.loads(json.dumps(events))
            if change == 'missingAll':
                changed = []
            if change == 'missingBefore':
                changed.pop(0)
            if change == 'missingContext':
                changed.pop(2)
            if change == 'wrongHash':
                changed[2]['entry']['data']['sha256'] = digest(b'fallback')
            if change == 'inactive':
                changed[0]['entry']['data']['valid'] = False
            if change == 'wrongRun':
                changed[2]['entry']['data']['run'] = 2
            if change == 'missingLaterContext':
                changed.append({'type': 'message_end', 'message': {'role': 'assistant'}})
            if change == 'missingLaterBefore':
                changed.append({'type': 'agent_start'})
            raw.write_text(''.join(json.dumps(event) + '\n' for event in changed))
            self.assertFalse(auditActivation(raw, expected)['valid'], change)

    def testNativeGenerationAuditIsRequired(self):
        from runTrial import Case, runAgent
        from unitTests import fixtureEvents, repository
        repo = self.root / 'repo'
        base = repository(repo)
        expected = b'PONYTAIL MODE ACTIVE transformed full body'
        for proof in [True, False]:
            parent = self.root / str(proof)
            private, evidence = parent / 'private', parent / 'evidence'
            private.mkdir(parents=True)
            evidence.mkdir()
            spec = Sandbox(repo, repo, private / 'runtime', Path('/usr/bin/true'))
            spec.package = self.package
            spec.nativeTrace = Path(__file__).with_name('nativeTrace.ts')
            spec.nativeInstructions = private / 'instructions'
            spec.nativeInstructions.write_bytes(expected)
            spec.auth = private / 'syntheticAuth'
            spec.auth.touch()
            save(evidence / 'package.json', {'arm': 'nativePonytail'})
            events = (activationEvents(expected) if proof else []) + fixtureEvents(self.profile.decode())
            raw, errors = private / 'raw', private / 'errors'
            raw.write_text(''.join(json.dumps(event) + '\n' for event in events))
            errors.touch()
            fake = {'exit': 0, 'stdout': str(raw), 'stderr': str(errors)}
            case = Case('synthetic', str(repo), base, 'No model.', 'true')
            with patch('runTrial.consume'), patch('runTrial.execute', return_value=fake) as launch:
                report = runAgent(spec, case, self.profile, private, evidence, 'neverReserved', [])[1]
            self.assertEqual(report['valid'], proof)
            argv = launch.call_args.args[0]
            self.assertNotIn('--append-system-prompt', argv)
            self.assertIn('/experiment/package/pi-extension/index.js', argv)
            self.assertIn('--skill', argv)
            self.assertEqual(json.loads((evidence / 'invocation.json').read_text())['native'], True)
            self.assertIn('raw SKILL is not appended', (evidence / 'prompt.txt').read_text())

    def testNativeCannotSkipPreflight(self):
        from runTrial import Case, runAgent
        spec = Sandbox(self.root, self.root, self.root, Path('/usr/bin/true'))
        spec.package = self.package
        with patch('runTrial.consume') as budget, patch('runTrial.execute') as launch:
            with self.assertRaisesRegex(ValueError, 'require the offline activation preflight'):
                runAgent(spec, Case('synthetic', '', '', '', 'true'), self.profile,
                         self.root, self.root, 'neverReserved', [])
        budget.assert_not_called()
        launch.assert_not_called()

    def testCliRequiresExplicitNativePair(self):
        script = Path(__file__).with_name('runTrial.py')
        for flags in [['--native'], ['--package', str(self.package)]]:
            result = subprocess.run(['python3', '-B', str(script), 'run', '/missing', '/missing', 'draw', *flags],
                                    capture_output=True, text=True, timeout=10)
            # Parse validation must happen before manifest/auth/Pi access.
            self.assertEqual(result.returncode, 2)
            self.assertIn('--native and --package', result.stderr)


if __name__ == '__main__':
    unittest.main()
