# Frozen implementation results

Only the requested coding profile and frozen briefs were used; no delegation. Production edits stay within each case's allowed scope. External oracles were executed unchanged.

## sourceBatchReads

Changed `atlas/src/atlas/services/navigation.py` and `navigation_source.py`: request-local path cache shares verification failures and decoded verified lines; eligibility stays ahead of access and excerpt/span policy stays per node. Added parameterized regression instrumentation to existing graph tests.

Commands/outcomes:
- `python /tmp/codingSessionV2/research/oracles/sourceBatchReads.py /tmp/codingSessionV2/runs/codingFrozen/sourceBatchReads` — all 5 passed.
- Linked `atlas/.venv` to `/home/leon/workspace/projects/atlas/atlas/.venv` (dependency environment only).
- Initial attempt at a base-repository venv failed (no such executable); no tests ran in that attempt.
- From `sourceBatchReads/atlas`: `PYTHONPATH=src .venv/bin/python -m pytest tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py -q` — 62 passed.
- `PYTHONPATH=src .venv/bin/pyright` — clean; `.venv/bin/ruff check .` — clean.
- `PYTHONPATH=src .venv/bin/python -m pytest -q` — first timed out after 120 seconds near completion; rerun with 300-second timeout passed: 1827 tests, 667 subtests, 9 existing SQLite reflection warnings.
- `git -C sourceBatchReads diff --check` — clean; reviewed production and test diff.

## isinCsvRecords

Replaced physical-line scanning in `commons/data/isin_loader.go` with the standard CSV reader. Header width is unrestricted; data records require exactly three fields. The bounded read loop never parses a record beyond the requested prefix. A small reader helper allows table tests without changing embedded data.

Commands/outcomes:
- `gofmt -w isinCsvRecords/commons/data/isin_loader.go isinCsvRecords/commons/data/isin_loader_test.go` — complete.
- `python /tmp/codingSessionV2/research/oracles/isinCsvRecords.py /tmp/codingSessionV2/runs/codingFrozen/isinCsvRecords` — all 13 scenarios passed.
- From `isinCsvRecords/commons`: `go test ./data` — all 13 native subtests/tests passed.
- `git -C isinCsvRecords diff --check` — clean; reviewed loader and new test file.

## scheduleTimeZones

Added optional `Automation.timezone`; passed it through the existing factory to Croner's timezone option. Explicit enabled-job zones are validated with `Intl.DateTimeFormat` before invoking any factory, ensuring injected factories cannot bypass atomic rollback. Disabled-job ordering, overlap state, naming and config loading are unchanged. Extended existing scheduler and stored-config tests.

Commands/outcomes:
- `python /tmp/codingSessionV2/research/oracles/scheduleTimeZones.py /tmp/codingSessionV2/runs/codingFrozen/scheduleTimeZones` — 7 passed (including DST, non-hour offsets, stored config).
- `python /tmp/codingSessionV2/research/finalOracles/scheduleFactoryContract.py /tmp/codingSessionV2/runs/codingFrozen/scheduleTimeZones` — 8 passed (default and injected factories).
- From `scheduleTimeZones`: `bun test worker/scheduler.test.ts src/automationConfig.test.ts worker/watcher.test.ts` — 17 passed, repeated after formatting.
- `bun run check` — blocked: local `tsc` not installed. Absolute installed `tsc --noEmit` — blocked: candidate lacks Bun/Node type definitions.
- `bun test` — 100 passed; 3 module-loading failures for missing `@earendil-works/pi-coding-agent` / `pi-tui` dependencies.
- Absolute installed `eslint` on affected production/tests — blocked: candidate lacks `@eslint/js`.
- Absolute installed `prettier --write worker/scheduler.ts`, then `prettier --check` on all four changed files — clean.
- `git diff --check` — clean; reviewed complete diff.

## pathEarlyExit

Changed only navigation orchestration and internal traversal production code. An optional target stops the queue at discovery and returns from the neighbor loop before post-completion cutoff bookkeeping; existing admission/budget checks run first. Context uses the unchanged untargeted traversal. Added real-reader call-count tests, including self-path at depth zero. Updated eight existing navigation snapshots using their helper after checking that only found-path graph prefixes/boundaries changed, with identical routes and route edges.

Commands/outcomes:
- `python /tmp/codingSessionV2/research/oracles/pathEarlyExit.py /tmp/codingSessionV2/runs/codingFrozen/pathEarlyExit` — all 8 passed.
- Linked `atlas/.venv` to the original Atlas dependency environment; all native Python commands use `PYTHONPATH=src`.
- From `pathEarlyExit/atlas`: `PYTHONPATH=src .venv/bin/python -m pytest tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py -q` — initially 53 passed and 8 expected snapshot mismatches; after reviewed navigation-only regeneration, 61 passed.
- Regeneration command: candidate Python script compared every old/new navigation response, asserted changed responses were found paths with unchanged `path`/`pathEdges`, prefix-identical nodes/edges and no new boundaries; invoked existing `tests.update_coffee_snapshots.write_navigation` for each core language. No extraction/analysis/other snapshots regenerated.
- `PYTHONPATH=src .venv/bin/pyright` and `.venv/bin/ruff check .` — clean.
- `PYTHONPATH=src .venv/bin/python -m pytest -q` (300-second timeout) — 1826 tests and 667 subtests passed, 9 existing SQLite reflection warnings.
- `git -C pathEarlyExit diff --check` — clean; reviewed production/test diff and semantic snapshot changes.

## pollProcessContract

`PollAndProcess` now polls through its receiver, fills the existing ID slice by index (preserving order/duplicates), and retains processor failure independently of acknowledgement failure. `errors.Join` is used only for dual failure; existing client error chains and empty-poll sleep survive unchanged. Added native transport-backed tests for request payloads, exact acknowledgement, failure paths and `errors.Is`/`errors.As`.

Commands/outcomes:
- `gofmt -w pollProcessContract/commons/sintropy/messages.go pollProcessContract/commons/sintropy/messages_test.go` — complete.
- `python /tmp/codingSessionV2/research/finalOracles/pollProcessContract.py /tmp/codingSessionV2/runs/codingFrozen/pollProcessContract` — all 6 scenarios passed.
- From `pollProcessContract/commons`: `go test -vet=off ./sintropy` and `go test -race -vet=off ./sintropy` — all 8 native tests/subtests passed in each run. Vet disabled as requested for existing unrelated blockers.
- `git diff --check` — clean; reviewed production diff and complete new test file.

## preScriptIsolation

Kept the existing TypeScript mutex and import-cache behavior. Awaiting `module.run()` now holds the override and lock through settlement; saved environment values retain `undefined` rather than collapsing it into an empty string. Restoration tests check both environment APIs, exact presence, serialized lifetimes, original failure identity, queue recovery, synchronous results and import failure. Shell production code is untouched.

Commands/outcomes:
- `python /tmp/codingSessionV2/research/finalOracles/preScriptIsolation.py /tmp/codingSessionV2/runs/codingFrozen/preScriptIsolation` — 6 passed, including shell behavior.
- Initial `bun test src/worker/preScript.test.ts src/worker/scheduledJobs/preScript.test.ts src/worker/bus/preScript.test.ts` timed out at 120 seconds. Direct new-test reruns (30/15-second tool limits, plus `--timeout 1000` and an isolated `-t 'asynchronous rejection' --timeout 2000` run) identified a test-only gate deadlock: Bun's rejection matcher waited before the test released its gate. Changed the test to capture rejection first and assert after releasing the gate; production implementation was unchanged.
- From `preScriptIsolation`: direct installed `bun test src/worker/preScript.test.ts src/worker/scheduledJobs/preScript.test.ts src/worker/bus/preScript.test.ts` — 5 direct regression tests passed; 2 existing caller suites blocked at module loading by missing `drizzle-orm`.
- Direct installed `bun test src/worker/preScript.test.ts` after formatting — 5 passed, 52 assertions.
- `bun run typecheck` — blocked: candidate lacks Bun type definitions.
- `bun run lint` — blocked: candidate lacks `@eslint/js`.
- Installed Prettier: `prettier --no-config --single-quote --no-semi --trailing-comma all --write src/worker/preScript.ts src/worker/preScript.test.ts` — applied candidate formatting options without unavailable Astro/Tailwind plugins.
- `git diff --check` — clean; reviewed production diff and complete new test file.

## Additional repository checks and final verification

For both Atlas cases, ran the local instructions' dashboard commands from each `dashboard`: `bun run build`, `bun test`, `bun run typecheck`, `bun lint --fix`. These were dependency-blocked: missing Vite, test dependencies, `tsc` and `eslint`, respectively. Repeated them individually to verify exit status after the combined report output was truncated. No dashboard changes resulted.

For both Atlas cases, from each repository root ran `PYTHONPATH=atlas/src atlas/.venv/bin/python -m atlas report --f .` — completed successfully against the entire candidate, without saving. No report-driven changes or metric tuning performed.

A focused scheduler type check passed using installed compiler/types without changing candidate dependencies:

```sh
cd scheduleTimeZones
/home/leon/workspace/projects/matato-pi/node_modules/.bin/tsc --noEmit --strict --skipLibCheck --module esnext --moduleResolution bundler --target es2022 --allowImportingTsExtensions --types bun,node --typeRoots /home/leon/workspace/projects/matato-pi/node_modules/@types src/automation.ts worker/scheduler.ts worker/scheduler.test.ts src/automationConfig.test.ts worker/watcher.test.ts
```

Final rerun executed all six exact `python <oraclePath> <candidateRepoPath>` commands above in listed order, with `scheduleFactoryContract.py` immediately after the scheduler oracle — all passed after final formatting. Final `git status --short` and `git diff --check` across all six repositories confirmed production edits are limited to allowed files, with focused tests/snapshots only beyond them. All diffs left in place; no commits, pushes, README/config/persistence changes, or edits to external oracles, profiles, briefs or originals.
