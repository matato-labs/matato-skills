import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/tmp/codingSessionV4')
output = root / 'reviews/tuningOne'
report = {}
profiles = {}
settingsPaths = []
casePrompts = {}
pins = json.loads((root / 'profilePins.json').read_text())
for arm in ['v3', 'v2', 'ponytail', 'candidateOne']:
    for case in ['pythonConfinedIgnoreFiles', 'preScriptEnvironmentLifetime']:
        trial = root / 'runs/tuningOne' / arm / case
        profile = (trial / 'currentProfile.md').read_bytes()
        profiles[arm] = profile
        pin = pins['reuseAblation' if arm == 'candidateOne' else arm]
        assert len(profile) == pin['bytes']
        assert hashlib.sha256(profile).hexdigest() == pin['sha256']
        invocation = json.loads((trial / 'invocation.json').read_text())
        agent = json.loads((trial / 'agent.json').read_text())
        raw = Path(agent['stdout'])
        events = [json.loads(line) for line in raw.read_bytes().splitlines()]
        starts = [event for event in events if event['type'] == 'tool_execution_start']
        first = starts[0]
        result = next(event for event in events if event['type'] == 'tool_execution_end' and event['toolCallId'] == first['toolCallId'])
        observed = '\n'.join(block.get('text', '') for block in result['result']['content'])
        messages = [event['message'] for event in events if event['type'] == 'message_end' and event['message']['role'] == 'assistant']
        settings = sorted(set((message.get('provider'), message.get('model'), message.get('thinkingLevel', message.get('providerThinkingLevel'))) for message in messages))
        localInstructions = [event['args']['path'] for event in starts if event['toolName'] == 'read' and Path(event['args'].get('path', '')).name in ['AGENTS.md', 'CLAUDE.md']]
        promptHash = hashlib.sha256((trial / 'prompt.txt').read_bytes()).hexdigest()
        casePrompts.setdefault(case, []).append(promptHash)
        settingsPaths.append(invocation['environment']['PI_CODING_AGENT_DIR'])
        statuses = {name: json.loads((trial / f'{name}.json').read_text())['exit'] for name in ['agent', 'acceptance', 'native']}
        record = {'firstTool': first['toolName'], 'firstPath': first['args'].get('path'), 'completeProfileObserved': profile.decode().strip() in observed, 'profileReadError': result.get('isError', False), 'settings': settings, 'settled': any(event['type'] == 'agent_settled' and not event.get('aborted', False) for event in events), 'finalStopReason': messages[-1].get('stopReason'), 'localInstructionReads': localInstructions, 'rawSha256Matches': hashlib.sha256(raw.read_bytes()).hexdigest() == json.loads((trial / 'profileAudit.json').read_text())['rawStreamSha256'], 'privateConfigurationPath': invocation['environment']['PI_CODING_AGENT_DIR'], 'isolationFlagsPresent': all(flag in invocation['argv'] for flag in ['--unshare-all', '--no-session', '--no-context-files', '--no-skills', '--no-mcp', '--no-extensions']), 'profileBytes': len(profile), 'profileSha256': hashlib.sha256(profile).hexdigest(), 'promptSha256': promptHash, 'recordedStageExits': statuses, 'agentSeconds': agent['seconds'], 'agentTimeout': agent['timedOut'], 'agentBudget': agent['timeoutSeconds']}
        assert first['toolName'] == 'read' and first['args']['path'] == '/tmp/codingSessionV4/currentProfile.md'
        assert record['completeProfileObserved'] and not record['profileReadError'] and record['rawSha256Matches'] and record['isolationFlagsPresent']
        assert record['settled'] and record['finalStopReason'] == 'stop'
        assert settings == [('openai-codex', 'gpt-6.1-sol', 'high')]
        assert agent['timeoutSeconds'] == 900 and not agent['timedOut'] and all(value == 0 for value in statuses.values())
        report[f'{arm}/{case}'] = record
assert len(set(settingsPaths)) == 8
assert all(len(set(values)) == 1 for values in casePrompts.values())
sentence = b'Share reusable results at their common lifetime. '
assert profiles['v3'].replace(sentence, b'') == profiles['candidateOne']
report['controls'] = {'distinctConfigurations': 8, 'sameCasePromptHashesMatch': True, 'candidateIsExactlySentenceRemoval': True, 'candidateBytes': len(profiles['candidateOne']), 'hiddenResponseModelIdentity': 'not exposed; requested and reported identity only'}
(output / 'independentAudit.json').write_text(json.dumps(report, indent=2) + '\n')
print('Eight raw streams, matched settings/prompts, pins, and exact candidate sentence removal independently verified.')
