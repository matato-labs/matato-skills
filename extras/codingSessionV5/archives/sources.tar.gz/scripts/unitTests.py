"""Model-free regression tests. All temporary files stay in the permitted scratch root."""
import ast
import fcntl
import json
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
from unittest.mock import patch
import zlib

from auditTrial import audit, scrub
from common import agentArgs, consume, model, owned, profileAlias, scratch
from measureTrial import capture, category, compressed, git
from runTrial import Case, runAgent
from sandboxTrial import Sandbox
from nativeTests import NativeTests


def repository(path: Path) -> str:
    path.mkdir()
    subprocess.run(['git', 'init', '-q', str(path)], check=True)
    (path / 'main.py').write_text('print(1)\n')
    subprocess.run(['git', '-C', str(path), 'add', '.'], check=True)
    subprocess.run(['git', '-C', str(path), '-c', 'user.name=Synthetic',
                    '-c', 'user.email=synthetic@invalid', '-c', 'commit.gpgsign=false',
                    '-c', 'core.hooksPath=/dev/null', 'commit', '-qm', 'Synthetic'], check=True)
    return git(path, ['rev-parse', 'HEAD']).decode().strip()


def fixtureEvents(profile: str):
    return [
        {'type': 'tool_execution_start', 'toolCallId': 'first', 'toolName': 'read',
         'args': {'path': str(profileAlias)}},
        {'type': 'tool_execution_end', 'toolCallId': 'first', 'toolName': 'read',
         'isError': False, 'result': {'content': [{'type': 'text', 'text': profile}]}},
        {'type': 'message_end', 'message': {'role': 'assistant', 'provider': 'openai-codex',
         'model': 'gpt-6.1-sol', 'thinkingLevel': 'high', 'stopReason': 'stop',
         'content': [{'type': 'text', 'text': 'Done fixtureCredentialValue'}],
         'usage': {'input': 10, 'output': 4, 'cacheRead': 2, 'cacheWrite': 0,
                   'reasoning': 1, 'totalTokens': 16,
                   'cost': {'input': 0.01, 'output': 0.02, 'cacheRead': 0.0, 'cacheWrite': 0, 'total': 0.03}}}},
        {'type': 'turn_end'}, {'type': 'agent_settled', 'aborted': False}]


class HarnessTests(unittest.TestCase):
    def setUp(self):
        owned(scratch / 'tests')
        self.temporary = tempfile.TemporaryDirectory(prefix='unit', dir=scratch / 'tests')
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def testSettingsAndPaths(self):
        args = agentArgs(Path('/tools/pi'))
        for flag in ['--no-skills', '--no-extensions', '--no-context-files', '--no-mcp', '--no-session']:
            self.assertIn(flag, args)
        self.assertEqual(args[args.index('--model') + 1], model)
        self.assertEqual(args[args.index('--thinking') + 1], 'high')
        self.assertEqual(args[args.index('--tools') + 1], 'read,bash,edit,write')
        with self.assertRaises(ValueError):
            owned(Path('/tmp/notAllowed'))
        for path in Path(__file__).parent.glob('*.py'):
            tree = ast.parse(path.read_text())
            self.assertLessEqual(len(path.read_text().splitlines()), 600, path.name)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    self.assertLessEqual(node.end_lineno - node.lineno + 1, 100, node.name)

    def testBudget(self):
        control = self.root / 'budget'
        consume('first', control)
        with self.assertRaises(RuntimeError):
            consume('first', control)
        for number in range(29):
            consume(str(number), control)
        with self.assertRaises(RuntimeError):
            consume('overflow', control)
        self.assertEqual(len(json.loads((control / 'budget.json').read_text())), 30)

    def testThreeSlots(self):
        control = self.root / 'control'
        control.mkdir()
        handles = [(control / f'slot{number}.lock').open('a') for number in range(3)]
        for handle in handles:
            fcntl.flock(handle, fcntl.LOCK_EX)
        marker = self.root / 'acquired'
        code = ('from pathlib import Path\nimport sys, common\n'
                'common.scratch = Path(sys.argv[1])\n'
                'with common.slot(): Path(sys.argv[2]).touch()\n')
        process = subprocess.Popen(['/usr/bin/python3', '-B', '-c', code, str(self.root), str(marker)],
                                   cwd=Path(__file__).parent, stdout=subprocess.DEVNULL)
        try:
            time.sleep(0.3)
            self.assertIsNone(process.poll())
            self.assertFalse(marker.exists())
            handles[0].close()
            self.assertEqual(process.wait(timeout=5), 0)
            self.assertTrue(marker.exists())
        finally:
            for handle in handles:
                handle.close()
            if process.poll() is None:
                process.kill()
                process.wait()

    def testAuditAndUsage(self):
        profile = 'Exact selected\u2028profile.\n'
        raw = self.root / 'raw'
        events = fixtureEvents(profile)
        # Updates repeat cumulative usage: only finalized assistant messages count.
        events.insert(2, {'type': 'message_update', 'usage': {'input': 999}})
        raw.write_text(''.join(json.dumps(event, ensure_ascii=False) + '\n' for event in events))
        report = audit(raw, self.root, profile.encode(), ['fixtureCredentialValue'])
        self.assertTrue(report['valid'])
        self.assertEqual(report['usage']['tokens']['input'], 10)
        self.assertEqual(report['usage']['tokens']['totalTokens'], 16)
        self.assertEqual(report['usage']['tokens']['reasoning'], 1)
        self.assertIsNone(report['usage']['tokens']['cacheWrite1h'])
        self.assertEqual(report['usage']['piReportedCostUsd']['total'], 0.03)
        self.assertIsNone(report['usage']['actualBilledCostUsd'])
        self.assertNotIn('fixtureCredentialValue', (self.root / 'finalSummary.txt').read_text())
        self.assertEqual(scrub('Bearer abcdefgh', []), '[REDACTED]')

    def testAuditRejectsCounterexamples(self):
        for number, change in enumerate(['wrongFirst', 'truncated', 'wrongModel', 'wrongThinking',
                                        'aborted', 'unsettled', 'unavailableUsage', 'malformed']):
            folder = self.root / str(number)
            folder.mkdir()
            events = fixtureEvents('profile')
            if change == 'wrongFirst':
                events[0]['args']['path'] = '/other.md'
            if change == 'truncated':
                events[1]['result']['content'][0]['text'] = 'prof'
            if change == 'wrongModel':
                events[2]['message']['model'] = 'other'
            if change == 'wrongThinking':
                del events[2]['message']['thinkingLevel']
            if change == 'aborted':
                events[-1]['aborted'] = True
            if change == 'unsettled':
                events.pop()
            if change == 'unavailableUsage':
                del events[2]['message']['usage']
            raw = folder / 'raw'
            raw.write_text(''.join(json.dumps(event) + '\n' for event in events) +
                           ('broken\n' if change == 'malformed' else ''))
            report = audit(raw, folder, b'profile', [])
            if change == 'unavailableUsage':
                self.assertIsNone(report['usage']['tokens']['input'])
            else:
                self.assertFalse(report['valid'], change)

    def testMeasurementAndPatch(self):
        repo = self.root / 'repo'
        base = repository(repo)
        originalIndex = (repo / '.git/index').read_bytes()
        (repo / 'main.py').write_text('# reason\nprint(2)\n')
        (repo / 'new.go').write_text('package main\n')
        (repo / 'main.test.ts').write_text('test("works", () => {})\n')
        (repo / 'bytes.bin').write_bytes(b'abc\0def')
        (repo / 'link').symlink_to('/unmounted/dependency')
        result = capture(repo, self.root, self.root, base, [])
        self.assertEqual(result['totals']['production']['added'], 3)
        self.assertEqual(result['totals']['production']['deleted'], 1)
        self.assertEqual(result['totals']['tests']['files'], 1)
        self.assertEqual(result['totals']['production']['afterLoc']['nonblank'], 3)
        self.assertEqual(result['totals']['production']['afterLoc']['code'], 2)
        self.assertIsNone(result['totals']['combined']['added'])
        patchBytes = (self.root / 'changes.patch').read_bytes()
        self.assertIn(b'new.go', patchBytes)
        self.assertIn(b'GIT binary patch', patchBytes)
        self.assertIn(b'/unmounted/dependency', patchBytes)
        self.assertEqual((repo / '.git/index').read_bytes(), originalIndex)
        self.assertEqual(category('tests/fixtures/a.py'), 'fixtures')
        self.assertEqual(category('lib/main.test.ts'), 'tests')
        compressor = zlib.compressobj(9, zlib.DEFLATED, -15)
        self.assertEqual(compressed(b'abc'), len(compressor.compress(b'abc') + compressor.flush()))
        self.assertEqual(compressed(b''), 0)
        replay = self.root / 'replay'
        subprocess.run(['git', 'clone', '-q', str(repo), str(replay)], check=True)
        subprocess.run(['git', '-C', str(replay), 'apply', '--binary', str(self.root / 'changes.patch')], check=True)
        self.assertEqual((replay / 'bytes.bin').read_bytes(), b'abc\0def')
        self.assertEqual((replay / 'new.go').read_text(), 'package main\n')
        (repo / 'leak.py').write_text('fixtureCredentialValue\n')
        blocked = self.root / 'blocked'
        blocked.mkdir()
        with self.assertRaises(ValueError):
            capture(repo, blocked, blocked, base, ['fixtureCredentialValue'])
        self.assertFalse((blocked / 'changes.patch').exists())
        (repo / 'leak.py').unlink()
        (repo / 'binaryLeak.bin').write_bytes(b'\0fixtureCredentialValue\0')
        with self.assertRaises(ValueError):
            capture(repo, blocked, blocked, base, ['fixtureCredentialValue'])

    def testSyntheticAgentWiring(self):
        private = self.root / ('longPrivatePath' * 8)
        private.mkdir()
        folder = self.root / 'evidence'
        folder.mkdir()
        repo = self.root / 'repo'
        base = repository(repo)
        spec = Sandbox(repo, repo, private / 'runtime', Path('/usr/bin/true'))
        spec.auth = private / 'auth.json'
        spec.auth.write_text('{"openai-codex":{"type":"api_key","key":"fixtureCredentialValue"}}')
        profile = b'Selected frozen profile.\n'
        raw, errors = private / 'raw', private / 'errors'
        raw.write_text(''.join(json.dumps(event) + '\n' for event in fixtureEvents(profile.decode())))
        errors.write_text('fixtureCredentialValue')
        fake = {'exit': 0, 'timedOut': False, 'seconds': 0.01, 'timeoutSeconds': 600,
                'stdout': str(raw), 'stderr': str(errors)}
        case = Case('synthetic', str(repo), base, 'No model task.', 'true')
        with patch('runTrial.consume') as budget, patch('runTrial.execute', return_value=fake) as launch:
            record, report, secrets = runAgent(spec, case, profile, private, folder,
                                               'syntheticNeverReserved', ['fixtureCredentialValue'])
        budget.assert_called_once_with('syntheticNeverReserved')
        self.assertEqual(launch.call_args.args[-1], 600)
        self.assertEqual(record['exit'], 0)
        self.assertTrue(report['valid'])
        self.assertEqual((folder / 'profile.md').read_bytes(), profile)
        self.assertNotIn('fixtureCredentialValue', (folder / 'agent.stderr').read_text())
        self.assertFalse((folder / 'agent.stdout').exists())
        self.assertEqual(json.loads((folder / 'invocation.json').read_text())['settings']['transport'], 'sse')

    def testExactBytesAndDeletion(self):
        repo = self.root / 'repo'
        base = repository(repo)
        (repo / 'main.py').unlink()
        (repo / 'noEof.py').write_bytes(b'pass')
        result = capture(repo, self.root, self.root, base, [])
        self.assertEqual(result['totals']['production']['addedBytes'], 4)
        self.assertEqual(result['totals']['production']['deletedBytes'], len(b'print(1)\n'))
        self.assertEqual(result['totals']['production']['byteGrowth'], 4 - len(b'print(1)\n'))


if __name__ == '__main__':
    unittest.main()
