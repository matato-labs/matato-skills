# Fixed-profile replication

Only `codingFrozen.md` used as coding skill. Cases implemented independently in listed order; production edits restricted to each brief's allowedScope. No README, oracle, shared brief, original, or Git configuration edits.

## sourceBatchReads

Cached `(status, bytes)` per eligible path within `sources`; single-source verification remains uncached and span/pagination handling remains per node. Added regression coverage using the existing graph fixture for success/failure reuse and request-local lifetime.

Commands (from run root unless stated):
- `python /tmp/codingSessionV2/research/oracles/sourceBatchReads.py /tmp/codingSessionV2/runs/codingReplication/sourceBatchReads`: 5 passed.
- `ln -s /home/leon/workspace/projects/atlas/atlas/.venv sourceBatchReads/atlas/.venv`: local dependency link; all Python checks use candidate `PYTHONPATH=src`.
- In `sourceBatchReads/atlas`, `PYTHONPATH=src .venv/bin/python -m pytest tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py`: 62 passed.
- `PYTHONPATH=src .venv/bin/pyright`: clean; `.venv/bin/ruff check .`: clean.
- Full `PYTHONPATH=src .venv/bin/python -m pytest` initially timed out at 120 seconds; rerun with `-q` and longer timeout: 1827 passed, 667 subtests passed, 9 warnings.
- In `sourceBatchReads`, `PYTHONPATH=atlas/src atlas/.venv/bin/python -m atlas report --f .`: passed; `git diff --check`: clean. Full diff inspected.

Dashboard checks omitted: no dashboard changes; avoiding unrelated lint autofixes outside allowed scope.

## isinCsvRecords

Replaced physical-line scanning with the standard CSV reader. Header has no field-count constraint; data records require three fields, retain whitespace, and are read only up to the requested limit. Nonpositive limits return immediately. Added native prefix/content regression coverage without changing embedded data; malformed, quoted, multiline, and large-record cases exercised by immutable oracle.

Commands:
- `gofmt -w isinCsvRecords/commons/data/isin_loader.go isinCsvRecords/commons/data/isin_loader_test.go`: passed.
- `python /tmp/codingSessionV2/research/oracles/isinCsvRecords.py /tmp/codingSessionV2/runs/codingReplication/isinCsvRecords`: all 13 scenarios passed.
- In `isinCsvRecords/commons`, `go test ./data` and `go vet ./data`: passed.
- `git diff --check`: clean; full production diff and new test inspected.

## scheduleTimeZones

Added optional `Automation.timezone`, passed through an optional factory argument to Croner's native timezone support. Explicit enabled zones are validated before any factory call, including injected factories; existing candidate cleanup preserves atomic replacement. Disabled jobs remain unvalidated. Added native injected-factory rollback/forwarding coverage.

Commands:
- `python /tmp/codingSessionV2/research/oracles/scheduleTimeZones.py /tmp/codingSessionV2/runs/codingReplication/scheduleTimeZones`: 7 passed (DST, non-hour offsets, stored configuration, local default, reload guards).
- `python /tmp/codingSessionV2/research/finalOracles/scheduleFactoryContract.py /tmp/codingSessionV2/runs/codingReplication/scheduleTimeZones`: 8 passed.
- In `scheduleTimeZones`, `bun test worker/scheduler.test.ts src/automationConfig.test.ts`: 13 passed.
- `bun run check`: blocked, `tsc` not installed; `bun run lint`: blocked, `eslint` not installed.
- Full `bun test`: 100 passed, 3 module-load failures from unavailable `@earendil-works/pi-coding-agent` / `@earendil-works/pi-tui`; no scheduler failures.
- `git diff --check`: clean; full diff inspected.

## pathEarlyExit

Added an internal optional traversal target. The run loop handles start-equals-target without expansion; edge expansion returns as soon as the target is admitted, before later neighbors or fetch-limit bookkeeping. Context omits the target and retains full bounded traversal. Added existing-fixture regression coverage for zero-depth self routes, edge-budget admission, no further adjacency, and unchanged context traversal.

Reviewed all eight coffee snapshot changes structurally before updating: only found path responses differ; nodes/edges are ordered prefixes of the previous responses, routes/status/metadata remain identical, and only boundaries for unvisited external nodes disappear. Retained compact snapshot formatting. No source fixtures needed changing.

Commands:
- `python /tmp/codingSessionV2/research/oracles/pathEarlyExit.py /tmp/codingSessionV2/runs/codingReplication/pathEarlyExit`: 8 passed.
- Linked `pathEarlyExit/atlas/.venv` to the original Atlas dependency environment; candidate imports selected with `PYTHONPATH=src`.
- In `pathEarlyExit/atlas`, `PYTHONPATH=src .venv/bin/python -m pytest tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py -q`: initially 53 passed / 8 expected obsolete-snapshot failures; after reviewed snapshot updates, 61 passed.
- `PYTHONPATH=src .venv/bin/pyright` and `.venv/bin/ruff check .`: clean.
- `PYTHONPATH=src .venv/bin/python -m pytest -q`: 1826 passed, 667 subtests passed, 9 warnings.
- In `pathEarlyExit`, `PYTHONPATH=atlas/src atlas/.venv/bin/python -m atlas report --f .`: passed.
- `git diff --check`: clean; production/test diffs and all snapshot semantic differences inspected.

Dashboard checks omitted because unchanged; no unrelated autofixes.

## pollProcessContract

Polling now uses the configured receiver; acknowledgement IDs are assigned into the exact-sized slice, preserving order/duplicates without synthetic entries. `errors.Join` retains processor and failed-acknowledgement causes. Existing poll/dequeue error chains and empty-poll delay are unchanged. Added native custom-transport tests for success, empty poll, polling failure, processing failure, dual failure, dequeue failure, payloads, order, and error discovery.

Commands:
- `gofmt -w pollProcessContract/commons/sintropy/messages.go pollProcessContract/commons/sintropy/messages_test.go`: passed.
- `python /tmp/codingSessionV2/research/finalOracles/pollProcessContract.py /tmp/codingSessionV2/runs/codingReplication/pollProcessContract`: all 6 scenarios passed.
- In `pollProcessContract/commons`, `go test -vet=off ./sintropy -run TestPollAndProcessContract -v` and `go test -vet=off -race ./sintropy`: passed. Vet disabled as requested for unrelated existing blockers.
- `git diff --check`: clean; full production diff and new test inspected.

## preScriptIsolation

Awaited the TypeScript script's result inside the existing mutex/restoration lifetime. Saved environment values now retain `undefined`; restoration distinguishes absence from a present empty string. No shell, cache, skip, configuration, or telemetry changes. Added native asynchronous/concurrent isolation and queued recovery coverage for synchronous throw, async rejection, and import failure.

Commands:
- Bun subprocess probe confirmed `process.env === Bun.env` and consistent empty-string/deletion visibility in this runtime.
- `python /tmp/codingSessionV2/research/finalOracles/preScriptIsolation.py /tmp/codingSessionV2/runs/codingReplication/preScriptIsolation`: 6 passed, including original rejection identity and shell behavior.
- In `preScriptIsolation`, `bun test src/worker/preScript.test.ts src/worker/scheduledJobs/preScript.test.ts src/worker/bus/preScript.test.ts`: 4 direct tests passed; 2 integration files blocked at module load by unavailable `drizzle-orm`.
- `bun test src/worker/preScript.test.ts`: 4 passed, no failures.
- `bun run typecheck`: blocked by missing Bun type definitions (`TS2688`).
- `bun run lint`: blocked by unavailable `@eslint/js` in the local dependency setup.
- `git diff --check`: clean; full production diff and new test inspected.

All six required external oracles and scheduler additionalAcceptance pass. Native checks that could not run to completion are documented above; no dependency manifests changed. Diffs left uncommitted.
