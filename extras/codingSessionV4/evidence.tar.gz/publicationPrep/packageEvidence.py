"""V4 only. Default: inventory/pending; package requires independent approval."""
from __future__ import annotations

import argparse
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
import gzip
import hashlib
import io
from itertools import product
import json
import os
from pathlib import Path, PurePosixPath
import re
import tarfile
import tempfile
from typing import TypeAlias, cast

JsonValue: TypeAlias = str | int | float | bool | None | Sequence['JsonValue'] | Mapping[str, 'JsonValue']
root = Path('/tmp/codingSessionV4')
prep = Path('/home/leon/.cache/codingSessionV4Owned/publicationPrep')
boundRepo = Path('/home/leon/.t3/worktrees/matato-pi/codingSessionV4Experiment')
owned = prep.parent
phases = {'ablationOne', 'tuningOne', 'tuningTwo', 'finalOne', 'finalTwo'}
rootFiles = set('ablationExecute.py ablationPreflight.py auditTrial.py candidateOneDecision.json '
                'candidateTwoDecision.json dependencyMounts.json finalFreeze.json finalOneExecute.py '
                'finalOnePreflight.py finalTwoExecute.py finalTwoPreflight.py finishStorageRelocation.py '
                'historicalInspection.md measureTrial.py originalProjects.json plan.json profilePins.json '
                'providerProxy.py relocateFinalStorage.py reviewContract.md runnerNotes.md runTrial.py '
                'sandboxTrial.py selfCheck.py packageEvidence.py'.split())
sourceDirs = {'base', 'copies', 'copy', 'owned', 'checkout', 'checkouts', 'source', 'src', 'worktrees',
              'node_modules', '.venv', '.git', '__pycache__', 'build', 'dist', 'cache', 'caches',
              'home', 'tmp', 'stage', 'runtime', 'agent', 'private', 'config', 'credentials', 'auth',
              '.config', '.pi', '.bun', '.cache', '.npm', '.uv', '.ssh'}
secretNames = {'auth.json', 'settings.json', 'models.json', 'config.json', '.env', 'environment',
               'session.json', 'session.jsonl', 'stream.jsonl', 'raw.jsonl', 'raw.json'}
runFiles = set('changes.patch fileMetrics.json result.json prompt.txt invocation.json toolTrace.jsonl '
               'profileAudit.json finalSummary.txt currentProfile.md agent.json agent.stderr'.split())
runExecution = re.compile(r'(?:setup\d+|worktree|gitStorage|acceptance|native)\.(?:json|stdout|stderr)$')
secretPatterns = {
    'githubToken': re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{35,}|github_pat_[A-Za-z0-9_]{40,})'),
    'providerToken': re.compile(rb'sk-(?:proj-|ant-)?[A-Za-z0-9_-]{40,}'),
    'privateKey': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    'bearer': re.compile(rb'(?i)Bearer\s+[A-Za-z0-9._~+/-]{24,}'),
    'jwt': re.compile(rb'eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}'),
    'assignedSecret': re.compile(rb'(?i)["\']?(?:api_key|access_token|refresh_token|password|client_secret)'
                                 rb'["\']?\s*[:=]\s*["\'][A-Za-z0-9_+/.=-]{20,}["\']'),
}
policy = {
    'includes': 'Explicit root helpers; profiles except Ponytail; recursive phase evidence/research/reviews '
                'files without suffix filtering; exact run allowlist; safe control budget; relocation proof.',
    'excludes': 'Ponytail upstream/source/profiles; private auth/config/environment; raw sessions/streams; '
                'source/base/owned/reviewer copies; dependencies/binaries/caches/git/worktrees; historical '
                'research/python/history; original user files (originalProjects is metadata only).',
    'replay': 'NOT HERMETIC. Absolute paths remain in frozen bytes. Retrieve original repositories at pinned '
              'revisions and Ponytail/profile from retrieval pin; supply offline local dependencies and exact '
              'Pi/Bun/Python/bash/git/bwrap versions. No original repository contents or dependency binaries '
              'are distributed. Original failed preflights/tuningTwo remain separate, never repaired.',
    'safety': 'No frozen bytes or binary patches are rewritten. Pattern matches block; independent scan '
              'and review of this exact member manifest is mandatory. Inventory never opens credential files.',
    'logicalRoot': str(root),
}


@dataclass(frozen=True)
class Member:
    sha256: str
    size: int
    mode: int


@dataclass(frozen=True)
class Pin:
    record: str
    target: str
    sha256: str


def jsonRead(path: Path) -> JsonValue:
    return cast(JsonValue, json.loads(path.read_text()))


def jsonWrite(path: Path, value: JsonValue) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def fileHash(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safeName(name: str) -> bool:
    path = PurePosixPath(name)
    return bool(path.parts) and not path.is_absolute() and '..' not in path.parts and str(path) == name and '\\' not in name and '\x00' not in name


def exclusion(rel: Path) -> str:
    parts = rel.parts
    if parts[0] in {'private', 'ponytail', 'worktrees', '__pycache__'}:
        return 'private/upstream/source/cache tree'
    if 'history' in parts and parts[:2] == ('research', 'python'):
        return 'historical duplicate; original historical evidence untouched'
    if set(parts[1:-1]) & sourceDirs or rel.name in sourceDirs:
        return 'source/dependency/private/runtime tree'
    if rel.suffix.lower() in {'.pyc', '.so', '.dll', '.dylib', '.exe', '.bin', '.o', '.a', '.whl'}:
        return 'compiled dependency/build binary (binary changes.patch remains included)'
    if rel.name in secretNames or rel.name.startswith('.env'):
        return 'credential/config/environment/raw input; contents not opened'
    if rel.suffix in {'.jsonl', '.ndjson'} and rel.name != 'toolTrace.jsonl':
        return 'raw session/stream not safe toolTrace'
    if rel.name.lower() == 'ponytail.md' or (parts[0] == 'runs' and 'ponytail' in parts and rel.name == 'currentProfile.md'):
        return 'Ponytail profile; retain hashes and retrieval pin only'
    return ''


def allowedDirectory(rel: Path) -> bool:
    p = rel.parts
    if p[0] == 'research':
        return len(p) == 1 or (p[1] in {'python', 'typescript', 'additional'} and
                (len(p) == 2 or p[2] in {'tuning', 'reserve', 'logs', 'commands', 'negativeControls'}))
    if p[0] == 'evidence':
        return len(p) == 1 or (p[1] in phases | {'harnessInitial'} and (len(p) == 2 or p[2] in {
                'preflight', 'preflightTwo', 'preflightThree', 'harnessFinal', 'frozenInputs', 'frozenTuning',
                'providerProbe', 'providerProbeSetup', 'providerProbeSetupTwo', 'providerProbeSetupFailure'}))
    if p[0] == 'reviews':
        return len(p) == 1 or (p[1] in phases and (len(p) == 2 or p[2] in {
                'logs', 'diagnosticLogs', 'commands', 'checks', 'probes', 'tooling'} or
                (p[1] == 'finalTwo' and p[2] == 'records')))
    if p[0] == 'runs':
        return len(p) <= 4 and (len(p) == 1 or p[1] in phases)
    if p[0] == 'profiles':
        return len(p) == 1
    return False


def inventory() -> tuple[dict[str, Path], list[dict[str, str]], list[str]]:
    files: dict[str, Path] = {}
    excluded: list[dict[str, str]] = []
    blocked: list[str] = []
    links = {'control': owned / 'control'}
    for area in ('runs', 'evidence', 'reviews'):
        for phase in ('finalOne', 'finalTwo'):
            links[f'{area}/{phase}'] = owned / area / phase
    def visit(folder: Path) -> None:
        for path in sorted(folder.iterdir()):
            rel = path.relative_to(root)
            name = rel.as_posix()
            reason = exclusion(rel)
            if reason:
                excluded.append({'path': name, 'reason': reason})
                continue
            if path.is_symlink() and (name not in links or path.resolve() != links[name]):
                blocked.append(name + ': unapproved symlink')
                continue
            if path.is_dir():
                if allowedDirectory(rel):
                    visit(path)
                elif name not in {'control', 'selfChecks'}:
                    blocked.append(name + ': unclassified directory')
                else:
                    excluded.append({'path': name, 'reason': 'handled safe subset separately'})
                continue
            if not path.is_file():
                blocked.append(name + ': not a regular file')
                continue
            if len(rel.parts) == 1 and name not in rootFiles:
                blocked.append(name + ': unclassified root file')
                continue
            if rel.parts[0] == 'runs' and (len(rel.parts) != 5 or not
                    (rel.name in runFiles or runExecution.fullmatch(rel.name))):
                blocked.append(name + ': unclassified run file')
                continue
            files[name] = path
    visit(root)
    budget = root / 'control/budget.json'
    if budget.is_file() and not budget.is_symlink():
        files['control/budget.json'] = budget
    for folder in sorted((root / 'selfChecks').iterdir()):
        for name in ('result.json', 'profile.md', 'trace/finalSummary.txt', 'trace/profileAudit.json',
                     'trace/toolTrace.jsonl', 'measurement/changes.patch', 'measurement/fileMetrics.json', 'oracle/manifest.json'):
            path = folder / name
            if path.is_file() and not path.is_symlink():
                files[path.relative_to(root).as_posix()] = path
    for path in sorted((owned / 'relocationEvidence').rglob('*')):
        rel = Path('relocationEvidence') / path.relative_to(owned / 'relocationEvidence')
        reason = exclusion(rel)
        if reason or path.is_symlink():
            excluded.append({'path': str(rel), 'reason': reason or 'symlink'})
            continue
        if path.is_file():
            files[rel.as_posix()] = path
    files['publicationPrep/packageEvidence.py'] = Path(__file__).resolve()
    return files, excluded, blocked


def membersFor(files: dict[str, Path]) -> dict[str, Member]:
    return {name: Member(fileHash(path), path.stat().st_size, 0o755 if path.stat().st_mode & 0o111 else 0o644)
            for name, path in sorted(files.items())}


def pinPairs(value: JsonValue) -> list[tuple[str, str]]:
    if not isinstance(value, dict):
        raise ValueError('Pin JSON must be an object')
    artifacts = value.get('artifacts', value)
    if not isinstance(artifacts, dict):
        raise ValueError('Pin artifacts must be an object')
    pairs: list[tuple[str, str]] = []
    for name, entry in artifacts.items():
        digest = entry.get('sha256') if isinstance(entry, dict) else entry
        if isinstance(digest, str) and re.fullmatch('[a-f0-9]{64}', digest):
            pairs.append((name, digest))
    return pairs


def checksumPairs(text: str) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    for line in text.splitlines():
        match = re.fullmatch(r'([a-f0-9]{64})\s+\*?(.+)', line)
        if not match:
            raise ValueError('unparsed checksum line')
        pairs.append((match[2], match[1]))
    return pairs


def readPins(files: dict[str, Path]) -> tuple[list[Pin], list[str]]:
    pins: list[Pin] = []
    errors: list[str] = []
    for name, path in sorted(files.items()):
        base = path.name.lower()
        isFreeze = name.startswith('research/') and base.startswith('freeze')
        isLauncher = name.startswith('evidence/') and base.startswith('launcher')
        if not (isFreeze or isLauncher):
            continue
        try:
            text = path.read_text()
            if text.lstrip().startswith('{'):
                pairs = pinPairs(jsonRead(path))
            else:
                pairs = checksumPairs(text)
            if not pairs:
                raise ValueError('no artifact pins parsed')
            pins.extend(Pin(name, target, digest) for target, digest in pairs)
        except (ValueError, UnicodeError) as error:
            errors.append(name + ': ' + str(error))
    return pins, errors


def auditPins(files: dict[str, Path], members: dict[str, Member]) -> dict[str, JsonValue]:
    pins, errors = readPins(files)
    records: list[dict[str, str]] = []
    for pin in pins:
        target = Path(pin.target)
        path = target if target.is_absolute() else root / Path(pin.record).parent / target
        logical = Path(os.path.normpath(path))
        name = logical.relative_to(root).as_posix() if logical.is_relative_to(root) else str(logical)
        reason = exclusion(Path(name)) if logical.is_relative_to(root) else 'external installed launcher/dependency; not distributed'
        if not logical.is_relative_to(root) and not (logical.name in {
                'pi', 'bun', 'bwrap', 'bash', 'python3.14', 'git', 'python3.11'} and (
                name.startswith('/usr/bin/') or name.startswith('/home/leon/.local/share/mise/installs/') or
                name.startswith('/home/leon/.local/share/uv/'))):
            errors.append(pin.record + ': unapproved external target ' + name)
            continue
        if reason:
            # Never open private/config targets, even if a malformed pin requests it.
            prohibited = logical.is_relative_to(root) and ('private' in logical.parts or logical.name in secretNames)
            status = 'notReadSensitive' if prohibited else 'excludedVerified' if logical.is_file() and fileHash(logical) == pin.sha256 else 'excludedMissingOrMismatch'
            records.append({**asdict(pin), 'status': status, 'reason': reason})
            if status != 'excludedVerified':
                errors.append(pin.record + ': ' + status + ' ' + name)
            continue
        if name not in members or members[name].sha256 != pin.sha256:
            errors.append(pin.record + ': missing/mismatched frozen artifact ' + name)
        records.append({**asdict(pin), 'status': 'includedVerified' if name in members and members[name].sha256 == pin.sha256 else 'BLOCKED'})
    return {'pins': records, 'errors': errors, 'pinFiles': sorted({pin.record for pin in pins})}


def scan(files: dict[str, Path]) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    # Report only member names and pattern labels, never matching text.
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        for label, pattern in secretPatterns.items():
            if pattern.search(data):
                findings.append({'path': name, 'pattern': label})
    return findings


def writeArchive(files: dict[str, Path], members: dict[str, Member], destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for name in ('evidence.tar.gz', 'evidenceMembers.json', 'evidence.sha256'):
        if (destination / name).exists():
            raise ValueError('Refusing overwrite: ' + name)
    jsonWrite(destination / 'evidenceMembers.json', {name: asdict(value) for name, value in members.items()})
    with ((destination / 'evidence.tar.gz').open('xb') as raw,
          gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed,
          tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as archive):
        for name, path in sorted(files.items()):
            data = path.read_bytes()
            record = members[name]
            if hashlib.sha256(data).hexdigest() != record.sha256 or len(data) != record.size:
                raise ValueError('Evidence changed during packaging: ' + name)
            member = tarfile.TarInfo(name)
            member.size, member.mode, member.mtime = record.size, record.mode, 0
            member.uid = member.gid = 0
            member.uname = member.gname = ''
            archive.addfile(member, io.BytesIO(data))
    (destination / 'evidence.sha256').write_text(''.join(fileHash(destination / name) + '  ' + name + '\n'
                                                       for name in ('evidence.tar.gz', 'evidenceMembers.json')))
    verifyArchive(destination)


def verifyArchive(destination: Path) -> None:
    checks = (destination / 'evidence.sha256').read_text().splitlines()
    expectedChecks = {fileHash(destination / name) + '  ' + name for name in ('evidence.tar.gz', 'evidenceMembers.json')}
    if len(checks) != 2 or set(checks) != expectedChecks:
        raise ValueError('External checksum mismatch')
    expected = cast(dict[str, dict[str, str | int]], jsonRead(destination / 'evidenceMembers.json'))
    seen: set[str] = set()
    with tarfile.open(destination / 'evidence.tar.gz', 'r:gz') as archive:
        for member in archive:
            if not safeName(member.name) or member.name in seen or member.name not in expected or member.type != tarfile.REGTYPE or member.linkname:
                raise ValueError('Unsafe/extra/duplicate/nonregular archive member')
            seen.add(member.name)
            record = expected[member.name]
            stream = archive.extractfile(member)
            if stream is None:
                raise ValueError('Missing member content')
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            if digest != record['sha256'] or member.size != record['size'] or member.mode != record['mode']:
                raise ValueError('Member content/size/mode mismatch: ' + member.name)
            if member.uid or member.gid or member.mtime or member.uname or member.gname or member.pax_headers:
                raise ValueError('Nondeterministic member metadata')
    if seen != set(expected):
        raise ValueError('Missing archive members')


def auditRuns(files: dict[str, Path]) -> dict[str, JsonValue]:
    tuningCases = {'pythonConfinedIgnoreFiles', 'preScriptEnvironmentLifetime'}
    finalCases = tuningCases | {'sequenceCreateRecovery', 'shellBootstrapLocation'}
    missing: dict[str, list[str]] = {}
    failedMissing: dict[str, list[str]] = {}
    identities: set[str] = set()
    for phase in sorted(phases):
        arms = {'v3', 'reuseAblation'} if phase == 'ablationOne' else {
                'v3', 'v2', 'ponytail', 'candidateOne' if phase == 'tuningOne' else 'candidateTwo'}
        for arm, case in product(sorted(arms), sorted(finalCases if phase.startswith('final') else tuningCases)):
            identity = f'runs/{phase}/{arm}/{case}'
            identities.add(identity)
            required = runFiles - ({'currentProfile.md'} if arm == 'ponytail' else set())
            absent = sorted(name for name in required if identity + '/' + name not in files)
            if absent:
                (failedMissing if phase == 'tuningTwo' else missing)[identity] = absent
    actual = {'/'.join(name.split('/')[:4]) for name in files if name.startswith('runs/')}
    return {'completeForPackaging': not missing and not (actual - identities), 'missingRequired': missing,
            'unexpectedIdentities': sorted(actual - identities), 'originalFailedTuningTwoMissing': failedMissing,
            'preservedPartialPatches': sorted(n for n in files if n.startswith('reviews/tuningTwo/') and n.endswith('.partial.patch')),
            'note': 'Failed tuningTwo gaps are original failures, NOT fabricated empty patches or successful runs.'}


def prepare() -> tuple[dict[str, Path], dict[str, Member], list[str]]:
    prep.mkdir(parents=True, exist_ok=True)
    files, excluded, blocked = inventory()
    members = membersFor(files)
    ponytailPin = cast(dict[str, dict[str, str | int]], jsonRead(root / 'profilePins.json'))['ponytail']
    ponytailHash = ponytailPin['sha256']
    blocked.extend(name + ': excluded Ponytail profile bytes under another name'
                   for name, member in members.items() if member.sha256 == ponytailHash)
    audit = auditPins(files, members)
    blocked.extend(cast(list[str], audit['errors']))
    jsonWrite(prep / 'frozenLauncherAudit.json', audit)
    jsonWrite(prep / 'publicationPolicy.json', policy)
    jsonWrite(prep / 'runInventoryAudit.json', auditRuns(files))
    jsonWrite(prep / 'auditInventory.json', {'included': sorted(files), 'excluded': excluded, 'blocked': blocked,
                                          'uncompressedBytes': sum(m.size for m in members.values()),
                                          'note': 'Directory exclusions are subtree records; no excluded contents read.'})
    for name in ('frozenLauncherAudit.json', 'publicationPolicy.json', 'auditInventory.json',
                 'runInventoryAudit.json', 'selfCheckResult.json'):
        if (prep / name).is_file():
            files['publicationPrep/' + name] = prep / name
    members = membersFor(files)
    jsonWrite(prep / 'candidateMembers.json', {name: asdict(value) for name, value in members.items()})
    jsonWrite(prep / 'publicationPending.json', {'publicationReady': False, 'archiveCreated': False,
              'candidateMembersSha256': fileHash(prep / 'candidateMembers.json'), 'blocked': blocked,
              'members': len(members), 'uncompressedBytes': sum(m.size for m in members.values()),
              'requires': 'FinalTwo and both reviews complete, rerun inventory, independent secret scan '
                          'of exact candidateMembers.json and external approval before package.',
              'selfCheck': jsonRead(prep / 'selfCheckResult.json') if (prep / 'selfCheckResult.json').exists() else None})
    return files, members, blocked


def selfCheck() -> None:
    folder = Path(tempfile.mkdtemp(prefix='publicationSelfCheck', dir=prep))
    sources = folder / 'sources'
    sources.mkdir()
    data = {'research/typescript/tuning/native': b'#!/bin/sh\nexit 0\n',
            'runs/finalTwo/v3/case/changes.patch': b'GIT binary patch\n\x00\xff\r\n',
            'runs/finalOne/v3/case/result.json': b'{"retained":true}\n'}
    files: dict[str, Path] = {}
    for index, (name, content) in enumerate(data.items()):
        path = sources / str(index)
        path.write_bytes(content)
        if index == 0:
            path.chmod(0o755)
        files[name] = path
    records = membersFor(files)
    for name in ('first', 'second'):
        writeArchive(files, records, folder / name)
    assert fileHash(folder / 'first/evidence.tar.gz') == fileHash(folder / 'second/evidence.tar.gz')
    assert not safeName('../escape') and not safeName('/absolute')
    failures: list[str] = []
    for defect in ('duplicate', 'missing', 'extra', 'traversal', 'symlink', 'content', 'mode'):
        target = folder / defect
        target.mkdir()
        jsonWrite(target / 'evidenceMembers.json', {n: asdict(m) for n, m in records.items()})
        brokenArchive(target, defect, data, records)
        (target / 'evidence.sha256').write_text(''.join(fileHash(target / n) + '  ' + n + '\n'
                                                      for n in ('evidence.tar.gz', 'evidenceMembers.json')))
        try:
            verifyArchive(target)
            failures.append(defect)
        except ValueError:
            pass
    if failures:
        raise ValueError('Self-check accepted defects: ' + ', '.join(failures))
    pinCheck(files, records, sources)
    jsonWrite(prep / 'selfCheckResult.json', {'passed': True, 'syntheticOnly': True, 'directory': str(folder),
              'scriptSha256': fileHash(Path(__file__)), 'extensionlessPinsAndExclusions': True,
              'deterministic': True, 'binaryBytesPreserved': True, 'rejected': ['duplicate', 'missing', 'extra',
              'traversal', 'symlink', 'content', 'mode']})


def brokenArchive(target: Path, defect: str, data: dict[str, bytes], records: dict[str, Member]) -> None:
    names = list(data)
    if defect == 'missing':
        names.pop()
    if defect == 'duplicate':
        names.append(names[0])
    if defect in {'extra', 'traversal'}:
        names.append('../escape' if defect == 'traversal' else 'extra')
    with tarfile.open(target / 'evidence.tar.gz', 'w:gz') as archive:
        for name in names:
            content = data.get(name, b'extra')
            member = tarfile.TarInfo(name)
            mode = records[name].mode if name in records else 0o644
            member.size, member.mode = len(content), 0o600 if defect == 'mode' else mode
            if defect == 'symlink' and name == names[0]:
                member.type, member.linkname = tarfile.SYMTYPE, '/outside'
                member.size = 0
            archive.addfile(member, io.BytesIO(b'x' * len(content) if defect == 'content' else content))


def pinCheck(files: dict[str, Path], members: dict[str, Member], sources: Path) -> None:
    native = 'research/typescript/tuning/native'
    freeze = sources / 'freezePins'
    freeze.write_text(members[native].sha256 + '  native\n')
    launcher = sources / 'launcherPins'
    jsonWrite(launcher, {'../../' + native: members[native].sha256})
    pinFiles = {**files, 'research/typescript/tuning/freezePins': freeze,
                'evidence/ablationOne/launcherPins': launcher}
    assert auditPins(pinFiles, members)['errors'] == []
    assert auditPins(pinFiles, {n: m for n, m in members.items() if n != native})['errors']
    wrong = {**members, native: Member('0' * 64, members[native].size, members[native].mode)}
    assert auditPins(pinFiles, wrong)['errors']
    for name in ('ponytail/source.ts', 'profiles/ponytail.md', 'runs/finalOne/ponytail/case/currentProfile.md',
                 'reviews/finalOne/runtime/secret', 'evidence/ablationOne/preflight/owned/source.py',
                 'private/auth.json', 'runs/finalTwo/v3/case/raw.jsonl', 'research/python/history/review.md'):
        assert exclusion(Path(name)), name
    assert not exclusion(Path('reviews/finalTwo/logs/ponytail/case/native.stdout'))
    assert not exclusion(Path('runs/finalTwo/ponytail/case/changes.patch'))
    suspect = sources / 'syntheticSecret'
    suspect.write_bytes(b'ghp_' + b'A' * 36)
    assert scan({'syntheticSecret': suspect}) == [{'path': 'syntheticSecret', 'pattern': 'githubToken'}]


def package(approval: Path) -> None:
    files, members, blocked = prepare()
    findings = scan(files)
    jsonWrite(prep / 'secretScan.json', {'findings': findings, 'independentScanStillRequired': True})
    if blocked or findings:
        raise ValueError('Blocked; see auditInventory.json and secretScan.json (no artifacts altered)')
    if auditRuns(files)['completeForPackaging'] is not True:
        raise ValueError('Incomplete run inventory; see runInventoryAudit.json')
    checked = cast(dict[str, JsonValue], jsonRead(prep / 'selfCheckResult.json'))
    if checked.get('passed') is not True or checked.get('scriptSha256') != fileHash(Path(__file__)):
        raise ValueError('Run selfCheck for this exact script before packaging')
    consent = cast(dict[str, JsonValue], jsonRead(approval))
    if consent.get('candidateMembersSha256') != fileHash(prep / 'candidateMembers.json') or not all(
            consent.get(key) is True for key in ('approved', 'independentSecretScanPassed', 'finalResultsReviewed')):
        raise ValueError('Independent approval must bind exact candidate manifest and final reviews')
    if not consent.get('reviewer') or not consent.get('scanner'):
        raise ValueError('Independent reviewer/scanner identities required')
    for phase in ('finalOne', 'finalTwo'):
        for name in (f'reviews/{phase}/review.md', f'reviews/{phase}/metrics.json', f'evidence/{phase}/executionSummary.json'):
            if name not in members:
                raise ValueError('Final evidence incomplete: ' + name)
    if membersFor(files) != members:
        raise ValueError('Evidence changed after inventory/scan')
    writeArchive(files, members, boundRepo / 'extras/codingSessionV4')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('inventory', 'selfCheck', 'package', 'verify'), nargs='?', default='inventory')
    parser.add_argument('--approval', type=Path)
    args = parser.parse_args()
    if args.mode == 'selfCheck':
        prep.mkdir(parents=True, exist_ok=True)
        selfCheck()
        return
    if args.mode == 'verify':
        verifyArchive(boundRepo / 'extras/codingSessionV4')
        return
    if args.mode == 'package':
        if args.approval is None:
            parser.error('--approval is required for package')
        package(args.approval)
        return
    prepare()


if __name__ == '__main__':
    main()
