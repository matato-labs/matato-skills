import concurrent.futures
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

root = Path('/tmp/codingSessionV4')
out = root / 'reviews/ablationOne'
private = root / 'private/ablationReview'
private.mkdir()
(out / 'logs').mkdir()
specification = importlib.util.spec_from_file_location('reviewSandbox', root / 'sandboxTrial.py')
helper = importlib.util.module_from_spec(specification)
specification.loader.exec_module(helper)
python = '/home/leon/workspace/projects/atlas/atlas/.venv/bin/python'
cases = [json.loads((root / path).read_text())['cases'][0] for path in ['research/python/manifest.json', 'research/typescript/tuning/manifest.json']]
checksums = {}
metrics = {}
audit = {}
jobs = []


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def archive(case: dict, target: Path) -> None:
    target.mkdir(parents=True)
    data = subprocess.check_output(['git', '-C', case['repo'], 'archive', case['base']])
    with tarfile.open(fileobj=io.BytesIO(data)) as packed:
        packed.extractall(target, filter='data')
    if case['id'] == 'preScriptEnvironmentLifetime':
        (target / 'node_modules').symlink_to(Path(case['repo']) / 'node_modules')


def runJob(case: dict, arm: str, target: Path, label: str, command: str, timeout: int) -> dict:
    runtime = private / 'runtime' / arm / case['id'] / label
    oracle = root / ('research/python' if case['id'] == 'pythonConfinedIgnoreFiles' else 'research/typescript/tuning')
    repo = Path(case['repo'])
    dependencies = [Path('/home/leon/.local/share/uv/python/cpython-3.11-linux-x86_64-gnu'), Path('/home/leon/.cache/tree-sitter-language-pack/v1.20.0/libs')] if case['id'] == 'pythonConfinedIgnoreFiles' else []
    spec = {'worktree': target, 'repo': repo, 'common': repo / '.git', 'oracle': oracle, 'runtime': runtime, 'profile': out / 'unused', 'profileSnapshot': out / 'unused', 'config': out / 'unused', 'auth': out / 'unused', 'dependencies': dependencies, 'pi': Path('/home/leon/.local/share/mise/installs/pi/1.1.0/pi/pi')}
    log = out / 'logs' / arm / case['id']
    log.mkdir(parents=True, exist_ok=True)
    result = helper.shell(spec, label, command, log, timeout)
    print(arm, case['id'], label, result['exit'], result['seconds'], flush=True)
    return {'arm': arm, 'case': case['id'], 'label': label, **result}


for case in cases:
    caseId = case['id']
    original = private / 'original' / caseId
    archive(case, original)
    originalOracle = case['checkCommand'].replace('{root}', str(original))
    jobs.append((case, 'original', original, 'frozenBehavior', originalOracle, 240))
    for arm in ['v3', 'reuseAblation']:
        trial = root / 'runs/ablationOne' / arm / caseId
        live = root / 'worktrees/ablationOne' / arm / caseId
        target = private / arm / caseId
        archive(case, target)
        patch = (trial / 'changes.patch').read_bytes()
        subprocess.run(['git', 'apply', '--unsafe-paths', '-p1', '-'], input=patch, cwd=target, check=True)
        changed = subprocess.check_output(['git', '-C', live, 'diff', '--name-only']).decode().splitlines()
        if caseId == 'preScriptEnvironmentLifetime':
            changed.append('src/worker/preScript.test.ts')
        details = []
        for name in sorted(set(changed)):
            baseFile = original / name
            newFile = target / name
            old = baseFile.read_bytes() if baseFile.exists() else b''
            new = newFile.read_bytes()
            assert new == (live / name).read_bytes(), name
            checksums[f'{arm}/{caseId}/{name}'] = digest(new)
            command = ['git', 'diff', '--no-index', '--numstat', '--', str(baseFile) if baseFile.exists() else '/dev/null', str(newFile)]
            difference = subprocess.run(command, stdout=subprocess.PIPE, check=False).stdout.decode()
            added, deleted = map(int, difference.split()[:2])
            oldLines = [line.strip() for line in old.decode().splitlines() if line.strip()]
            newLines = [line.strip() for line in new.decode().splitlines() if line.strip()]
            import difflib
            normalized = list(difflib.unified_diff(oldLines, newLines, n=0))
            diagnosticAdded = sum(line.startswith('+') and not line.startswith('+++') for line in normalized)
            diagnosticDeleted = sum(line.startswith('-') and not line.startswith('---') for line in normalized)
            details.append({'path': name, 'category': 'tests' if '/tests/' in name or '.test.' in name else 'production', 'additions': added, 'deletions': deleted, 'churn': added + deleted, 'baseBytes': len(old), 'resultBytes': len(new), 'byteGrowth': len(new) - len(old), 'baseLines': len(old.splitlines()), 'resultLines': len(new.splitlines()), 'nonblankStrippedAdditions': diagnosticAdded, 'nonblankStrippedDeletions': diagnosticDeleted})
        metrics[f'{arm}/{caseId}'] = details
        profile = (trial / 'currentProfile.md').read_bytes()
        invocation = json.loads((trial / 'invocation.json').read_text())
        agent = json.loads((trial / 'agent.json').read_text())
        audit[f'{arm}/{caseId}'] = {'profileBytes': len(profile), 'profileSha256': digest(profile), 'profileAudit': json.loads((trial / 'profileAudit.json').read_text()), 'argvTail': invocation['argv'][invocation['argv'].index('--print'):], 'agentExit': agent.get('exit'), 'agentTimeout': agent.get('timedOut'), 'agentSeconds': agent.get('seconds'), 'agentBudget': agent.get('timeoutSeconds'), 'promptSha256': digest((trial / 'prompt.txt').read_bytes()), 'base': subprocess.check_output(['git', '-C', live, 'rev-parse', 'HEAD']).decode().strip()}
        for label, key in [('frozenBehavior', 'checkCommand'), ('frozenNative', 'nativeCommand')]:
            jobs.append((case, arm, target, label, case[key].replace('{root}', str(target)), 420 if caseId == 'pythonConfinedIgnoreFiles' and label == 'frozenNative' else 240))
        negative = private / (arm + 'OriginalProduction') / caseId
        archive(case, negative)
        for item in details:
            if item['category'] == 'tests':
                (negative / item['path']).write_bytes((target / item['path']).read_bytes())
        if caseId == 'preScriptEnvironmentLifetime':
            jobs.append((case, arm, target, 'addedMaintained', 'bun test src/worker/preScript.test.ts', 180))
            jobs.append((case, arm, target, 'changedLint', 'bun node_modules/eslint/bin/eslint.js src/worker/preScript.ts src/worker/preScript.test.ts', 180))
            negativeCommand = 'bun test src/worker/preScript.test.ts'
        else:
            negativeCommand = f'cd atlas && PYTHONPATH="{negative}/atlas/src" {python} -B -m pytest -p no:cacheprovider -q tests/test_discovery.py tests/test_atlasignore.py'
        jobs.append((case, arm, negative, 'originalProductionMaintained', negativeCommand, 180))

(out / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
(out / 'audit.json').write_text(json.dumps(audit, indent=2) + '\n')
for path in [root / 'reviewContract.md', root / 'plan.json', root / 'historicalInspection.md', root / 'sandboxTrial.py', out / 'supplementPlan.json', out / 'reviewRunner.py']:
    checksums[str(path)] = digest(path.read_bytes())
for case in cases:
    folder = root / ('research/python' if case['id'] == 'pythonConfinedIgnoreFiles' else 'research/typescript/tuning')
    for path in folder.iterdir():
        if path.is_file():
            checksums[str(path)] = digest(path.read_bytes())
(out / 'checksums.json').write_text(json.dumps(checksums, indent=2) + '\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(lambda args: runJob(*args), jobs))
(out / 'commands.json').write_text(json.dumps(results, indent=2) + '\n')
