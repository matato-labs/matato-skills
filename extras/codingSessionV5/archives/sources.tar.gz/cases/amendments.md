# Resumed preparation: infrastructure amendments

This preparation authored changes only in `cases/` and owned cache evidence. No implementation fixes,
model trials, credential reads, dependency installs, source commits, live services,
or production edits were made. The held-out brief remains restricted to its own
case directory; do not pass its artifacts to development arms.

## Frozen intent

All four `brief.txt` files, manifest brief strings, acceptance files, command
specifications, fixture doubles, source-path selections, bases, source hashes and
research notes are byte-for-byte unchanged from the interrupted preparation.
The original acceptance requirements were not weakened to obtain readiness.
`initialStatus.json` remains historical, not overwritten with today's state.

The briefs' 900-second intended implementation budget is unchanged. The new
harness independently imposes a 600-second agent-process cap and 120-second
per-command cap; launchers retain their existing 100-second child cap. Preparation
proves executable controls, not that any future agent can finish in those limits.

## Exact amendments

| Files | Infrastructure-only change |
| --- | --- |
| Each `runCheck.py` | Use required harness `TMPDIR`; remove the legacy casePreparation-only restriction and fallback. Scratch is never created beside the read-only launcher. Existing nested network isolation, clean environment and child timeout remain. |
| Each `manifest.json` | Add explicit immutable `inputPaths` for launcher, command specification, acceptance and, where used, the inert fixture executable. Existing dependency mounts remain explicit. |
| TypeScript manifests | Mount the already-installed Bun 1.3.11 `bin` directory and probe that exact binary. The current host default is different; acceptance/native commands retain their originally selected 1.3.11 binary. No runtime upgraded or installed. |
| Each manifest's last setup command | Execute the existing positive-only control selection through the same launcher. This is fixture verification, not dependency setup or a production operation. Its separate `setupN` evidence must pass before acceptance. |
| Each `sourcePins.json` | Preserve all original pins; add a reference to `preparationPins.json`, which hashes final artifacts and offline dependency trees. |
| New reports/checker/catalog metadata | Record the real harness evidence, final hashes, readiness, unchanged original sources and amendments. No harness/baseline/profile code was edited by this preparation. |

## Concurrent external harness revision

After the first successful controls, the read-only scope check detected external
changes to six harness files (`common.py`, `sandboxTrial.py`, `runTrial.py`,
`unitTests.py`, `selfCheck.py`, `operations.md`) and four new native-support files
(`nativeTrial.py`, `nativeTests.py`, `nativeProbe.mjs`, `nativeTrace.ts`). None was
authored or reverted here. Their before/final hashes and attribution are retained
in `originalPins.json` and `resume/externalHarnessChanges.json`. All four originals,
unit tests, isolation self-check and captured-measurement replays were repeated
against the final observed revision; superseded logs are retained as `*First.log`
and `*Second.log`. A second external update was detected before pin creation and
triggered another full control/replay pass. The verifier pins that observed revision, not a false claim that other V5 files
stayed unchanged. Native model execution was not used.

Report-generation guards stopped before writing pins on a relative-path
normalization error and on the correctly detected concurrent harness updates.
The new verifier's output matching was also corrected to allow Bun's intervening
filtered-test line and pytest's appended duration. Only preparation reporting
utilities were adjusted; no acceptance or source changes resulted. Failed freeze
and verification logs are retained in preparation scratch.

Input paths list individual oracle files rather than case directories: evidence
reports, source pins and later metadata updates cannot be accidentally treated as
acceptance inputs. The harness snapshots these files once and mounts the snapshots
read-only. Dependencies are read-only mounts, separately hashed, not installed or
bundled. Their fingerprints include resolved roots, file bytes, symlink targets
and modes; they are local replay prerequisites, not portable package locks.

```mermaid
flowchart LR
  A["Frozen case inputs"] --> B["runTrial.py originals"]
  B --> C["Independent base clone and positive controls"]
  C --> D["Assertion-level acceptance failure"]
  C --> E["Passing unchanged native checks"]
  D --> F["Integrity and source-hash verification"]
  E --> F
```

## Superseded evidence

The retained `casePreparation/manifestPreflight*` runs used a copied legacy V4
sandbox, not the now-present V5 harness. The first run stopped at setup0; the
canonical run had missing interpreter-path mounts for two cases. The final legacy
run timed out in the navigation native check after 100 seconds. None is counted
as final V5 readiness evidence. Earlier test-authoring probe amendments are already
described in the unchanged per-case research notes; this resume made none.

The full navigation native selection now passes under the real V5 harness,
including all eight coffee language snapshots. No tests were removed, timeout
raised, snapshots regenerated, or production code patched. The old timeout's root
cause was not established. Successful real-harness evidence supersedes it; it does
not prove that runtime variance is impossible.

The audit of 377 existing log/control artifacts, their hashes, infrastructure
signals, the pre-resume case snapshot and full original-source snapshot are kept
under `/home/leon/.cache/codingSessionV5/casePreparation/resume/`. Legacy logs are
retained, not rewritten or relabeled as passing controls.

## Verification and limits

`controlReport.json` in each case points to its real `originals` evidence and
captured-measurement replay. The aggregate `controlReport.json` lists development
readiness without disclosing held-out content. `originalPins.json` fingerprints
all tracked working files, HEAD, index, status and tracked diff of the five
original repositories, plus the final non-case V5 inventory and observed external
changes from the pre-resume inventory.

Run the standard-library, read-only check from any directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /home/leon/workspace/projects/matato-pi/extras/codingSessionV5/cases/verifyPreparation.py
```

It verifies source/base/artifact/dependency pins, immutable-input inventory,
manifest identity, evidence integrity, assertion markers, passing controls/native
checks, clean source in independent clones, unchanged originals and matching
final external-revision pins for other V5 files.
The harness's own model-free unit tests, isolation self-check and `check` command
were also run; exact evidence paths are in the aggregate report. Synthetic auth
values in harness tests are not owner credentials. No real auth was accessed.

No candidate implementation was produced, so passing a fixed implementation and
future task solvability remain untested. Atlas mutation tooling is unavailable in
the installed CLI (see the recorded help probe); no mutants or mutation score are
claimed. No model-run budget was consumed.
