#!/usr/bin/env python3
"""Exercise the real pre-script API with local runtime input modules and barriers."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

repo = Path(sys.argv[1]).resolve()
source = r'''
import { test, expect } from 'bun:test';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { runPreScript, getPreScriptSkipReason } from __module__;
const key = 'FINAL_HOLDOUT_SCRIPT_ENV';
const emptyKey = 'FINAL_HOLDOUT_EMPTY_ENV';
const absentKey = 'FINAL_HOLDOUT_ABSENT_ENV';
function deferred() { let resolve!: () => void; const promise = new Promise<void>(r => resolve = r); return { promise, resolve }; }
async function sandbox(body: (folder: string) => Promise<void>) {
 const names = [key, emptyKey, absentKey];
 const previous = names.map(name => process.env[name]);
 const folder = await mkdtemp(join(tmpdir(), 'finalPreScript-'));
 try { process.env[key] = 'parent'; process.env[emptyKey] = ''; delete process.env[absentKey]; await body(folder); }
 finally {
  names.forEach((name, i) => { if (previous[i] === undefined) delete process.env[name]; else process.env[name] = previous[i]; });
  delete (globalThis as any).__finalPreScriptState;
  await rm(folder, {recursive:true, force:true});
 }
}
function call(folder: string, name: string, value: string) {
 return runPreScript({scriptPath:join(folder, name), skillPath:folder, environment:{[key]:value, [emptyKey]:'temporary', [absentKey]:'introduced'}, label:name});
}
function stateFor(labels: string[]) {
 const states: any = {};
 for (const label of labels) states[label] = {entered:deferred(), gate:deferred(), seen:[]};
 (globalThis as any).__finalPreScriptState = states;
 return states;
}
const asyncInput = `export async function run() {
 const key = 'FINAL_HOLDOUT_SCRIPT_ENV';
 const label = process.env[key];
 const state = globalThis.__finalPreScriptState[label];
 state.seen.push([process.env[key], Bun.env[key]]);
 state.entered.resolve();
 await state.gate.promise;
 state.seen.push([process.env[key], Bun.env[key]]);
 if (state.fail) throw state.fail;
 return {label, after:process.env[key]};
}`;
function restored() {
 expect(process.env[key]).toBe('parent'); expect(Bun.env[key]).toBe('parent');
 expect(process.env[emptyKey]).toBe(''); expect(Bun.env[emptyKey]).toBe('');
 expect(Object.hasOwn(process.env, absentKey)).toBe(false);
}
test('synchronous values preserve exact empty versus absent environment', async () => sandbox(async folder => {
 await writeFile(join(folder, 'sync.ts'), `export function run() { return {value:process.env.${key}, empty:process.env.${emptyKey}} }`);
 expect(await call(folder, 'sync.ts', 'sync')).toEqual({value:'sync', empty:'temporary'});
 restored();
}));
test('asynchronous run owns environment through settlement', async () => sandbox(async folder => {
 const states = stateFor(['A']);
 await writeFile(join(folder, 'async.ts'), asyncInput);
 const pending = call(folder, 'async.ts', 'A');
 await states.A.entered.promise;
 const during = process.env[key];
 states.A.gate.resolve();
 const result = await pending;
 expect(during).toBe('A');
 expect(states.A.seen).toEqual([['A','A'], ['A','A']]);
 expect(result).toEqual({label:'A', after:'A'});
 restored();
}));
test('overlapping callers cannot enter until previous asynchronous run settles', async () => sandbox(async folder => {
 const states = stateFor(['A','B']);
 await writeFile(join(folder, 'first.ts'), asyncInput);
 await writeFile(join(folder, 'second.ts'), asyncInput);
 const a = call(folder, 'first.ts', 'A');
 await states.A.entered.promise;
 const b = call(folder, 'second.ts', 'B');
 await Bun.sleep(40);
 const premature = states.B.seen.length;
 states.A.gate.resolve();
 const resultA = await a;
 await states.B.entered.promise;
 states.B.gate.resolve();
 const resultB = await b;
 expect(premature).toBe(0);
 expect(resultA).toEqual({label:'A', after:'A'});
 expect(resultB).toEqual({label:'B', after:'B'});
 expect(states.A.seen).toEqual([['A','A'],['A','A']]);
 expect(states.B.seen).toEqual([['B','B'],['B','B']]);
 restored();
}));
test('rejection restores environment and releases next caller without replacing cause', async () => sandbox(async folder => {
 const states = stateFor(['A','B']);
 const failure = new Error('input script rejection'); states.A.fail = failure;
 await writeFile(join(folder, 'reject.ts'), asyncInput);
 await writeFile(join(folder, 'next.ts'), asyncInput);
 const pending = call(folder, 'reject.ts', 'A').catch(error => error);
 await states.A.entered.promise; states.A.gate.resolve();
 expect(await pending).toBe(failure);
 const afterReject = [process.env[key], process.env[emptyKey], process.env[absentKey]];
 const next = call(folder, 'next.ts', 'B');
 await states.B.entered.promise; states.B.gate.resolve();
 expect(await next).toEqual({label:'B', after:'B'});
 expect(afterReject).toEqual(['parent','',undefined]);
 restored();
}));
test('synchronous throw and module import failure do not poison subsequent runs', async () => sandbox(async folder => {
 await writeFile(join(folder, 'throw.ts'), `export function run() { throw new Error('sync failure') }`);
 await expect(call(folder, 'throw.ts', 'A')).rejects.toThrow('sync failure');
 await writeFile(join(folder, 'import.ts'), `throw new Error('import failure'); export function run() { return null }`);
 await expect(call(folder, 'import.ts', 'A')).rejects.toThrow('import failure');
 await writeFile(join(folder, 'good.ts'), `export function run() { return {skip:true,reason:'local check'} }`);
 const result = await call(folder, 'good.ts', 'B');
 expect(getPreScriptSkipReason(result)).toBe('local check');
 restored();
}));
test('shell scripts remain isolated child processes and return JSON', async () => sandbox(async folder => {
 await writeFile(join(folder, 'input.sh'), `printf '{"value":"%s"}' "$FINAL_HOLDOUT_SCRIPT_ENV"`);
 expect(await call(folder, 'input.sh', 'shell')).toEqual({value:'shell'});
 restored();
}));
'''.replace('__module__', json.dumps(str(repo / 'src/worker/preScript.ts')))
with tempfile.TemporaryDirectory(prefix='finalPreScriptOracle-') as folder:
    test = Path(folder) / 'isolation.test.ts'
    test.write_text(source)
    result = subprocess.run(['bun', 'test', '--timeout', '5000', str(test)], cwd=repo, env={**os.environ, 'MATATO_TEST_STORAGE_PATH':folder, 'OTEL_SDK_DISABLED':'true'}, timeout=45)
sys.exit(result.returncode)
