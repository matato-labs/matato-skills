#!/usr/bin/env python3
"""Small scoped integrity, shared-policy and fixture-projection audit."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
from reviewFrozenChecks import ROOT, LOGS, VARIANTS, BRIEFS, git, manifest

before=json.loads((LOGS/'inputHashes.json').read_text())
assert before==manifest()
for item in json.loads((ROOT/'research/cases.json').read_text())['cases']:
    assert hashlib.sha256(Path(item['oraclePath']).read_bytes()).hexdigest()==item['oracleSha256']
for name in ['research/finalBaseLogs/frozen.sha256','research/supplemental/SHA256SUMS','research/supplemental/SHA256SUMS-sql','research/supplemental/SHA256SUMS-sql-portable','research/supplementalRoundTwo/SHA256SUMS']:
    subprocess.run(['sha256sum','-c',name],cwd=ROOT,check=True)

def definitions(text):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(text)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}

for variant in VARIANTS:
    for brief in BRIEFS:
        repo=ROOT/'runs'/variant/brief['caseName']
        changed=git(repo,'diff','--name-only','HEAD').splitlines()
        production=[p for p in changed if '/tests/' not in p and '.test.' not in p and not p.endswith('_test.go')]
        assert set(production)<=set(brief['allowedScope'])
        assert not any('README' in p for p in changed)
        print('SCOPE',variant,brief['caseName'],json.dumps(production))
    repo=ROOT/'runs'/variant/'sourceBatchReads'
    p='atlas/src/atlas/services/navigation_source.py'
    old=definitions(git(repo,'show','HEAD:'+p)); new=definitions((repo/p).read_text())
    for name in ['local_bytes','contained_bytes','source_lines','source_status','excerpt_lines']:
        assert old[name]==new[name],(variant,name)
    print('SHARED_SAFETY_EXCERPT_POLICY_UNCHANGED',variant)
# Prove the sole dynamic snapshot adapter computes exactly the fixed snapshots
# adopted by the other three arms; no candidate output enters expected values.
repo=ROOT/'runs/ponytailReplication/pathEarlyExit'
for path in (repo/'atlas/tests/snapshots/coffee').glob('*/navigation.json'):
    expected=json.loads(path.read_text())
    for name,response in expected.items():
        if not name.startswith('path_') or response['status']!='found': continue
        target=response['path'][-1]
        target_index=next(i for i,n in enumerate(response['nodes']) if n['stableKey']==target)
        response['nodes']=response['nodes'][:target_index+1]
        last_edge=response['pathEdges'][-1]
        response['edges']=response['edges'][:response['edges'].index(last_edge)+1]
        keys={n['stableKey'] for n in response['nodes']}
        response['boundaries']=[b for b in response['boundaries'] if b['stableKey'] in keys]
    relative=path.relative_to(repo)
    assert expected==json.loads((ROOT/'runs/codingFrozen/pathEarlyExit'/relative).read_text())
    print('PROJECTED_FIXTURE_EXACTLY_MATCHES_FIXED',path.parent.name)
print('UNCHANGED_INPUT_FILES',len(before))
