import concurrent.futures
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tarfile
import time

root = Path('/tmp/codingSessionV3')
review = root / 'reviews/roundTwo'
records = []

def git(folder, *args):
    return subprocess.check_output(['git', '-C', str(folder), *args])

def paths(folder):
    changed = git(folder, 'diff', '--name-only', '-z').decode().split('\0')
    extra = git(folder, 'ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')
    return sorted(set(name for name in changed + extra if name and name != 'node_modules'))

def fingerprint():
    files = [p for p in (root / 'runs/tuningTwo').rglob('*') if p.is_file()]
    for result in results:
        folder = Path(result['worktree'])
        files += [folder / name for name in paths(folder) if (folder / name).is_file()]
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}

def run(label, command, folder):
    log = review / 'commands' / (label + '.log')
    log.parent.mkdir(exist_ok=True)
    start = time.monotonic()
    with log.open('w') as output:
        output.write('CWD ' + str(folder) + '\nCOMMAND ' + command + '\n')
        output.flush()
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', CI='1', DO_NOT_TRACK='1')
        proc = subprocess.Popen(['bash', '-c', command], cwd=folder, env=env,
                                stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = proc.wait(timeout=120)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait()
            code = 124
        elapsed = round(time.monotonic() - start, 3)
        output.write(f'\nEXIT {code}\nSECONDS {elapsed}\n')
    record = dict(label=label, command=command, cwd=str(folder), exit=code, seconds=elapsed,
                  output=str(log), sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    records.append(record)
    (review / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, code, elapsed, flush=True)

def archive(result, target):
    target.mkdir(parents=True)
    with tarfile.open(fileobj=io.BytesIO(git(Path(result['worktree']), 'archive', result['base']))) as stream:
        stream.extractall(target, filter='data')

def prepare(result):
    source = Path(result['worktree'])
    target = review / 'copies' / result['arm'] / result['case']
    archive(result, target)
    for name in paths(source):
        origin, destination = source / name, target / name
        if origin.is_file():
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(origin, destination)
        elif destination.exists():
            destination.unlink()
    if result['case'] == 'memoryReferenceResolution':
        (target / 'node_modules').symlink_to('/home/leon/workspace/projects/matato/node_modules', target_is_directory=True)
    if result['case'] == 'pythonUnicodeGraphFind':
        (target / 'atlas/.venv').symlink_to('/home/leon/workspace/projects/atlas/atlas/.venv', target_is_directory=True)
    return target

def pythonPrefix(folder):
    return f'cd "{folder}/atlas" && PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTEST_ADDOPTS= PYTHONPATH="{folder}/atlas/src:{folder}/atlas" '

def pytest(folder, label, files):
    return pythonPrefix(folder) + f'/home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B -m pytest -q -p no:cacheprovider --basetemp="{review}/temp/{label}" ' + files

def maintained(result, folder, suffix=''):
    if result['case'] == 'pythonUnicodeGraphFind':
        return pytest(folder, result['arm'] + 'Maintained' + suffix, 'tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py')
    if result['case'] == 'memoryReferenceResolution':
        home = review / 'temp' / (result['arm'] + 'Home' + suffix)
        home.mkdir(parents=True, exist_ok=True)
        return f'HOME="{home}" bun test src/storage/memoryBlock.test.ts src/storage/database.test.ts src/agent/matatoAgentTools.test.ts'
    tests = sorted(folder.glob('test/beer_game/quantity*test.exs'))
    expression = 'ExUnit.start(seed: 0); ' + '; '.join(f'Code.require_file("{path}")' for path in tests)
    return f'elixir -pa "/tmp/codingSessionV3/research/elixir/runtime/lib/*/ebin" -r "lib/beer_game/game/*.ex" -e \'{expression}\''

cases = {}
for language in ['python', 'typescript', 'elixir']:
    for case in json.loads((root / 'research' / language / 'tuning/manifest.json').read_text())['cases']:
        cases[case['id']] = case
results = [json.loads(path.read_text()) for path in sorted((root / 'runs/tuningTwo').glob('*/*/result.json'))]
before = fingerprint()
(review / 'before.json').write_text(json.dumps(before, indent=2))
for result in results:
    folder = prepare(result)
    case = cases[result['case']]
    label = result['arm'] + result['case']
    run(label + 'Acceptance', case['checkCommand'].format(root=folder), folder)
    run(label + 'Native', case['nativeCommand'].format(root=folder).replace('/tmp/codingSessionV3/research/python/tuning/nativeTemp', str(review / 'temp' / (label + 'Native'))), folder)
    run(label + 'Maintained', maintained(result, folder), folder)
    if result['case'] == 'pythonUnicodeGraphFind':
        run(result['arm'] + 'PythonIntegration', pytest(folder, label + 'Integration', 'tests/test_coffee_pipeline.py tests/test_variant_snapshots.py tests/test_declaration_coffee.py -k "python or each_physical"'), folder)
        changed = [name.removeprefix('atlas/') for name in paths(Path(result['worktree'])) if name.endswith('.py')]
        scope = ' '.join('"' + name + '"' for name in changed)
        prefix = pythonPrefix(folder) + '/home/leon/workspace/projects/atlas/atlas/.venv/bin/'
        run(result['arm'] + 'PythonLint', prefix + 'ruff check ' + scope, folder)
        run(result['arm'] + 'PythonTypes', prefix + 'pyright ' + scope, folder)
    if result['case'] == 'memoryReferenceResolution':
        run(result['arm'] + 'MaintainedTestLint', 'bun node_modules/eslint/bin/eslint.js src/storage/memoryBlock.test.ts', folder)
    if result['arm'] != 'candidateTwo':
        continue
    negative = review / 'negative' / result['case']
    shutil.copytree(folder, negative, symlinks=True)
    production = [name for name in paths(Path(result['worktree'])) if name.startswith(('atlas/src/', 'src/')) and '.test.' not in name or name.startswith('lib/')]
    for name in production:
        (negative / name).write_bytes(git(Path(result['worktree']), 'show', result['base'] + ':' + name))
    run(label + 'BaseNegative', maintained(result, negative, 'Base'), negative)
    if result['case'] == 'pythonUnicodeGraphFind':
        run(label + 'CoffeeBaseNegative', pytest(negative, 'candidateCoffeeBase', 'tests/test_coffee_navigation_snapshots.py'), negative)
    if result['case'] == 'elixirQuantityBoundaries':
        for name in production:
            target = review / 'schemaNegative' / Path(name).stem
            shutil.copytree(folder, target, symlinks=True)
            (target / name).write_bytes(git(Path(result['worktree']), 'show', result['base'] + ':' + name))
            run('candidateSchemaOriginal' + Path(name).stem, maintained(result, target), target)
after = fingerprint()
(review / 'after.json').write_text(json.dumps(after, indent=2))
assert before == after
(review / 'integrity.json').write_text(json.dumps(dict(unchanged=True, files=len(before)), indent=2) + '\n')
