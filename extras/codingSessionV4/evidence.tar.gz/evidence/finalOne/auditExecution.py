import hashlib
import json
from pathlib import Path

root = Path('/tmp/codingSessionV4')
evidence = root / 'evidence/finalOne'

def save(name, value):
    (evidence / name).write_text(json.dumps(value, indent=2) + '\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

results = sorted((root / 'runs/finalOne').glob('*/*/result.json'))
assert len(results) == 16
records = []
prompts = {}
for path in results:
    result = json.loads(path.read_text())
    folder = path.parent
    invocation = json.loads((folder / 'invocation.json').read_text()) if (folder / 'invocation.json').exists() else None
    profile = json.loads((folder / 'profileAudit.json').read_text()) if (folder / 'profileAudit.json').exists() else None
    traces = [json.loads(line) for line in (folder / 'toolTrace.jsonl').read_text().splitlines()] if (folder / 'toolTrace.jsonl').exists() else []
    starts = [event for event in traces if event['event'] == 'tool_execution_start']
    successful = {event['id'] for event in traces if event['event'] == 'tool_execution_end' and not event.get('isError', False)}
    localReads = [event for event in starts if event['name'] == 'read' and Path(event.get('path', '')).name in ['AGENTS.md', 'CLAUDE.md'] and event['id'] in successful]
    promptHash = digest(folder / 'prompt.txt') if (folder / 'prompt.txt').exists() else None
    prompts.setdefault(result['case'], []).append(promptHash)
    execution = {}
    for name in ['gitStorage', 'worktree', 'setup0', 'setup1', 'setup2', 'agent', 'acceptance', 'native']:
        metadata = folder / (name + '.json')
        if not metadata.exists():
            continue
        record = json.loads(metadata.read_text())
        execution[name] = {key: record[key] for key in ['exit', 'seconds', 'timeoutSeconds', 'timedOut', 'startedAt', 'finishedAt']}
    argv = invocation['argv'] if invocation else []
    requiredFlags = ['--print', '--mode', '--no-session', '--no-extensions', '--no-skills', '--no-prompt-templates', '--no-context-files', '--no-mcp', '--no-approve', '--offline']
    runtime = bool(invocation and all(flag in argv for flag in requiredFlags) and argv[argv.index('--model') + 1] == 'openai-codex/gpt-6.1-sol' and argv[argv.index('--thinking') + 1] == 'high' and argv[argv.index('--tools') + 1] == 'read,bash,edit,write' and '--unshare-all' in argv and result['piVersion'] == '1.1.0' and execution['agent']['timeoutSeconds'] == 900)
    profileMatches = profile and profile['profileExpectedSha256'] == result['profileSha256'] == digest(folder / 'currentProfile.md') == digest(Path(result['profilePath']))
    record = {key: result.get(key) for key in ['case', 'arm', 'status', 'seconds', 'agentSeconds', 'setupExit', 'agentExit', 'acceptanceExit', 'nativeExit', 'error']}
    record.update({'runtimeInvocationValid': runtime, 'profileHashesMatch': bool(profileMatches), 'profileAudit': profile, 'successfulLocalInstructionReads': localReads, 'promptSha256': promptHash, 'execution': execution, 'publicationReady': False})
    records.append(record)
save('runtimeAudits.json', records)
save('promptPairing.json', {case: {'hashes': values, 'fourArmsByteIdentical': len(values) == 4 and len(set(values)) == 1} for case, values in prompts.items()})
artifacts = {}
for path in sorted((root / 'runs/finalOne').rglob('*')):
    if path.is_file() and not path.is_symlink():
        artifacts[str(path)] = digest(path)
save('runArtifactHashes.json', artifacts)
print(json.dumps({'runs': len(records), 'runtimeValid': sum(record['runtimeInvocationValid'] for record in records), 'profilesMatch': sum(record['profileHashesMatch'] for record in records), 'ledger': json.loads((root / 'control/budget.json').read_text())['reserved']}))
for record in records:
    print(record['case'], record['arm'], record['status'], record['agentSeconds'], record['agentExit'], record['acceptanceExit'], record['nativeExit'])
