import { afterAll, expect, test } from "bun:test";
import { mkdtemp, mkdir, realpath, rm, symlink } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";

const root = process.env.CASE_ROOT!;
const { listWorkspaceRepos, run } = await import(join(root, "src/workspaceRepos.ts")) as typeof import("../../../../src/workspaceRepos.ts");
const scratch = await mkdtemp(join(tmpdir(), "checkout-roots-"));
const saved = process.env.WORKSPACE;
afterAll(async () => {
  if (saved === undefined) delete process.env.WORKSPACE;
  else process.env.WORKSPACE = saved;
  await rm(scratch, { recursive: true, force: true });
});

async function repository(path: string, origin?: string): Promise<void> {
  await mkdir(path, { recursive: true });
  await run("git", ["init", "-q", path]);
  if (origin) await run("git", ["-C", path, "remote", "add", "origin", origin]);
}

async function rows(workspace: string): Promise<Array<{ name: string; directory: string; repositoryUrl: string }>> {
  process.env.WORKSPACE = workspace;
  return (await listWorkspaceRepos()).sort((a: { name: string }, b: { name: string }) => a.name.localeCompare(b.name));
}

test("positive control: standalone checkouts, origin filtering, and helpers", async () => {
  const workspace = join(scratch, "ordinary");
  const checkout = join(workspace, "real repo");
  await repository(checkout, "https://example.invalid/real.git");
  await repository(join(workspace, "noOrigin"));
  await mkdir(join(workspace, "ordinaryFolder"));
  expect(await rows(workspace)).toEqual([{ name: "real repo", directory: checkout, repositoryUrl: "https://example.invalid/real.git" }]);
  delete process.env.WORKSPACE;
  await expect(listWorkspaceRepos()).rejects.toThrow("WORKSPACE must point");
});

test("does not inherit a parent checkout's origin for ordinary children", async () => {
  const workspace = join(scratch, "parent checkout");
  await repository(workspace, "https://example.invalid/parent.git");
  await mkdir(join(workspace, "notes"));
  await mkdir(join(workspace, "build"));
  const nested = join(workspace, "actual child");
  await repository(nested, "https://example.invalid/child.git");
  await repository(join(workspace, "noOrigin"));
  expect(await rows(workspace)).toEqual([{ name: "actual child", directory: nested, repositoryUrl: "https://example.invalid/child.git" }]);
});

test("a bare repository is not a usable working checkout", async () => {
  const workspace = join(scratch, "bare workspace");
  await mkdir(workspace);
  const bare = join(workspace, "archive.git");
  await run("git", ["init", "-q", "--bare", bare]);
  await run("git", ["-C", bare, "remote", "add", "origin", "https://example.invalid/bare.git"]);
  expect(await rows(workspace)).toEqual([]);
});

test("positive control: linked worktrees and a symlinked WORKSPACE", async () => {
  const workspace = join(scratch, "worktrees");
  const main = join(scratch, "main checkout");
  await repository(main, "https://example.invalid/worktree.git");
  await run("git", ["-C", main, "-c", "user.name=Fixture", "-c", "user.email=fixture@example.invalid", "commit", "-q", "--allow-empty", "-m", "fixture"]);
  await mkdir(workspace);
  const linked = join(workspace, "linked checkout");
  await run("git", ["-C", main, "worktree", "add", "-q", "--detach", linked]);
  await symlink(main, join(workspace, "directoryLink"));
  const alias = join(scratch, "workspace alias");
  await symlink(workspace, alias);
  const result = await rows(alias);
  expect(result).toHaveLength(1);
  expect(result[0]).toEqual({ name: "linked checkout", directory: join(alias, "linked checkout"), repositoryUrl: "https://example.invalid/worktree.git" });
  expect(await realpath(result[0].directory)).toBe(await realpath(linked));
});
