#!/usr/bin/env python3
"""Actual Croner lifecycle, timer ownership and extra timezone combinations."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

repo = Path(sys.argv[1]).resolve()
text = r'''
import { afterEach, expect, mock, spyOn, test } from "bun:test";
import { Cron as RealCron } from __cron__;
const jobs: Array<RealCron> = [];
class ObservedCron extends RealCron {
  constructor(...args: ConstructorParameters<typeof RealCron>) {
    super(...args);
    jobs.push(this);
  }
}
mock.module(__cron__, () => ({ Cron: ObservedCron }));
const { createScheduler } = await import(__scheduler__);
const cleanups: Array<() => void> = [];
afterEach(() => {
  for (const cleanup of cleanups.splice(0).reverse()) cleanup();
  for (const job of jobs.splice(0)) job.stop();
});
function automation(overrides: Record<string, unknown> = {}): any {
  return { jobName: "old", enabled: true, schedule: "0 9 * * *", timezone: "UTC",
    userPrompt: "run", canOverlap: false, model: "test", thinkingLevel: "off",
    canLaunchSubAgents: false, useSkill: false, ...overrides };
}
function scheduler(run = async (_job: any) => {}) {
  const result = createScheduler({ run, onError: () => {} });
  cleanups.push(result.stop);
  return result;
}
function timers() {
  const live = new Set<any>();
  const set = globalThis.setTimeout;
  const clear = globalThis.clearTimeout;
  const setSpy = spyOn(globalThis, "setTimeout").mockImplementation((...args: any[]) => {
    const id = (set as any)(...args); live.add(id); return id;
  });
  const clearSpy = spyOn(globalThis, "clearTimeout").mockImplementation((id: any) => {
    live.delete(id); return clear(id);
  });
  cleanups.push(() => { setSpy.mockRestore(); clearSpy.mockRestore(); });
  return live;
}

test.each(["", "Not/AZone"])("invalid explicit zone %j rolls back real timers", async timezone => {
  const live = timers();
  let calls = 0;
  const s = scheduler(async () => { calls += 1; });
  s.replace([automation()]);
  expect(live.size).toBe(1);
  expect(() => s.replace([
    automation({jobName: "candidate", timezone: "Asia/Kathmandu"}),
    automation({jobName: "disabled", enabled: false, timezone: "Bad/Zone", schedule: "bad"}),
    automation({jobName: "invalid", timezone}),
  ])).toThrow();
  expect(s.names()).toEqual(["old"]);
  expect(jobs[0].isStopped()).toBe(false);
  expect(jobs[1].isStopped()).toBe(true);
  expect(live.size).toBe(1);
  await jobs[0].trigger();
  expect(calls).toBe(1);
  s.stop();
  expect(live.size).toBe(0);
  const count = jobs.length;
  s.replace([automation({timezone: "bad"})]);
  expect(jobs.length).toBe(count);
  await jobs[0].trigger();
  expect(calls).toBe(1);
});

test.each(["cron", "duplicate", "monitor"])("%s failure cleans zoned candidate without touching old timer", kind => {
  const live = timers();
  const s = scheduler();
  s.replace([automation()]);
  const bad = kind === "cron" ? { schedule: "0 0 0 * * * 2026" } :
    kind === "duplicate" ? { jobName: "candidate", enabled: false } : { monitor: true };
  expect(() => s.replace([
    automation({jobName: "candidate", timezone: "Europe/Berlin"}),
    automation({jobName: "bad", ...bad}),
  ])).toThrow();
  expect(s.names()).toEqual(["old"]);
  expect(live.size).toBe(1);
  expect(jobs[1].isStopped()).toBe(true);
  s.stop();
  expect(live.size).toBe(0);
});

test.each(["0 9 * * *", "0 0 9 * * *"])("%s follows a thirty-minute DST transition", pattern => {
  const s = scheduler();
  s.replace([automation({schedule: pattern, timezone: "Australia/Lord_Howe"})]);
  expect(jobs[0].nextRun(new Date("2026-04-03T00:00:00Z"))?.toISOString()).toBe("2026-04-03T22:00:00.000Z");
  expect(jobs[0].nextRun(new Date("2026-04-04T00:00:00Z"))?.toISOString()).toBe("2026-04-04T22:30:00.000Z");
});

test("remove and re-add zone keeps in-flight guard, then stop blocks manual trigger", async () => {
  let release = () => {};
  const pending = new Promise<void>(resolve => { release = resolve; });
  let calls = 0;
  const s = scheduler(async () => { calls += 1; await pending; });
  s.replace([automation()]);
  const first = jobs[0].trigger();
  s.replace([]);
  s.replace([automation({timezone: "America/New_York"})]);
  await jobs[1].trigger();
  expect(calls).toBe(1);
  release(); await first;
  await jobs[1].trigger();
  expect(calls).toBe(2);
  s.stop(); await jobs[1].trigger();
  expect(calls).toBe(2);
});

test("installed dependency validation is eager only when date logic executes", () => {
  const results: Array<Record<string, unknown>> = [];
  for (const zone of ["", "Not/AZone", "UTC"]) {
    for (const callback of [false, true]) {
      let cron: RealCron | undefined;
      let threw = false;
      try { cron = callback ? new RealCron("0 9 * * *", {paused:true, timezone:zone}, () => {}) :
        new RealCron("0 9 * * *", {paused:true, timezone:zone}); }
      catch { threw = true; }
      finally { cron?.stop(); }
      results.push({zone, callback, threw});
    }
  }
  console.log("DEPENDENCY_VALIDATION", JSON.stringify(results));
});
'''
for key, value in {"__cron__": str(repo / "node_modules/croner/dist/croner.js"),
                   "__scheduler__": str(repo / "worker/scheduler.ts")}.items():
    text = text.replace(key, json.dumps(value))
with tempfile.TemporaryDirectory(prefix="supplementalZones") as d:
    p = Path(d) / "supplemental.test.ts"
    p.write_text(text)
    result = subprocess.run(["bun", "test", str(p)], cwd=repo,
                            env={**os.environ, "TZ": "Asia/Tokyo"}, timeout=45)
sys.exit(result.returncode)
