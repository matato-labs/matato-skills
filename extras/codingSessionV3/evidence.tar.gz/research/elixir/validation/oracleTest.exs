defmodule GameVocabularyTest do
  use ExUnit.Case, async: true

  alias BeerGame.Game.{Board, Order, Player, PlayerOrders}
  import Ecto.Changeset, only: [apply_action: 2, apply_changes: 1, get_field: 2, put_assoc: 3]

  @player %{name: "Retailer", role: "retailer", stock: 8, backlog: 8,
            weekly_orders: 4, last_order: 4}
  @cases [{Player, @player, :role, ["retailer", "wholesaler", "factory"]},
          {Order, %{amount: 4, type: "PLAYER_ORDER", state: "PENDING"}, :type, ["PLAYER_ORDER", "CPU_ORDER"]},
          {Order, %{amount: 4, type: "PLAYER_ORDER", state: "PENDING"}, :state, ["PENDING", "DELIVERED"]},
          {PlayerOrders, %{type: "SENDING"}, :type, ["SENDING", "RECEIVING"]}]

  defp params(attrs, :atoms), do: attrs
  defp params(attrs, :strings), do: Map.new(attrs, fn {key, value} -> {Atom.to_string(key), value} end)

  defp invalid(changeset, fields, action) do
    refute changeset.valid?
    assert Enum.sort(Keyword.keys(changeset.errors)) == Enum.sort(fields)
    assert {:error, _changeset} = apply_action(changeset, action)
  end

  for {schema, attrs, field, allowed} <- @cases,
      value <- ["UNKNOWN", "retailer", "factory", "CPU_ORDER", "SENDING", "PENDING",
                "pending", "player_order", "sending", "Retailer", " PENDING", "factory "],
      value not in allowed,
      keys <- [:atoms, :strings], action <- [:insert, :update] do
    test "#{inspect(schema)} rejects #{field}=#{inspect(value)} #{keys} #{action}" do
      schema = unquote(schema)
      attrs = unquote(Macro.escape(attrs))
      field = unquote(field)
      original = if unquote(action) == :insert, do: struct(schema), else: struct(schema, attrs)
      changes = if unquote(action) == :insert, do: Map.put(attrs, field, unquote(value)),
                else: %{field => unquote(value)}
      changeset = schema.changeset(original, params(changes, unquote(keys)))
      invalid(changeset, [field], unquote(action))
      assert changeset.data == original
    end
  end

  for {schema, attrs, field, allowed} <- @cases,
      value <- allowed, keys <- [:atoms, :strings], action <- [:insert, :update] do
    test "#{inspect(schema)} accepts #{field}=#{value} #{keys} #{action}" do
      schema = unquote(schema)
      attrs = unquote(Macro.escape(attrs))
      field = unquote(field)
      original = if unquote(action) == :insert, do: struct(schema), else: struct(schema, attrs)
      changes = if unquote(action) == :insert, do: Map.put(attrs, field, unquote(value)),
                else: %{field => unquote(value)}
      changeset = schema.changeset(original, params(changes, unquote(keys)))
      assert changeset.valid?
      assert changeset.errors == []
      assert {:ok, applied} = apply_action(changeset, unquote(action))
      assert Map.fetch!(applied, field) == unquote(value)
      assert changeset.data == original
    end
  end

  for {type, state, errors} <- [{"UNKNOWN", "UNKNOWN", [:type, :state]},
                               {"UNKNOWN", "PENDING", [:type]},
                               {"CPU_ORDER", "UNKNOWN", [:state]},
                               {"PLAYER_ORDER", nil, [:state]},
                               {"UNKNOWN", nil, [:type, :state]}],
      keys <- [:atoms, :strings], action <- [:insert, :update] do
    test "order reports independent type/state errors #{inspect({type, state})} #{keys} #{action}" do
      original = if unquote(action) == :insert, do: %Order{},
                 else: %Order{amount: 4, type: "PLAYER_ORDER", state: "DELIVERED"}
      changeset = Order.changeset(original, params(%{amount: "7", type: unquote(type), state: unquote(state)}, unquote(keys)))
      invalid(changeset, unquote(errors), unquote(action))
      assert changeset.data == original
    end
  end

  for type <- ["PLAYER_ORDER", "CPU_ORDER"], state <- ["PENDING", "DELIVERED"],
      keys <- [:atoms, :strings] do
    test "all supported order combinations preserve casting #{type} #{state} #{keys}" do
      changeset = Order.changeset(%Order{}, params(%{amount: "7", type: unquote(type), state: unquote(state)}, unquote(keys)))
      assert {:ok, order} = apply_action(changeset, :insert)
      assert order == %Order{amount: 7, type: unquote(type), state: unquote(state)}
      assert {:ok, ^order} = order |> Order.changeset(%{}) |> apply_action(:update)
    end
  end

  for {schema, attrs, field, _allowed} <- @cases,
      value <- [nil, %{}, []], keys <- [:atoms, :strings], action <- [:insert, :update] do
    test "#{inspect(schema)} retains invalid nil/cast handling #{field}=#{inspect(value)} #{keys} #{action}" do
      schema = unquote(schema)
      attrs = unquote(Macro.escape(attrs))
      original = if unquote(action) == :insert, do: struct(schema), else: struct(schema, attrs)
      changes = Map.put(attrs, unquote(field), unquote(Macro.escape(value)))
      changeset = schema.changeset(original, params(changes, unquote(keys)))
      invalid(changeset, [unquote(field)], unquote(action))
      unless unquote(is_nil(value)) do
        {_message, metadata} = Keyword.fetch!(changeset.errors, unquote(field))
        assert metadata[:validation] == :cast
      end
      assert changeset.data == original
    end
  end

  test "default PENDING is not confused with an explicitly cleared state" do
    for keys <- [:atoms, :strings] do
      changeset = Order.changeset(%Order{}, params(%{amount: "4", type: "CPU_ORDER"}, keys))
      assert changeset.valid?
      assert get_field(changeset, :state) == "PENDING"
      cleared = Order.changeset(%Order{}, params(%{amount: "4", type: "CPU_ORDER", state: nil}, keys))
      invalid(cleared, [:state], :insert)
    end
  end

  test "all supported state transitions remain legal; no transition policy is introduced" do
    for type <- ["PLAYER_ORDER", "CPU_ORDER"], before <- ["PENDING", "DELIVERED"], afterState <- ["PENDING", "DELIVERED"] do
      original = %Order{id: 19, amount: 4, type: type, state: before}
      changeset = Order.changeset(original, %{"state" => afterState})
      assert {:ok, applied} = apply_action(changeset, :update)
      assert applied == %{original | state: afterState}
      assert changeset.data == original
    end
  end

  test "existing required and amount cast failures remain field-specific" do
    for {schema, fields} <- [{Order, [:amount, :type]}, {PlayerOrders, [:type]},
                            {Player, [:name, :role, :stock, :backlog, :weekly_orders, :last_order]}] do
      changeset = schema.changeset(struct(schema), %{})
      invalid(changeset, fields, :insert)
      assert Enum.all?(changeset.errors, fn {_field, {_message, metadata}} -> metadata[:validation] == :required end)
    end
    for type <- ["PLAYER_ORDER", "CPU_ORDER"] do
      changeset = Order.changeset(%Order{}, %{amount: "not an integer", type: type})
      invalid(changeset, [:amount], :insert)
      {_message, metadata} = Keyword.fetch!(changeset.errors, :amount)
      assert metadata[:validation] == :cast
    end
  end

  test "valid roles preserve unrelated data and associations can still be attached" do
    for role <- ["retailer", "wholesaler", "factory"] do
      original = struct(Player, Map.merge(@player, %{role: role, cpu: true, board_id: 9}))
      assert {:ok, ^original} = original |> Player.changeset(%{}) |> apply_action(:update)
      assert {:ok, renamed} = original |> Player.changeset(%{"name" => "Renamed"}) |> apply_action(:update)
      assert renamed == %{original | name: "Renamed"}
    end
    board = %Board{name: "Workshop"}
    player = Player.changeset(%Player{}, @player) |> put_assoc(:board, board) |> apply_changes()
    order = Order.changeset(%Order{}, %{amount: "4", type: "PLAYER_ORDER"}) |> apply_changes()
    for type <- ["SENDING", "RECEIVING"] do
      changeset = PlayerOrders.changeset(%PlayerOrders{}, %{type: type})
                  |> put_assoc(:player, player) |> put_assoc(:order, order)
      assert changeset.valid?
      assert {:ok, association} = apply_action(changeset, :insert)
      assert association.type == type
      assert association.player == player and association.order == order
      assert {:ok, ^association} = association |> PlayerOrders.changeset(%{}) |> apply_action(:update)
    end
  end
end
