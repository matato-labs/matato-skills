"""Execute the actual manual_deps; no source extraction or source rewriting."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

import pytest

HERE = Path(__file__).resolve().parent
CACHE = Path(os.environ["TMPDIR"])
ROOT = Path(os.environ["CASE_ROOT"])


def execute(os_name: str, fault: str) -> tuple[subprocess.CompletedProcess[str], list[dict[str, str | list[str]]]]:
    with tempfile.TemporaryDirectory(prefix="shellFixture", dir=CACHE) as temporary:
        runtime = Path(temporary)
        bins, etc, home = (runtime / name for name in ("bin", "etc", "home"))
        for path in (bins, etc, home):
            path.mkdir()
        if os_name == "arch":
            (etc / "arch-release").touch()
        if os_name == "debian":
            (etc / "debian_version").write_text("fixture\n")
        for name in ("uname", "sudo", "curl", "brew", "chsh", "zsh", "rm", "sdkApplied"):
            target = bins / name
            shutil.copyfile(HERE / "fixtureCommand.py", target)
            target.chmod(0o700)
        events = runtime / "events.jsonl"
        events.touch()
        environment = {
            "PATH": f"{bins}:/usr/bin:/bin", "HOME": str(home), "USER": "fixture",
            "CASE_BIN": str(bins), "CASE_EVENTS": str(events), "CASE_OS": os_name,
            "CASE_FAULT": fault, "LC_ALL": "C", "TMPDIR": str(runtime),
        }
        argv = ["/usr/bin/bwrap", "--unshare-all", "--die-with-parent", "--new-session",
                "--ro-bind", "/", "/", "--bind", str(runtime), str(runtime),
                "--ro-bind", str(etc), "/etc",
                "--proc", "/proc", "--dev", "/dev", "--chdir", str(runtime),
                "--", "/bin/bash", "--noprofile", "--norc", str(ROOT / "manual_deps")]
        result = subprocess.run(argv, env=environment, capture_output=True, text=True, timeout=15)
        assert "bwrap:" not in result.stderr, result.stderr
        rows = [json.loads(line) for line in events.read_text().splitlines()]
        print("FIXTURE", json.dumps({"os": os_name, "fault": fault, "exit": result.returncode, "events": rows}))
        assert rows, f"installer did not reach fixtures: {result.stderr}"
        return result, rows


@pytest.mark.parametrize("os_name", ["arch", "debian", "darwin"])
def test_positive_control_successful_routes(os_name: str) -> None:
    result, rows = execute(os_name, "none")
    assert result.returncode == 0, result.stderr
    assert "finish to install dependencies" in result.stdout
    assert [row["command"] for row in rows].count("sdkApplied") == 1
    assert any(row["command"] == "chsh" for row in rows)
    commands = [row["args"] for row in rows if row["command"] == "sudo"]
    if os_name == "arch":
        assert ["pacman", "-Sy", "--noconfirm", "git", "zsh", "xclip", "docker"] in commands
    if os_name == "debian":
        assert ["apt-get", "update"] in commands
        assert ["apt-get", "install", "-y", "git", "zsh", "xclip"] in commands
    if os_name != "darwin":
        assert ["install", "-c", "-m", "0755", "devpod", "/usr/local/bin"] in commands
    else:
        assert any(row["command"] == "brew" and row["args"] == ["install", "git", "zsh", "xclip"] for row in rows)


@pytest.mark.parametrize("os_name", ["arch", "debian"])
@pytest.mark.parametrize("fault", ["devpodHttp", "devpodTransport", "devpodInstall"])
def test_devpod_failure_stops_installation(os_name: str, fault: str) -> None:
    result, rows = execute(os_name, fault)
    assert result.returncode != 0, f"{fault} falsely reported success: {result.stdout}"
    assert not any(row["command"] == "curl" and any("sdkman" in arg for arg in row["args"]) for row in rows)
    assert not any(row["command"] == "chsh" for row in rows)
    assert "finish to install dependencies" not in result.stdout
    if fault != "devpodInstall":
        assert not any(row["command"] == "sudo" and row["args"][0] == "install" for row in rows)


@pytest.mark.parametrize("fault", ["sdkHttp", "sdkTransport"])
def test_sdk_failure_cannot_reach_shell_change(fault: str) -> None:
    result, rows = execute("darwin", fault)
    assert result.returncode != 0, f"{fault} falsely reported success: {result.stdout}"
    assert not any(row["command"] == "chsh" for row in rows)
    assert "finish to install dependencies" not in result.stdout
