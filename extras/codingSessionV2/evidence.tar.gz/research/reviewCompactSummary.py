#!/usr/bin/env python3
"""Summarize independently verified artifacts and record scoped reproducibility facts."""
import hashlib
import json
import re
import subprocess
import types
from reviewCompactChecks import execute

runner = types.ModuleType('compact_runner')
execute('reviewFrozenChecks.py', runner.__dict__)
ROOT, LOGS, VARIANTS = runner.ROOT, runner.LOGS, runner.VARIANTS
metrics = json.loads((LOGS/'verifiedMetrics.json').read_text())
summary = {}
for variant in VARIANTS:
    summary[variant] = {group: {key: sum(m[group][key] for m in metrics if m['variant'] == variant) for key in ['added','deleted','churn','net']} for group in ['source','tests','combined','normalizedSource','normalizedTests','normalizedCombined']}
(LOGS/'totals.json').write_text(json.dumps(summary, indent=2)+'\n')
profiles = {}
for path in (ROOT/'profiles').glob('*.md'):
    data = path.read_bytes()
    profiles[path.name] = dict(bytes=len(data), words=len(data.split()), lines=len(data.splitlines()), sha256=hashlib.sha256(data).hexdigest())
(LOGS/'profileSizes.json').write_text(json.dumps(profiles, indent=2)+'\n')
frozen = json.loads((ROOT/'research/reviewFrozenLogs/inputHashes.json').read_text())
current = runner.manifest()
protected = [p for p in frozen if p == 'frozenBriefs.json' or '/oracles/' in p or '/supplemental/' in p or '/supplementalRoundTwo/' in p or '/finalOracles/' in p]
assert all(current[p] == frozen[p] for p in protected)
print('PRIOR_FROZEN_INPUT_HASHES_MATCH', len(protected))
for variant in VARIANTS:
    for case in ['sourceBatchReads','pathEarlyExit']:
        repo = ROOT/'runs'/variant/case
        command = [str(repo/'atlas/.venv/bin/python'), '-c', 'import sys,atlas.services.navigation as n; print(sys.version); print(n.__file__); assert n.__file__.startswith(sys.argv[1])', str(repo/'atlas/src')]
        runner.run((f'import-{variant}-{case}', command, repo/'atlas', {'PYTHONPATH':'src'}))
for tool in [['go','version'], ['bun','--version'], ['python','--version']]:
    print('VERSION', subprocess.check_output(tool, text=True).strip())
for path in sorted(LOGS.glob('native-*.log')):
    text = path.read_text()
    snippets = re.findall(r'(?:\d+ passed[^\n]*|\d+ pass\n|\d+ fail\n|--- PASS: [^\n]+)', text)
    print(path.stem, '; '.join(snippets).replace('\n',''))
print('TOTALS', json.dumps(summary))
assert current == runner.manifest()
