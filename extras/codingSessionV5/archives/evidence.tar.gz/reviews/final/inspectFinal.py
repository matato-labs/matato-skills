"""Read only public artifacts; preserve frozen measurements and review evidence."""
from pathlib import Path
import ast
import hashlib
import json
import re

root = Path(__file__).parent
project = Path('/home/leon/workspace/projects/matato-pi')
rows = json.loads((root / 'inventory.json').read_text())
results = {}
for name in ['revisionTwoResults', 'holdoutResults']:
    for run in json.loads((project / 'extras/codingSessionV5' / f'{name}.json').read_text())['runs']:
        results[str(Path(run['evidence']).parent)] = run


def inspectSnapshots(row):
    evidence = Path(row['path']) / 'evidence'
    changes = []
    for chunk in (evidence / 'changes.patch').read_text().split('diff --git ')[1:]:
        path = chunk.splitlines()[0].split(' b/')[1]
        if '/snapshots/' not in path or not path.endswith('.json'):
            continue
        before = json.loads('\n'.join(line[1:] for line in chunk.splitlines()
                                     if line.startswith('-') and not line.startswith('---')))
        after = json.loads('\n'.join(line[1:] for line in chunk.splitlines()
                                    if line.startswith('+') and not line.startswith('+++')))
        changes.append({'path': path, 'existingCount': len(before),
                        'addedKeys': sorted(set(after) - set(before)),
                        'removedKeys': sorted(set(before) - set(after)),
                        'changedExistingKeys': [key for key in before if key in after and before[key] != after[key]],
                        'unchangedExistingCount': sum(before[key] == after[key] for key in before if key in after)})
    return changes


def inspectFiles(row):
    run = results[row['path']]
    files = []
    case = {'workspaceCheckoutRoots': 'ts', 'navigationUnseenEdgeBudget': 'py',
            'installerDownloadFailures': 'bash', 'holdoutOne': 'hold'}[row['case']]
    for item in run['capturedMeasurement']['files']:
        path = item['path']
        source = Path(row['path']) / 'workspace' / path
        copy = root / 'copies' / row['label'] / case / 'candidate' / path
        record = {'path': path, 'lines': item['afterLoc']['physical'],
                  'isSymlink': source.is_symlink(), 'matchesDisposableAfterChecks': False}
        if source.is_symlink():
            record.update({'target': str(source.readlink()),
                           'matchesDisposableAfterChecks': copy.is_symlink() and source.readlink() == copy.readlink()})
        else:
            data = source.read_bytes()
            record.update({'sha256': hashlib.sha256(data).hexdigest(),
                           'matchesDisposableAfterChecks': data == copy.read_bytes()})
            if source.suffix == '.py':
                functions = [node for node in ast.walk(ast.parse(data))
                             if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
                record['functions'] = [{'name': node.name, 'start': node.lineno, 'end': node.end_lineno,
                                        'lines': node.end_lineno - node.lineno + 1} for node in functions]
        files.append(record)
    return files


def inspectPublic(row):
    run = results[row['path']]
    evidence = Path(row['path']) / 'evidence'
    audit = json.loads((evidence / 'audit.json').read_text())
    allowed = ['activation.json', 'agent.json', 'audit.json', 'changes.patch', 'finalSummary.txt',
               'manifest.json', 'measurement.json', 'native.json', 'native.stdout', 'native.stderr',
               'acceptance.json', 'acceptance.stdout', 'acceptance.stderr', 'toolTrace.jsonl']
    hashes = {name: hashlib.sha256((evidence / name).read_bytes()).hexdigest() == run['evidenceHashes'][name]
              for name in allowed}
    return {'label': row['label'], 'draw': row['draw'], 'case': row['case'], 'arm': row['arm'],
            'path': row['path'], 'status': run['status'], 'validCompletion': run['validCompletion'],
            'agent': run['agent'], 'audit': {key: audit.get(key) for key in
                ['valid', 'settled', 'aborted', 'unexpectedRecovery', 'toolStarts', 'toolEnds', 'turns']},
            'activation': audit.get('nativeActivation'), 'publicHashesMatch': hashes,
            'profileMetadataSha256': run['profileSha256'], 'packageMetadataSha256': run['packageSha256'],
            'finalSummary': (evidence / 'finalSummary.txt').read_text(), 'metrics': run['metrics'],
            'frozenMeasurement': run['capturedMeasurement'], 'checks': run['checks'],
            'snapshots': inspectSnapshots(row), 'files': inspectFiles(row)}


def traceSummary(row):
    lines = [f"\n## {row['label']} {row['case']}"]
    starts = {}
    for line in (Path(row['path']) / 'evidence/toolTrace.jsonl').read_text().splitlines():
        event = json.loads(line)
        if event['event'] == 'tool_execution_start':
            starts[event['id']] = event
            lines.append(f"START {event['name']} {event.get('command') or event.get('path') or ''} timeout={event.get('timeout')}")
        else:
            starts.pop(event['id'], None)
            lines.append(f"END {event['name']} ms={event.get('durationMs')} error={event.get('isError')} bytes={event.get('payloadBytes')}")
    lines.append('UNFINISHED ' + json.dumps(list(starts.values())))
    return '\n'.join(lines)


def diagnostics(text):
    records = []
    for block in text.split('## ')[1:]:
        header = block.splitlines()[0]
        measured = re.search(r'Measured: ([\d.]+); maximum: ([\d.]+)', block)
        records.append({'key': header, 'measured': float(measured[1]),
                        'maximum': float(measured[2]), 'evidence': block.strip()})
    return records


def atlasComparison(row):
    case = {'workspaceCheckoutRoots': 'ts', 'navigationUnseenEdgeBudget': 'py',
            'installerDownloadFailures': 'bash', 'holdoutOne': 'hold'}[row['case']]
    folder = root / 'checks' / row['label'] / case
    action = {'py': 'wholeCheck', 'hold': 'externalDeliveredWholeCheck'}.get(case, 'externalWholeCheck2')
    baseline = 'baselineWholeCheck' if case == 'py' else 'externalBaselineWholeCheck2'
    candidate = diagnostics((folder / 'candidate' / f'{action}.stdout').read_text())
    original = diagnostics((folder / 'original' / f'{baseline}.stdout').read_text())
    candidateMap, originalMap = ({item['key']: item for item in items} for items in [candidate, original])
    return {'label': row['label'], 'case': case, 'requiredRepositoryPolicy': case == 'py',
            'candidateCount': len(candidate), 'originalCount': len(original),
            'introduced': [item for key, item in candidateMap.items() if key not in originalMap],
            'removed': [item for key, item in originalMap.items() if key not in candidateMap],
            'worsened': [{'before': originalMap[key], 'after': item} for key, item in candidateMap.items()
                         if key in originalMap and item['measured'] > originalMap[key]['measured']],
            'candidateEvidence': str(folder / 'candidate' / f'{action}.stdout'),
            'originalEvidence': str(folder / 'original' / f'{baseline}.stdout')}


summary = [inspectPublic(row) for row in rows]
(root / 'evidenceSummary.json').write_text(json.dumps(summary, indent=2) + '\n')
(root / 'snapshotChanges.json').write_text(json.dumps([{'label': row['label'], 'changes': row['snapshots']}
                                                     for row in summary if row['snapshots']], indent=2) + '\n')
(root / 'atlasComparison.json').write_text(json.dumps([atlasComparison(row) for row in rows], indent=2) + '\n')
(root / 'traces.txt').write_text('\n'.join(traceSummary(row) for row in rows) + '\n')
checks = []
for path in sorted((root / 'checks').glob('*/*/*/*.json')):
    record = json.loads(path.read_text())
    record['record'] = str(path)
    record['command'] = path.with_suffix('.command.txt').read_text()
    checks.append(record)
(root / 'checkResults.json').write_text(json.dumps(checks, indent=2) + '\n')
print('Saved evidenceSummary.json, snapshotChanges.json, atlasComparison.json, traces.txt, checkResults.json')
for row in summary:
    print(row['label'], row['case'], 'complete', row['validCompletion'], 'hashes', all(row['publicHashesMatch'].values()),
          'filesMatch', all(item['matchesDisposableAfterChecks'] for item in row['files']))
