# Restricted held-out selection and architectural fit

Compatible. Do not include this case's brief, topic, owner, assertions, logs or counts in development-arm prompts or public preparation summaries. This directory is the held-out artifact; its manifest's role is authoritative.

`worker/scheduler.ts:18–43` owns candidate construction/cleanup, lines 53–69 own active-run overlap/error accounting, and lines 72–90 own installed-set replacement and shutdown. `worker/index.ts:11–24` wires the scheduler to the real worker and watcher. `worker/watcher.ts` submits replacements; `worker/testFixtures.ts:3–26` provides complete automation values and deterministic in-flight control. No runner subprocess, timers, network, credentials or live worker is required to exercise the scheduler contract.

Retirement belongs at the scheduler's installed-set lifecycle boundary, not at caller polling or the automation runner. A name-only liveness check would confuse an old callback with a new callback sharing its jobName. Clearing active-run state on replacement would break already-started work and same-name overlap protection. The independent acceptance invokes retained callbacks directly through the real injected-factory API, checks discarded candidates after failure, and includes a passing in-flight/overlap control. The original maintained scheduler suite remains the native compatibility check.

The case is fresh and independent from the three development tasks. No model or profile has attempted it. No speculative production implementation or source patch was produced during preparation.
