# Terminal shared supplement and synthesis audit

**Verdict: NOT MET. No implementation repair, skill revision, cherry-picking or new hypothesis.** CandidateThree meets the runtime-size ceiling and beats every comparator's combined physical churn in both complete final draws. It does not beat every comparator's production churn in either draw. Shared supplements also prevent a no-correctness/completeness-loss claim.

All **72** saved patches match their `result.json` hashes and current live git patches. All **48 original final acceptance records remain green and unchanged**. These supplementary tests are separate evidence, not retroactive edits to frozen checks or acceptance results.

## One common supplementary result table

Entries show **status and passing/selected tests**, not coverage scores. Root tests independently exercise a symlink at `sessions/matato` and its `sessions` ancestor. Zero tests independently exercise persisted room ID 0 and topic ID 0. Work is the unchanged-in-this-audit real `src/storage/work.test.ts` suite in each output.

| Draw | Arm | Root anchor | Persisted zero IDs | Work consumer |
|---|---|---|---|---|
| finalOne | main | FAIL 0/2 | FAIL 0/2 | PASS 8/8 |
| finalOne | PR112 | PASS 2/2 | PASS 2/2 | FAIL 7/8 |
| finalOne | Ponytail | PASS 2/2 | PASS 2/2 | FAIL 7/8 |
| finalOne | candidateThree | FAIL 0/2 | FAIL 0/2 | PASS 8/8 |
| finalTwo | main | FAIL 0/2 | PASS 2/2 | FAIL 7/8 |
| finalTwo | PR112 | FAIL 0/2 | PASS 2/2 | FAIL 7/8 |
| finalTwo | Ponytail | FAIL 0/2 | PASS 2/2 | PASS 8/8 |
| finalTwo | candidateThree | FAIL 0/2 | PASS 2/2 | FAIL 7/8 |
| Common pinned original | original production + tests | FAIL 0/2 | FAIL 0/2 | PASS 8/8 |

The common original control is commit `4f2b75f73087b5f2c60995629c591dc91a591567`, verified identical for both relevant tasks in all eight final combinations. One original archive supplies all three controls. Its two failing probes are **expected pre-fix failures**, not implementation passes or a mutation score. The 13 nonzero current-output commands are real supplemental failures; two further nonzero commands are original controls. All 27 completed commands have full logs, cwd, exact allowlisted environment, argv, sandbox argv, exit, duration and output SHA-256 in `evidence.json`/`commands.json`; none timed out.

### Specific behavior and classification

**Root anchor:** finalOne main/candidate and **every finalTwo arm** delete both the outside target and its outside referenced child in **both** stable fixtures. The root/ancestor symlink survives. Before calling the real cleanup module, the probe writes and reads back both protected files; after cleanup it prints both survival booleans, checks the symlink, and attempts to read the protected bytes again. Failing logs show `targetSurvives:false`, `referencedChildSurvives:false`, then ENOENT. FinalOne PR/Ponytail preserve both files byte-for-byte and pass. Example evidence: `commands/finalTwoprsessionTreeConfinementrootAnchor.log`; every arm has its own equivalent log.

The failing implementations compare `realpath(file)` against `realpath(root)`, so a symlink **moves the anchor** outside the lexical managed root. FinalOne PR/Ponytail instead compare the canonical file against the fixed lexical root. `evidence.json.commonResults[].sourceEvidence` includes exact source paths, hashes and numbered excerpts. This resolves the finalTwo review's previously untested root classification symmetrically; its general confinement description must not be read as establishing this boundary.

**Policy qualification:** this probe implements the fixed lexical-root interpretation of “supplied path and canonical target ... strictly below `<getMatatoAgentDir()>/sessions/matato`,” also used by finalOne. Intentionally allowing relocation of the managed root through a root/ancestor symlink would be a different product policy; under that policy, the defect label would need qualification. No relocation exception is stated in the brief. The observed outside deletion is unambiguous; this audit does not claim a concurrent-race exploit or arbitrary remote exploitability. All fixtures are stable, wholly inside disposable homes.

**Persisted zero:** finalOne main/candidate return normally for both supplied-zero cases, commit newly created rows, and create a link to persisted zero. Five-table before/after JSON proves that behavior. The seed is inserted through the real Drizzle schema into a migrated local SQLite database and explicitly asserted present before invocation. There is no positive-ID schema CHECK. This does **not** claim the normal auto-increment APIs generate zero. The brief explicitly says a supplied zero is unresolved, with no persisted-row exception, so this is not the root-policy ambiguity. FinalOne PR/Ponytail and **all finalTwo arms** throw with the required room/topic-and-zero message and leave all five tables equal to their prior state. The latter resolves finalTwo's previously unexecuted zero classification; its ordinary-zero assertions alone did not establish it. Example logs: `commands/finalOnecandidateThreememoryReferenceResolutionzeroIds.log` and `commands/finalTwocandidateThreememoryReferenceResolutionzeroIds.log`.

The original zero control also returns without throwing and changes the tables, but silently discards these unresolved links rather than exhibiting the same accepted-zero-link behavior. Expected failure provenance is therefore retained, not flattened into identical behavior.

**Work consumer:** the five failing combinations all fail only `deletes related records and session files`: `existsSync(sessionFile)` remains true. Their fixture still uses `agent/sessions/agent.jsonl`, outside the new `matato` root. The file surviving is correct confinement; the maintained fixture/expectation integration is stale. FinalOne main/candidate and finalTwo Ponytail use an eligible fixture and pass all eight. The original suite passes eight on original production. Do not weaken confinement to satisfy the stale fixture. No fixture was repaired here.

## Probe inspection, freeze and isolation

Read finalOne's `stableSessionConfirmation.ts`, `zeroIdProbe.ts`, `runConfirmation.py`, `runExtras.py` and `runReview.py`, plus the repository Bun configuration, preload, home helper, migration fixture, affected production and work test. The probes import **real modules**, not mocks or copied implementations. Bun runs from each archived project root, loading its normal `bunfig.toml` → `src/test/setup.ts`. That preload isolates HOME and test storage; the root probe additionally uses `setTestHomePath` per case, and the zero probe uses `createTestDatabaseFixture` with real offline migrations.

Byte-identical copies of both original probe templates are retained under `probes/`. Before any suite execution, the shared zero template received only a seed-presence assertion and diagnostic before/after logging around the original call. Its original throw/message and five-table-equality assertions remain. The root template is unchanged. This is reviewer-only observation instrumentation, not an implementation revision or edit to existing checks. All generated probes are identical after substituting their own real-module import prefix; that equality, template hashes and individual hashes are verified in `probeFreeze.json` and `evidence.json.normalizedProbeAudit`.

Execution used **17 own archive copies** under `reviews/sharedFinal/copies`: two task copies per final combination and one common original. Base archives receive only the immutable measured implementation files; no ignored environment/credential files or original `.git` directory are transferred. Existing dependency symlinks are read-only by usage and additionally protected by the sandbox. No service, network, install, application startup or optional mutant was used. Local test SQLite migration is not application/database-server startup.

Each command runs through Bubblewrap with `/` read-only, **only `reviews/sharedFinal` writable**, a separate network namespace, cleared inherited environment, and allowlisted review-local HOME/TMPDIR/cache/test storage. Bun's top-level invocation disables automatic dotenv loading. No live environment secrets are inherited or recorded. Original checkouts and shared dependencies cannot be written by these subprocesses. Source files in every own copy are hashed/type/mode-checked after execution; all remain identical, including dependency links. Logs and scratch are retained.

`before.json` and `after.json` match across **46,762 file fingerprints and 72 original worktree HEAD/status records**. They cover all implementations, run artifacts, profiles, frozen research/check files and existing top-level reviewer artifacts. User worktree status was clean at entry and remains clean. No original implementation, profile, README or existing check was edited.

## Independent metrics: all 72 retained outputs

`metrics.json` recomputes every file from live **NUL-delimited** git numstat and independently parses each saved patch with `git apply --numstat -z` (read-only). Exact patch hashes match both live git and `result.json`; recorded category totals agree. All changed nonignored source is accounted for; dependency/build links are excluded. Fixtures, builders and snapshots count as tests; other churn is zero. Reviewer metric files from all four rounds independently agree, including exact byte growth. `git --no-optional-locks` avoids index refresh writes.

`+/−` below is generated added/deleted physical lines. Byte growth is exact changed-file resulting bytes minus pinned-base bytes, **not** patch-file size or a normalized semantic measure.

| Draw | Arm | Production/test churn | Combined churn | +/− | Net lines | Byte growth |
|---|---|---:|---:|---:|---:|---:|
| tuningOne | main | 60/577 | 637 | 619/18 | +601 | +54,971 |
| tuningOne | PR112 | 63/621 | 684 | 661/23 | +638 | +209,063 |
| tuningOne | Ponytail | 66/625 | 691 | 672/19 | +653 | +55,689 |
| tuningOne | candidateOne | 58/629 | 687 | 670/17 | +653 | +35,131 |
| tuningTwo | main | 60/594 | 654 | 632/22 | +610 | +219,384 |
| tuningTwo | PR112 | 63/648 | 711 | 692/19 | +673 | +182,438 |
| tuningTwo | Ponytail | 60/592 | 652 | 629/23 | +606 | +209,782 |
| tuningTwo | candidateTwo | 61/647 | 708 | 686/22 | +664 | +77,816 |
| finalOne | main | 96/1088 | 1184 | 1150/34 | +1116 | +83,294 |
| finalOne | PR112 | 104/1157 | 1261 | 1219/42 | +1177 | +199,849 |
| finalOne | Ponytail | 98/1126 | 1224 | 1192/32 | +1160 | +81,011 |
| finalOne | candidateThree | 104/1058 | 1162 | 1125/37 | +1088 | +207,189 |
| finalTwo | main | 98/1112 | 1210 | 1179/31 | +1148 | +64,577 |
| finalTwo | PR112 | 132/1217 | 1349 | 1303/46 | +1257 | +66,851 |
| finalTwo | Ponytail | 104/1130 | 1234 | 1201/33 | +1168 | +61,316 |
| finalTwo | candidateThree | 105/1026 | 1131 | 1097/34 | +1063 | +197,027 |

Across all 72 outputs: **14,727 added / 452 deleted = 15,179 churn; +14,275 net lines; +2,005,388 bytes**. This is descriptive accounting across different tasks/candidates, not a valid pooled final success test.

Across the two final draws only, candidate has **209 production / 2084 test / 2293 combined churn**, **2222/71 added/deleted**, **+2151 net lines**, **+404,216 bytes**. Main is 194/2200/2394, +147,871 bytes; PR112 236/2374/2610, +266,700 bytes; Ponytail 202/2256/2458, +142,327 bytes. Pooling must not replace the predeclared per-draw gate: candidate finalOne production deltas versus main/PR/Ponytail are **+8/0/+6**, finalTwo **+7/−27/+1**. A tie is not strictly below. Combined deltas are respectively **−22/−99/−62** and **−79/−218/−103**.

CandidateThree remains **2,642 bytes**, versus main 5,121, PR112 3,161, Ponytail 3,492. Its SHA-256 is `57cc21ce6ded5cc772232dfa87225d1880dd533bfa65f02921d8b9c2e656d2b6`; all 46 freeze-listed hashes match. No new runtime script/reference is introduced. Size-ceiling compliance is genuine but insufficient.

### Formatting, snapshots and per-case losses

Physical line counts are the declared metric, not a complexity or byte metric. FinalOne's reviewer secondary nonblank/trimmed-line comparison narrows candidate/main combined churn from **1162/1184 to 1068/1072**; production still loses. Historical candidateOne's apparent two-line production win over main consisted of omitted blank separators. FinalTwo's reviewer reports candidate production 105 versus main 96/Ponytail 104 even after excluding added production blanks. These attributed diagnostics do not change physical totals or imply semantic equivalence after normalization.

One-line generated JSON can replace megabytes for two churn lines. FinalOne candidate Unicode test growth is **173,355 bytes**, versus main 46,674, PR112 161,855, Ponytail 42,306; finalTwo candidate's six existing snapshot replacements account for **+157,611 bytes** and about **7.32 MB** of resulting files. The reviewers fully parsed these snapshots and exercised their generator routes; this audit verifies their byte metrics, not a fresh structural/generator rerun. Candidate's existing shared sample has high fan-out; comparator dedicated samples can have lower byte costs. Both final candidate byte totals exceed every baseline despite lower combined physical lines.

Per-case losses also remain: finalOne candidate memory and quantities lose combined churn to every comparator, and Unicode to main/Ponytail; finalTwo loses Unicode/memory to main and memory/quantities to Ponytail. Detailed per-file/per-case totals are retained. No best-case selection, reformatting or deletion of safeguards is credited as an improvement.

## Reuse that is real, mostly shared

**Python Unicode:** every arm composes `str.casefold`, a deterministic connection-local SQLite UDF, the existing SQLAlchemy connection event and SQL query/ranking facilities. NULL preservation, literal `instr`, raw stable-key matching, repository scope, ordering and limits stay in the owning layer. Tuple/generator unpacking versus separate assignments is a small expression-sharing/layout choice, not a new algorithm or measured reduction in SQLite evaluations. Final candidates reuse the maintained CoffeeNavigation collector/generator seam; historical missing fixture consumers do not recur in these outputs according to both final reviews.

**Literal database paths:** every arm uses the dependency's structured `URL.create('sqlite', database=str(target))`, rather than manual escaping or a new storage API. Existing path resolution, parent creation, transactions, foreign keys, migration/WAL and readonly machinery remain. Candidate reduces some test setup by extending maintained persistence/CLI/navigation seams; that bounded organizational gain is not a proof of complete equivalence for every omitted matrix combination.

**Memory:** all arms reuse the existing transaction, persisted/new exact-name Maps, stores/linkers and Set/`mergeNumbers` deduplication. Late errors remain inside the original transaction. Candidate additionally creates the room-ID Set **once at the common `createTopics` lifetime**, passing it to room resolution instead of rebuilding it per topic. That is genuine common-lifetime reuse, but costs signature/call-site churn and has no measured throughput/memory benefit. Membership alone cannot replace the explicit zero policy: finalOne demonstrates the distinction. Shared fixtures/table readers/rejection helpers preserve meaningful rollback, recovery and exclusive-ID assertions; candidate does not win aggregate memory test churn.

**Sessions:** native `realpath`/`stat`, separator-bounded containment and the existing visited recursion are shared mechanisms. Smaller consolidated traversal scenarios cover many real interactions, but omitted root-anchor coverage is not automatically harmless deduplication. Existing caller fixtures must agree with the narrowed root. No stable-path check here establishes TOCTOU protection.

**Ecto:** all quantity patches are the same six native `validate_number(..., greater_than_or_equal_to: 0)` compositions. Vocabulary patches use `validate_inclusion`, existing casting/required checks and a separate state cast with `empty_values: []` to distinguish omitted default from explicit clearing. No custom validator, parser, dependency, service or migration is needed. Case tables/builders can reduce setup; fewer assertions or Cartesian case counts alone establish neither adequacy nor inadequacy.

```mermaid
flowchart LR
  Code[Owning code + dependency composition] --> Owned[Maintained regressions]
  Code --> Callers[Existing caller fixtures]
  Fixtures[Shared sample] --> Consumers[Inventory + snapshots]
  Fixtures --> Generator[Maintained generator]
  Owned --> Gate[Behavior AND completeness AND production AND combined size]
  Callers --> Gate
  Consumers --> Gate
  Generator --> Gate
```

## Earlier findings, responses and unresolved limits

Round one rejected candidateOne's unregistered Python fixture and missing regeneration integration; main also missed dependent variants. Its combined size gate failed, and its apparent production advantage was whitespace. Round two's candidateTwo passed the selected behavior/consumer checks but still lacked a maintained route for its separate snapshot; its combined/production gate failed against main/Ponytail. These are historical rejected draws, not repaired or erased by later draws.

The parent retained every implementation, adopted the final 2,642-byte candidate within the predeclared maximum-three-revision bound, and froze it before both complete six-case draws. Hash checks support the stated **no repair/no cherry-pick** response. Both final reviewers report the Python fixture/generator omissions absent in the new outputs and the selected original acceptance/native/maintained commands green. This audit attributes those broader reruns to them; it independently executes only the common supplements above. FinalOne's root/zero and comparator work findings reproduce; finalTwo's work finding reproduces; its untested root/zero boundaries now have the same probes applied to every arm.

The mutation report is **tooling blocked**: installed Atlas has no mutation command/catalog, zero selected/executed mutants, score N/A. Original-production controls and passing maintained baselines are not a substitute mutation score. No optional mutation was attempted here.

The disclosed early reserved TypeScript brief exposure remains a reviewer-blindness limitation. All 72 invocation records use explicit profiles and no-discovery/offline flags, and all recorded profile hashes match current frozen profiles. This establishes configuration consistency, **not actual tool-use history, absence of contamination or strict holdout blindness**. No raw tool-history audit or causal/statistical superiority claim is made. Native discovery was selective; Ecto native repeated its oracle rather than discovering added tests, which reviewers loaded separately. Frozen green never meant all maintained consumers or supplementary boundaries were green.

Reported broader Python/full-suite timeouts, performance-test failure and missing dashboard tooling remain attributed, unresolved limitations, not independently established passes or confirmed regressions here. No full application, frontend, DB-backed Ecto or exhaustive security suite was run in this terminal audit.

**Terminal disposition:** runtime skill size passes; narrower combined-LOC improvement is real under the declared physical metric; the complete production-AND-combined objective and no-completeness-loss claim fail. No further implementation, revision, success-labelled PR or Ponytail removal is performed by this delegated review. Deliverables: `review.md`, `evidence.json`, `metrics.json`, reproducible drivers and exact command logs, all under `reviews/sharedFinal`.
