# Selection and architectural fit

Compatible. Fresh task, not V1–V4 search/path/confinement/memory/Ecto/lifetime/atomic-create/bootstrap work.

Observed owner: `src/workspaceRepos.ts:45–70` combines immediate filesystem discovery with local Git process effects; `runResult:16–30` owns process capture and `run:34–42` owns rejection. `listWorkspaceRepos:58–62` asks only for a remote, so Git's ancestor discovery supplies an enclosing repository's origin and bare repositories qualify. The maintained seam is `src/workspaceRepos.test.ts:25–47`; repository-wide tracked-source search found no additional listWorkspaceRepos caller. This is an exported utility contract, not a newly wired UI feature.

Smallest change belongs at candidate classification inside this utility, with maintained Git-fixture regressions in its existing test file. Do not place filtering in a consumer, redefine process helpers, or add recursive scanning. A plausible boundary violation is changing returned paths to canonical paths merely because identity comparison needs canonicalization; the symlinked-WORKSPACE positive fixture detects it. A directory-.git-only heuristic would reject the linked-worktree control.

Acceptance creates actual local Git repositories, one enclosing workspace checkout, a bare repository and a linked worktree; it never contacts an origin. It asserts complete membership, so `.git`, inherited folders and no-origin children cannot silently leak. Original negative and passing native/positive controls are recorded separately. Frozen checks are independent from any later model-authored maintained tests.
