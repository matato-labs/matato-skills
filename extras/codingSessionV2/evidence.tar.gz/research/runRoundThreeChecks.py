#!/usr/bin/env python3
"""Review-only checks, importing candidates explicitly. No candidate edits."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
LOGS = ROOT / 'research/reviewRoundThreeLogs'
LOGS.mkdir(exist_ok=True)
VARIANTS = ['ponytailThird', 'codingThird']
CASES = ['sourceBatchReads', 'isinCsvRecords', 'scheduleTimeZones', 'pathEarlyExit']

def manifest():
    paths = [ROOT/'briefs.json', ROOT/'thirdMetrics.json']
    for directory in ['profiles', 'patches', 'research/oracles', 'research/supplemental', 'research/supplementalRoundTwo']:
        paths += [p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in str(p)]
    for variant in VARIANTS + ['base']:
        for case in CASES:
            repo = ROOT/('base' if variant == 'base' else 'runs/'+variant)/case
            tracked = subprocess.check_output(['git','-C',str(repo),'ls-files','-z']).decode().split('\0')
            paths += [repo/p for p in tracked if p and (repo/p).is_file()]
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}

jobs = []
for variant in VARIANTS:
    for case in CASES:
        repo = ROOT/'runs'/variant/case
        for suite in ['oracles', 'supplemental', 'supplementalRoundTwo']:
            script = ROOT/'research'/suite/(case+'.py')
            if script.exists():
                jobs.append((f'{suite}-{variant}-{case}', [sys.executable,str(script),str(repo)], ROOT, {}))
        if case in ['sourceBatchReads','pathEarlyExit']:
            py = str(repo/'atlas/.venv/bin/python')
            jobs.append((f'import-{variant}-{case}', [py,'-c','import atlas.services.navigation as n; print(n.__file__)'], repo/'atlas', {'PYTHONPATH':'src'}))
            for test, name in [('tests/test_graph_navigation.py','native'),('tests/test_coffee_navigation_snapshots.py','coffee')]:
                jobs.append((f'{name}-{variant}-{case}', [py,'-m','pytest',test,'-q'], repo/'atlas', {'PYTHONPATH':'src'}))
            if case == 'sourceBatchReads':
                jobs.append((f'sql-{variant}',[py,str(ROOT/'research/supplemental/sourceSqlWorkPortable.py'),str(repo)],ROOT,{}))
                jobs.append((f'old-resources-{variant}',[py,str(ROOT/'research/sourceResourcesRoundTwo.py'),str(repo)],ROOT,{}))
        elif case == 'isinCsvRecords':
            jobs.append((f'native-{variant}-{case}', ['go','test','./data','-count=1','-v'], repo/'commons', {'GOWORK':'off','GOPROXY':'off','GOSUMDB':'off'}))
        else:
            for zone in ['Asia/Tokyo','UTC','America/Los_Angeles']:
                jobs.append((f'native-{variant}-{case}-{zone.replace("/","-")}', ['bun','test','worker/scheduler.test.ts','src/automationConfig.test.ts'],repo,{'TZ':zone}))
            jobs.append((f'semantics-{variant}',[sys.executable,str(ROOT/'research/schedulerSemanticsRoundTwo.py'),str(repo)],ROOT,{}))

def run(job):
    name, cmd, cwd, env = job
    try:
        p = subprocess.run(cmd,cwd=cwd,env={**os.environ,**env},capture_output=True,timeout=300)
        output, rc = p.stdout+p.stderr, p.returncode
    except subprocess.TimeoutExpired as e:
        output, rc = (e.stdout or b'')+(e.stderr or b'')+b'\nTIMEOUT\n', 124
    (LOGS/(name+'.log')).write_bytes(('COMMAND '+json.dumps(cmd)+'\nCWD '+str(cwd)+'\nENV '+json.dumps(env)+'\nEXIT '+str(rc)+'\n').encode()+output)
    print(name,rc,flush=True)
    return {'name':name,'exit':rc}

if __name__ == '__main__':
    before = manifest()
    (LOGS/'inputHashes.json').write_text(json.dumps(before,indent=2)+'\n')
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(run,jobs))
    (LOGS/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    after = manifest()
    differences = [p for p in before.keys() | after.keys() if before.get(p) != after.get(p)]
    (LOGS/'immutability.json').write_text(json.dumps({'unchanged':not differences,'differences':differences,'files':len(before)},indent=2)+'\n')
    assert not differences, differences
    sys.exit(any(r['exit'] for r in results))
