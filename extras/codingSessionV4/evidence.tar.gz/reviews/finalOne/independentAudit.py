import hashlib
import json
from pathlib import Path

root = Path('/tmp/codingSessionV4')
out = Path('/home/leon/.cache/codingSessionV4Owned/reviews/finalOne')
report = {}
configs = set()
prompts = {}
for arm in ['v3', 'v2', 'ponytail', 'candidateTwo']:
    for case in ['pythonConfinedIgnoreFiles', 'preScriptEnvironmentLifetime', 'sequenceCreateRecovery', 'shellBootstrapLocation']:
        trial = root / 'runs/finalOne' / arm / case
        profile = (trial / 'currentProfile.md').read_bytes()
        invocation = json.loads((trial / 'invocation.json').read_text())
        agent = json.loads((trial / 'agent.json').read_text())
        raw = Path(agent['stdout']).read_bytes()
        events = [json.loads(line) for line in raw.splitlines()]
        starts = [event for event in events if event['type'] == 'tool_execution_start']
        first = starts[0]
        result = next(event for event in events if event['type'] == 'tool_execution_end' and event['toolCallId'] == first['toolCallId'])
        observed = '\n'.join(block.get('text', '') for block in result['result']['content'])
        messages = [event['message'] for event in events if event['type'] == 'message_end' and event['message']['role'] == 'assistant']
        settings = sorted(set((message.get('provider'), message.get('model'), message.get('thinkingLevel', message.get('providerThinkingLevel'))) for message in messages))
        promptHash = hashlib.sha256((trial / 'prompt.txt').read_bytes()).hexdigest()
        prompts.setdefault(case, []).append(promptHash)
        configs.add(invocation['environment']['PI_CODING_AGENT_DIR'])
        record = {'completeProfileObserved': profile.decode().strip() in observed, 'profileReadError': result.get('isError', False), 'settings': settings, 'settled': any(event['type'] == 'agent_settled' and not event.get('aborted', False) for event in events), 'finalStopReason': messages[-1].get('stopReason'), 'localInstructionReads': [event['args']['path'] for event in starts if event['toolName'] == 'read' and Path(event['args'].get('path', '')).name in ['AGENTS.md', 'CLAUDE.md']], 'rawSha256Matches': hashlib.sha256(raw).hexdigest() == json.loads((trial / 'profileAudit.json').read_text())['rawStreamSha256'], 'isolationFlagsPresent': all(flag in invocation['argv'] for flag in ['--unshare-all', '--no-session', '--no-context-files', '--no-skills', '--no-mcp', '--no-extensions']), 'profileBytes': len(profile), 'profileSha256': hashlib.sha256(profile).hexdigest(), 'promptSha256': promptHash, 'recordedStageExits': {name: json.loads((trial / f'{name}.json').read_text())['exit'] for name in ['agent', 'acceptance', 'native']}, 'agentSeconds': agent['seconds'], 'agentTimeout': agent['timedOut'], 'agentBudget': agent['timeoutSeconds']}
        assert first['toolName'] == 'read' and first['args']['path'] == '/tmp/codingSessionV4/currentProfile.md'
        assert record['completeProfileObserved'] and not record['profileReadError'] and record['rawSha256Matches'] and record['isolationFlagsPresent']
        assert settings == [('openai-codex', 'gpt-6.1-sol', 'high')]
        if arm == 'candidateTwo':
            assert len(profile) == 2630 and record['profileSha256'] == '6efa072c53b7e83aae7a17f4f60a45efd113cd8dc927c1c1ebf815ec3cd25643'
        report[f'{arm}/{case}'] = record
assert len(configs) == 16 and all(len(set(values)) == 1 for values in prompts.values())
report['controls'] = {'distinctConfigurations': 16, 'sameCasePromptHashesMatch': True, 'hiddenResponseModelIdentity': 'not exposed; requested and reported identity only', 'completePairedComparison': False, 'invalid': 'v2/pythonConfinedIgnoreFiles900sec timeout'}
(out / 'independentAudit.json').write_text(json.dumps(report, indent=2) + '\n')
print('Sixteen raw streams/profile observations independently verified; invalid V2Python retained.')
