import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

root = Path('/tmp/codingSessionV4')
disk = Path('/home/leon/.cache/codingSessionV4Owned')
disk.mkdir(mode=0o700)
evidence = disk / 'relocationEvidence'
evidence.mkdir(mode=0o700)

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            value.update(block)
    return value.hexdigest()

def inventory(paths):
    return {str(path): digest(path) for parent in paths for path in sorted(parent.rglob('*')) if path.is_file() and not path.is_symlink()}

def save(name, data):
    (evidence / name).write_text(json.dumps(data, indent=2) + '\n')

oldPaths = [root / name for name in ['runs', 'evidence', 'reviews', 'profiles', 'research', 'worktrees']]
before = inventory(oldPaths)
save('oldBefore.json', before)
harness = evidence / 'harnessBefore'
harness.mkdir()
for path in [*root.glob('*.py'), *root.glob('*.json'), root / 'runnerNotes.md']:
    shutil.copy2(path, harness / path.name)
save('harnessBefore.json', inventory([harness]))
privateBefore = inventory([root / 'private'])
ledgerBefore = inventory([root / 'control'])
assert json.loads((root / 'control/budget.json').read_text())['reserved'] == 19
save('ledgerBefore.json', ledgerBefore)
save('ledgerBeforeContents.json', json.loads((root / 'control/budget.json').read_text()))
for name in ['private', 'control']:
    source = root / name
    target = disk / name
    # Cross-filesystem move retains complete file bytes and mode; no live launchers.
    shutil.move(str(source), str(target))
    source.symlink_to(target, target_is_directory=True)
assert inventory([root / 'private']) == privateBefore
assert inventory([root / 'control']) == ledgerBefore
for name in ['worktrees', 'runs', 'evidence']:
    target = disk / name / 'finalOne'
    target.mkdir(parents=True, mode=0o700)
    (root / name / 'finalOne').symlink_to(target, target_is_directory=True)
save('relocation.json', {'time': time.time(), 'disk': str(disk), 'mode': oct(disk.stat().st_mode & 0o777), 'privateBytesUnchanged': True, 'ledgerBytesUnchanged': True, 'ledgerCount': 19, 'moved': ['private', 'control'], 'futureSymlinks': ['worktrees/finalOne', 'runs/finalOne', 'evidence/finalOne'], 'originalAuth': 'not opened or modified'})
after = {path: digest(Path(path)) for path in before}
assert after == before
save('oldAfterRelocation.json', after)
save('ledgerAfter.json', inventory([root / 'control']))
record = subprocess.run(['df', '-B1', str(disk), '/tmp'], capture_output=True, text=True)
(evidence / 'dfBeforeAllocation.txt').write_text(record.stdout + record.stderr)
allocation = disk / 'syntheticAllocation'
with allocation.open('xb') as stream:
    for number in range(320):
        stream.write(b'X' * 1048576)
    stream.flush()
    os.fsync(stream.fileno())
allocated = allocation.stat()
assert allocated.st_blocks * 512 > 256 * 1024 * 1024
save('allocation.json', {'bytes': allocated.st_size, 'allocatedBytes': allocated.st_blocks * 512, 'fsync': True, 'deletedAfterProof': True})
allocation.unlink()
record = subprocess.run(['df', '-B1', str(disk), '/tmp'], capture_output=True, text=True)
(evidence / 'dfAfterAllocation.txt').write_text(record.stdout + record.stderr)
print('Relocated; private and ledger bytes unchanged; old evidence hashes match; allocated/fsynced/deleted 320MiB on disk.', flush=True)
