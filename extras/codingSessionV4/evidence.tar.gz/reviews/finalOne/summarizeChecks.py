from datetime import datetime
import hashlib
import json
from pathlib import Path
import re

out = Path('/home/leon/.cache/codingSessionV4Owned/reviews/finalOne')
commands = []
for path in sorted((out / 'logs').rglob('*.execution.json')):
    record = json.loads(path.read_text())
    roundName, arm, case, name = path.relative_to(out / 'logs').parts
    record.update({'round': roundName, 'arm': arm, 'case': case, 'label': name.removesuffix('.execution.json')})
    text = Path(record['stdout']).read_text() + '\n' + Path(record['stderr']).read_text()
    record['summaries'] = re.findall(r'^.*(?:\d+ passed.*|\d+ failed.*|\d+ subtests passed.*|\d+ pass$|\d+ fail$|Ran \d+ tests.*|PASS: generator preserves.*|error TS\d+.*)$', text, re.MULTILINE)
    commands.append(record)
(out / 'allCommands.json').write_text(json.dumps(commands, indent=2) + '\n')
(out / 'checkSummary.json').write_text(json.dumps([{key: record[key] for key in ['round', 'arm', 'case', 'label', 'exit', 'timedOut', 'timeoutSeconds', 'seconds', 'summaries']} for record in commands], indent=2) + '\n')
events = []
for record in commands:
    events += [(datetime.fromisoformat(record['startedAt']), 1), (datetime.fromisoformat(record['finishedAt']), -1)]
running = 0
maximum = 0
for moment, change in sorted(events):
    running += change
    maximum = max(maximum, running)
print('Recorded commands:', len(commands), 'maximum overlapping:', maximum)
assert maximum <= 8
plans = {name: {'sha256': hashlib.sha256((out / name).read_bytes()).hexdigest(), 'mtimeNs': (out / name).stat().st_mtime_ns} for name in ['supplementPlan.json', 'mountCorrectionPlan.json', 'lifetimeDiagnosticPlan.json']}
(out / 'executionLimits.json').write_text(json.dumps({'commands': len(commands), 'maxConcurrent': maximum, 'commandBudgetMax': max(record['timeoutSeconds'] for record in commands), 'originalScoresUnchanged': True, 'plans': plans}, indent=2) + '\n')
for record in commands:
    if record['round'] == 'finalOne':
        print(record['arm'], record['case'], record['label'], record['exit'], record['summaries'][-4:])
