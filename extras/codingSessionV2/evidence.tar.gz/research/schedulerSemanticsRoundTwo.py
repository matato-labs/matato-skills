#!/usr/bin/env python3
"""Installed API observations, not a newly imposed injected-factory contract."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
repo = Path(sys.argv[1]).resolve()
script = r'''
import { Cron } from __cron__;
import { createScheduler } from __scheduler__;
const original = Intl.DateTimeFormat;
let formats = 0;
Intl.DateTimeFormat = new Proxy(original, {
  construct(target, args, newTarget) { formats += 1; return Reflect.construct(target, args, newTarget); },
});
const job = (timezone?: string) => ({jobName:'job',enabled:true,schedule:'* * * * * *',timezone,
 userPrompt:'',canOverlap:false,model:'test',thinkingLevel:'off',canLaunchSubAgents:false,useSkill:false});
try {
  for (const injected of [false, true]) {
    for (const timezone of [undefined, 'UTC', 'Asia/Kathmandu', '', 'Not/AZone']) {
      const schedules: Array<Cron> = [];
      const scheduler = createScheduler({run:async()=>{},onError:()=>{},
        ...(injected ? {createSchedule:(pattern, _run, zone) => {
          const cron = new Cron(pattern, {paused:true,mode:'5-or-6-parts',timezone:zone});
          schedules.push(cron); return cron;
        }} : {}),
      });
      formats = 0;
      let error: unknown;
      try { scheduler.replace([job(timezone) as any]); } catch(e) { error = e; }
      console.log(JSON.stringify({injected,timezone:timezone ?? '<omitted>',threw:!!error,format_constructions:formats,names:scheduler.names()}));
      scheduler.stop(); schedules.forEach(s => s.stop());
    }
  }
} finally { Intl.DateTimeFormat = original; }
'''
script = script.replace('__cron__', json.dumps(str(repo/'node_modules/croner/dist/croner.js'))).replace('__scheduler__', json.dumps(str(repo/'worker/scheduler.ts')))
with tempfile.TemporaryDirectory() as d:
    p = Path(d)/'probe.ts'
    p.write_text(script)
    result = subprocess.run(['bun',str(p)],cwd=repo,env={**os.environ,'TZ':'Asia/Tokyo'},timeout=30)
sys.exit(result.returncode)
