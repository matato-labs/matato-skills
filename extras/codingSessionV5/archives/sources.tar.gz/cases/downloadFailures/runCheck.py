"""Offline checks against an owned checkout; all children are network-isolated."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent


def invoke(argv: list[str], root: Path, cwd: Path, environment: dict[str, str]) -> int:
    runtime = environment["TMPDIR"]
    sandbox = ["/usr/bin/bwrap", "--unshare-all", "--die-with-parent", "--new-session",
               "--ro-bind", "/", "/", "--bind", runtime, runtime,
               "--bind", str(root), str(root), "--proc", "/proc", "--dev", "/dev",
               "--chdir", str(cwd), "--"]
    print("RUN", json.dumps(sandbox + argv), flush=True)
    process = subprocess.Popen(sandbox + argv, cwd=cwd, env=environment, start_new_session=True)
    try:
        return process.wait(timeout=100)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait()
        print("TIMEOUT after 100 seconds", flush=True)
        return 124


def main() -> int:
    checkout, mode = sys.argv[1:]
    root = Path(checkout).resolve()
    specification = json.loads((HERE / "commands.json").read_text())
    scratch = Path(os.environ["TMPDIR"])
    with tempfile.TemporaryDirectory(prefix=f"{HERE.name}Run", dir=scratch) as temporary:
        runtime = Path(temporary)
        home = runtime / "home"
        home.mkdir()
        environment = {
            "PATH": specification["path"], "HOME": str(home), "TMPDIR": str(runtime),
            "XDG_CACHE_HOME": str(runtime / "cache"), "XDG_CONFIG_HOME": str(home / "config"),
            "PYTHONDONTWRITEBYTECODE": "1", "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
            "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null",
            "GIT_TERMINAL_PROMPT": "0", "GIT_OPTIONAL_LOCKS": "0",
            "TREE_SITTER_LANGUAGE_PACK_LIBS_DIR": "/home/leon/.cache/tree-sitter-language-pack/v1.20.0/libs",
            "LC_ALL": "C.UTF-8", "CASE_ROOT": str(root), "CI": "1",
        }
        environment["PYTHONPATH"] = f"{root}/atlas/src:{root}/atlas"
        values = {"root": str(root), "case": str(HERE), "runtime": str(runtime)}
        cwd = Path(specification["cwd"].format(**values))
        for command in specification[mode]:
            status = invoke([arg.format(**values) for arg in command], root, cwd, environment)
            if status:
                return status
    return 0


if __name__ == "__main__":
    sys.exit(main())
