import hashlib
import json
from pathlib import Path

root = Path('/tmp/codingSessionV4')
out = root / 'reviews/tuningOne'
private = Path('/dev/shm/codingSessionV4tuningReview')
metrics = json.loads((out / 'metrics.json').read_text())
checksums = json.loads((out / 'checksums.json').read_text())
unchanged = {}
for key, expected in checksums.items():
    if key.startswith('/'):
        assert hashlib.sha256(Path(key).read_bytes()).hexdigest() == expected, key
        continue
    arm, case, name = key.split('/', 2)
    live = root / 'worktrees/tuningOne' / arm / case / name
    copy = private / arm / case / name
    unchanged[key] = hashlib.sha256(live.read_bytes()).hexdigest() == expected
    assert hashlib.sha256(copy.read_bytes()).hexdigest() == expected, str(copy)
assert all(unchanged.values())

inventory = {}
for case in ['pythonConfinedIgnoreFiles', 'preScriptEnvironmentLifetime']:
    paths = {row['path']: row['category'] for identity, rows in metrics['files'].items() if identity.endswith('/' + case) for row in rows}
    inventory[case] = {}
    for arm in ['original', 'v3', 'v2', 'ponytail', 'candidateOne']:
        target = private / arm / case
        inventory[case][arm] = {category: sum((target / name).stat().st_size for name, kind in paths.items() if (category == 'combined' or kind == category) and (target / name).exists()) for category in ['production', 'tests', 'fixtures', 'snapshots', 'combined']}
metrics['matchedInventoryResultBytes'] = inventory
metrics['matchedInventoryExplanation'] = 'Union of all eight changed paths per case, including unchanged base files in arms not editing them. Missing new files count zero. Avoid comparing different changed-file inventories as total repository size.'
metrics['qualityGate'] = {'candidateProductionVsPonytail': 'NOT MET: additions 26 >23, churn38 >34, result bytes11964 >11785', 'candidateCombinedVsPonytail': 'Numerically better: additions392 <478, churn440 <527; not a production win', 'runtimeBytes': 2593, 'runtimeCap': 2642, 'finalRepeatedDraws': 'not run; tuning only', 'nativeRecheck': 'Ponytail one observed frozen bus timing failure, preserved; symmetric separate diagnostic green, not a corrected score'}
(out / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
(out / 'integrity.json').write_text(json.dumps({'allRecordedInputsStillMatch': True, 'liveImplementationFilesUnchanged': unchanged, 'noImplementationRuns': True, 'sandbox': 'bwrap unshare-all; originals/dependencies read-only, no credentials/network/services; private copies in /dev/shm after pre-execution /tmp quota error', 'earlierEvidence': 'Only read; all supplements stored here'}, indent=2) + '\n')
for case, arms in inventory.items():
    print(case, arms)
