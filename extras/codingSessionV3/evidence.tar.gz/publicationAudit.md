# Final publication audit

**BLOCKED: incomplete frozen TypeScript harness packaging.** No benchmark, application tests, archived-script execution, extraction, repository edits or PR creation performed.

`extras/codingSessionV3/evidence.tar.gz` omits four frozen files:

```
research/typescript/tuning/native
research/typescript/tuning/oracle
research/typescript/validation/native
research/typescript/validation/oracle
```

`finalFreeze.json` hashes these files and the retained task manifests invoke them. No archive member contains their exact bytes under another name. All four originals still exist under `/tmp/codingSessionV3/`, matching their freeze hashes. `packageEvidence.py` filters out extensionless files. The report's non-hermetic warning covers external environments/dependencies, but does not disclose these missing experiment-owned entry points. Archive/member hashes are valid; they cannot establish that intended files were included. Publication needs packaging correction or explicit disclosure; nothing changed during this audit.

## Verified

The 16 draw aggregates and all 72 implementation records in `results.json` match archived sharedFinal metrics. All eight final report table rows and reported percentage reductions match. Independently parsed every whole patch with read-only `git apply --numstat -z`; per-file counts and shared category totals agree. All 72 saved patch hashes match original run records and cleanup entries. All 72 invocation-audit hashes match retained invocations.

Both final reviewers' 303 completed-command log hashes match their records. Their frozen acceptance, original-native and selected maintained checks each total 48 passes. All 24 supplemental result cells and 27 shared command-log hashes match; original controls are root 0/2, zero 0/2, work 8/8. The negative overall verdict is honest: neither draw passes production churn, and supplements expose completeness defects. Historical rejected draws, blocked mutation testing and limitations remain disclosed. Three tuningOne Elixir original agent exits/durations remain null, not inferred from reruns.

Runtime skill exactly matches frozen candidateThree SHA-256 `57cc21ce6ded5cc772232dfa87225d1880dd533bfa65f02921d8b9c2e656d2b6`: 2,642 bytes, 362 words, 17 lines, valid expected frontmatter. Archived main/PR profiles match their pinned Git versions. README, preScript.ts and old skill report match origin/main. Tracked changes are confined to the skill; untracked publication files are confined to extras/codingSessionV3.

Archive SHA-256 is `103866ca4b9f0d1718e089d7c2e470f1bd52cc56edf3b20b35798a953ce822ab`; 19,200,163 compressed bytes; 1,663 regular UTF-8 members. All 1,662 manifest hashes/sizes verified, with the manifest itself covered by archive SHA. No unsafe paths, symlinks, source worktrees, .git, dependencies/binaries, .env/credential files or full Ponytail profile marker found. Common GitHub/API/private-key/AWS/Telegram/Slack/JWT/credential-URL scans found no matches; pattern scans are not proof of exhaustive secret absence. Ponytail comparison outputs correctly remain. `archiveAudit.json.uncompressedBytes` intentionally excludes the 264,565-byte member manifest; total member payload is 217,317,597 bytes, not a corruption finding.

All 72 recorded worktrees and their registrations are absent. Original Atlas, Beer Game and Matato checkouts are clean at recorded commits. Ponytail checkout and both loose profiles, including `/tmp/necessaryEvaluation/versions/ponytail.md`, are absent. Cleanup driver verifies live patches before each removal; cleanup hashes match retained patches. `pi list` and active settings show only matato-pi and pi-rtk-optimizer. Inspected configured active locations; no active Ponytail reference found. Installed runtime's old report has only a historical Ponytail comparison reference, not installation. Historical results/archives are retained intentionally.

Suggested future PR title: **Coding-session V3 experiment: smaller skill, unmet completeness gate**. Do not imply proven superiority.

## Verification commands

Run from `/home/leon/.t3/worktrees/matato-pi/t3-eefce132`:

```sh
(cd extras/codingSessionV3 && sha256sum -c evidence.sha256)
sha256sum skills/coding-session/SKILL.md
wc -c -w -l skills/coding-session/SKILL.md
git diff --exit-code origin/main -- README.md skills/coding-session/scripts/preScript.ts skills/coding-session/report/evaluation.md
git diff --check
pi list
```

Read-only archive integrity, freeze omissions and reported aggregates:

```sh
python - <<'PY'
import hashlib, json, pathlib, tarfile
root = pathlib.Path('extras/codingSessionV3')
results = json.loads((root / 'results.json').read_text())
with tarfile.open(root / 'evidence.tar.gz') as archive:
    members = archive.getmembers()
    names = {entry.name for entry in members}
    manifest = json.load(archive.extractfile('memberManifest.json'))
    assert len(members) == len(names) == 1663
    assert names == {entry['path'] for entry in manifest} | {'memberManifest.json'}
    for entry in members:
        path = pathlib.PurePosixPath(entry.name)
        assert entry.isfile() and not path.is_absolute() and '..' not in path.parts
    for entry in manifest:
        data = archive.extractfile(entry['path']).read()
        assert len(data) == entry['bytes']
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
    freeze = json.load(archive.extractfile('finalFreeze.json'))['sha256']
    print('Missing frozen files:', sorted(set(freeze) - names))
    metrics = json.load(archive.extractfile('reviews/sharedFinal/metrics.json'))
    for draw in results['draws']:
        for category in ['production', 'tests', 'combined']:
            assert draw[category] == metrics['byDraw'][draw['draw']][draw['arm']][category]
    patches = [name for name in names if name.endswith('/changes.patch')]
    assert len(patches) == 72
    print('Verified member hashes, draw aggregates and 72 retained patches')
PY
```

Read-only cleanup-state verification:

```sh
python - <<'PY'
import json, os, pathlib, subprocess
record = json.loads(pathlib.Path('extras/codingSessionV3/cleanup.json').read_text())
paths = [entry['path'] for entry in record['removedWorktrees']]
paths += [record['removedPonytailCheckout']] + record['removedPonytailProfiles']
assert len(record['removedWorktrees']) == 72
assert not [path for path in paths if os.path.lexists(path)]
for repo, expected in record['sourceCheckouts'].items():
    def git(*args):
        return subprocess.check_output(['git', '--no-optional-locks', '-C', repo, *args], text=True)
    assert git('status', '--porcelain') == expected['status'] == ''
    assert git('rev-parse', 'HEAD').strip() == expected['head']
    assert '/tmp/codingSessionV3/worktrees' not in git('worktree', 'list', '--porcelain')
print('72 worktrees absent, Ponytail checkout/profiles absent, three source projects clean')
PY
```
