import { afterEach, beforeEach, test } from 'bun:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { createMemoryBlock, findMemoryRooms, findMemoryTopicsById, unlinkMemoryItemTopic, type CreateMemoryBlockInput } from 'candidateRoot/src/storage/memoryBlock'
import { migrateStorageDatabase, withDatabaseConnection } from 'candidateRoot/src/storage/database'
import { memoryRoom, memoryTopic, memoryTopicRoom, memoryItem, memoryItemTopic } from 'candidateRoot/src/storage/schema'

let storagePath = ''
let seed: ReturnType<typeof createMemoryBlock>

const metadata = (name: string) => ({ name, summary: `${name} summary`, keywords: [name, '保存'] })
const makeInput = (): CreateMemoryBlockInput => ({
  rooms: [metadata('newRoom')],
  topics: [{ ...metadata('newTopic'), roomNames: ['newRoom', 'oldRoom'] }],
  item: { title: 'new item', content: 'full content\n保存', summary: 'item summary', keywords: ['one', '保存'], topics: [{ name: 'newTopic' }] },
})
const snapshot = () => withDatabaseConnection((database) => ({
  rooms: database.select().from(memoryRoom).all(),
  topics: database.select().from(memoryTopic).all(),
  roomLinks: database.select().from(memoryTopicRoom).all(),
  items: database.select().from(memoryItem).all(),
  itemLinks: database.select().from(memoryItemTopic).all(),
}))
const roomId = (): number => {
  const room = seed.rooms[0]
  assert(room)
  return room.id
}
const topicId = (): number => {
  const topic = seed.topics[0]
  assert(topic)
  return topic.id
}
const rejectsAtomically = (input: CreateMemoryBlockInput, kind: 'room' | 'topic', reference: string): void => {
  const before = snapshot()
  assert.throws(() => createMemoryBlock(input), new RegExp(`(?=.*${kind})(?=.*${reference})`, 'i'))
  assert.deepEqual(snapshot(), before, 'rejection must roll back all five memory tables')
  const recovered = createMemoryBlock(makeInput())
  assert.equal(recovered.item.title, 'new item', 'a failed transaction must not poison later calls')
}

beforeEach(async () => {
  storagePath = await mkdtemp(path.join(tmpdir(), 'memoryFixture'))
  process.env.MATATO_TEST_STORAGE_PATH = storagePath
  withDatabaseConnection(migrateStorageDatabase)
  seed = createMemoryBlock({
    rooms: [metadata('oldRoom'), metadata('otherRoom')],
    topics: [{ ...metadata('oldTopic'), roomNames: ['oldRoom'] }, { ...metadata('otherTopic'), roomNames: ['otherRoom'] }],
    item: { title: 'old item', content: 'original', summary: 'original summary', keywords: ['original'], topics: [{ name: 'oldTopic' }] },
  })
})
afterEach(async () => { await rm(storagePath, { recursive: true, force: true }) })

test('missing room name rejects instead of dropping one edge of a mixed request', () => {
  const input = makeInput()
  const topic = input.topics[0]
  assert(topic)
  topic.roomIds = [roomId()]
  topic.roomNames = ['newRoom', 'missingRoom']
  rejectsAtomically(input, 'room', 'missingRoom')
})
test('case mismatched room name is unresolved', () => {
  const input = makeInput()
  const topic = input.topics[0]
  assert(topic)
  topic.roomNames = ['OldRoom']
  rejectsAtomically(input, 'room', 'OldRoom')
})
test('missing numeric room identifies its reference and rolls back', () => {
  const input = makeInput()
  const topic = input.topics[0]
  assert(topic)
  topic.roomIds = [roomId(), 987654]
  rejectsAtomically(input, 'room', '987654')
})
test('zero room ID is not silently filtered out', () => {
  const input = makeInput()
  const topic = input.topics[0]
  assert(topic)
  topic.roomIds = [0]
  rejectsAtomically(input, 'room', '0')
})
test('late missing topic name rolls back newly created rooms, topics, item and links', () => {
  const input = makeInput()
  input.item.topics.push({ name: 'missingTopic' })
  rejectsAtomically(input, 'topic', 'missingTopic')
})
test('case mismatched topic name is unresolved', () => {
  const input = makeInput()
  input.item.topics = [{ name: 'OldTopic' }]
  rejectsAtomically(input, 'topic', 'OldTopic')
})
test('invalid explicit topic ID cannot fall back to a valid name', () => {
  const input = makeInput()
  input.item.topics = [{ name: 'oldTopic', id: 876543 }]
  rejectsAtomically(input, 'topic', '876543')
})
test('zero explicit topic ID cannot fall back or disappear', () => {
  const input = makeInput()
  input.item.topics = [{ name: 'oldTopic', id: 0 }]
  rejectsAtomically(input, 'topic', '0')
})
test('valid explicit topic ID remains authoritative over a stale name', () => {
  const input = makeInput()
  input.item.topics = [{ id: topicId(), name: 'staleName' }, { id: topicId(), name: 'otherTopic' }]
  const result = createMemoryBlock(input)
  const topics = findMemoryTopicsById({ topicIds: seed.topics.map((topic) => topic.id) })
  assert.deepEqual(topics.find((topic) => topic.id === topicId())?.items.map((item) => item.id), [seed.item.id, result.item.id])
  assert.equal(topics.find((topic) => topic.name === 'otherTopic')?.items.length, 0)
})
test('new and persisted names/IDs resolve together and overlapping references deduplicate', () => {
  const before = snapshot()
  const input = makeInput()
  const topic = input.topics[0]
  assert(topic)
  topic.roomIds = [roomId(), roomId()]
  topic.roomNames = ['oldRoom', 'newRoom', 'newRoom']
  input.item.topics = [{ name: 'oldTopic' }, { name: 'oldTopic', id: topicId() }, { name: 'newTopic' }, { name: 'newTopic' }]
  const result = createMemoryBlock(input)
  const createdTopic = result.topics[0]
  const createdRoom = result.rooms[0]
  assert(createdTopic && createdRoom)
  assert.deepEqual(new Set(createdTopic.roomIds), new Set([roomId(), createdRoom.id]))
  const after = snapshot()
  assert.equal(after.roomLinks.length - before.roomLinks.length, 2)
  assert.equal(after.itemLinks.length - before.itemLinks.length, 2)
  assert.deepEqual(after.rooms.filter((row) => row.id !== createdRoom.id), before.rooms)
  assert.deepEqual(after.topics.filter((row) => row.id !== createdTopic.id), before.topics)
  assert.deepEqual(after.items.filter((row) => row.id !== result.item.id), before.items)
  assert.deepEqual(after.roomLinks.filter((row) => row.topicId !== createdTopic.id), before.roomLinks)
  assert.deepEqual(after.itemLinks.filter((row) => row.itemId !== result.item.id), before.itemLinks)
  assert.equal(result.item.content, input.item.content)
  assert.deepEqual(result.item.keywords, input.item.keywords)
  assert.equal(result.item.summary, input.item.summary)
  assert.equal(result.rooms[0]?.summary, 'newRoom summary')
  assert.deepEqual(result.topics[0]?.keywords, ['newTopic', '保存'])
  assert.equal(findMemoryRooms().find((room) => room.id === createdRoom.id)?.topicIds.includes(createdTopic.id), true)
  assert.deepEqual(findMemoryTopicsById({ topicIds: [createdTopic.id] })[0]?.items, [result.item])
  unlinkMemoryItemTopic({ itemId: result.item.id, topicId: createdTopic.id })
  assert.deepEqual(findMemoryTopicsById({ topicIds: [createdTopic.id] })[0]?.items, [])
  assert.equal(findMemoryTopicsById({ topicIds: [topicId()] })[0]?.items.length, 2)
})
test('omitted optional room lists and an unlinked item remain legitimate', () => {
  const input = makeInput()
  input.rooms = []
  input.topics = [metadata('newTopic')]
  input.item.topics = []
  const result = createMemoryBlock(input)
  assert.deepEqual(result.rooms, [])
  assert.deepEqual(result.topics[0]?.roomIds, [])
  assert.equal(result.item.title, 'new item')
  assert.deepEqual(snapshot().itemLinks.map((row) => row.itemId), [seed.item.id])
})
test('empty creation lists still allow linking an item to persisted topics by name', () => {
  const input = makeInput()
  input.rooms = []
  input.topics = []
  input.item.topics = [{ name: 'oldTopic' }]
  const result = createMemoryBlock(input)
  assert.deepEqual(result.rooms, [])
  assert.deepEqual(result.topics, [])
  assert.equal(findMemoryTopicsById({ topicIds: [topicId()] })[0]?.items.at(-1)?.id, result.item.id)
})
