from pathlib import Path
import json
import sys

scripts = Path('/home/leon/workspace/projects/matato-pi/extras/codingSessionV5/scripts')
sys.path.insert(0, str(scripts))
from measureTrial import aggregate, compressed, lineChanges, loc

root = Path(__file__).parent
rows = json.loads((root / 'evidenceSummary.json').read_text())
lines = ['### Runtime and communication', '', '| Patch | Seconds | Turns/tools | Input/output/cache-read/total tokens | Pi USD | Final words | Density |', '|---|---:|---:|---|---:|---:|---:|']
for row in rows:
    tokens = row['usage']['tokens']
    reply = row['finalSummary'].encode()
    density = compressed(reply) / len(reply)
    lines.append(f"| {row['label']} {row['case']} | {row['agent']['seconds']:.3f} | {row['audit']['turns']}/{row['audit']['toolStarts']} | " + '/'.join(str(tokens[key]) for key in ['input', 'output', 'cacheRead', 'totalTokens']) + f" | {row['usage']['piReportedCostUsd']['total']:.7f} | {row['audit']['replyWords']} | {density:.3f} |")
lines.extend(['', '### Delivered size', '', 'Each cell reports `add/delete/churn; addedBytes/deletedBytes; resultBytes; physical/nonblank/code LOC; files; rawDEFLATE-addedBytes`.', '', '| Patch | Production | Maintained test/support code | Snapshots | Combined frozen |', '|---|---|---|---|---|'])
normalized = []
for row in rows:
    inventory = json.loads((root / 'inventory.json').read_text())
    run = next(item for item in inventory if item['label'] == row['label'] and item['path'].endswith('/' + row['case']))
    patch = (Path(run['path']) / 'evidence/changes.patch').read_bytes()
    additions = {}
    for chunk in patch.split(b'diff --git ')[1:]:
        path = chunk.splitlines()[0].split(b' b/')[1].decode()
        added, deleted = lineChanges(b'diff --git ' + chunk)
        additions[path] = added
        item = next(item for item in row['measurement']['files'] if item['path'] == path)
        assert len(deleted) == item['deletedBytes']
        assert len(added.splitlines()) == item['added']
        assert len(deleted.splitlines()) == item['deleted']
    files = row['measurement']['files']
    for item in files:
        path = Path(run['path']) / 'workspace' / item['path']
        data = str(path.readlink()).encode() if path.is_symlink() else path.read_bytes()
        assert len(data) == item['resultBytes'] and loc(data) == item['afterLoc']
        assert len(additions[item['path']]) == item['addedBytes']
    groups = {
        'production': [item for item in files if item['category'] == 'production' or item['path'] == 'manual_deps'],
        'support': [item for item in files if item['category'] in ['tests', 'fixtures']],
        'snapshots': [item for item in files if item['category'] == 'snapshots'],
        'combined': files,
    }
    values = {name: aggregate(items, b''.join(additions[item['path']] for item in items)) for name, items in groups.items()}
    assert values['combined'] == row['measurement']['totals']['combined']
    cells = []
    for value in values.values():
        after = value['afterLoc']
        cells.append(f"{value['added']}/{value['deleted']}/{value['added'] + value['deleted']}; {value['addedBytes']}/{value['deletedBytes']}; {value['resultBytes']}; {after['physical']}/{after['nonblank']}/{after['code']}; {value['files']}; {value['compressedAddedBytes']}")
    lines.append(f"| {row['label']} {row['case']} | " + ' | '.join(cells) + ' |')
    normalized.append({'label': row['label'], 'case': row['case'], 'totals': values, 'finalDensity': compressed(row['finalSummary'].encode()) / len(row['finalSummary'].encode())})
(root / 'metricTables.md').write_text('\n'.join(lines) + '\n')
(root / 'normalizedMetrics.json').write_text(json.dumps(normalized, indent=2) + '\n')
print('Verified current public workspace file sizes, added bytes and combined metrics; saved metricTables.md and normalizedMetrics.json')
