#!/usr/bin/env python3
"""Compile the real data package using Go overlays; never edit its files."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

repoPath = Path(sys.argv[1]).resolve()
fixtureCases = [
    ("quotedRecords", 'isin,name,currency\r\nAU1,"Aurora, Capital",EUR\r\nAU2,"A ""quoted"" name",USD\r\nAU3,"two\r\nlines",GBP\r\n', 20,
     [{"Isin": "AU1", "Name": "Aurora, Capital", "Currency": "EUR"},
      {"Isin": "AU2", "Name": 'A "quoted" name', "Currency": "USD"},
      {"Isin": "AU3", "Name": "two\nlines", "Currency": "GBP"}], False),
    ("spacesAndBlankLines", 'isin,name,currency\n\n  AU1, spaced name , EUR  \n\nAU2,plain,USD\n', 1,
     [{"Isin": "  AU1", "Name": " spaced name ", "Currency": " EUR  "}], False),
    ("longRecord", 'isin,name,currency\nAU1,' + 'x' * 70000 + ',EUR\n', 1,
     [{"Isin": "AU1", "Name": 'x' * 70000, "Currency": "EUR"}], False),
    ("prefixBeforeMalformed", 'isin,name,currency\nAU1,valid,EUR\nAU2,"unterminated,USD\n', 1,
     [{"Isin": "AU1", "Name": "valid", "Currency": "EUR"}], False),
    ("longTailBeyondLimit", 'isin,name,currency\nAU1,valid,EUR\nAU2,' + 'x' * 70000 + ',USD\n', 1,
     [{"Isin": "AU1", "Name": "valid", "Currency": "EUR"}], False),
    ("unterminatedQuote", 'isin,name,currency\nAU1,valid,EUR\nAU2,"unterminated,USD\n', 2, [], True),
    ("shortRecord", 'isin,name,currency\nAU1,short\n', 10, [], True),
    ("wideRecord", 'isin,name,currency\nAU1,name,EUR,extra\n', 10, [], True),
    ("zeroLimit", 'isin,name,currency\nAU1,"unterminated\n', 0, [], False),
    ("negativeLimit", 'isin,name,currency\nAU1,"unterminated\n', -3, [], False),
    ("headerOnly", 'isin,name,currency\r\n', 4, [], False),
    ("emptyFile", '', 4, [], False),
    ("plainRecords", 'isin,name,currency\nAU1,one,EUR\nAU2,two,USD\n', 7,
     [{"Isin": "AU1", "Name": "one", "Currency": "EUR"}, {"Isin": "AU2", "Name": "two", "Currency": "USD"}], False),
]
goTest = '''package data

import (
    "encoding/json"
    "os"
    "reflect"
    "testing"
)

func TestIsinCsvBehavior(t *testing.T) {
    var expectation struct {
        Limit int
        Rows []Isin
        WantError bool
    }
    if err := json.Unmarshal([]byte(os.Getenv("isinExpectation")), &expectation); err != nil {
        t.Fatal(err)
    }
    rows, err := LoadISINs(expectation.Limit)
    if expectation.WantError {
        if err == nil { t.Fatalf("malformed CSV must return an error, got %d rows", len(rows)) }
        return
    }
    if err != nil { t.Fatalf("valid requested prefix failed: %v", err) }
    if len(rows) == 0 && len(expectation.Rows) == 0 { return }
    if !reflect.DeepEqual(rows, expectation.Rows) {
        t.Fatalf("decoded rows differ: got count=%d, want count=%d; first rows: %.180v / %.180v", len(rows), len(expectation.Rows), rows, expectation.Rows)
    }
}
'''
failedCases = []
with tempfile.TemporaryDirectory(prefix="isinCsvOracle") as tempPath:
    scratchPath = Path(tempPath)
    testPath = scratchPath / "oracleRecords_test.go"
    testPath.write_text(goTest)
    csvPath = scratchPath / "isins.csv"
    overlayPath = scratchPath / "overlay.json"
    overlayPath.write_text(json.dumps({"Replace": {
        str(repoPath / "commons/data/oracleRecords_test.go"): str(testPath),
        str(repoPath / "commons/data/isins.csv"): str(csvPath),
    }}))
    for caseName, csvText, limit, rows, wantError in fixtureCases:
        print(f"\n=== {caseName} ===", flush=True)
        csvPath.write_bytes(csvText.encode())
        environment = {**os.environ, "GOWORK": "off", "GOPROXY": "off", "GOSUMDB": "off",
                       "isinExpectation": json.dumps({"Limit": limit, "Rows": rows, "WantError": wantError})}
        result = subprocess.run(["go", "test", "-overlay", str(overlayPath), "./data", "-run", "^TestIsinCsvBehavior$", "-count=1", "-v"],
                                cwd=repoPath / "commons", env=environment, timeout=60)
        if result.returncode:
            failedCases.append(caseName)
print(f"\nFailed scenarios: {failedCases}")
sys.exit(bool(failedCases))
