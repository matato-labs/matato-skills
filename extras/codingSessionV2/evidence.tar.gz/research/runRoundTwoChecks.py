#!/usr/bin/env python3
"""Review-only runner; never writes candidate code. Logs exact commands and exits."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
logs = root / 'research/reviewRoundTwoLogs'
logs.mkdir(exist_ok=True)
py = str(root / 'runs/codingFinal/sourceBatchReads/atlas/.venv/bin/python')
cases = ['sourceBatchReads', 'isinCsvRecords', 'scheduleTimeZones', 'pathEarlyExit']
jobs = []
for variant in ['base', 'ponytailFinal', 'codingFinal']:
    for case in cases:
        repo = root / ('base' if variant == 'base' else 'runs/' + variant) / case
        for suite in ['oracles', 'supplemental']:
            script = root / 'research' / suite / (case + '.py')
            if script.exists():
                jobs.append((f'{suite}-{variant}-{case}', [sys.executable, str(script), str(repo)], root, {}))
        if case == 'sourceBatchReads':
            jobs.append((f'sql-{variant}', [py, str(root / 'research/supplemental/sourceSqlWorkPortable.py'), str(repo)], root, {}))
        if variant == 'base':
            continue
        if case in ['sourceBatchReads', 'pathEarlyExit']:
            jobs.append((f'native-{variant}-{case}', [str(repo / 'atlas/.venv/bin/python'), '-m', 'pytest', 'tests/test_graph_navigation.py', '-q'], repo / 'atlas', {'PYTHONPATH':'src'}))
        elif case == 'isinCsvRecords':
            jobs.append((f'native-{variant}-{case}', ['go', 'test', './data', '-count=1', '-v'], repo / 'commons', {'GOWORK':'off','GOPROXY':'off','GOSUMDB':'off'}))
        else:
            for zone in ['Asia/Tokyo', 'UTC', 'America/Los_Angeles']:
                jobs.append((f'native-{variant}-{case}-{zone.replace("/", "-")}', ['bun', 'test', 'worker/scheduler.test.ts', 'src/automationConfig.test.ts'], repo, {'TZ':zone}))

def run(job):
    name, cmd, cwd, env = job
    try:
        p = subprocess.run(cmd, cwd=cwd, env={**os.environ, **env}, capture_output=True, timeout=300)
        output = p.stdout + p.stderr
        rc = p.returncode
    except subprocess.TimeoutExpired as e:
        output, rc = (e.stdout or b'') + (e.stderr or b'') + b'\nTIMEOUT\n', 124
    (logs / (name + '.log')).write_bytes(('COMMAND ' + json.dumps(cmd) + '\nCWD ' + str(cwd) + '\nENV ' + json.dumps(env) + '\nEXIT ' + str(rc) + '\n').encode() + output)
    print(name, rc, flush=True)
    return {'name':name, 'exit':rc}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(run, jobs))
(logs / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
