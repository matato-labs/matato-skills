#!/usr/bin/env python3
"""Measure real repository queries, rather than equating file-port calls with all SQL."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile

repo = Path(sys.argv[1]).resolve()
text = '''from unittest.mock import patch
import pytest
from tests.test_graph_navigation import graph, driver
from atlas.persistence.navigation import navigation_reader
from atlas.services.navigation import NavigationService

@pytest.mark.parametrize("key", ["file", "run"])
@pytest.mark.parametrize("size", [1, 10])
def test_real_sql_work(graph, key, size):
    with navigation_reader("Local", None) as reader:
        statements = []
        driver(reader).set_trace_callback(statements.append)
        with patch.object(reader, "file", wraps=reader.file) as indexed:
            rows = NavigationService(reader).sources([key] * size, 1, None)["sources"]
        driver(reader).set_trace_callback(None)
    assert all(row["status"] == "ok" for row in rows)
    selects = [sql for sql in statements if sql.lstrip().upper().startswith("SELECT")]
    metadata = sum("FROM graph_files" in sql for sql in selects)
    verification = sum("JOIN graph_files" in sql for sql in selects)
    print(f"SQL_WORK key={key} nodes={size} selects={len(selects)} file_metadata_queries={metadata} verification_queries={verification}", flush=True)
    assert indexed.call_count == 1
'''
with tempfile.TemporaryDirectory(prefix="sourceSqlWork") as d:
    path = Path(d) / "test_sql_work.py"
    path.write_text(text)
    env = {**os.environ, "PYTHONPATH": os.pathsep.join([str(repo / "atlas"), str(repo / "atlas/src")])}
    result = subprocess.run([str(repo / "atlas/.venv/bin/python"), "-m", "pytest", "-q", "-s", str(path)],
                            cwd=repo / "atlas", env=env, timeout=60)
sys.exit(result.returncode)
