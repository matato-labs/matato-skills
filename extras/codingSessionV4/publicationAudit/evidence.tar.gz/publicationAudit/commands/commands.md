# Publication-auditor commands

Executed in the bound `codingSessionV4Experiment` worktree unless scripts specify owned audit cwd. No models, implementation runs, repairs, cleanup, commits, PR or merge.

```sh
python /home/leon/.cache/codingSessionV4Owned/publicationPrep/packageEvidence.py selfCheck
python /home/leon/.cache/codingSessionV4Owned/publicationPrep/packageEvidence.py inventory
python /home/leon/.cache/codingSessionV4Owned/publicationAudit/scanInputs.py
python /home/leon/.cache/codingSessionV4Owned/publicationAudit/auditPins.py
python /home/leon/.cache/codingSessionV4Owned/publicationAudit/auditMetrics.py
```

An initial read-only pin/metric/scan pass preceded the final sequence above. The final selfCheck created a new synthetic fixture directory and therefore changed the selfCheck metadata hash; final scans/approval bind the later `1ac1a4c1...` manifest, not the earlier `53b0804a...` provisional inventory. No real archive existed before approval.

Read-only inline Python additionally inspected all 78 FinalTwo records' schemas/environment key names, walked 2,710 stdout/stderr metadata references against the selected paths, compared 1,001 frozen run/input records to the final member manifest, independently hashed 1,172 safe original target files, verified the two known preexisting user edits, and checked audit-script line/function bounds. Their exact observed data are in `scans/`. No excluded private/auth/config/raw stream was opened; explicit Git/config skips remain reported.

Approval was written from actual current Pi identity, exact independent scanner hash, clean scan/pin/metric reports and final candidateMembers hash, then:

```sh
python /home/leon/.cache/codingSessionV4Owned/publicationPrep/packageEvidence.py package --approval /home/leon/.cache/codingSessionV4Owned/publicationAudit/approval.json
python /home/leon/.cache/codingSessionV4Owned/publicationPrep/packageEvidence.py verify
python /home/leon/.cache/codingSessionV4Owned/publicationAudit/verifyArchive.py
```

All returned exit0. Per-command logs retained here. Independent verifier streams every member, rechecks all bytes/paths/modes/metadata and pin hashes, rescans content, checks the exact approved manifest and external checksums, without extraction or preparer imports. No archive input changed after approval. Final audit/report copies are outside the selected archive root, so do not require or create archive self-hash cycles.
