# Ponytail compact repeat

Implemented all six frozen briefs independently, in their listed order. Used only `/tmp/codingSessionV2/profiles/ponytail.md`, default/full, as the coding profile. Read each available local `AGENTS.md` and searched callers before changing shared behavior. No delegation, other profiles, prior results, or research reviews were consulted.

Production changes remain within each brief's allowedScope. Additional edits are maintained tests and reviewed path snapshots. No README, embedded CSV, shared/original source, external oracle, Git configuration, or parent files changed. No commit or push. Diffs remain in the six candidate repositories.

All required external oracles and scheduler additionalAcceptance pass on final candidates. Raw command output is in `checks/`.

## Command context

Commands below use this arm as `$ROOT`:

```sh
ROOT=/tmp/codingSessionV2/runs/ponytailCompactRepeat
```

For native Atlas checks, linked each candidate's `atlas/.venv` to `/home/leon/workspace/projects/atlas/atlas/.venv`. Every Python execution against a candidate used `PYTHONPATH=src` from its `atlas/` directory, or `PYTHONPATH=atlas/src` from its repository root, so imports select candidate source. Dependency links are ignored, not source diffs.

## sourceBatchReads

Changed `atlas/src/atlas/services/navigation.py` and `navigation_source.py`. One request-local dictionary shares verification status and verified bytes by eligible path, including failures. Excerpt/span selection remains per node; single-source calls do not share state. Extended `atlas/tests/test_graph_navigation.py` using its existing persisted graph fixture to check reads, failures, independent spans, and new bytes/indexed hashes on another call.

```text
sources call -> per-path verification -> per-node excerpt
next call   -> fresh verification
```

```sh
python /tmp/codingSessionV2/research/oracles/sourceBatchReads.py "$ROOT/sourceBatchReads"
# PASS; final output: checks/sourceBatchReads-final-oracle.log

cd "$ROOT/sourceBatchReads/atlas"
PYTHONPATH=src .venv/bin/python -m pytest tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py -q
PYTHONPATH=src .venv/bin/python -m pytest -q
PYTHONPATH=src .venv/bin/ruff check .
PYTHONPATH=src .venv/bin/pyright
# ALL PASS

cd "$ROOT/sourceBatchReads"
PYTHONPATH=atlas/src atlas/.venv/bin/python -m atlas report --f .
# PASS
```

Logs: `source-tests.log`, `source-all-tests.log`, `source-lint.log`, `source-types.log`, `source-report.log`. An initial pyright invocation before linking `.venv` could not resolve installed packages; the linked-environment rerun passes. No persistence or CLI changes were needed.

## isinCsvRecords

Changed only production `commons/data/isin_loader.go`. Standard `encoding/csv` replaces physical-line scanning. A small reader-based internal helper makes actual record parsing testable without changing embedded data. Header field count is unrestricted; data records require exactly three fields. The loop checks the limit before the next record read. Added `commons/data/isin_loader_test.go` for quoted commas/quotes/multiline text, CRLF, whitespace, large names, malformed records, empty inputs, limits, and embedded-data loading.

```sh
gofmt -w "$ROOT/isinCsvRecords/commons/data/isin_loader.go" "$ROOT/isinCsvRecords/commons/data/isin_loader_test.go"
python /tmp/codingSessionV2/research/oracles/isinCsvRecords.py "$ROOT/isinCsvRecords"
# PASS; checks/isinCsvRecords-final-oracle.log

cd "$ROOT/isinCsvRecords/commons"
go test ./data
# PASS; checks/isin-tests.log
go test ./...
# FAIL in untouched packages; checks/isin-all-tests.log
```

The broad suite reports model test compilation errors involving UUIDs/removed fields, cache ordering assumptions, and existing logger/vet diagnostics in `sintropy/stream_client.go`. These are outside scope and were left unchanged. No new CSV parser or dependency was needed.

## scheduleTimeZones

Added `timezone?: string` to `src/automation.ts`; changed `worker/scheduler.ts` to pass that optional zone to Croner and factories. Enabled jobs validate explicit zones through `Intl.DateTimeFormat` inside existing atomic candidate construction, before factory invocation. Disabled jobs stay inert. Stored configuration already preserves the field through its spread; no config or session naming change was necessary. Extended `worker/scheduler.test.ts` for zone propagation and invalid-zone rollback with injected factories.

```sh
python /tmp/codingSessionV2/research/oracles/scheduleTimeZones.py "$ROOT/scheduleTimeZones"
python /tmp/codingSessionV2/research/finalOracles/scheduleFactoryContract.py "$ROOT/scheduleTimeZones"
# BOTH PASS; checks/scheduleTimeZones-final-oracle.log, schedule-factory-final.log

cd "$ROOT/scheduleTimeZones"
bunx prettier --write src/automation.ts worker/scheduler.ts worker/scheduler.test.ts
bun test worker/scheduler.test.ts worker/watcher.test.ts src/automation.test.ts src/automationConfig.test.ts
# PASS; checks/schedule-focused-tests.log
bun test
# BLOCKED by missing Pi packages in unrelated test imports; checks/schedule-tests.log
bun run check
# BLOCKED: tsc executable absent from linked dependencies; checks/schedule-types.log
bunx eslint src/automation.ts worker/scheduler.ts worker/scheduler.test.ts
# BLOCKED: missing @eslint/js; checks/schedule-lint.log

/home/leon/workspace/projects/matato-pi/node_modules/.bin/tsc --noEmit --strict --skipLibCheck --target esnext --module preserve --moduleResolution bundler --allowImportingTsExtensions --typeRoots /home/leon/workspace/projects/matato-pi/node_modules/@types --types bun src/automation.ts worker/scheduler.ts worker/scheduler.test.ts
# PASS, scoped typecheck using installed compiler/types; checks/schedule-focused-types.log
```

No timezone conversion implementation, global timezone setting, or dependency was added; Croner handles daylight-saving transitions and non-hour offsets.

## pathEarlyExit

Changed `atlas/src/atlas/services/navigation.py` and `navigation_walk.py`. Path traversal supplies an optional stop target; context does not. The walk stops after admitting the target edge within budgets, before later neighbors, fetch-limit bookkeeping, or subsequent expansions. An already-present start target bypasses expansion entirely. Existing admission, edge ordering, route reconstruction, and external boundaries remain intact.

Extended `atlas/tests/test_graph_navigation.py` to instrument adjacency and verify budget-edge completion, start-equals-target, and unchanged context cutoffs. Updated only affected found-path payloads in the eight existing coffee navigation snapshots. The snapshot review asserts unchanged routes, path edges, and filters, unchanged non-path responses, and retained graph/boundary/diagnostic rows drawn from the old payload. `checks/path-snapshot-review.log` records the reviewed graph reductions; snapshots retain their existing compact serialization.

```sh
python /tmp/codingSessionV2/research/oracles/pathEarlyExit.py "$ROOT/pathEarlyExit"
# PASS; checks/pathEarlyExit-final-oracle.log

cd "$ROOT/pathEarlyExit/atlas"
PYTHONPATH=src .venv/bin/python -m pytest tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py -q
PYTHONPATH=src .venv/bin/python -m pytest -q
PYTHONPATH=src .venv/bin/ruff check .
PYTHONPATH=src .venv/bin/pyright
# ALL PASS

cd "$ROOT/pathEarlyExit"
PYTHONPATH=atlas/src atlas/.venv/bin/python -m atlas report --f .
# PASS
```

Logs: `path-tests.log`, `path-all-tests.log`, `path-lint.log`, `path-types.log`, `path-report.log`. The first native run identified expected snapshot changes and an incorrectly ordered `PathRequest` in the new test; corrected the test and reviewed snapshots before the passing reruns. Storage queries and public requests were not changed.

## pollProcessContract

Changed only production `commons/sintropy/messages.go`. Polling now uses the receiver, IDs fill their allocated positions, and `errors.Join` preserves processor and failed-acknowledgement causes when both fail. Existing receiver acknowledgement methods, payloads, and empty-poll backoff remain unchanged. Added `commons/sintropy/messages_test.go` with a configured HTTP transport checking URL, forwarded request, ordered duplicate IDs, processor sequencing, success/failure endpoints, no-op cases, and retained error causes.

```sh
gofmt -w "$ROOT/pollProcessContract/commons/sintropy/messages.go" "$ROOT/pollProcessContract/commons/sintropy/messages_test.go"
python /tmp/codingSessionV2/research/finalOracles/pollProcessContract.py "$ROOT/pollProcessContract"
# PASS; checks/pollProcessContract-final-oracle.log

cd "$ROOT/pollProcessContract/commons"
go test -vet=off ./sintropy
go test -race -vet=off ./sintropy
# BOTH PASS; checks/poll-tests.log, poll-race.log
```

Used the requested `-vet=off` for existing unrelated blockers. No unrelated client method changes or HTTP wrappers were needed.

## preScriptIsolation

Changed only production `src/worker/preScript.ts`. Awaiting `module.run()` keeps existing mutex ownership and overrides alive through settlement. Saved environment values retain `undefined`; restoration tests explicitly for absence rather than truthiness. Existing Bun/process assignments and deletions remain paired. No new mutex, queue, telemetry, import-cache behavior, or shell execution implementation was needed.

Added `src/worker/preScript.test.ts` for concurrent asynchronous overrides, exact empty/absent restoration through both environment APIs, original run errors, synchronous/asynchronous/import failures, queue recovery, missing modules, cache reuse, skip results, and shell isolation.

```sh
python /tmp/codingSessionV2/research/finalOracles/preScriptIsolation.py "$ROOT/preScriptIsolation"
# PASS; checks/preScriptIsolation-final-oracle.log

cd "$ROOT/preScriptIsolation"
bun test src/worker/preScript.test.ts
# PASS; checks/preScript-tests.log
bun test
# BLOCKED by missing dependencies in unrelated test imports; checks/preScript-all-tests.log
bun run typecheck
# BLOCKED: missing bun type definitions; checks/preScript-types.log
bun run lint
# BLOCKED: missing @eslint/js; checks/preScript-lint.log

/home/leon/workspace/projects/matato/node_modules/.bin/tsc --noEmit --strict --skipLibCheck --target esnext --module preserve --moduleResolution bundler --allowImportingTsExtensions --typeRoots /home/leon/workspace/projects/matato/node_modules/@types --types bun src/worker/preScript.ts src/worker/preScript.test.ts
# PASS, scoped typecheck using installed compiler/types; checks/preScript-focused-types.log

/home/leon/workspace/projects/matato/node_modules/.bin/prettier --no-config --semi false --single-quote --trailing-comma all --write src/worker/preScript.test.ts
# PASS; avoids unavailable optional config plugins, retains project TS style
```

The broad Bun suite cannot load packages including Drizzle, Croner, Pi, Elysia, and React in this minimally linked candidate. No package manifests or lockfiles were changed to address unrelated dependencies.

## Final verification and limits

Reran all six external oracle commands and scheduler additionalAcceptance after final edits: all exit successfully. Ran `git -C <candidate> diff --check` for every candidate: all pass. Reviewed production diffs against allowedScope; new regression files remain untracked as requested, alongside tracked diffs.

Skipped unrelated dashboard builds/tests/lint and did not run auto-fixing checks outside allowed files. Broad TypeScript test/lint/project checks remain dependency-blocked; the changed TypeScript and maintained tests pass scoped typechecks and focused Bun tests. The unrelated broad Go failures remain unresolved. No functional limitation was deliberately introduced.
