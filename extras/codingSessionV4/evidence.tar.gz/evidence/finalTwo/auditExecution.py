"""Operational audit only. Never execute model/check commands or score implementation quality."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re

root = Path('/tmp/codingSessionV4')
evidence = root / 'evidence/finalTwo'


def save(name, value):
    (evidence / name).write_text(json.dumps(value, indent=2) + '\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text()) if path.exists() else None


def concurrent(intervals):
    events = [(datetime.fromisoformat(record[key]).timestamp(), delta) for record in intervals for key, delta in [('startedAt', 1), ('finishedAt', -1)]]
    active, maximum = 0, 0
    for timestamp, delta in sorted(events):
        active += delta
        maximum = max(maximum, active)
    return maximum


def inspect(manifest, arm):
    case = json.loads(Path(manifest).read_text())['cases'][0]
    folder = root / 'runs/finalTwo' / arm / case['id']
    result = load(folder / 'result.json')
    invocation = load(folder / 'invocation.json')
    profile = load(folder / 'profileAudit.json')
    record = {'case': case['id'], 'arm': arm, 'resultAvailable': result is not None, 'publicationReady': False}
    for key in ['status', 'seconds', 'agentSeconds', 'setupExit', 'agentExit', 'acceptanceExit', 'nativeExit', 'error']:
        record[key] = result.get(key) if result else None
    execution = {}
    for metadata in sorted(folder.glob('*.json')):
        data = load(metadata)
        if isinstance(data, dict) and 'timeoutSeconds' in data:
            execution[metadata.stem] = {key: data[key] for key in ['exit', 'seconds', 'timeoutSeconds', 'timedOut', 'startedAt', 'finishedAt']}
    record['execution'] = execution
    argv = invocation['argv'] if invocation else []
    required = ['--print', '--no-session', '--no-extensions', '--no-skills', '--no-prompt-templates', '--no-context-files', '--no-mcp', '--no-approve', '--offline', '--unshare-all', '--cap-drop']
    options = {'--mode': 'json', '--model': 'openai-codex/gpt-6.1-sol', '--thinking': 'high', '--tools': 'read,bash,edit,write'}
    record['runtimeInvocationValid'] = bool(result and invocation and all(flag in argv for flag in required) and all(flag in argv and argv[argv.index(flag) + 1] == value for flag, value in options.items()) and result['piVersion'] == '1.1.0' and execution.get('agent', {}).get('timeoutSeconds') == 900)
    snapshot = folder / 'currentProfile.md'
    record['actualProfileBytes'] = snapshot.stat().st_size if snapshot.exists() else None
    record['actualProfileSha256'] = digest(snapshot) if snapshot.exists() else None
    record['profileHashesMatch'] = bool(result and profile and profile['profileExpectedSha256'] == result['profileSha256'] == record['actualProfileSha256'] == digest(Path(result['profilePath'])))
    record['profileReadValid'] = bool(profile and record['profileHashesMatch'] and all(profile[key] for key in ['firstToolIsProfileRead', 'profileReadSucceeded', 'profileContentsObserved']))
    record['profileAudit'] = profile
    record['completionValid'] = bool(profile and profile['malformedRecords'] == 0 and profile['observedModels'] == ['openai-codex/gpt-6.1-sol'] and profile['observedThinking'] == ['high'] and profile['settled'] and not profile['aborted'] and profile['finalStopReason'] == 'stop' and record['agentExit'] == 0)
    record['promptSha256'] = digest(folder / 'prompt.txt') if (folder / 'prompt.txt').exists() else None
    priorPrompt = root / 'runs/finalOne' / arm / case['id'] / 'prompt.txt'
    record['promptMatchesFinalOne'] = record['promptSha256'] == digest(priorPrompt) if priorPrompt.exists() and record['promptSha256'] else None
    record['checkCapsValid'] = all(stage['timeoutSeconds'] == 120 for name, stage in execution.items() if name in ['acceptance', 'native']) and all(name in execution for name in ['acceptance', 'native'])
    tracePath = folder / 'toolTrace.jsonl'
    traces = [json.loads(line) for line in tracePath.read_text().splitlines()] if tracePath.exists() else []
    succeeded = {event['id'] for event in traces if event['event'] == 'tool_execution_end' and not event.get('isError', False)}
    record['successfulLocalInstructionReads'] = [event for event in traces if event['event'] == 'tool_execution_start' and event['name'] == 'read' and Path(event.get('path', '')).name in ['AGENTS.md', 'CLAUDE.md'] and event['id'] in succeeded]
    record['privateConfig'] = invocation['environment']['PI_CODING_AGENT_DIR'] if invocation else None
    priorInvocation = load(root / 'runs/finalOne' / arm / case['id'] / 'invocation.json')
    normalize = lambda value: re.sub(r'/private/[0-9a-f]{16}/', '/private/<fresh>/', value.replace('/finalOne/', '/<draw>/').replace('/finalTwo/', '/<draw>/'))
    record['invocationMatchesFinalOneApartFromFreshPaths'] = bool(invocation and priorInvocation and normalize(json.dumps(invocation, sort_keys=True)) == normalize(json.dumps(priorInvocation, sort_keys=True)))
    pythonAliasEquivalent = Path('/usr/bin/python').resolve() == Path('/usr/bin/python3').resolve()
    priorNormalized = normalize(json.dumps(priorInvocation, sort_keys=True)).replace('"/usr/bin/python"', '"/usr/bin/python3"')
    record['invocationMatchesFinalOneWithEquivalentPythonAlias'] = bool(invocation and priorInvocation and pythonAliasEquivalent and normalize(json.dumps(invocation, sort_keys=True)) == priorNormalized)
    mounts = load(root / 'dependencyMounts.json')
    previous = load(root / 'evidence/finalOne/preflightComplete.json')
    sourceCommon = next(item['sourceCommonReadonlyDependency'] for item in previous['results'] if item['case'] == case['id'])
    expectedMounts = [Path(case['repo']).resolve(), Path(sourceCommon)]
    for path in case.get('dependencyPaths', []) + mounts.get(case['repo'], []):
        expectedMounts.extend([Path(path), Path(path).resolve()])
    readOnly = {argv[index + 1] for index, value in enumerate(argv) if value == '--ro-bind'}
    record['readOnlySourceAndDependenciesValid'] = bool(invocation and all(str(path) in readOnly for path in expectedMounts))
    return record


def main():
    schedule = load(evidence / 'schedule.json')
    records = [inspect(manifest, arm) for manifest, arm in schedule['jobs']]
    assert len(records) == 16
    save('runtimeAudits.json', records)
    pairing = {}
    for record in records:
        pairing.setdefault(record['case'], []).append(record['promptSha256'])
    save('promptPairing.json', {case: {'hashes': values, 'fourArmsByteIdentical': len(values) == 4 and None not in values and len(set(values)) == 1} for case, values in pairing.items()})
    returned = [load(path) for path in sorted(evidence.glob('*.returned.json'))]
    agents = [record['execution']['agent'] for record in records if 'agent' in record['execution']]
    settings = {'records': len(records), 'resultsAvailable': sum(record['resultAvailable'] for record in records), 'runtimeInvocationValid': sum(record['runtimeInvocationValid'] for record in records), 'profileReadValid': sum(record['profileReadValid'] for record in records), 'completionValid': sum(record['completionValid'] for record in records), 'uniquePrivateConfigs': len({record['privateConfig'] for record in records if record['privateConfig'] is not None}), 'runnerReturns': len(returned), 'maxConcurrentTrials': concurrent(returned), 'maxConcurrentAgents': concurrent(agents), 'ledger': load(root / 'control/budget.json')['reserved'], 'noRetries': True, 'qualityScoringPerformed': False, 'independentReviewRequired': True, 'stopNoFurtherImplementations': True, 'publicationReady': False}
    if returned:
        settings['drawWallSeconds'] = round((max(datetime.fromisoformat(record['finishedAt']) for record in returned) - min(datetime.fromisoformat(record['startedAt']) for record in returned)).total_seconds(), 3)
    for key in ['promptMatchesFinalOne', 'checkCapsValid', 'invocationMatchesFinalOneApartFromFreshPaths', 'invocationMatchesFinalOneWithEquivalentPythonAlias', 'readOnlySourceAndDependenciesValid']:
        settings[key] = sum(record[key] is True for record in records)
    settings['stageExits'] = {stage: {str(code): sum(record[stage] == code for record in records) for code in sorted({record[stage] for record in records if record[stage] is not None})} for stage in ['agentExit', 'acceptanceExit', 'nativeExit']}
    save('operationalSummary.json', settings)
    artifacts = {str(path): digest(path) for path in sorted((root / 'runs/finalTwo').rglob('*')) if path.is_file() and not path.is_symlink()}
    save('runArtifactHashes.json', artifacts)
    lines = ['# finalTwo execution report', '', 'Second predeclared draw, not a replacement or resampling of finalOne. Exactly 16 scheduled identities; ledger 35 → ' + str(settings['ledger']) + '. STOP: no further implementations or candidate revisions. No repair, retry, model probe, original-source/shared-dependency/README edit, quality scoring or winner selection.', '', 'Frozen original-base preflight reused from finalOne. Same disk-owned writable storage and logical symlink scheme; bounded 64 MiB allocation succeeded. Filesystem headroom recorded; effective Btrfs quota remains unavailable. Frozen caps: agent 900s, acceptance/native 120s. No unsandboxed fallback.', '', 'Runtime invocation/profile-read audits: ' + str(settings['runtimeInvocationValid']) + '/' + str(settings['profileReadValid']) + ' of 16. Distinct private configs: ' + str(settings['uniquePrivateConfigs']) + '. Maximum simultaneous trials/agents: ' + str(settings['maxConcurrentTrials']) + '/' + str(settings['maxConcurrentAgents']) + '. Draw wall seconds: ' + str(settings.get('drawWallSeconds')) + '.', '', '| Arm | Case | Agent | Acceptance | Native | Status | Agent seconds |', '|---|---|---:|---:|---:|---|---:|']
    for record in records:
        lines.append('| ' + ' | '.join(str(record[key]) if record[key] is not None else 'unavailable' for key in ['arm', 'case', 'agentExit', 'acceptanceExit', 'nativeExit', 'status', 'agentSeconds']) + ' |')
    lines += ['', 'Exact invocation spelling difference: this coordinator used /usr/bin/python3 rather than finalOne /usr/bin/python; both resolve to the same hashed /usr/bin/python3.14. All 16 invocations otherwise match finalOne after normalizing fresh draw/private paths. No launcher bytes or runtime settings changed.', '', 'Missing observations remain unavailable, never inferred as exit0. Original timeout/failure records remain authoritative; no longer diagnostics executed here. Agent completion is separate from acceptance/native status. Exact invocations, stage timings/timeouts/exits, snapshotted profile bytes/hashes and successful observed reads are retained in run records and runtimeAudits.json.', '', 'Integrity: see integrity.json and before/after inventories for frozen inputs (including extensionless launchers), executables, original source/Git metadata and historical outputs. CandidateTwo remains 2630 bytes / 6efa072c53b7e83aae7a17f4f60a45efd113cd8dc927c1c1ebf815ec3cd25643.', '', 'Independent review required. No implementation quality/completeness winner is asserted. Frozen suffix classification labels extensionless setup as other: reviewer must classify setup as production symmetrically, retaining original metrics. Raw credentials/streams stay private; publicationReady false.']
    (evidence / 'report.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps(settings, indent=2))


if __name__ == '__main__':
    main()
