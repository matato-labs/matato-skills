import { afterEach, beforeEach, expect, test } from 'bun:test'
import { mkdtemp, rm } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'

const caseRoot = process.env.codingSessionCaseRoot!
const { runPreScript } = await import(path.join(caseRoot, 'src/worker/preScript.ts')) as typeof import('../base/src/worker/preScript')
type RunnerInput = Parameters<typeof runPreScript>[0]
type Gate = { started: ReturnType<typeof Promise.withResolvers<void>>; done: ReturnType<typeof Promise.withResolvers<void>> }
type Control = { gates: Map<string, Gate>; events: Array<string> }
const names = ['caseValue', 'caseEmpty', 'caseAbsent', 'caseUnrelated']
let skillPath = ''
let previous: Map<string, string | undefined>
let control: Control

beforeEach(async () => {
  previous = new Map(names.map((name) => [name, process.env[name]]))
  process.env.caseValue = 'outside'
  process.env.caseEmpty = ''
  delete process.env.caseAbsent
  delete process.env.caseUnrelated
  skillPath = await mkdtemp(path.join(os.tmpdir(), 'preScriptOracle'))
  await Bun.write(path.join(skillPath, 'control.ts'), `
export const gates = new Map<string, { started: ReturnType<typeof Promise.withResolvers<void>>; done: ReturnType<typeof Promise.withResolvers<void>> }>()
export const events: Array<string> = []
`)
  control = await import(path.join(skillPath, 'control.ts')) as Control
})

afterEach(async () => {
  for (const [name, value] of previous) {
    if (value === undefined) delete process.env[name]
    else process.env[name] = value
  }
  await rm(skillPath, { recursive: true, force: true })
})

const inputFor = async (name: string, source: string): Promise<RunnerInput> => {
  const scriptPath = path.join(skillPath, `${name}.ts`)
  await Bun.write(scriptPath, source)
  return {
    scriptPath,
    skillPath,
    environment: { caseValue: name, caseEmpty: 'insideEmpty', caseAbsent: 'insideAbsent' },
    label: name,
  }
}

const expectRestored = (): void => {
  for (const environment of [Bun.env, process.env]) {
    expect(environment.caseValue).toBe('outside')
    expect(Object.hasOwn(environment, 'caseEmpty')).toBe(true)
    expect(environment.caseEmpty).toBe('')
    expect(Object.hasOwn(environment, 'caseAbsent')).toBe(false)
  }
}

const gatedInput = async (name: string, reject: boolean = false): Promise<RunnerInput> => {
  control.gates.set(name, { started: Promise.withResolvers<void>(), done: Promise.withResolvers<void>() })
  return inputFor(name, `
import { gates, events } from './control.ts'
const name = ${JSON.stringify(name)}
const evaluated = Bun.env.caseValue
events.push(name + 'Evaluation')
export const run = async () => {
  const gate = gates.get(name)!
  events.push(name)
  gate.started.resolve()
  await gate.done.promise
  const observed = { evaluated, bun: Bun.env.caseValue, process: process.env.caseValue, empty: Bun.env.caseEmpty, absent: process.env.caseAbsent }
  ${reject ? "throw new Error('asyncFailure:' + observed.bun)" : 'return observed'}
}
`)
}

test('async reads retain overlay through settlement and restore exact prior state', async () => {
  const input = await gatedInput('first')
  const pending = runPreScript(input)
  await control.gates.get('first')!.started.promise
  const during = process.env.caseValue
  control.gates.get('first')!.done.resolve()
  const result = await pending
  expect(during).toBe('first')
  expect(result).toEqual({ evaluated: 'first', bun: 'first', process: 'first', empty: 'insideEmpty', absent: 'insideAbsent' })
  expectRestored()
})

test('overlapping TypeScript calls wait before module evaluation and async execution', async () => {
  const first = await gatedInput('first')
  const second = await gatedInput('second')
  const firstPending = runPreScript(first)
  await control.gates.get('first')!.started.promise
  const secondPending = runPreScript(second)
  await Bun.sleep(25)
  const beforeRelease = [...control.events]
  control.gates.get('first')!.done.resolve()
  const firstResult = await firstPending
  await control.gates.get('second')!.started.promise
  control.gates.get('second')!.done.resolve()
  const secondResult = await secondPending
  expect(beforeRelease).toEqual(['firstEvaluation', 'first'])
  expect(control.events).toEqual(['firstEvaluation', 'first', 'secondEvaluation', 'second'])
  expect(firstResult).toMatchObject({ evaluated: 'first', bun: 'first', process: 'first' })
  expect(secondResult).toMatchObject({ evaluated: 'second', bun: 'second', process: 'second' })
  expectRestored()
})

test('async rejection restores overlay, retains error, and releases queued work', async () => {
  const failing = await gatedInput('failing', true)
  const pending = runPreScript(failing).then(() => 'resolved', (error: Error) => error.message)
  await control.gates.get('failing')!.started.promise
  const next = await inputFor('recovery', 'export const run = () => ({ value: Bun.env.caseValue })')
  const recovery = runPreScript(next)
  control.gates.get('failing')!.done.resolve()
  const result = await pending
  expect(await recovery).toEqual({ value: 'recovery' })
  expect(result).toBe('asyncFailure:failing')
  expectRestored()
})

test('synchronous throw, import failure, and missing file restore and release', async () => {
  for (const [name, source] of [
    ['syncFailure', "export const run = () => { throw new Error('syncFailure') }"],
    ['importFailure', "throw new Error('importFailure'); export const run = () => null"],
  ]) {
    const input = await inputFor(name, source)
    await expect(runPreScript(input)).rejects.toThrow(name)
    expectRestored()
  }
  const missing = await inputFor('missing', 'export const run = () => null')
  await rm(missing.scriptPath)
  await expect(runPreScript(missing)).rejects.toThrow()
  expectRestored()
  expect(await runPreScript(await inputFor('recovery', 'export const run = () => 7'))).toBe(7)
  expectRestored()
})

test('JSON results and unrelated environment writes survive restoration', async () => {
  for (const [index, value] of [null, false, 0, '', [1, 'two'], { skip: true, reason: 'nothing' }].entries()) {
    const input = await inputFor(`value${index}`, `export const run = () => { process.env.caseUnrelated = 'kept'; return ${JSON.stringify(value)} }`)
    expect(await runPreScript(input)).toEqual(value)
    expectRestored()
    expect(process.env.caseUnrelated).toBe('kept')
  }
})

test('shell execution stays independent while TypeScript is awaiting', async () => {
  const gated = await gatedInput('first')
  const pending = runPreScript(gated)
  await control.gates.get('first')!.started.promise
  const scriptPath = path.join(skillPath, 'shell.sh')
  await Bun.write(scriptPath, `printf '{"value":"%s","cwd":"%s"}' "$caseValue" "$PWD"`)
  const shell = runPreScript({ scriptPath, skillPath, environment: { caseValue: 'shell' }, label: 'shell' })
  const raced = await Promise.race([
    shell.then((value) => ({ completed: true, value })),
    Bun.sleep(1000).then(() => ({ completed: false, value: null })),
  ])
  control.gates.get('first')!.done.resolve()
  await pending
  await shell
  expect(raced).toEqual({ completed: true, value: { value: 'shell', cwd: skillPath } })
  expectRestored()
  await Bun.write(scriptPath, "printf 'shellFailure' >&2; exit 9")
  await expect(runPreScript({ scriptPath, skillPath, environment: {}, label: 'shell' })).rejects.toThrow('shellFailure')
  await Bun.write(scriptPath, "printf 'notJson'")
  await expect(runPreScript({ scriptPath, skillPath, environment: {}, label: 'shell' })).rejects.toThrow('invalid JSON')
})
