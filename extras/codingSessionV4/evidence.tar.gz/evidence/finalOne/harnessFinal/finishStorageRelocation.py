import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import time

root = Path('/tmp/codingSessionV4')
disk = Path('/home/leon/.cache/codingSessionV4Owned')
evidence = disk / 'relocationEvidence'

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            value.update(block)
    return value.hexdigest()

def privateInventory(parent):
    result = {}
    for path in parent.rglob('*'):
        metadata = path.lstat()
        value = stat.S_IFMT(metadata.st_mode), stat.S_IMODE(metadata.st_mode)
        if path.is_symlink():
            value += (os.readlink(path),)
        elif stat.S_ISREG(metadata.st_mode):
            value += (digest(path),)
        result[str(path.relative_to(parent))] = value
    return result

def save(name, data):
    (evidence / name).write_text(json.dumps(data, indent=2) + '\n')

before = privateInventory(root / 'private')
with (disk / 'private/relocationCopy.stdout').open('wb') as output, (disk / 'private/relocationCopy.stderr').open('wb') as errors:
    record = subprocess.run(['rsync', '-a', str(root / 'private') + '/', str(disk / 'private') + '/'], stdout=output, stderr=errors)
assert record.returncode == 0
# Copy logs are new private files, not part of historical inventory.
(disk / 'private/relocationCopy.stdout').unlink()
(disk / 'private/relocationCopy.stderr').unlink()
assert privateInventory(disk / 'private') == before
shutil.rmtree(root / 'private')
(root / 'private').symlink_to(disk / 'private', target_is_directory=True)
shutil.move(str(root / 'control'), str(disk / 'control'))
(root / 'control').symlink_to(disk / 'control', target_is_directory=True)
ledger = {str(p): digest(p) for p in (root / 'control').iterdir() if p.is_file()}
assert ledger == json.loads((evidence / 'ledgerBefore.json').read_text())
for name in ['worktrees', 'runs', 'evidence']:
    target = disk / name / 'finalOne'
    target.mkdir(parents=True, mode=0o700)
    (root / name / 'finalOne').symlink_to(target, target_is_directory=True)
before = json.loads((evidence / 'oldBefore.json').read_text())
after = {path: digest(Path(path)) for path in before}
assert after == before
save('oldAfterRelocation.json', after)
save('ledgerAfter.json', ledger)
save('relocation.json', {'time': time.time(), 'disk': str(disk), 'mode': oct(disk.stat().st_mode & 0o777), 'privateBytesModesLinksAndSpecialFilesUnchanged': True, 'ledgerBytesUnchanged': True, 'ledgerCount': 19, 'initialCopyIssue': 'shutil cross-device copy cannot copy inactive sockets/FIFOs; original remained intact; rsync -a copied special nodes and complete tree verified before deleting old owned storage', 'moved': ['private', 'control'], 'futureSymlinks': ['worktrees/finalOne', 'runs/finalOne', 'evidence/finalOne'], 'originalAuth': 'not opened or modified'})
record = subprocess.run(['df', '-B1', str(disk), '/tmp'], capture_output=True, text=True)
(evidence / 'dfBeforeAllocation.txt').write_text(record.stdout + record.stderr)
allocation = disk / 'syntheticAllocation'
with allocation.open('xb') as stream:
    for number in range(320):
        stream.write(b'X' * 1048576)
    stream.flush()
    os.fsync(stream.fileno())
allocated = allocation.stat()
assert allocated.st_blocks * 512 > 256 * 1024 * 1024
save('allocation.json', {'bytes': allocated.st_size, 'allocatedBytes': allocated.st_blocks * 512, 'fsync': True, 'deletedAfterProof': True})
allocation.unlink()
record = subprocess.run(['df', '-B1', str(disk), '/tmp'], capture_output=True, text=True)
(evidence / 'dfAfterAllocation.txt').write_text(record.stdout + record.stderr)
print('Relocation complete; historical hashes and private tree verified; 320MiB allocated/fsynced/deleted.', flush=True)
