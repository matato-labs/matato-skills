## General notes

- This project is a single Bun project (no workspaces). Source lives under `src/`:
  - `src/agent` — the Matato agent (built on `@earendil-works/pi-coding-agent` + `@earendil-works/pi-ai`)
  - `src/ai` — provider and transcript helpers
  - `src/config` — bootstrap loading from database-backed config and environment variables
  - `src/gateway` — external gateways (e.g. Telegram)
  - `src/worker` — long running entrypoint with `heartbeat`, `coding-session`, `prWatcher`, `telegram` runners
  - `data/` — bootstrap data; `data/config.json` seeds runtime config, `data/environmentVariables.json` seeds environment variables, and `data/agent/skills/` holds the agent skills
- Run scripts from the repository root (e.g. `bun run worker`, `bun test`, `bunx tsc`).
- Do not write comments in the code, I will tell you when I want to document code.
- At the end of each iteration, when there are TypeScript changes, run `bunx tsc` (or `bun run typecheck`) and `bun test` for the affected code before reporting back.
- When a file is to large over 600 lines, it must be split
- Do not implement large functions that passes 100 lines or reach 4 nested levels

Default to using Bun instead of Node.js.

- Use `bun <file>` instead of `node <file>` or `ts-node <file>`
- Use `bun test` instead of `jest` or `vitest`
- Use `bun build <file.html|file.ts|file.css>` instead of `webpack` or `esbuild`
- Use `bun install` instead of `npm install` or `yarn install` or `pnpm install`
- Use `bun run <script>` instead of `npm run <script>` or `yarn run <script>` or `pnpm run <script>`
- Use `bunx <package> <command>` instead of `npx <package> <command>`
- Bun automatically loads .env, so don't use dotenv.
- Always check tests and eslint and typescript, `bun test`, `bun lint` and `bun tsc`

## Testing

Use `bun test` to run tests.

```ts#index.test.ts
import { test, expect } from "bun:test";

test("hello world", () => {
  expect(1).toBe(1);
});
```

### Usage of Zod

- There are dependencies that require Zod, but it's not my intention to use it.
- Use simple types over Zod complex data type annotations.

### General code rules

- Use guard clauses with early returns or throw errors instead of nested code

```ts
// DONT
if (a === b) {
  if (aFunction(a) === 'a value') {
    // some code...
  } else {
    console.log('a log')
  }
} else {
  console.log('another log')
}
// some other code code ...

// DO THIS  INSTEAD
if (a !== b) {
  console.log('a log')
}

const aValue = aFunction(a)
if (aValue !== 'a value') {
  console.log('a log')
}

// some code
// some other code code...
```

- Do not use Type[] to type an array, use `Array<Type>`
- Maintain small functions that are clear to follow
- Do not use classes unless strictly necessary
- Never use `unknown`, `any`, or imprecise placeholder types. Types must be precise. If the correct type cannot be resolved safely from the codebase or context, stop and ask the user for help instead of guessing.
- **DO NOT** do complex manual validations or duplicate TypeScript with runtime type checks. The TypeScript type system MUST be used over programmatic validations for input shapes and field types. If a value is typed as `string`, `number`, an object, or an array, do not add `typeof`, `Array.isArray`, `'property' in value`, or object-shape `if` checks to prove that again.
- Model inputs with precise non-nullable types at the boundary. Transform untyped external data into those types once at the boundary, then rely on the compiler inside the application code.
- Runtime checks are only acceptable for business rules that TypeScript cannot express, such as a remote resource not existing or a domain constraint that depends on runtime state.

```ts
// DONT
type RunJobInput = {
  jobName?: string
  timeoutSeconds?: number
}

const runJob = (input: RunJobInput): void => {
  if (typeof input.jobName !== 'string' || !input.jobName) {
    throw new Error('jobName is required')
  }

  if (typeof input.timeoutSeconds !== 'number') {
    throw new Error('timeoutSeconds is required')
  }

  startJob(input.jobName, input.timeoutSeconds)
}

// DO
type RunJobInput = {
  jobName: string
  timeoutSeconds: number
}

const runJob = (input: RunJobInput): void => {
  startJob(input.jobName, input.timeoutSeconds)
}
```

- **DO NOT** change things you are not asked to, **DO NOT** refactor anything you are not asked to.
- When some code doesn't exist anymore, it's intentional, **DO NOT** bring it back on your own.
- Make types non nullable in Interfaces or Types to avoid null checks

- **DO NOT** use `-` or `_` in names (functions, files, variables), follow the pattern `thisIsAName`

## Configuration and secrets

- Runtime config is stored in the SQLite database under `STORAGE_PATH/agent/matato.sqlite` after first bootstrap. `data/config.json` is only the seed used when the config tables are empty.
- Runtime environment variables are stored in the same database. `data/environmentVariables.json` is only the seed used when the environment variable table is empty.
- `STORAGE_PATH` is the bootstrap location. Deployment resolves it from the database when available and falls back to `data/environmentVariables.json` when the database does not exist yet.
- Manage persisted environment variables with `bun run cli env`. Do not bring back `.env.local` loading for deploy.
- Do not introduce alternative configuration files. Extend the existing database-backed config or environment variable seed flow instead.

## Skills

- When the user asks to modify, add, or review a "skill" in this project, they are always referring to the skills under `data/agent/skills/`. Do not look at `~/.claude/skills/` or other locations.
- Do not add tests that validate the exact contents of a skill file or assert that a skill contains a specific string. Test the behavior produced by the skill instead of locking tests to skill wording.

## Agentic workflows

- Limit the number of programmatic actions when developing an agent.
- Create tools that are passed to the agent to execute actions.
- The Matato agent is built on `@earendil-works/pi-coding-agent` and `@earendil-works/pi-ai`. Do not introduce LangChain or other agent frameworks unless the user explicitly asks.
- Take `src/agent/matatoAgent.ts` as the base when creating new agents.
- Limit the number of string parsings; prefer structured responses instead.
