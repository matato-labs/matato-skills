#!/usr/bin/env python3
"""Package evidence, never Ponytail source/profile or implementation checkouts."""
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT/'research/reviewCompactEvidence.tar.gz'
files = list(ROOT.glob('review*.md')) + list(ROOT.glob('*.json'))
files += list((ROOT/'profiles').glob('coding*.md'))
files += list((ROOT/'patches').glob('*/*.patch'))
files += list((ROOT/'runs').glob('*/result.md'))
files += [p for p in (ROOT/'research').rglob('*') if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts and not p.name.startswith('reviewCompactEvidence')]
files = sorted(set(files))
assert len([p for p in files if p.suffix == '.patch']) == 70
assert len([p for p in files if p.name == 'result.md']) == 14
assert not any(p.is_symlink() or 'node_modules' in p.parts or p == ROOT/'profiles/ponytail.md' or p.is_relative_to(ROOT/'ponytail') for p in files)
manifest = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with tarfile.open(OUT, 'w:gz') as archive:
    for path in files:
        archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
with tarfile.open(OUT) as archive:
    assert archive.getnames() == list(manifest)
    for member in archive:
        assert member.isfile()
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == manifest[member.name]
(ROOT/'research/reviewCompactEvidenceManifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
digest = hashlib.sha256(OUT.read_bytes()).hexdigest()
(ROOT/'research/reviewCompactEvidence.sha256').write_text(digest+'  research/reviewCompactEvidence.tar.gz\n')
print(json.dumps(dict(archive=str(OUT.relative_to(ROOT)), members=len(files), bytes=OUT.stat().st_size, sha256=digest, excluded=['ponytail/', 'profiles/ponytail.md', 'candidate/base checkouts', 'dependencies/caches']), indent=2))
