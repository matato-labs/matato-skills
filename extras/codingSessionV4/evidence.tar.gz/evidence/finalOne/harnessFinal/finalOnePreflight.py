from concurrent.futures import ThreadPoolExecutor
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

from auditTrial import publishExecution
from runTrial import makeWorktree
from measureTrial import git
from sandboxTrial import root, shell

evidence = root / 'evidence/finalOne'
manifests = [root / path for path in ['research/python/manifest.json', 'research/typescript/tuning/manifest.json', 'research/typescript/reserve/manifest.json', 'research/additional/reserve/manifest.json']]

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def hashes():
    paths = [*root.glob('*.py'), *root.glob('*.json'), *root.joinpath('profiles').glob('*.md')]
    for manifest in manifests:
        paths += [path for path in manifest.parent.iterdir() if path.is_file()]
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(set(paths))}

class Quota(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint64) for name in ['blockHard', 'blockSoft', 'currentSpace', 'inodeHard', 'inodeSoft', 'currentInodes', 'blockTime', 'inodeTime']] + [('valid', ctypes.c_uint32)]

def quota(path):
    descriptor = os.open(path, os.O_RDONLY)
    libc = ctypes.CDLL(None, use_errno=True)
    data = Quota()
    result = libc.syscall(443, descriptor, 0x80000700, os.getuid(), ctypes.byref(data))
    error = ctypes.get_errno()
    os.close(descriptor)
    return {'exit': result, 'errno': error, 'values': {name: getattr(data, name) for name, field in Quota._fields_}}

def preflight(manifest):
    case = json.loads(manifest.read_text())['cases'][0]
    folder = evidence / 'preflight' / case['id']
    folder.mkdir(parents=True)
    private = root / 'private' / uuid.uuid4().hex[:16]
    private.mkdir(mode=0o700)
    worktree = folder / 'owned'
    base, common = makeWorktree(case, worktree, private, folder)
    for name in ['runtime', 'config']:
        (private / name).mkdir()
    auth = private / 'auth.json'
    auth.write_text('{}\n')
    auth.chmod(0o400)
    mounts = json.loads((root / 'dependencyMounts.json').read_text())
    sourceCommon = Path(os.fsdecode(git(Path(case['repo']), ['rev-parse', '--git-common-dir'])).strip())
    sourceCommon = (Path(case['repo']) / sourceCommon).resolve()
    spec = {'worktree': worktree, 'repo': Path(case['repo']).resolve(), 'common': common, 'oracle': manifest.parent, 'runtime': private / 'runtime', 'config': private / 'config', 'auth': auth, 'profile': root / 'profiles/v3.md', 'profileSnapshot': root / 'profiles/v3.md', 'pi': Path(shutil.which('pi')).resolve(), 'dependencies': [Path(p) for p in case.get('dependencyPaths', []) + mounts.get(case['repo'], [])] + [sourceCommon]}
    command = f'''test "$(pwd -P)" = '{worktree}'
python3 -c 'from pathlib import Path; assert Path.cwd() == Path("{worktree}"); assert Path("{worktree}").resolve() == Path("{worktree}")'
test ! -w '{case['repo']}'
test ! -w '{sourceCommon}/index'
test ! -w '{common}'
test ! -w '{manifest}'
test ! -e /home/leon/.pi/agent/auth.json
test ! -e /tmp/codingSessionV4/runs
test ! -e /tmp/codingSessionV4/profiles/candidateTwo.md
for name in AGENTS.md CLAUDE.md; do if [ -e "$name" ]; then test -r "$name"; fi; done
printf scratch > '{manifest.parent}/scratchProof'
rm '{manifest.parent}/scratchProof'
test -r '{sourceCommon}/HEAD'
printf 'logical cwd/Path.resolve, source/dependency/Git readonly, phase scratch writable, hidden auth/rivals verified\\n'
'''
    record = shell(spec, 'confinement', command, private, 30)
    publishExecution(record, 'confinement', folder, [])
    assert record['exit'] == 0, case['id'] + ' confinement'
    for index, command in enumerate(case['setupCommands']):
        label = f'setup{index}'
        record = shell(spec, label, command.replace('{root}', str(worktree)), private, 120)
        publishExecution(record, label, folder, [])
        assert record['exit'] == 0, case['id'] + ' ' + label
    exits = {}
    for label, key in [('acceptance', 'checkCommand'), ('native', 'nativeCommand')]:
        record = shell(spec, label, case[key].replace('{root}', str(worktree)), private, 120)
        publishExecution(record, label, folder, [])
        exits[label] = record['exit']
    result = {'case': case['id'], 'base': base, 'exits': exits, 'passed': exits['acceptance'] == 1 and exits['native'] == 0, 'implementationLaunches': 0, 'sourceCommonReadonlyDependency': str(sourceCommon), 'logicalWorktree': str(worktree), 'physicalWorktree': str(worktree.resolve()), 'physicalPrivate': str(private.resolve())}
    save(folder / 'result.json', result)
    print(json.dumps(result), flush=True)
    return result

if __name__ == '__main__':
    before = hashes()
    assert before[str(root / 'profiles/candidateTwo.md')] == '6efa072c53b7e83aae7a17f4f60a45efd113cd8dc927c1c1ebf815ec3cd25643'
    assert (root / 'profiles/candidateTwo.md').stat().st_size == 2630
    save(evidence / 'frozenBefore.json', before)
    save(evidence / 'quotaBefore.json', {str(path): quota(str(path)) for path in [Path('/tmp'), Path('/home/leon/.cache/codingSessionV4Owned')]})
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(preflight, manifests))
    save(evidence / 'frozenAfterPreflight.json', hashes())
    assert hashes() == before
    save(evidence / 'preflightComplete.json', {'passed': all(result['passed'] for result in results), 'results': results, 'implementationLaunches': 0})
    sys.exit(0 if all(result['passed'] for result in results) else 1)
