"""V4 JSONL allowlist extraction; raw streams remain private, never publication inputs."""
import json
from pathlib import Path
import re
from typing import NotRequired, TypedDict

from measureTrial import digest
from sandboxTrial import Execution, currentProfile


class Arguments(TypedDict):
    path: NotRequired[str]
    command: NotRequired[str]
    offset: NotRequired[int]
    limit: NotRequired[int]


class Content(TypedDict):
    type: str
    text: NotRequired[str]


class Message(TypedDict):
    role: str
    content: list[Content]
    provider: NotRequired[str]
    model: NotRequired[str]
    responseModel: NotRequired[str]
    thinkingLevel: NotRequired[str]
    providerThinkingLevel: NotRequired[str]
    stopReason: NotRequired[str]
    errorMessage: NotRequired[str]


class ToolResult(TypedDict):
    content: list[Content]


class Event(TypedDict):
    type: str
    toolCallId: NotRequired[str]
    toolName: NotRequired[str]
    args: NotRequired[Arguments]
    result: NotRequired[ToolResult]
    isError: NotRequired[bool]
    durationMs: NotRequired[float]
    message: NotRequired[Message]
    level: NotRequired[str]
    aborted: NotRequired[bool]


class Trace(TypedDict):
    event: str
    id: str
    name: str
    payloadSha256: str
    payloadBytes: int
    path: NotRequired[str]
    command: NotRequired[str]
    isError: NotRequired[bool]
    durationMs: NotRequired[float]


class Audit(TypedDict):
    events: int
    malformedRecords: int
    toolStarts: int
    toolEnds: int
    firstToolIsProfileRead: bool
    profileReadSucceeded: bool
    profileContentsObserved: bool
    profileExpectedSha256: str
    observedModels: list[str]
    observedThinking: list[str]
    observedResponseModels: list[str]
    finalStopReason: str
    finalError: str
    settled: bool
    aborted: bool
    rawStreamSha256: str
    rawStreamBytes: int
    finalSummarySha256: str


secretPattern = re.compile(
    r'(?i)(?:Bearer\s+\S+|(?:sk|ghp|gho|xoxb|xoxp)[-][A-Za-z0-9_-]{12,}'
    r'|eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+'
    r'|(?:api[_-]?key|access[_-]?token|refresh[_-]?token|password|secret)'
    r'\s*[=:]\s*[\"\']?[^\s\"\']{6,})')
sensitiveCommand = re.compile(
    r'(?i)(auth\.json|/proc/|\benv\b|printenv|credentials|print-api-key|'
    r'print-bearer-token|\btoken\b|\bsecret\b|\bpassword\b|set\s*[+-]x)')


def scrub(text: str, secrets: list[str]) -> str:
    for value in secrets:
        if len(value) >= 8:
            text = text.replace(value, '[REDACTED]')
    return secretPattern.sub('[REDACTED]', text)


def publishExecution(record: Execution, label: str, folder: Path,
                     secrets: list[str]) -> None:
    public = record.copy()
    for field in ['stdout', 'stderr']:
        source = Path(record['stdout'] if field == 'stdout' else record['stderr'])
        target = folder / f'{label}.{field}'
        target.write_text(scrub(source.read_text(errors='replace'), secrets))
        if field == 'stdout':
            public['stdout'] = str(target)
        else:
            public['stderr'] = str(target)
    (folder / f'{label}.json').write_text(scrub(json.dumps(public, indent=2), secrets) + '\n')


def audit(raw: Path, folder: Path, profile: bytes, secrets: list[str]) -> Audit:
    starts, ends, events, malformed = 0, 0, 0, 0
    firstRead, readOk, observed = False, False, False
    readIds: set[str] = set()
    models: set[str] = set()
    thinking: set[str] = set()
    responseModels: set[str] = set()
    finalText, stopReason, finalError = '', '', ''
    settled, aborted = False, False
    expected = profile.decode('utf-8').strip()
    with raw.open('rb') as stream, (folder / 'toolTrace.jsonl').open('x') as output:
        for line in stream:
            try:
                event: Event = json.loads(line)
            except (json.JSONDecodeError, UnicodeDecodeError):
                malformed += 1
                continue
            events += 1
            kind = event['type']
            if kind == 'message_end' and event['message']['role'] == 'assistant':
                message = event['message']
                models.add(message.get('provider', '') + '/' + message.get('model', ''))
                thinking.add(message.get('thinkingLevel', message.get('providerThinkingLevel', 'unreported')))
                finalText = '\n'.join(block.get('text', '') for block in message['content']
                                      if block['type'] == 'text')
                stopReason, finalError = message.get('stopReason', ''), message.get('errorMessage', '')
                if message.get('responseModel'):
                    responseModels.add(message['responseModel'])
            if kind == 'agent_settled':
                settled, aborted = True, event.get('aborted', False)
            if kind == 'thinking_level_changed':
                thinking.add(event['level'])
            if kind not in {'tool_execution_start', 'tool_execution_end'}:
                continue
            trace: Trace = {'event': kind, 'id': event['toolCallId'],
                            'name': event['toolName'], 'payloadSha256': digest(line),
                            'payloadBytes': len(line)}
            if kind == 'tool_execution_start':
                args = event['args']
                path = args.get('path', '')
                isRead = event['toolName'] == 'read' and path == str(currentProfile)
                if starts == 0:
                    firstRead = isRead
                starts += 1
                if isRead:
                    readIds.add(event['toolCallId'])
                if path and not sensitiveCommand.search(path):
                    trace['path'] = scrub(path, secrets)
                command = args.get('command', '')
                if command and not sensitiveCommand.search(command):
                    trace['command'] = scrub(command, secrets)
            else:
                ends += 1
                trace['isError'] = event.get('isError', False)
                trace['durationMs'] = event.get('durationMs', 0)
                if event['toolCallId'] in readIds and not trace['isError']:
                    readOk = True
                    text = '\n'.join(block.get('text', '') for block in event['result']['content'])
                    observed = observed or expected in text
            output.write(json.dumps(trace) + '\n')
    rawBytes = raw.read_bytes()
    safeSummary = scrub(finalText, secrets)
    (folder / 'finalSummary.txt').write_text(safeSummary)
    result: Audit = {'events': events, 'malformedRecords': malformed, 'toolStarts': starts,
                     'toolEnds': ends, 'firstToolIsProfileRead': firstRead,
                     'profileReadSucceeded': readOk, 'profileContentsObserved': observed,
                     'profileExpectedSha256': digest(profile), 'observedModels': sorted(models),
                     'observedThinking': sorted(thinking), 'observedResponseModels': sorted(responseModels),
                     'finalStopReason': stopReason, 'finalError': scrub(finalError, secrets),
                     'settled': settled, 'aborted': aborted, 'rawStreamSha256': digest(rawBytes),
                     'rawStreamBytes': len(rawBytes),
                     'finalSummarySha256': digest(safeSummary.encode())}
    (folder / 'profileAudit.json').write_text(json.dumps(result, indent=2) + '\n')
    return result
