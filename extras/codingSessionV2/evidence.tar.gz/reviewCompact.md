# Independent final review — compact profile and replication

## Verdict and disposition

**The requested overall win is not demonstrated.** Coding has larger production and combined patches in both complete pairs: **137/636 vs 120/612** production/combined churn first, **135/739 vs 125/507** replication. A narrower benefit does replicate: coding transforms a repeated source file once per request, rather than once per consumer. This costs more retained memory for distinct files. No measured general speedup, universal resource saving, or production benchmark superiority follows.

**No incorrect required behavior found in the 24 candidates.** All frozen original/additional acceptance, existing supplements and focused native checks pass. This is acceptance-domain evidence, not proof of arbitrary-input equivalence or complete repository coverage. Coding's additional maintained tests often protect distinct contracts; the excess cannot honestly be dismissed as bloat.

Stop here, as instructed. There are **70 saved case patches** across all rounds. Do not continue optional stopping until a preferred winner appears, choose per-case outputs, or revive round three's seven-line combined advantage as the final result. The parent-directed experiment/skill-refinement PR is appropriate **only with this no-overall-win label**, not a superiority/production-benchmark claim. Ponytail removal is the user's separate instruction, not a scientific consequence of these results. Unlike earlier reviews' evidence-contingent removal advice, this review recognizes that independent instruction; **I have not removed Ponytail**.

No profile, candidate implementation, parent-project file, brief, oracle or saved patch edited; no delegation, commits, PR or deletion. Added this report and review evidence under `research/`. No further skill wording or task-specific solutions proposed.

## Scope, integrity and protocol limits

Read `reviewInitial.md`, `reviewRoundTwo.md`, `reviewRoundThree.md`, `reviewFrozen.md`, current/prior coding profiles, Ponytail profile, all 24 compact source/test diffs, four implementer reports, and relevant production integration/API code. The eight minified snapshot changes per path arm were decoded and compared structurally, not treated as semantically trivial physical lines.

All 24 actual `git diff --binary HEAD` outputs match saved patches after diff-prefix normalization; all numstats match `compactMetrics.json`. HEADs equal the corresponding clean bases; whitespace checks pass; no untracked candidate source escapes accounting. Production changes stay inside each frozen `allowedScope`; no README, production CSV data, dependency manifest or lockfile changed. The clean base commits are Atlas `64017b798a75fccff7d6d545172251851fcef615`, mini-broker `4b1e143abc40f4582d90bfcdc7c55b06d787a934`, scheduler `92ec28467170bb8b520ebe53dea234b7623dec46`, pre-script `4f2b75f73087b5f2c60995629c591dc91a591567`.

The scoped **146-file** input manifest covers changed candidate paths, patches, profiles, briefs/metrics and frozen checks, not whole worktrees/dependencies. It is unchanged after checks, cross-tests, controls and resource observations. Eighteen protected brief/oracle/supplement files also match the prior frozen-review manifest; original selected oracle hashes and all supplemental/final SHA manifests verify. Evidence: `research/reviewCompactLogs/{inputHashes.json,immutability.json,integrity.log,summary.log,hygiene.json,audit.log}`. Handled missing-HEAD-file diagnostics in the audit refer to new test files, not failed assertions.

The supplied fresh-agent, concurrent-pair and no-prior-metrics-peeking protocol is not independently reconstructible from these artifacts. I verify the recorded outputs, not historical blinding or agent independence. Repetition uses the same six tasks; the two newer tasks were holdouts in the preceding frozen phase, **not newly unseen tasks in this phase**. Adaptive earlier task/profile development remains a generalization limitation.

## Exact accounting

Churn = additions + deletions against the common base; net = additions − deletions. Tests include config tests, coffee assertions and snapshot files. Cells are **production / tests / combined churn**.

| Case | Ponytail first | coding first | Ponytail repeat | coding repeat |
|---|---:|---:|---:|---:|
| sourceBatchReads | 26 / 34 / 60 | 43 / 55 / 98 | 30 / 28 / 58 | 42 / 48 / 90 |
| isinCsvRecords | 39 / 44 / 83 | 38 / 55 / 93 | 40 / 46 / 86 | 39 / 50 / 89 |
| scheduleTimeZones | 14 / 93 / 107 | 15 / 72 / 87 | 14 / 45 / 59 | 14 / 83 / 97 |
| pathEarlyExit | 13 / 40 / 53 | 13 / 58 / 71 | 13 / 38 / 51 | 13 / 90 / 103 |
| pollProcessContract | 14 / 111 / 125 | 14 / 115 / 129 | 14 / 95 / 109 | 14 / 163 / 177 |
| preScriptIsolation | 14 / 170 / 184 | 14 / 144 / 158 | 14 / 130 / 144 | 13 / 170 / 183 |
| **Total** | **120 / 492 / 612** | **137 / 499 / 636** | **125 / 382 / 507** | **135 / 604 / 739** |

| Arm | Production added/deleted; net | Tests added/deleted; net | Combined added/deleted; net |
|---|---:|---:|---:|
| Ponytail first | 76/44; +32 | 482/10; +472 | 558/54; +504 |
| coding first | 88/49; +39 | 491/8; +483 | 579/57; +522 |
| Ponytail repeat | 80/45; +35 | 372/10; +362 | 452/55; +397 |
| coding repeat | 82/53; +29 | 592/12; +580 | 674/65; +609 |

Coding minus Ponytail is **+17 production, +7 tests, +24 combined** first; **+10, +222, +232** repeat. Replication coding's smaller production **net** (+29 vs +35) is not smaller production churn. Summed descriptively: **272 vs 245 production, 1,103 vs 874 tests, 1,375 vs 1,119 combined**. Repeated tasks are not twelve independent task samples.

Ignoring blank/comment-only lines and horizontal whitespace, while retaining line boundaries, production/test/combined churn is **114/469/583 vs 125/462/587** first and **113/355/468 vs 127/563/690** repeat. The first combined gap nearly disappears under this proxy; replication does not. Neither physical nor normalized lines measure semantic complexity. No runtime complexity is relocated into test fixtures, another production module or a dependency. Longest changed Python function is 52 lines; largest changed Python file is 479 lines. Details: `verifiedMetrics.json`, `totals.json`, `footprint.json`.

## Checks actually executed

`research/reviewCompactChecks.py checks` reuses the prior frozen runner with **only arm names, metrics filename and log destination changed**. It records **96 entries, all exit zero**, including observations as well as suites. For each arm:

| Frozen check | Result |
|---|---|
| Original source, 5 methods | pass |
| Original CSV, 13 public embedded-data scenarios | pass |
| Original scheduler, 7 tests | pass |
| Original path, 8 methods | pass |
| Poll/process, 6 scenarios | pass |
| Pre-script isolation, 6 tests | pass |
| Scheduler factory contract, 8 tests | pass |
| Earlier source/CSV/scheduler supplements, 3/12/9 | pass |
| Path supplement, 6 methods including 36-budget grid | pass |
| Real-SQL supplement, 4 cases | pass |

The ninth scheduler supplement observes dependency behavior. SQL uses the already-frozen portable interpreter wrapper, without assertion changes.

| Native checks | P first | C first | P repeat | C repeat |
|---|---:|---:|---:|---:|
| Source graph pytest | 49 pass | 50 pass | 48 pass | 51 pass |
| Path graph pytest | 49 pass | 49 pass | 46 pass | 55 pass |
| Coffee navigation, separately in both Python cases | 14 each | 14 each | 14 each | 14 each |
| Go CSV package | pass | pass | pass | pass |
| Go poll/process package | pass | pass | pass | pass |
| Scheduler + config Bun, each of three local zones | 14 pass | 15 pass | 14 pass | 14 pass |
| Direct pre-script Bun | 5 pass | 4 pass | 6 pass | 5 pass |

Native Python runs select actual candidate imports with `PYTHONPATH`, independently confirmed by eight `import-*` logs and module-path assertions. Atlas interpreter is CPython **3.11.16**; standalone launcher **3.14.7**; Go **1.26.1**; Bun **1.4.1**. Scheduler native checks use Asia/Tokyo, UTC and America/Los_Angeles. Go network module resolution is disabled. Native Go uses `-vet=off`; this is not a vet-clean claim, given documented unrelated pre-existing logger diagnostics. Counts are not coverage scores.

### Cross-suites: 20 pass, four explained non-passes

All **24** cross invocations retained, using explicit target Python imports, temporary Go overlays and absolute target Bun imports. **20 pass**. Two first-pair CSV invocations cannot compile because the private helpers differ: `undefined: loadISINs` versus `undefined: readISINs`. This is an injection-seam naming mismatch, not parsing failure; no aliases or assertions were changed to erase it. Both replication CSV cross-suites pass.

The other two non-passes are coding source tests on Ponytail source, one in each pair: each has **two assertion failures**, for valid and unsupported-encoding input, because Ponytail decodes four times where coding asserts once. Verification/read assertions and public statuses agree. This is the real additional transformation guarantee, **not a failure of the frozen verification-only source brief**. All scheduler, path and both new-task cross-suites pass. Logs: `crossResults.json`, `crossRunner.log`, `cross-*.log`; the cross driver itself does not aggregate failures into its process exit.

### Negative controls and maintained regressions

Reran the seven unchanged original/additional checks on clean bases: all fail for expected behavioral reasons, not setup problems. Source: five failing methods; CSV: seven failed scenarios, including the original panic/size/whitespace faults; scheduler: four failures; path: four; poll/process: six; pre-script: five; factory: four. The poll oracle intercepts the default HTTP transport, so its base diagnostic opens no socket.

Also ran **12 native-base diagnostics**: every arm's source, path and direct pre-script tests against actual unchanged base imports. All detect regressions. Source assertion failures are **4/5/3/5**, path **3/4/1/6**, pre-script **5/4/5/5**, in P-first/C-first/P-repeat/C-repeat order. Logs show repeated file work, unwanted expansion/cutoffs, overlapping async runs, and lost empty-string restoration. These are whole-original-source negative controls, **not a mutation score** or proof every assertion is necessary. Native CSV tests cannot run unchanged on the original source because their reader helpers do not exist there; no synthetic base helper was inserted. Native poll base diagnostics were not run; the safe public oracle negative control covers its original failures.

Evidence: `research/reviewCompactControls.py`, `controlResults.json`, `controlRunner.log`, `base-*.log`, `native-base-*.log`. Every check's exact command, cwd, environment override, exit and output is in its named log; positive results are indexed in `results.json`, native/version/import summaries in `summary.log`.

## Semantic and resource audit

### Source batch: reproducible CPU-work reduction, reproducible memory cost

All four preserve containment, pinned-descriptor access, size bounds, hash checks, coordinate decoding, status metadata, excerpt limits, independent spans/pagination/order/duplicates and per-request freshness. AST checks confirm unchanged safety/decoding/excerpt-policy definitions. Public single-source behavior and precedence probes agree: unverified before local safety, changed before invalid encoding, unsupported encoding before missing span. External/pathless inputs exit before file access; duplicate returned line lists remain independently mutable.

```mermaid
flowchart LR
  A[Eligible path per call] --> B[One verification / read / hash]
  B --> P[Ponytail: cached bytes]
  P --> Q[Decode and split per consumer]
  B --> C[coding: cached decoded lines]
  C --> D[Independent consumer excerpts]
  Q --> D
```

For **100 same-file nodes**, each arm does **1 verification / 1 read / 1 hash**. Full transformations are **100/1/100/1** in P-first/C-first/P-repeat/C-repeat order, for both valid and unsupported encoding. Two ten-node encoding-failure calls repeat verification twice and decode **20/2/20/2** times. For a 1,064,960-byte file, 100 duplicates hand **106,496,000 vs 1,064,960 bytes** to decoding in either pair. Eight distinct files cause eight decodes in all arms. Node enrichment, per-node slicing/encoding-size checks and response assembly remain; no 100× runtime claim follows.

| Synthetic traced peak allocations | Each Ponytail arm | Each coding arm |
|---|---:|---:|
| 20,000 ineligible entries | 4,027,664 B | 4,027,664 B |
| Four distinct ~1 MiB, 64-character-line files | 11,595,081 B | 14,363,835 B |
| Eight distinct such files | 15,857,529 B | 22,317,955 B |
| 100 duplicates of one such file | 8,399,171 B | 8,399,171 B |

The eight-file coding peak is **6,460,426 B (~41%) higher**. Existing bounded-read allocation dominates the duplicate-file peak. Returned eight-file allocations are only **6,840/7,232 B**, so whole-file caches do not survive return in this probe. Both retain distinct-file data during the call; the 8 MiB bound is per file, **not a batch memory bound**. These are synthetic `tracemalloc` observations, not RSS or production latency benchmarks.

Real SQLite work remains identical: ten repeated file or symbol keys cause **42 SELECTs**, including **10 node-enrichment file-metadata queries and one verification query**; one node uses six SELECTs. No global SQL deduplication or O(distinct-paths) total-work claim. No extra whole-batch intermediate result pass remains from round two. C-repeat inlines the consumer excerpt body instead of retaining C-first's separate `verified_excerpt`; unchanged public semantics are checked, not inferred from line counts. Evidence: unchanged `sourceResourcesRoundThree.py`, `resources-*`, `sql-*`, `integrity.log`.

### CSV: native reuse and durable parsing regressions in all four

All use strict standard `encoding/csv`, unrestricted header width followed by three-field data, error checks before indexing, and a record limit checked before the next `Read`. All open/close the embedded file in the wrapper, even for nonpositive limits, then return before parsing those limits. No `ReadAll`, trimming, Scanner limit, custom parser, new dependency or data change. Buffered suffix bytes may be prefetched; **record parsing**, not exact byte consumption, is bounded. Positive-prefix algorithms are equivalent over the checked domain; one-line churn differences are layout/declaration differences.

The prior frozen review's three native CSV suites that still passed the original loader are **not the current situation**. All four current arms have a private reader seam and maintained tests for quoted/multiline records, large fields, whitespace, malformed quotes/widths and prefix isolation. First coding has 17 table cases versus Ponytail's 12, including malformed data both within and beyond the prefix, blank input, and quoted-suffix junk. Replication Ponytail loops four malformed tails both inside/outside the prefix; coding uses 12 named cases. These are actual parsing regressions, not only embedded normal-data limits. They do not establish identical coverage, but the old missing-regression finding is addressed in every arm. The external public-API overlays independently establish current correctness; they have not replaced maintained tests.

### Scheduler: shared validation owns both seams

Every arm adds the real optional production field, passes it through the existing factory argument and Croner option, and validates explicit enabled zones in **`buildSchedules` before either factory**. Empty and ordinary bad zones reject with default and zone-agnostic injected factories; candidates stop and old schedules remain usable. Disabled bad jobs remain inert. Existing config spreading and the real worker preserve/use the field. Cron width/mode, DST, fractional offsets, duplicates, monitor checks, overlap across reloads, stop and timer cleanup remain intact.

All arms give identical observed construction counts: default **9 Intl formatters** for valid UTC/Kathmandu, **0** omitted, **1** before bad-zone rejection; injected valid zones use **1**. Boundary validation duplicates some default constructor work, but enforces the required injected-factory policy; removing it on default-only evidence would repeat the earlier gap. Installed Croner remains the scheduling authority; no bespoke timezone arithmetic. Coding's comment and C-repeat's `en` versus `en-US` validation locale do not demonstrate an efficiency advantage.

Maintained coverage differs: P-repeat checks forwarding/injected rollback but adds no real zoned scheduling assertion; coding repeat adds real-default five/six-field DST/fractional-offset checks and stored-config preservation. P-first and coding first both exercise real scheduling through different seams; coding tests explicit empty as well as ordinary-invalid injected zones. External lifecycle/stored-zone checks pass every arm. Extra tests are not automatically redundant native-platform retesting: they also check correct option forwarding and validation ownership. Evidence: `factory-*`, `semantics-*`, scheduler supplements/native logs.

### Path: same bounded BFS, legitimate stronger coding-repeat tests

All reuse the existing BFS/admission budgets/order/parents, passing a target only from `path`. Identity stops without expansion, and admitted discovery exits before later neighbors or speculative fetch-limit bookkeeping. `context` retains the full bounded traversal; external nodes do not expand. Frozen direction/tie/exhaustion/missing-key/budget checks, including the 36-budget grid, pass. A storage call can already have prefetched later rows; no elimination of storage prefetch is claimed.

All **32** revised language snapshots are identical across arms. Per language, exactly one successful response changes only nodes/edges/boundaries, with exact ordered prefixes ending at the route edge and correctly retained external boundaries. Routes, metadata, schema, filters and other responses remain unchanged. Per arm, aggregate graph reduction is **45 nodes and 61 edges**. No dynamic snapshot projection or response-sized expectation adapter is introduced this round.

P-repeat's compact native addition checks completion/identity and continued context cutoffs. Coding repeat adds a branching persisted fixture and explicit in/out/both directions, prior external boundary, no later-node access, budget rejection and external non-expansion. Its **90 vs 38** test churn therefore buys distinct maintained contracts, not proven 52-line waste. First coding likewise explicitly tests prior boundaries and admission limits. There is no production algorithm/reuse advantage here; production churn is 13 in every arm. Evidence: `snapshots.json`, readable `path-*.diff`, native/cross/base logs.

### New Go holdout: identical existing-client and native-error reuse

All four production `messages.go` files are **byte-identical**. Polling uses the configured receiver's existing `poll`/`post`/`doRequest`, acknowledgements reuse the existing endpoints, and underlying request wrapping/typed HTTP errors remain intact. The request passes unchanged; IDs fill one exact-size slice before processing, preserving order/duplicates even if a processor mutates its input. Processing occurs once, then exactly one success/failure acknowledgement; failures/empty polls never process or acknowledge, and the original 100 ms backoff remains. Processor-only failure returns the original error; dual failure uses standard `errors.Join`. No client, retry, error-combination or transport implementation is reinvented.

Tests instrument actual receiver transport/payload/order/error identity. First native suites have six scenarios each; Ponytail additionally times empty backoff, coding mutates processor input and checks typed poll causes. Repeat coding separates real HTTP-status failures from transport failures and tests omitted versus explicit-zero counts; Ponytail's six-scenario suite is smaller but does not cover all those combinations. Coding repeat's **163 vs 95** test lines are partly more coverage and partly separate scenario scaffolding. Cross-passing proves compatible implementations, not that these assertions should be deleted. One exact-size ID slice avoids the original synthetic-empty IDs and append growth; no allocation/throughput benchmark was measured.

### New TypeScript holdout: same lifetime fix, different scaffolding/coverage

P-first, C-first and P-repeat production pre-script files are byte-identical; C-repeat differs only by a saved-environment type alias. All await the original run **inside** the existing nested-finally/module-wide mutex lifetime, save `undefined` distinctly, restore both environment APIs and release the existing queue after import/run failures. Existing cache URL, sync results, shell spawning, skip interpretation, telemetry and public signatures are untouched. No new lock/queue/process abstraction. Required serialization is correctness, not an optional throughput optimization; unrelated environment writers/threads remain outside this process-local protocol.

Maintained tests use real temporary script inputs, not substitute runtime implementations. P-first and C-repeat use explicit gates; C-first uses a short suspension plus a maximum-active sentinel; P-repeat uses suspended concurrent samples. All detect the original async/environment bug on actual base imports. Error identity, recovery and empty/absent restoration are meaningful. P-first/P-repeat also add direct shell/skip/cache assertions; coding first concentrates on all override keys before/after suspension, and coding repeat adds missing-module/cache recovery. Existing caller checks and the external oracle cover preserved shell/skip behavior, but broader integrations were not independently rerun here. The **144 vs 170** first and **170 vs 130** repeat test-line comparison is not a stable complexity advantage in either direction.

## Compact skill guards and size

| Profile | UTF-8 bytes | Whitespace words | Lines |
|---|---:|---:|---:|
| Original coding | 5,121 | 740 | 36 |
| Previous frozen coding | 4,724 | 641 | 33 |
| Current compact coding | **3,161** | **422** | **21** |

The current skill is **1,960 bytes / 318 words / 15 lines smaller than original**, and smaller than the previous frozen profile on every ceiling. No growth and no edit during review.

**No critical current guard appears substantively weakened by the condensation.** It explicitly retains authoritative types/schemas/defaults, sparse field presence, omission versus explicit values, errors/ownership, production-call-shape probes, policy across extension points, trust-boundary/security/synchronization/accessibility/data-loss/cleanup protections, failure/replacement/recovery precedence, the necessity question, reusable transformed results versus consumer-specific outcomes, bounded lifetime, whole-path work/copies/retained data, maintained regressions and meaningful assertions, and honest checks/limitations. External probes are now explicitly supplemental, not a substitute for repository regressions.

Some detailed examples/directives are compressed away: placeholder defaults/parallel models, required copying, consuming less instead of discarding, and formatting/relocation metric gaming are less individually explicit. Authoritative contracts, ownership, readable changes, adapter accounting, complete diffs and no safeguard/count trading still cover their core intent. This is a wording audit, **not empirical proof of equivalent instruction compliance**. Six tasks do not exercise every schema/default/sparse-update, accessibility or data-loss risk. The replicated decode saving and passing seam checks support only those observed behaviors; they cannot establish profile causality, a universal optimum, or smaller generated code from shortening the skill.

## Reproduction, evidence archive and limitations

From `/tmp/codingSessionV2`:

```sh
python research/reviewCompactChecks.py checks
python research/reviewCompactChecks.py audit
python research/reviewCompactChecks.py cross
python research/reviewCompactControls.py
python research/reviewCompactSummary.py
python research/reviewCompactChecks.py integrity
```

Cross/control scripts intentionally retain individual nonzero outcomes in JSON; inspect those logs rather than interpreting a successful driver exit as all-pass. Controls import original sources without modifying candidate files. Scoping/manifest checks were rerun after all diagnostics.

`research/reviewCompactEvidence.tar.gz` is the compact PR-evidence bundle: all five reviews, frozen briefs/metrics, coding profiles, research checks/scripts/logs, all **70** saved patches and **14** implementer `result.md` files. It excludes **the entire Ponytail source checkout and `profiles/ponytail.md`**, all candidate/base checkouts, dependencies and caches. `research/reviewCompactEvidence.sha256` authenticates it; archive member hashes and retrieval facts are in `research/reviewCompactEvidenceManifest.json` and `research/reviewCompactProvenance.json`. Earlier review prose may describe proposed profiles and evidence-contingent removal advice; those are historical artifacts, not the final disposition.

Ponytail retrieval: `https://github.com/DietrichGebert/ponytail`, commit **`84740e3d344b69b4a133201fa519eb37a62a2b2a`**, path `skills/ponytail/SKILL.md`, SHA-256 **`ba68ff26239c3c3b05b2a9a47ee0d9a6b93a69639a2555ec87a5d44bffaf2f0c`**. Independently verified byte-identical to the experiment profile. Thus the profile need not be retained in PR evidence. Recreate dependencies/worktrees at recorded repository commits and apply whole-arm patches; original scripts assume this experiment path and some linked local test environments, so the archive is evidence, not a hermetic benchmark distribution.

No independently rerun full-project suites, TypeScript typecheck/lint, additive six-patch integration, live broker/long-running worker, concurrent filesystem-swap stress, representative latency distribution or RSS benchmark. Implementers' broader passes and dependency blockers are reported in their retained results, not promoted to reviewer-executed checks. No confidence interval or significance claim is warranted from this adaptively developed, small repeated task set.

**Final: acceptance passes; repeated-file work reduction replicates; distinct-file memory rises; coding remains larger in both complete pairs. Requested overall superiority remains unestablished.**
