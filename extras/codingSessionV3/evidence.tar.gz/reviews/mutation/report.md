# Independent bounded mutation adequacy probe

**Result: mutation tooling blocked, not an adequacy pass.** Installed Atlas 0.1.0 has no `mutations` command or mutation catalog. No manual mutants were invented. Both maintained baselines passed, including the candidate-added tests. Selected/executed/skipped manifests: **0/0/0**. Killed/survived/invalid/timeout/inconclusive mutants: **0/0/0/0/0**. Selected-sample score: **N/A**; no equivalence or full-coverage claim.

## Target and comparison

Requested sources were `/tmp/codingSessionV3/worktrees/finalOne/candidateThree/{memoryReferenceResolution,sessionTreeConfinement}`. Both HEADs and the comparison base specified by the tuning/validation manifests are `4f2b75f73087b5f2c60995629c591dc91a591567`. The target is each complete dirty filesystem state, not HEAD alone: staged/unstaged/intent-to-add contents were copied from disk, including added tests and exact dependency symlink bytes. No untracked nonignored files were present. Ignored environments/credentials were not transferred.

| Target | Exact HEAD diff (added/deleted) |
| --- | --- |
| Memory | `src/storage/memoryBlock.ts` +36/-8; new `src/storage/memoryBlock.test.ts` +355/-0 |
| Sessions | `src/agent/matatoAgentSessions.ts` +16/-7; `src/agent/matatoAgentSessions.test.ts` +142/-1; `src/storage/work.test.ts` +2/-3 |

Each also has the existing experiment dependency symlink `node_modules` +1/-0. It was preserved, not installed or modified. Complete binary-capable HEAD/staged/unstaged diffs and original porcelain-v2 statuses are in each target's artifact directory. `sourceHashes.json` records every tracked path's SHA-256, bytes, mode and file/symlink kind.

Production target hashes:

```text
memoryBlock.ts          14ea3555188cdbbec7b5034bedc985950de9a7914ea840b10f5eee45fd2a5d25
matatoAgentSessions.ts  e64cd166c85e6fad32325967bf06e4c04defc4cbc1e1be0f0fdfeac96f39d5e6
```

## Isolation and bounds

Agent-owned copy root: `/tmp/atlasMutationProbexdlsom_3`; separate pristine snapshots were under its `pristine/`, outside test roots. All copied paths, including added tests, matched original bytes/modes/symlinks before execution. No Git worktrees, commits, installs, production changes, test changes, skill edits or source configuration edits were made.

Every Atlas/test/compiler/lint process ran through Bubblewrap: `/` read-only, only the owned isolation root writable, a separate network namespace, isolated HOME/STORAGE_PATH/TMPDIR/cache, and an allowlisted credential-free environment. Shared `node_modules` and original checkouts/profiles were read-only. Parser cache was copied into owned isolation; no download or service was used. Normal repository Bun preloads and database fixtures supplied additional per-test local homes/SQLite files; fixture migrations used installed tools, not services.

Limit: at most three total behavior-relevant mutants, 120 seconds per subprocess, approximately 15 minutes overall. Work completed about 20:31 local time after inspection began 20:25. All command process groups were stopped/verified absent. No command timed out.

## Installed Atlas discovery and fresh analysis

The fixed executable was `/home/leon/.local/bin/atlas`, resolving to the installed uv tool. Installed metadata identifies Atlas 0.1.0. The local Atlas checkout was also inspected and contains no mutation implementation; it was not modified or substituted.

| Command | Cwd | Exit | Evidence |
| --- | --- | --- | --- |
| `atlas mutations --help` | owned isolation root | 2 | `mutationsHelp.stderr.log`: `Error: No such command 'mutations'.` |
| `atlas mutations --rules` | owned isolation root | 2 | `mutationsRules.stderr.log`, same error |
| `atlas mutations -f <whole isolated project>` | each isolated target root | 2 each | `<target>FreshMutations.stderr.log`, same error |
| `atlas report -f <whole isolated project> --format json` | each isolated target root | 0 each | `<target>FreshWholeProjectAnalysis.stdout.log` |

Fresh, whole-project, unsaved analyses completed: memory 341 files/3,015 callables; sessions 340 files/2,997 callables; both zero parse errors. These reports are structural analysis, **not mutation manifests**, and do not resolve the missing catalog. Neither `--save`, `--saved` nor `atlas index` was used. Installed implementation confirms unsaved report does not open persistence. No Atlas index was written.

Installed configuration contract is flat optional metric check limits (`maxFileLines`, `maxFunctionLines`, etc.), with unknown keys forbidden; it has no mutation rules. Copies of the installed configuration/command implementation and metadata are in `tooling/`. No temporary `atlas.json` was created: configuring invented mutation keys would violate this contract. Original projects have no `atlas.json`.

## Relevant behavior reviewed, without inventing operators

Memory changes add explicit missing-room-ID/name and missing-topic-ID/name rejection inside the existing transaction. The ID-presence branch retains authoritative IDs, including rejecting zero rather than treating it as absent. Maintained new tests directly import the real storage module and assert missing-reference error contents, equality of all five memory tables after rollback, successful later recovery, valid-ID authority, exact-name behavior, deduplicated links, and empty collections. Source evidence is `memoryBlock.ts:85–134,152–160` plus the preserved diff. Test assertion attribution is baseline-only: `expectAtomicRejection` asserts `.toThrow(message)` and table snapshots `.toEqual(before)`; no mutation kill is claimed.

Session changes constrain supplied and canonical paths to strict descendants of `sessions/matato`, require regular files, and check eligibility before reference traversal. Maintained new tests directly exercise the real deletion module against local files/symlinks. They assert eligible cyclic/shared/repeated descendants disappear, unsafe files/directories and protected children remain, and escaping symlinks remain symbolic links. The adjusted work test checks its real deletion caller using the managed session path. Source evidence is `matatoAgentSessions.ts:150–196` and the preserved diff. Baseline assertion attribution: eligible files `.toBe(false)` for existence; unsafe/protected paths `.toBe(true)`; escaping links `lstat(...).isSymbolicLink()` remains true.

No available catalog/manifests exist to select an exact relevant replacement. Consequently no manifest IDs, operators, byte spans/base64 payloads, sourceHash validations or mutant diffs can honestly be supplied. Uncataloged manual guard negations, test-code edits, vendor edits and unrelated arithmetic were not used as substitutes.

| File/line | Rule/edit | Relevance | Checks | Outcome/evidence |
| --- | --- | --- | --- | --- |
| — | No supported manifests obtained | Memory resolution and confined deletion reviewed | Maintained baselines below | Tooling blocked; `mutationsHelp.stderr.log`, `mutationsRules.stderr.log`, both fresh mutation logs |

No selected relevant candidates were left unexecuted; the installed tool prevents determining a supported candidate set. Mutation sensitivity of rollback/ID authority/name resolution, lexical/canonical confinement, regular-file eligibility and recursive traversal remains **unassessed**, despite baseline assertions passing.

## Maintained baselines

Commands derive from root `AGENTS.md`, `package.json` (`test: bun test`), `bunfig.toml` (normal test preload), CI, and the experiment's existing native command definitions. No external oracle or replacement test harness was substituted. Bun runs TypeScript modules directly; no emitted build is required. Existing native test selections were expanded to include the candidate's added/changed maintained test files.

Cwds were `/tmp/atlasMutationProbexdlsom_3/memoryReferenceResolution` and `/tmp/atlasMutationProbexdlsom_3/sessionTreeConfinement` respectively. Actual executable paths, exact argv, sandbox argv, environment, cwd, exit, duration, timeout and full stdout/stderr paths for **every** command are recorded in `ledger.json`.

| Target | Command | Exit / collected result | Logs (stdout and stderr) |
| --- | --- | --- | --- |
| Memory | `bun test src/storage/memoryBlock.test.ts src/agent/matatoAgentTools.test.ts src/storage/database.test.ts` | 0; 34 pass, 0 fail; 107 assertions; 3 files; 5.496s | `memoryReferenceResolutionBaselineTests.*.log` |
| Memory | `bun node_modules/typescript/bin/tsc --noEmit` | 0; 23.630s | `memoryReferenceResolutionBaselineTypes.*.log` |
| Memory | `bun node_modules/eslint/bin/eslint.js src/storage/memoryBlock.ts src/storage/memoryBlock.test.ts src/storage/memoryRoomStore.ts src/storage/memoryTopicStore.ts src/storage/memoryItemStore.ts src/storage/database.ts` | 0; 1.569s | `memoryReferenceResolutionBaselineLint.*.log` |
| Sessions | `bun test src/agent/matatoAgentSessions.test.ts src/agent/matatoAgentPaths.test.ts src/storage/work.test.ts` | 0; 23 pass, 0 fail; 73 assertions; 3 files; 11.912s | `sessionTreeConfinementBaselineTests.*.log` |
| Sessions | `bun node_modules/typescript/bin/tsc --noEmit` | 0; 34.361s | `sessionTreeConfinementBaselineTypes.*.log` |
| Sessions | `bun node_modules/eslint/bin/eslint.js src/agent/matatoAgentSessions.ts src/agent/matatoAgentSessions.test.ts src/agent/matatoAgentPaths.ts src/config/configUtils.ts src/storage/work.test.ts` | 0; 2.628s | `sessionTreeConfinementBaselineLint.*.log` |

These are focused maintained suites, not a claim that the full project test suite was run. Baseline and mutant commands would have been identical per target, but no mutant execution was possible.

## Infrastructure incident and integrity

After memory lint completed successfully, rewriting the ledger hit the local disk quota. This is a **logging infrastructure interruption**, not a failing test or mutant outcome. Its full command array was intact and recovered to `recoveredCommands.json`; original per-path hashes, diffs, command logs and exit/duration records survived. Removed only owned copied parser bundles/Bun cache, resumed the remaining target without altering source/config/test commands, and rebuilt the ledger. The failed driver's traceback is retained in `driver.log`; continuation and final integrity verification are in `resume.log`. No mutation, timeout or invalid test result was inferred from this incident.

Final verification found every original target path, isolated target path and pristine snapshot identical to its initial hash/type/mode, and original Git statuses identical. Git index modification times also predate this probe (20:07 and 20:16), corroborating no Git index refresh write. No mutation required restoration; pristine hashes were verified anyway. All recorded command process groups are absent. Original checkouts, experiment outputs outside this requested review directory, profiles and shared dependencies were not changed. Only this report directory and owned temporary isolation were written. The owned isolation is removed after evidence/integrity persistence; no pre-existing workspace is removed.
