import hashlib
import json
from pathlib import Path

root = Path('/tmp/codingSessionV4')
out = Path('/home/leon/.cache/codingSessionV4Owned/reviews/finalTwo')
files = json.loads((out / 'metricsFiles.json').read_text())
fields = ['additions', 'deletions', 'churn', 'baseBytes', 'resultBytes', 'byteGrowth', 'nonblankStrippedAdditions', 'nonblankStrippedDeletions']
categories = ['production', 'tests', 'fixtures', 'snapshots', 'combined']
perCase = {}
totals = {}
for identity, rows in files.items():
    arm = identity.split('/')[1]
    perCase[identity] = {}
    for category in categories:
        values = {key: sum(row[key] for row in rows if category == 'combined' or row['category'] == category) for key in fields}
        values['nonblankStrippedChurn'] = values['nonblankStrippedAdditions'] + values['nonblankStrippedDeletions']
        perCase[identity][category] = values
        totals.setdefault(arm, {}).setdefault(category, {key: 0 for key in values})
        for key, value in values.items():
            totals[arm][category][key] += value
inventory = {}
for case in {identity.split('/')[2] for identity in files}:
    paths = {row['path']: row['category'] for identity, rows in files.items() if identity.endswith('/' + case) for row in rows}
    inventory[case] = {}
    for arm in ['original', 'v3', 'v2', 'ponytail', 'candidateTwo']:
        target = out / 'copies' / ('original' if arm == 'original' else 'finalTwo/' + arm) / case
        inventory[case][arm] = {category: sum((target / name).stat().st_size for name, kind in paths.items() if (category == 'combined' or kind == category) and (target / name).exists()) for category in categories}
losses = {}
for case in inventory:
    candidate, pony = perCase['finalTwo/candidateTwo/' + case], perCase['finalTwo/ponytail/' + case]
    losses[case] = {category: {key: candidate[category][key] - pony[category][key] for key in ['additions', 'deletions', 'churn', 'resultBytes', 'byteGrowth', 'nonblankStrippedChurn']} for category in categories}
metrics = {'qualification': 'All16 agents completed; original native6timeouts retained. Descriptive size metrics do not supply correctness/instruction gates.', 'files': files, 'perCase': perCase, 'descriptiveTotals': totals, 'candidateMinusPonytail': losses, 'matchedInventoryResultBytes': inventory, 'resultBytesMeaning': 'Entire changed files, not repository; matched inventory union per case includes unchanged files equally.', 'accountingCorrection': 'Extensionless setup is production equally; original suffix metrics preserved in frozenMetrics.json.'}
(out / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
checksums = json.loads((out / 'checksums.json').read_text())
integrity = {}
for identity, expected in checksums.items():
    roundName, arm, case, name = identity.split('/', 3)
    live = root / 'worktrees' / roundName / arm / case / name
    copy = out / 'copies' / roundName / arm / case / name
    integrity[identity] = hashlib.sha256(live.read_bytes()).hexdigest() == expected and hashlib.sha256(copy.read_bytes()).hexdigest() == expected
assert all(integrity.values())
(out / 'integrity.json').write_text(json.dumps({'liveAndOwnedChangedFilesUnchanged': integrity, 'allMatch': True, 'sourceRepairs': False, 'modelRuns': 0}, indent=2) + '\n')
for identity, values in perCase.items():
    print(identity, {key: [values[key][field] for field in ['additions', 'deletions', 'churn', 'resultBytes', 'byteGrowth']] for key in categories})
print('TOTALS', json.dumps(totals, indent=2))
