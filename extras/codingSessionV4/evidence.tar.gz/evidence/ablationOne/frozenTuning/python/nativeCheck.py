"""Run maintained discovery consumers and the real generator in a disposable copy."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

artifactRoot = Path(__file__).resolve().parent
sharedPython = "/home/leon/workspace/projects/atlas/atlas/.venv/bin/python"


def runNative(root: Path) -> None:
    with TemporaryDirectory(prefix="native", dir=artifactRoot) as temporary:
        scratch = Path(temporary)
        copyRoot = scratch / "repo"
        shutil.copytree(root, copyRoot, symlinks=True,
                        ignore=shutil.ignore_patterns(".git", ".venv", "__pycache__", ".pytest_cache",
                                                     "node_modules", ".ruff_cache", ".atlas"))
        project = copyRoot / "atlas"
        environment = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1",
                       "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1", "PYTHONPATH": str(project / "src"),
                       "TMPDIR": str(scratch), "DATABASE_PATH": str(scratch / "unused.sqlite")}
        suites = ["tests/test_discovery.py", "tests/test_atlasignore.py",
                  "tests/test_folder_cli.py", "tests/test_folder_report_cli.py",
                  "tests/test_coffee.py", "tests/test_coffee_pipeline.py",
                  "tests/test_variant_snapshots.py", "tests/test_coffee_navigation_snapshots.py",
                  "tests/test_script_member_coffee_snapshots.py",
                  "tests/test_coffee_safety_review_snapshots.py"]
        command = [sharedPython, "-B", "-m", "pytest", "-p", "no:cacheprovider", "-q",
                   "--basetemp", str(scratch / "pytest"), *suites]
        print("MAINTAINED", command, flush=True)
        subprocess.run(command, cwd=project, env=environment, check=True, timeout=180)
        snapshotRoot = project / "tests/snapshots"
        before = {path.relative_to(snapshotRoot).as_posix(): json.loads(path.read_text())
                  for path in snapshotRoot.rglob("*.json")}
        generator = [sharedPython, "-B", "-m", "tests.update_coffee_snapshots", "--navigation"]
        print("GENERATOR", generator, flush=True)
        subprocess.run(generator, cwd=project, env=environment, check=True, timeout=180)
        after = {path.relative_to(snapshotRoot).as_posix(): json.loads(path.read_text())
                 for path in snapshotRoot.rglob("*.json")}
        changed = sorted(name for name in before.keys() | after.keys()
                         if before.get(name) != after.get(name))
        assert not changed, f"Generator disagrees with maintained snapshots: {changed}"
        print(f"PASS: generator preserves all {len(before)} parsed snapshot outputs", flush=True)


if __name__ == "__main__":
    runNative(Path(sys.argv[1]).resolve())
