"""Independent final gates. No generated score and no frozen artifact rewrites."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).parent
project = Path('/home/leon/workspace/projects/matato-pi')
summaries = json.loads((root / 'evidenceSummary.json').read_text())
comparisons = json.loads((root / 'atlasComparison.json').read_text())
checks = json.loads((root / 'checkResults.json').read_text())
caseNames = {'workspaceCheckoutRoots': 'ts', 'navigationUnseenEdgeBudget': 'py',
             'installerDownloadFailures': 'bash', 'holdoutOne': 'hold'}


def checkRecord(label, case, variant, action):
    record = next(item for item in checks if Path(item['record']).relative_to(root / 'checks').parts
                  == (label, case, variant, action + '.json'))
    return {key: record[key] for key in ['exit', 'timedOut', 'seconds', 'timeoutSeconds', 'record', 'stdout', 'stderr', 'command']}


def testCounts(record, case):
    text = Path(record['stdout']).read_text() + Path(record['stderr']).read_text()
    if case == 'bash':
        return {'methodsExecuted': int(re.search(r'Ran (\d+) tests', text)[1]), 'scenarios': 15,
                'scenarioFailures': int(re.search(r'failures=(\d+)', text)[1]) if 'failures=' in text else 0,
                'skipped': 'skipped' in text.lower()}
    if case == 'py':
        return {'passed': int(re.search(r'(\d+) passed', text)[1]),
                'failed': int(re.search(r'(\d+) failed', text)[1]) if re.search(r'(\d+) failed', text) else 0}
    return {'passed': int(re.search(r'(\d+) pass\n', text)[1]),
            'failed': int(re.search(r'(\d+) fail\n', text)[1])}


def sizes(summary, case):
    data = {'fileLimitExclusive': 600, 'functionLimitExclusive': 100,
            'allChangedCodeFilesBelow600': True, 'newIndividualFunctionsBelow100': True,
            'oversizedChangedFunctions': [], 'inheritedSuiteCallbackLines': None}
    data['allChangedCodeFilesBelow600'] = all(item['lines'] < 600 for item in summary['files'])
    if case in ['ts', 'hold']:
        path = root / 'checks' / summary['label'] / case / 'candidate/sizes.stdout'
        for line in path.read_text().splitlines():
            item = json.loads(line)
            data['oversizedChangedFunctions'].extend({'path': item['path'], **function}
                for function in item['functions'] if function['lines'] >= 100)
        data['evidence'] = str(path)
    else:
        data['oversizedChangedFunctions'] = [{'path': item['path'], **function}
            for item in summary['files'] for function in item.get('functions', []) if function['lines'] >= 100]
        data['evidence'] = str(root / 'evidenceSummary.json')
    if case == 'hold':
        data['inheritedSuiteCallbackLines'] = 101
        data['baselineEvidence'] = str(root / 'checks' / summary['label'] / case / 'original/baselineSizes.stdout')
        data['assessment'] = 'worsenedExistingOversize; strictChangedFunctionLimitFails; newlyAddedIndividualFunctionsPass'
    else:
        data['assessment'] = 'pass'
    return data


def runGate(summary):
    label, case = summary['label'], caseNames[summary['case']]
    ownedAction = 'ownedPinned' if case in ['ts', 'hold'] else 'owned'
    owned = checkRecord(label, case, 'candidate', ownedAction)
    control = checkRecord(label, case, 'original', ownedAction)
    policy = next(item for item in comparisons if item['label'] == label and item['case'] == case)
    gate = {'label': label, 'draw': summary['draw'], 'arm': summary['arm'], 'case': summary['case'],
            'publicEvidence': summary['path'] + '/evidence', 'validCompletion': summary['validCompletion'],
            'completionEvidence': summary['path'] + '/evidence/agent.json', 'audit': summary['audit'],
            'activation': {key: value for key, value in summary['activation'].items() if key != 'observations'},
            'maintained': {'status': 'pass', 'counts': testCounts(owned, case), 'execution': owned},
            'catchesOriginal': {'status': 'behaviorallyRejected', 'counts': testCounts(control, case),
                                'finalTestsAndSnapshotsRetained': True, 'execution': control},
            'acceptance': checkRecord(label, case, 'candidate', 'acceptance'),
            'typeLintOrSyntax': checkRecord(label, case, 'candidate', 'lint'),
            'size': sizes(summary, case), 'atlas': policy,
            'sourceSafety': {'status': 'passWithinInspectedScope', 'unrelatedProductionChanges': False,
                             'readmeOrDependencyOrSchemaChanges': False, 'originalsWritableInSandbox': False,
                             'changedDeliveredBytesMatchDisposableAfterChecks': all(item['matchesDisposableAfterChecks'] for item in summary['files']),
                             'nodeModulesSetupSymlinkMustNotShip': any(item['isSymlink'] and item['path'] == 'node_modules' for item in summary['files'])},
            'snapshots': {'status': 'compatible' if summary['snapshots'] else 'notApplicable', 'changes': summary['snapshots']},
            'publicArtifactHashChecksPass': all(summary['publicHashesMatch'].values()),
            'metricsEvidence': str(root / 'evidenceSummary.json'), 'allMetricsQualifies': False,
            'requiredRepositoryClosure': 'focusedRequirementsComplete' if case != 'py' else 'incomplete'}
    if case == 'py':
        gate['importerCollection'] = checkRecord(label, case, 'candidate', 'fullCollect')
        gate['wholeImporter'] = {'status': 'incompleteTimeout', **checkRecord(label, case, 'candidate', 'fullImporter')}
        gate['dashboard'] = {'status': 'blockedMissingDependenciesAndTools', **checkRecord(label, case, 'candidate', 'dashboardChecks')}
        gate['affectedMaintained'] = checkRecord(label, case, 'candidate', 'affected')
        gate['requiredAtlasStatus'] = 'pass' if policy['candidateCount'] == 0 else 'failIntroducedViolations'
        gate['qualityAssessment'] = 'invalidCompletionAndIncompleteRepositoryClosure'
        if label == 'P':
            gate['qualityAssessment'] += 'AndRequiredAtlasRegression'
            gate['activationAggregateDisagreesWithArtifact'] = False
            gate['activationCountCorrespondenceIncomplete'] = True
    if case in ['ts', 'hold']:
        gate['relatedMaintained'] = checkRecord(label, case, 'candidate', 'related')
        gate['qualityAssessment'] = 'relevantBehaviorTypeLintSizePass' if case == 'ts' else 'behaviorPassButExistingSuiteSizeDebtWorsens'
    if case == 'hold':
        gate['reviewerSupplement'] = {'status': '4passed;NotDeliveredCoverageOrRepair',
            'execution': checkRecord(label, case, 'candidate', 'schedulerSupplement'),
            'source': str(root / 'reviewScheduler.test.ts'),
            'originalControlQualification': '2assertionFailures+1frameworkTimeout+1passingStopControl;TimeoutNotCountedAsKill',
            'originalExecution': checkRecord(label, case, 'original', 'schedulerSupplement')}
        gate['coverageNote'] = 'All delivered suites lack the combined failed-replacement-with-multiple-active-runs probe; first holdout lacks synchronous factory/stop/resume callback probe. Reviewer supplement checks both without changing delivered tests.'
    if case == 'bash':
        gate['qualityAssessment'] = 'behaviorAndFrozenSizePassWithSupplementalDefaultAtlasWarnings'
        gate['coverageNote'] = 'Linux-isolated Darwin simulation, not native macOS; copied frozen inert fixture is shared with acceptance.'
    return gate


gates = [runGate(summary) for summary in summaries]
for item in checks:
    item['stdoutSha256'] = hashlib.sha256(Path(item['stdout']).read_bytes()).hexdigest()
    item['stderrSha256'] = hashlib.sha256(Path(item['stderr']).read_bytes()).hexdigest()
report = {'schemaVersion': 1, 'study': 'codingSessionV5', 'review': 'finalIndependentQualityAudit',
          'scope': '6revisionTwo+4holdoutOneTwo;PublicEvidenceOnly', 'formallyBlindedScore': None,
          'scoringNote': 'Artifact identities were visible. Formal unbiased scoring was not requested and was not performed.',
          'freeze': json.loads((project / 'extras/codingSessionV5/finalFreeze.json').read_text()),
          'profileSkillOrDeploymentChanged': False, 'modelRunsOrInstallsOrApplicationServices': False,
          'sourceChangesOnlyInDisposableCopies': True, 'supplementalChildLimitSeconds': 110,
          'supplementalEnclosingCommandLimitSeconds': 120,
          'evidenceRoot': str(root), 'evidenceIndex': str(root / 'evidenceSummary.json'),
          'inspectionQualifications': str(root / 'inspectionAttempts.md'),
          'allMetrics': {'qualifyingCandidates': [], 'candidateTwoQualifies': False, 'candidateOneQualifies': False,
                         'reasons': ['Both final development Python generations are invalid 600-second timeouts.',
                                    'Correctness and production metrics tie; every directional metric must improve strictly.',
                                    'Resource tradeoffs and required Python closure gaps remain.',
                                    'Heldout tests worsen existing oversized suite callbacks; P Python adds required Atlas failures.'],
                         'priorCandidateEvidence': 'extras/codingSessionV5/reviews/revisionOneQuality.md',
                         'aggregateOrDensityScoreUsed': False},
          'runs': gates, 'supplementalCommands': checks,
          'unavailableOrIncomplete': ['Whole importer completion', 'Successful dashboard build/test/type/lint closure',
              'Native macOS execution', 'Provider invoice or wire-model verification', 'Formal unbiased scores'],
          'report': 'extras/codingSessionV5/reviews/finalQuality.md'}
path = project / 'extras/codingSessionV5/reviews/gateResults.json'
path.write_text(json.dumps(report, separators=(',', ':')) + '\n')
print('Wrote', path, 'with', len(gates), 'run gates and', len(checks), 'supplemental command records')
