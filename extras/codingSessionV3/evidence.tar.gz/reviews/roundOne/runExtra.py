import json
from pathlib import Path

review = Path('/tmp/codingSessionV3/reviews/roundOne')
source = (review / 'runReview.py').read_text().split('\ncases = {}')[0]
exec(source.replace("'commands.json'", "'extraCommands.json'"))
for arm in ['candidateOne', 'main', 'pr', 'ponytail']:
    folder = review / 'copies' / arm / 'pythonUnicodeGraphFind'
    command = f'cd "{folder}/atlas" && PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTEST_ADDOPTS= PYTHONPATH="{folder}/atlas/src:{folder}/atlas" /home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B -m pytest -q -p no:cacheprovider --basetemp="{review}/temp/{arm}Integration" tests/test_coffee_pipeline.py tests/test_variant_snapshots.py tests/test_declaration_coffee.py -k "python or each_physical"'
    run(arm + 'PythonIntegration', command, folder)
