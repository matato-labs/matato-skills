#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 1 || "$1" != /* || ! -d "$1/lib/beer_game/game" ]]; then
  printf 'Usage: %s /absolute/worktree/path\n' "$0" >&2
  exit 2
fi
here=$(cd -- "$(dirname -- "$0")" && pwd)
shared=$(dirname -- "$here")
exec elixir -pa "$shared/runtime/lib/decimal/ebin" -pa "$shared/runtime/lib/ecto/ebin" -pa "$shared/runtime/lib/telemetry/ebin" "$shared/run.exs" "$1" "$here/oracleTest.exs"
