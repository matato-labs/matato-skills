import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/tmp/codingSessionV4')
out = root / 'reviews/tuningOne'
private = Path('/dev/shm/codingSessionV4tuningReview')
case = json.loads((root / 'research/typescript/tuning/manifest.json').read_text())['cases'][0]
repo = Path(case['repo'])
specification = importlib.util.spec_from_file_location('reviewSandbox', root / 'sandboxTrial.py')
helper = importlib.util.module_from_spec(specification)
specification.loader.exec_module(helper)
results = []


def runJob(arm: str, target: Path, label: str, command: str) -> None:
    runtime = private / 'diagnosticRuntime' / arm / label
    spec = {'worktree': target, 'repo': repo, 'common': repo / '.git', 'oracle': root / 'research/typescript/tuning', 'runtime': runtime, 'profile': out / 'unused', 'profileSnapshot': out / 'unused', 'config': out / 'unused', 'auth': out / 'unused', 'dependencies': [], 'pi': Path('/home/leon/.local/share/mise/installs/pi/1.1.0/pi/pi')}
    log = out / 'diagnosticLogs' / arm
    log.mkdir(parents=True, exist_ok=True)
    result = helper.shell(spec, label, command, log, 180)
    results.append({'arm': arm, 'label': label, **result})
    print(arm, label, result['exit'], result['seconds'], flush=True)


for arm in ['v3', 'reuseAblation']:
    target = private / ('ablation' + arm) / case['id']
    target.mkdir(parents=True)
    data = subprocess.check_output(['git', '-C', case['repo'], 'archive', case['base']])
    with tarfile.open(fileobj=io.BytesIO(data)) as packed:
        packed.extractall(target, filter='data')
    (target / 'node_modules').symlink_to(repo / 'node_modules')
    patch = (root / 'runs/ablationOne' / arm / case['id'] / 'changes.patch').read_bytes()
    subprocess.run(['git', 'apply', '--unsafe-paths', '-p1', '-'], input=patch, cwd=target, check=True)

for arm in ['v3', 'v2', 'ponytail', 'candidateOne', 'ablationv3', 'ablationreuseAblation', 'original']:
    runJob(arm, private / arm / case['id'], 'busTimingDiagnostic', 'bun test src/worker/bus/bus.test.ts')
for arm in ['v3', 'v2', 'ponytail', 'candidateOne', 'ablationv3', 'ablationreuseAblation']:
    target = private / (arm + 'OriginalProduction') / case['id']
    runJob(arm, target, 'scheduledOriginalProduction', "bun test src/worker/scheduledJobs/preScript.test.ts -t 'runs a TypeScript pre-script module|runs a shell pre-script|runs the product-manager|throws when a pre-script|throws when a TypeScript'")
(out / 'diagnosticCommands.json').write_text(json.dumps(results, indent=2) + '\n')
print('Diagnostic plan sha256', hashlib.sha256((out / 'diagnosticPlan.json').read_bytes()).hexdigest())
