import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/tmp/codingSessionV4')
out = root / 'reviews/tuningTwo'
partial = json.loads((out / 'partialMetrics.json').read_text())
commands = json.loads((out / 'commands.json').read_text())
failure = json.loads((root / 'evidence/tuningTwo/failureSummary.json').read_text())
metrics = {'status': 'resourceBlockedIncomplete', 'validProductionComparison': False, 'qualityGate': 'not established; partial issues recorded', 'candidateBytes': 2630, 'candidateSha256': hashlib.sha256((root / 'profiles/candidateTwo.md').read_bytes()).hexdigest(), 'reservations': 19, 'runnerAttempts': 8, 'agentInvocations': 6, 'validRuntimeAudits': 0, 'completedDrawTotals': None, 'partialCases': {}, 'supplementalCommands': []}
fields = ['additions', 'deletions', 'churn', 'resultBytes', 'byteGrowth', 'nonblankStrippedAdditions', 'nonblankStrippedDeletions']
for key, value in partial.items():
    if value['status'] == 'no valid retained worktree':
        metrics['partialCases'][key] = {'status': 'unavailable', 'production': None, 'tests': None, 'fixtures': None, 'snapshots': None, 'combined': None}
        continue
    record = {'status': value['status'], 'base': value['base'], 'files': value['files']}
    for category in ['production', 'tests', 'fixtures', 'snapshots', 'combined']:
        selected = [item for item in value['files'] if item['category'] == category or category == 'combined']
        record[category] = {field: sum(item[field] for item in selected) for field in fields}
    metrics['partialCases'][key] = record
    arm, case = key.split('/')
    live = root / 'worktrees/tuningTwo' / arm / case
    for item in value['files']:
        if item['baseBytes'] != 0:
            continue
        extra = subprocess.run(['git', '--no-optional-locks', '-C', str(live), 'diff', '--no-index', '--', '/dev/null', item['path']], stdout=subprocess.PIPE, check=False).stdout
        with (out / f'{arm}.{case}.partial.patch').open('ab') as patch:
            patch.write(extra)
for command in commands:
    metrics['supplementalCommands'].append({key: command[key] for key in ['arm', 'case', 'label', 'exit', 'timedOut', 'seconds', 'stdout', 'stderr']})
(out / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
frozen = []
for run in failure['runs']:
    frozen.append({'identity': run['identity'], 'status': run['resultStatus'], 'runtimeAuditPassed': run['runtimeAuditPassed'], 'agentExit': run['agent'].get('exit'), 'acceptanceExit': run['acceptance'].get('exit'), 'nativeExit': run['native'].get('exit'), 'resultError': run.get('resultError')})
(out / 'frozenStatus.json').write_text(json.dumps(frozen, indent=2) + '\n')
hashes = json.loads((out / 'originalHashes.json').read_text())
known = json.loads((root / 'evidence/tuningTwo/before.json').read_text())
for name in ['frozenInputs', 'ablationOutputs', 'ablationEvidence', 'tuningOneOutputs', 'tuningOneEvidence']:
    hashes.update(known[name])
finalIntegrity = {'checked': len(hashes), 'mismatches': [path for path, expected in hashes.items() if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected]}
(out / 'finalIntegrity.json').write_text(json.dumps(finalIntegrity, indent=2) + '\n')
artifacts = {str(path.relative_to(out)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(out.rglob('*')) if path.is_file() and path.name != 'artifacts.sha256'}
(out / 'artifacts.sha256').write_text(''.join(f'{value}  {name}\n' for name, value in artifacts.items()))
print(json.dumps({'commands': len(commands), 'integrity': finalIntegrity, 'timeouts': [item for item in metrics['supplementalCommands'] if item['timedOut']]}, indent=2))
