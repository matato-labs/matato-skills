import hashlib
import json
from pathlib import Path
import shutil
import subprocess


root = Path('/tmp/codingSessionV3')
expectedPonytailHash = 'ba68ff26239c3c3b05b2a9a47ee0d9a6b93a69639a2555ec87a5d44bffaf2f0c'
exclusions = ['--', '.', ':(exclude)node_modules', ':(exclude)atlas/.venv',
              ':(exclude)_build', ':(exclude)deps']


def git(path: Path, *args: str) -> str:
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(path),
                                    *args], text=True)


def main() -> None:
    cases = {}
    for manifest in (root / 'research').glob('*/*/manifest.json'):
        for case in json.loads(manifest.read_text())['cases']:
            cases[case['id']] = case
    removed = []
    for resultPath in sorted((root / 'runs').glob('*/*/*/result.json')):
        result = json.loads(resultPath.read_text())
        worktree = Path(result['worktree'])
        assert worktree.is_relative_to(root / 'worktrees'), worktree
        patch = git(worktree, 'diff', '--no-ext-diff', *exclusions)
        digest = hashlib.sha256(patch.encode()).hexdigest()
        assert digest == result['patchSha256'], worktree
        assert (resultPath.parent / 'changes.patch').read_text() == patch, worktree
        repo = Path(cases[result['case']]['repo'])
        assert git(worktree, 'rev-parse', 'HEAD').strip() == result['base']
        subprocess.run(['git', '-C', str(repo), 'worktree', 'remove', '--force',
                        str(worktree)], check=True, capture_output=True)
        removed.append({'path': str(worktree), 'patchSha256': digest})
    assert len(removed) == 72, len(removed)
    ponytail = root / 'ponytail'
    assert git(ponytail, 'remote', 'get-url', 'origin').strip() == 'https://github.com/DietrichGebert/ponytail.git'
    ponytailCommit = git(ponytail, 'rev-parse', 'HEAD').strip()
    shutil.rmtree(ponytail)
    profiles = [root / 'profiles/ponytail.md',
                Path('/tmp/necessaryEvaluation/versions/ponytail.md')]
    for profile in profiles:
        assert hashlib.sha256(profile.read_bytes()).hexdigest() == expectedPonytailHash
        profile.unlink()
    sourceChecks = {}
    for repo in {Path(case['repo']) for case in cases.values()}:
        status = git(repo, 'status', '--porcelain')
        assert not status, (repo, status)
        registered = git(repo, 'worktree', 'list', '--porcelain')
        assert str(root / 'worktrees') not in registered, repo
        sourceChecks[str(repo)] = {'status': status, 'head': git(repo, 'rev-parse', 'HEAD').strip()}
    record = {'removedWorktrees': removed, 'worktreeCount': len(removed),
              'removedPonytailCheckout': str(ponytail), 'ponytailCommit': ponytailCommit,
              'removedPonytailProfiles': [str(path) for path in profiles],
              'profileSha256': expectedPonytailHash, 'sourceCheckouts': sourceChecks,
              'retained': 'Historical comparison patches/results and sealed prior evidence archives; no active Ponytail installation.',
              'activePackageCheck': 'pi list: matato-pi and pi-rtk-optimizer only',
              'checkedActiveLocations': ['~/.pi/agent', '~/.agents', '~/.claude', '~/.codex', '~/.config/opencode'],
              'preexistingUnrelatedChanges': ['matato-pi: ?? web-app/', 'quick-note: M components/tasks/task-shared.test.ts', 'personal-blog: ?? PRODUCT.md']}
    (root / 'cleanup.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'removedWorktrees': len(removed), 'removedPonytail': True,
                      'sourceCheckoutsClean': True}))


if __name__ == '__main__':
    main()
