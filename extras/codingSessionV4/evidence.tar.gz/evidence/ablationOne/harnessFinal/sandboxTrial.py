"""Experiment-specific V4 Bubblewrap construction and bounded subprocess recording."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import time
from typing import TypedDict


root = Path('/tmp/codingSessionV4')
currentProfile = root / 'currentProfile.md'
proxyPath = root / 'provider.sock'


class Execution(TypedDict):
    argv: list[str]
    cwd: str
    environment: dict[str, str]
    startedAt: str
    finishedAt: str
    seconds: float
    timeoutSeconds: int
    timedOut: bool
    exit: int
    stdout: str
    stderr: str


class Sandbox(TypedDict):
    worktree: Path
    repo: Path
    common: Path
    oracle: Path
    runtime: Path
    profile: Path
    profileSnapshot: Path
    config: Path
    auth: Path
    dependencies: list[Path]
    pi: Path


def environment(runtime: Path, config: Path | None = None) -> dict[str, str]:
    env = {'PATH': os.environ.get('PATH', '/usr/local/bin:/usr/bin:/bin'),
           'HOME': str(runtime / 'home'), 'TMPDIR': str(runtime / 'tmp'),
           'XDG_CACHE_HOME': str(runtime / 'cache'),
           'XDG_CONFIG_HOME': str(runtime / 'config'),
           'XDG_DATA_HOME': str(runtime / 'data'),
           'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CI': '1',
           'PI_OFFLINE': '1', 'PI_TELEMETRY': '0', 'PI_SKIP_VERSION_CHECK': '1',
           'PYTHONDONTWRITEBYTECODE': '1', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1',
           'TREE_SITTER_LANGUAGE_PACK_LIBS_DIR': '/home/leon/.cache/tree-sitter-language-pack/v1.20.0/libs',
           'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_NOSYSTEM': '1',
           'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_TERMINAL_PROMPT': '0',
           'PIP_NO_INDEX': '1', 'npm_config_offline': 'true', 'CARGO_NET_OFFLINE': 'true',
           'GOCACHE': str(runtime / 'goCache'), 'GOPATH': str(runtime / 'goPath')}
    for name in ['home', 'tmp', 'cache', 'config', 'data', 'goCache', 'goPath']:
        (runtime / name).mkdir(parents=True, exist_ok=True)
    if config:
        env['PI_CODING_AGENT_DIR'] = str(config)
    return env


def bind(args: list[str], source: Path, target: Path, writable: bool = False) -> None:
    args.extend(['--bind' if writable else '--ro-bind', str(source), str(target)])


def sandbox(spec: Sandbox, stage: Path, agent: bool = False,
            endpoint: Path | None = None) -> list[str]:
    args = ['bwrap', '--die-with-parent', '--new-session', '--unshare-all',
            '--ro-bind', '/', '/', '--tmpfs', '/tmp', '--tmpfs', '/home',
            '--tmpfs', '/root', '--tmpfs', '/run', '--tmpfs', '/var/tmp',
            '--proc', '/proc', '--dev', '/dev',
            '--cap-drop', 'ALL']
    # Only explicitly required home tooling/source/dependencies are visible again.
    tools = [spec['pi'].parent, Path('/usr/bin/python3').resolve().parent]
    tools += [Path(part) for part in os.environ.get('PATH', '').split(':')
              if part and Path(part).is_dir() and Path(part).is_absolute()]
    paths = [spec['repo'], spec['common'], *tools, *spec['dependencies']]
    mounted: set[str] = set()
    for path in sorted(paths, key=lambda item: len(item.parts)):
        resolved = path.resolve()
        for candidate in [resolved, path]:
            if str(candidate) in mounted:
                continue
            bind(args, candidate, candidate)
            mounted.add(str(candidate))
    # Frozen launchers create scratch beside themselves; only files are immutable.
    oracleStage = stage / 'oracle'
    oracleStage.mkdir(exist_ok=True)
    bind(args, oracleStage, spec['oracle'], True)
    for path in sorted(spec['oracle'].iterdir()):
        if path.is_file():
            bind(args, path, spec['oracle'] / path.name)
    bind(args, spec['worktree'], spec['worktree'], True)
    bind(args, stage, stage, True)
    if agent:
        bind(args, spec['config'], spec['config'], True)
        bind(args, spec['auth'], spec['config'] / 'auth.json')
        bind(args, spec['profileSnapshot'], spec['profile'])
        bind(args, spec['profileSnapshot'], currentProfile)
        bind(args, root / 'providerProxy.py', root / 'providerProxy.py')
        if endpoint:
            bind(args, endpoint, proxyPath)
    for path in ['/tmp', '/home', '/root', '/run', '/var/tmp']:
        args.extend(['--remount-ro', path])
    args.extend(['--chdir', str(spec['worktree']), '--'])
    return args


def execute(argv: list[str], cwd: Path, env: dict[str, str], private: Path,
            label: str, timeout: int) -> Execution:
    outPath, errPath = private / f'{label}.stdout', private / f'{label}.stderr'
    startedAt = datetime.now(timezone.utc).isoformat()
    started = time.monotonic()
    timedOut = False
    with outPath.open('xb') as output, errPath.open('xb') as errors:
        process = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                   stdout=output, stderr=errors, start_new_session=True)
        try:
            exitCode = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timedOut = True
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            exitCode = 124
        finally:
            # Kill surviving tool/service children even after a clean top-level exit.
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    result: Execution = {'argv': argv, 'cwd': str(cwd), 'environment': env,
                         'startedAt': startedAt,
                         'finishedAt': datetime.now(timezone.utc).isoformat(),
                         'seconds': round(time.monotonic() - started, 3),
                         'timeoutSeconds': timeout, 'timedOut': timedOut,
                         'exit': exitCode, 'stdout': str(outPath), 'stderr': str(errPath)}
    (private / f'{label}.execution.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


def shell(spec: Sandbox, label: str, command: str, private: Path,
          timeout: int) -> Execution:
    stage = spec['runtime'] / label
    stage.mkdir(parents=True)
    env = environment(stage)
    argv = sandbox(spec, stage) + ['/bin/bash', '--noprofile', '--norc', '-euc', command]
    return execute(argv, spec['worktree'], env, private, label, timeout)
