# Independent FINAL review A — V3 finalOne

**The predeclared gate is NOT MET.** CandidateThree has lower combined line churn than every baseline, but production churn exceeds main/Ponytail and only ties PR112. All 24 frozen acceptance commands, 24 manifest-native commands and 24 explicitly selected maintained suites pass. Supplemental checks nevertheless expose a candidate/main confinement vulnerability and an explicit-zero boundary failure. PR112/Ponytail have a separate stale maintained integration test. No implementation, profile or frozen check was repaired; no further revision is proposed.

This review covers exactly `runs/finalOne/{main,pr,ponytail,candidateThree}` and their 24 matching worktrees. Parent reports all 48 frozen acceptance executions across both final draws passed; I independently reran finalOne only, not finalTwo or the other final review. A failed mandatory finalOne gate already rules out success in **both** complete draws.

## Critical findings

### R6 — high: candidateThree/main move the confinement boundary through a symlink

In both arms, `sessionTreeConfinement/src/agent/matatoAgentSessions.ts:176–180` resolves **the root itself** with `realpath(root)`, then accepts targets below that potentially outside directory. A stable symlink at `agent/sessions/matato`, or at its `sessions` ancestor, therefore makes unrelated outside files eligible for deletion and reference traversal. This violates the requested requirement that both supplied path and canonical target remain below the managed session root.

I created both fixtures entirely inside my disposable home, wrote and verified an outside target containing a reference to another outside file, then called cleanup through the lexical managed path. Candidate and main deleted **both files** in both cases; the symlink remained. PR112 and Ponytail preserved both files. There is no filesystem race in this reproduction. The ordinary escaping **nested** file/directory symlink checks pass for every arm; they do not test a moving root anchor.

Evidence: `commands/{candidateThree,main,pr,ponytail}StableSessionConfirmation.log`, with explicit before-read assertions and after-state JSON; initial independent two-case reproductions are retained as `*stableSessionProbe.log`. Ponytail already owns a discriminating maintained root-symlink regression at `src/agent/matatoAgentSessions.test.ts:252`; candidate/main omit it. This is meaningful missing security coverage, not equivalent setup duplication.

```mermaid
flowchart LR
  supplied[Lexical managed path] --> link[Symlinked managed root / ancestor]
  link --> outside[Outside canonical target]
  outside --> moved[Candidate/main compare against realpath root]
  moved --> deletion[Outside target AND referenced child deleted]
```

### R7 — medium, explicit boundary: candidateThree/main accept supplied zero IDs when zero rows exist

Candidate `memoryReferenceResolution/src/storage/memoryBlock.ts:95,118` checks Set membership but not the specified zero sentinel. Main has the same room issue and accepts a zero topic through its ID Map. A schema-valid persisted ID `0` therefore resolves instead of throwing. Both current implementations returned normally for a topic referring to room zero and an item referring to topic zero, committing the block. PR112/Ponytail explicitly reject zero and leave all five tables unchanged.

Evidence: `commands/{candidateThree,main,pr,ponytail}zeroIdProbe.log`. This probe **directly seeds schema-valid SQLite rows**; it does not claim the normal auto-increment creation APIs emit zero. Ordinary zero references into normally created data are rejected in all arms and are covered by maintained/frozen checks. The brief nevertheless declares a supplied zero unresolved, without a persisted-row exception. There is no schema positive-ID CHECK establishing the stronger assumption used by candidate/main.

### R8 — integration: PR112/Ponytail leave an affected work-cleanup fixture outside the new root

Their unchanged `sessionTreeConfinement/src/storage/work.test.ts:109–115` still creates the session at `agent/sessions/agent.jsonl`, outside `sessions/matato`, and expects work deletion to remove it. The focused existing work suite fails **1/8** for each arm. Pinned original production/tests pass **8/8**. Main and candidate adapt this fixture to the eligible root and pass **8/8**; candidate reuses `resolveGuiChatSessionDirectory`.

Evidence: `commands/{pr,ponytail,main,candidateThree,pureBase}WorkSessionIntegration.log`. This is stale integration coverage, **not** a reason to weaken confinement or allow deleting the old out-of-root path. The original native selections and changed-suite selections do not include this unchanged comparator file.

### R9 — final gate: combined improvement is not a production AND combined win

Independently recomputed production/test churn matches the parent exactly: main **96/1088**, PR112 **104/1157**, Ponytail **98/1126**, candidate **104/1058**. Candidate combined **1162** is below **1184/1261/1224**, but production is **+8/0/+6** versus the baselines. A tie is not strictly below. Additionally, R6/R7 defeat an unqualified effectiveness/completeness claim despite green frozen checks.

## Recomputed metrics

Git physical additions/deletions include new files, fixtures, helpers, snapshots and Unicode/backslash filenames. Dependency links and build artifacts are excluded. `metrics.json` includes every changed file, hashes, bytes, physical churn/net, and a secondary nonblank/trimmed-line comparison. No source was reformatted to manufacture a win.

| Arm | Production +/− (churn) | Tests +/− (churn) | Combined churn | Added lines | Combined net | Combined byte growth |
|---|---:|---:|---:|---:|---:|---:|
| main | 72/24 (96) | 1078/10 (1088) | 1184 | 1150 | +1116 | +83,294 |
| PR112 | 78/26 (104) | 1141/16 (1157) | 1261 | 1219 | +1177 | +199,849 |
| Ponytail | 73/25 (98) | 1119/7 (1126) | 1224 | 1192 | +1160 | +81,011 |
| candidateThree | 79/25 (104) | 1046/12 (1058) | 1162 | 1125 | +1088 | +207,189 |

| Case | main prod/tests | PR112 prod/tests | Ponytail prod/tests | Candidate prod/tests |
|---|---:|---:|---:|---:|
| Unicode graph find | 17/97 | 17/115 | 14/106 | 16/113 |
| Literal DB paths | 4/77 | 5/96 | 4/105 | 5/66 |
| Memory references | 36/351 | 39/353 | 39/344 | 44/355 |
| Session confinement | 23/163 | 27/211 | 25/189 | 23/148 |
| Quantity boundaries | 6/170 | 6/169 | 6/158 | 6/176 |
| Game vocabulary | 10/230 | 10/213 | 10/224 | 10/200 |

Candidate combined deltas are **−22/−99/−62** versus main/PR112/Ponytail. It loses memory and quantity churn to every comparator, and Unicode churn to main/Ponytail. The aggregate line saving is not a universal per-case saving.

After dropping blank lines and trimming line-edge whitespace for a secondary comparison, combined churn is candidate **1068**, main **1072**, PR112 **1155**, Ponytail **1095**. Thus most of the 22-line physical advantage over main is formatting/spacing, although not all. Production remains candidate **104** versus **96/103/96**. This diagnostic does not replace the predeclared physical-line metric, excuse defects, or assert semantic equivalence after normalization.

Byte accounting reverses the aggregate ranking: candidate has the largest byte growth. Its existing Python sample fans out through shared and overlay snapshots: Unicode test byte growth is **173,355**, versus main **46,674**, PR112 **161,855**, Ponytail **42,306**. Candidate replaces about **7.17 MB** of old snapshot/test lines with about **7.34 MB**, largely in single-line JSON. Main/Ponytail's registered dedicated samples avoid that fan-out. These are real maintenance costs, not free two-line changes. All **14 changed JSON snapshots**, totaling **14,739,235 bytes / 465,118 scalar leaves**, were fully parsed and traversed; structural differences are in `snapshotAudit.json`. Full snapshot comparisons and generator comparisons also parse complete JSON, never truncated mirrors.

Profile bytes/hashes match the freeze: candidate **2642**, main **5121**, PR112 **3161**, Ponytail **3492**. Candidate is 401 bytes below candidateTwo and meets the runtime size ceiling without a new runtime script/reference. All 46 freeze-listed hashes match. This establishes size compliance, not implementation-gate success.

## Genuine reuse, and what smaller tests do or do not preserve

**Python search:** all arms use `str.casefold`, SQLite's connection-local deterministic UDF, the existing SQLAlchemy connect event and existing SQL ranking/query composition. No new dependency, data rewrite, migration, reindex or global replacement of SQLite `lower`. NULL stays NULL. Literal `instr`, exact raw stable keys, repository scope, rank/external/tie ordering, diagnostics, metadata and limits remain in the owning layer. Candidate/PR share three SQL expression objects through tuple/generator composition; main names them separately, Ponytail repeats the expressions. These are small composition choices, not a new algorithm or demonstrated reduction in SQLite evaluations.

Candidate's production-indexed Unicode scenario now lives in `CoffeeNavigation.collect → localized_find`, so the unchanged maintained navigation generator reaches it. Its existing fixture root, all shared snapshots and Python variants are consistent. **R1/R2/R4 do not recur in these outputs:** every arm passes fixture consumers and regeneration. I ran each real generator with Python language/variant selection, intercepted snapshot writes in memory, fully parsed outputs and matched every emitted snapshot **byte-for-byte**: candidate/PR six writes, main/Ponytail seven including their dedicated sample. No baselines were regenerated on disk. Historical failures remain historical; these are new draws, not repairs.

**Literal paths:** every arm composes the existing dependency API `URL.create("sqlite", database=str(target))` with the existing engine. The read-only factory already uses `URL.create` and `Path.as_uri`; neither a hand-written escaping algorithm nor a parallel engine was needed. Parent creation, expansion/resolution, connection events, foreign keys, migration WAL and transactions stay intact. Candidate extends existing persistence, navigation-snapshot and project-CLI fixture seams. Its seven selection cases plus combined troublesome path and isolated options case avoid main's character × entry-point matrix while preserving the different path-selection routes. Its 66 test-churn lines versus 77/96/105 are plausibly reduced duplication; focused behavior checks find no path defect. This is bounded evidence, not proof that every omitted combination is redundant.

**Memory:** every arm reuses `withStorageTransaction`, persisted/new name Maps, existing stores/linkers and `Set`/`mergeNumbers`. Throws occur inside the original transaction, including late item-topic resolution, and the all-five-table regressions protect rollback/recovery. Explicit IDs remain authoritative over stale/different names with `id !== undefined`; exact-name semantics and deduplication are preserved for normal data. Candidate genuinely shares the derived room-ID Set once at the common `createTopics` lifetime rather than rebuilding it per topic. That costs signature/call-site lines: its 44 production churn is larger than 36/39/39. No measured throughput/memory saving follows. R7 shows why membership reuse cannot silently replace the zero policy.

All memory suites reuse `createTestDatabaseFixture`; candidate's typed input builder, table reader and rejection/recovery helper are real setup/assertion reuse. Its exclusive-ID cases assert the wrong topic stays unlinked, unlike an ambiguous success assertion where both topics are expected anyway. Rollback, late failure, recovery, metadata, exact names, persisted-only links, empty collections and unlink assertions are meaningful. Candidate still spends 355 test lines versus 351/353/344 and keeps a separate unlink setup. There is no observed test-size win here, nor evidence that more test lines automatically buy complete boundary coverage.

**Sessions:** all arms use native `realpath`/`stat`, separator-bounded lexical checks and the existing visited-set recursion. Candidate/main/PR resolve child paths inside the existing JSON-line `try`, so malformed non-string child values are ignored there; Ponytail checks the actual JSON value once before traversal. This is a real untyped boundary, not duplication of a trusted internal TypeScript shape. All arms preserve finite graph traversal, cycles/shared references, invalid/missing/directory children and non-session protections in the ordinary fixtures. Candidate's two consolidated scenarios share writers/reference builders and exercise substantial interactions rather than a separate harness. But its smaller 148-line test churn versus Ponytail's 189 omits Ponytail's distinct root-symlink regression. **Do not credit the entire saving as harmless deduplication.** Main's 163-line suite also misses it; PR's implementation happens to reject it but lacks that explicit maintained case.

**Elixir:** all six quantity validators are identical idiomatic `validate_number(..., greater_than_or_equal_to: 0)` compositions. All vocabulary patches reuse `validate_inclusion`; state is cast separately with `empty_values: []` and required validation, preserving omitted PENDING while rejecting explicit nil/empty state. No custom parser/range policy, transition policy, quantity-policy change in the vocabulary task, migrations, service or dependency was added. Candidate's vocabulary case table reduces repeated schema setup to 200 lines versus 230/213/224 while retaining per-field invalid/valid/update/no-op checks, explicit nil/empty, accumulated errors and association composition. Quantity tests cost 176 versus 170/169/158 despite shared schema construction; much remaining multiplication covers common Ecto casting/action behavior. Neither smaller case counts nor larger Cartesian loops alone establish effectiveness.

The substantive reuse is genuine but largely **shared by the baselines**. The seam-first process reduced some test organization, not aggregate production machinery. R6 and R7 prevent a no-completeness-loss conclusion. No revision, causal prompt-effect claim, measured resource-saving claim or universal superiority claim is warranted.

## Checks actually executed

`evidence.json` contains **146** command records with exact command, cwd, exit, duration, complete output path and verified output SHA-256. Each command had a 120-second cap; none timed out. TypeScript native wrappers also enforce their original internal budgets. Frozen scripts were copied unchanged into my review directory solely to confine their temporary files; original manifests/oracles/profiles stayed unchanged. Python basetemps were uniquely substituted under this review directory.

All **24 frozen acceptance**, **24 manifest-native**, **24 explicit maintained selections**, **4 shared Python consumer selections**, **4 standalone Python fixture selections** and **4 actual generator-route audits** passed. The explicit maintained selections include every added/changed test file, not just whatever native discovery happens to collect. Native Elixir runs the external oracle again; it does **not** discover the new owned tests, which were separately required into pure ExUnit.

| Maintained test cases executed | main | PR112 | Ponytail | Candidate |
|---|---:|---:|---:|---:|
| Unicode | 149 | 64 | 149 | 60 |
| Literal paths | 98 | 56 | 65 | 47 |
| Memory | 32 | 35 | 37 | 34 |
| Sessions | 31 | 24 | 25 | 23 |
| Quantities | 12 | 21 | 6 | 12 |
| Vocabulary | 8 | 7 | 9 | 7 |

Counts reflect explicit file selections and parametrization, not comparable coverage scores. Main/Ponytail changed the shared pipeline test file, so their Unicode maintained selection additionally executes that file's existing cases. All arms also receive the same focused fixture-consumer selection. Session candidate/main maintained selections include their changed work suite; the unchanged PR/Ponytail suite was then run explicitly and exposed R8.

All **8 Python Pyright**, **8 configured Python Ruff**, **8 TS native type/source-lint**, and **8 explicit changed TS-test ESLint** checks passed. Two initial overbroad Ruff invocations explicitly supplied intentionally unresolved fixture sample names in main/Ponytail; they failed F821. Those sample files are excluded by the repository's `extend-exclude = ["tests/fixtures"]`. Consistent `--force-exclude` reruns pass for all eight Python outputs. Failed invocations remain recorded, not mislabeled as passes or production defects. Pyright uses a read-only linked shared `.venv` in each own copy, with fixtures excluded as configured.

The security/zero probes are **supplements, not replacements** for these owned regressions. Their current-production failures are R6/R7. The focused existing work-suite failures are R8. Frozen-green therefore does not mean all checks green.

### Candidate maintained original-production controls

I retained candidate tests/fixtures and restored pinned original production only in **separate own copies**. No experiment source was reverted.

| Case | Original-production maintained result | Detects |
|---|---|---|
| Unicode | 2 failed, 58 passed | Unicode ranking and real indexed Unicode navigation |
| Literal paths | 15 failed, 32 passed | Literal path selection plus existing CLI/navigation consumers on troublesome paths |
| Memory | 10 failed, 24 passed | Missing room/topic references, including late atomic failures |
| Sessions | 2 failed, 21 passed | Unsafe traversal/deletion and invalid-child handling |
| Quantities | 4 failed, 8 passed | Negative schema quantities and simultaneous player errors |
| Vocabulary | 3 failed, 4 passed | Unsupported values, explicit clearing and accumulated order errors |

Unicode coffee-only independently fails 1/14. Restoring only each Ecto file separately also fails: quantity Order **1**, CpuOrderData **1**, Player **2**; vocabulary Order **3**, Player **1**, PlayerOrders **1**. Thus an early failing comprehension over one schema does not conceal another file's missing validator. Each experiment starts from its own pristine current-production copy, not a previous failing restoration.

All six maintained suites detect the original holes. Already-correct valid input, ID precedence, association/default/state-update behavior is expected to pass original production; that is compatibility coverage, **not failure to detect the bug**. These controls do not establish mutation adequacy or complete coverage of new risks—R6/R7 demonstrate the distinction. No Atlas manifest mutation score is claimed.

## Scope, integrity and blindness limits

All execution used archive copies under `reviews/finalOne`; dependency links were used read-only. Real prebuilt Ecto/Decimal/Telemetry runtime was loaded directly with `elixir -pa`, without PostgreSQL, Mix aliases, application startup, network or installs. Only local temporary SQLite databases were written. No blanket full application/frontend suite was run.

Original outputs/profiles/research files and changed-source fingerprints before/after match across **8,885 files and 24 worktree HEAD/status records**, including a final verification after supplements. All 24 source transfers have per-file hashes. No original worktree, user checkout, shared dependency, README or profile was modified. Detailed shared dependency trees were not independently checksummed; read-only usage is the claim.

A reviewer-local tmpfs quota interruption happened between commands while opening a log; only my completed disposable negative copies/runtime fixtures were removed, and execution resumed without changing checks or source. A separate supplemental runner initially reached PR before its own copy existed, spawned no test, then resumed after copy creation. Both infrastructure traces and all completed/negative outputs remain in `runner.log`/`extraRunner.log`; neither is hidden as a test pass.

**No strict reviewer blindness is claimed:** the earlier reviewer saw a reserved TypeScript brief before freeze, as disclosed in revisionTwo/round-one review. All 24 invocation records show no-discovery flags and an explicit `--append-system-prompt` profile; profile hashes match the freeze. Logs contain final summaries, not tool histories, so absence of contamination and causal blindness are **not externally proven** by those flags. I did not read the other final reviewer or finalTwo outputs. No final finding informed another revision.

Primary deliverables: `review.md`, `evidence.json`; detailed metrics `metrics.json`; complete JSON audit `snapshotAudit.json`; exact execution evidence `commands/*.log`; integrity/freeze/transfer hashes alongside them. **Final verdict: size ceiling passes; combined finalOne line gate passes; production strict-below gate fails against all three baselines; correctness supplements fail. Full predeclared production AND combined/effectiveness gate: NOT MET.**
