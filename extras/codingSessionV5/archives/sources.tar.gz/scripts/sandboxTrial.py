"""Allowlisted filesystem, private PID/network namespaces, bounded process lifetime."""
from dataclasses import dataclass, field
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

from common import profileAlias, proxyAlias


@dataclass
class Sandbox:
    workspace: Path
    source: Path
    runtime: Path
    pi: Path
    dependencies: list[Path] = field(default_factory=list)
    inputs: list[tuple[Path, Path]] = field(default_factory=list)
    profile: Path | None = None
    config: Path | None = None
    auth: Path | None = None
    package: Path | None = None
    nativeTrace: Path | None = None
    nativeInstructions: Path | None = None


def environment(stage: Path) -> dict[str, str]:
    for name in ['home', 'tmp', 'cache', 'config', 'data']:
        (stage / name).mkdir(parents=True, exist_ok=True)
    return {'PATH': '/tools:/usr/bin:/bin', 'HOME': str(stage / 'home'),
            'TMPDIR': str(stage / 'tmp'), 'XDG_CACHE_HOME': str(stage / 'cache'),
            'XDG_CONFIG_HOME': str(stage / 'config'), 'XDG_DATA_HOME': str(stage / 'data'),
            'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CI': '1',
            'PI_CODING_AGENT_DIR': '/experiment/config', 'PI_OFFLINE': '1',
            'PI_TELEMETRY': '0', 'PI_SKIP_VERSION_CHECK': '1',
            'PYTHONDONTWRITEBYTECODE': '1', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1',
            'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_NOSYSTEM': '1',
            'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_TERMINAL_PROMPT': '0',
            'PIP_NO_INDEX': '1', 'npm_config_offline': 'true', 'CARGO_NET_OFFLINE': 'true'}


def bind(args: list[str], source: Path, target: Path, writable: bool = False) -> None:
    args.extend(['--bind' if writable else '--ro-bind', str(source), str(target)])


def sandbox(spec: Sandbox, stage: Path, endpoint: Path | None = None,
            cloning: bool = False, agent: bool = False) -> list[str]:
    args = ['bwrap', '--die-with-parent', '--new-session', '--unshare-all',
            '--cap-drop', 'ALL', '--proc', '/proc', '--dev', '/dev',
            '--dir', '/tmp', '--dir', '/home', '--dir', '/run', '--dir', '/experiment',
            '--dir', '/tools']
    for name in ['/usr', '/bin', '/sbin', '/lib', '/lib64']:
        path = Path(name)
        if path.is_symlink():
            args.extend(['--symlink', os.readlink(path), name])
        elif path.exists():
            bind(args, path, path)
    for name in ['/etc/ssl', '/etc/ca-certificates', '/etc/ld.so.cache', '/etc/localtime']:
        if Path(name).exists():
            bind(args, Path(name), Path(name))
    for name in ['node', 'bun']:
        executable = shutil.which(name)
        if executable:
            bind(args, Path(executable).resolve(), Path('/tools') / name)
    # No root/home mount: history, other runs, sockets and user config stay invisible.
    paths = [spec.source, spec.pi.parent, *spec.dependencies]
    for path in sorted(set(paths), key=lambda item: len(item.parts)):
        resolved = path.resolve(strict=True)
        if resolved == Path('/') or resolved in [Path('/home'), Path.home()]:
            raise ValueError('Refusing a broad private mount')
        bind(args, resolved, resolved)
        if path != resolved:
            bind(args, resolved, path)
    for snapshot, alias in spec.inputs:
        bind(args, snapshot, alias)
    bind(args, spec.workspace, spec.workspace, True)
    if not cloning:
        bind(args, spec.workspace / '.git', spec.workspace / '.git')
    bind(args, stage, stage, True)
    if spec.profile:
        bind(args, spec.profile, profileAlias)
    if spec.config:
        # Pi's credential/settings reads acquire sibling lock directories.
        bind(args, spec.config, Path('/experiment/config'), True)
        bind(args, spec.config / 'settings.json', Path('/experiment/config/settings.json'))
    if spec.package:
        bind(args, spec.package, Path('/experiment/package'))
        if (stage / 'config/ponytail').exists():
            bind(args, stage / 'config/ponytail', stage / 'config/ponytail')
    if spec.nativeTrace:
        bind(args, spec.nativeTrace, Path('/experiment/nativeTrace.ts'))
    if spec.nativeInstructions:
        bind(args, spec.nativeInstructions, Path('/experiment/nativeInstructions.txt'))
    if agent:
        if spec.auth is None or spec.config is None:
            raise ValueError('Agent requires private selected-provider auth')
        bind(args, spec.auth, Path('/experiment/config/auth.json'))
        bind(args, Path(__file__).with_name('providerProxy.py'), Path('/experiment/providerProxy.py'))
    if endpoint:
        bind(args, endpoint, proxyAlias)
    # Root and parent directories are immutable; only explicit writable binds survive.
    args.extend(['--remount-ro', '/', '--chdir', str(spec.workspace), '--'])
    return args


def execute(argv: list[str], env: dict[str, str], private: Path, label: str, timeout: int):
    started = time.monotonic()
    timedOut = False
    stdout, stderr = private / f'{label}.stdout', private / f'{label}.stderr'
    with stdout.open('xb') as output, stderr.open('xb') as errors:
        process = subprocess.Popen(argv, cwd=private, env=env, stdin=subprocess.DEVNULL,
                                   stdout=output, stderr=errors, start_new_session=True)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timedOut = True
            code = 124
        finally:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
    return {'exit': code, 'timedOut': timedOut, 'seconds': round(time.monotonic() - started, 3),
            'timeoutSeconds': timeout, 'stdout': str(stdout), 'stderr': str(stderr)}


def shell(spec: Sandbox, label: str, command: str, private: Path,
          timeout: int = 120, cloning: bool = False):
    stage = spec.runtime / label
    env = environment(stage)
    argv = sandbox(spec, stage, cloning=cloning) + ['/bin/bash', '--noprofile', '--norc', '-euc', command]
    return execute(argv, env, private, label, timeout)
