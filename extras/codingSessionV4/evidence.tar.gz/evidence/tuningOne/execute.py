"""Execute exactly eight tuningOne identities, no retries or output analysis."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback

root = Path('/tmp/codingSessionV4')
evidence = root / 'evidence/tuningOne'
coordinator = Path(__file__).resolve()
manifests = [root / 'research/python/manifest.json',
             root / 'research/typescript/tuning/manifest.json']
arms = ['v3', 'v2', 'ponytail', 'candidateOne']


def stamp():
    return datetime.now(timezone.utc).isoformat()


def save(name, value):
    (evidence / name).write_text(json.dumps(value, indent=2) + '\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def treeHashes(directory):
    return {str(path): digest(path) for path in sorted(directory.rglob('*'))
            if path.is_file() and not path.is_symlink()}


def frozenPaths():
    paths = [*root.glob('*.py'), root / 'plan.json', root / 'runnerNotes.md',
             root / 'candidateOneDecision.json', root / 'profilePins.json',
             root / 'dependencyMounts.json', coordinator]
    paths += [root / 'profiles' / f'{arm}.md' for arm in [*arms, 'reuseAblation']]
    for manifest in manifests:
        # Immediate files only; never traverse base/history/reserve or other phases.
        paths += [path for path in manifest.parent.iterdir() if path.is_file()]
    return sorted(set(paths))


def launcherPaths():
    result = {}
    for name in ['python', 'python3', 'pi', 'bun', 'bwrap', 'bash', 'git', 'node']:
        spelling = shutil.which(name)
        if spelling is None:
            raise RuntimeError(f'Required launcher not found: {name}')
        resolved = Path(spelling).resolve()
        result[name] = {'path': spelling, 'resolved': str(resolved), 'sha256': digest(resolved)}
    return result


def snapshot(paths):
    return {'frozenInputs': {str(path): digest(path) for path in paths},
            'launchers': launcherPaths(),
            'ablationOutputs': treeHashes(root / 'runs/ablationOne'),
            'ablationEvidence': treeHashes(root / 'evidence/ablationOne')}


def prelaunch():
    if (root / 'runs/tuningOne').exists() or (root / 'worktrees/tuningOne').exists():
        raise RuntimeError('tuningOne already exists; no reuse, retry or repair permitted')
    if (evidence / 'before.json').exists():
        raise RuntimeError('Coordinator already attempted; no relaunch permitted')
    decision = json.loads((root / 'candidateOneDecision.json').read_text())
    candidate = (root / 'profiles/candidateOne.md').read_bytes()
    v3 = (root / 'profiles/v3.md').read_bytes()
    removed = b' Share reusable results at their common lifetime.'
    assert v3.count(removed) == 1 and v3.replace(removed, b'', 1) == candidate
    assert candidate == (root / 'profiles/reuseAblation.md').read_bytes()
    assert digest(root / 'profiles/candidateOne.md') == decision['sha256']
    assert len(candidate) == decision['bytes']
    ledger = json.loads((root / 'control/budget.json').read_text())
    assert ledger['reserved'] == 4 and len(ledger['runs']) == 4
    assert all(identity.startswith('ablationOne/') for identity in ledger['runs'])
    jobs = []
    for manifest in manifests:
        cases = json.loads(manifest.read_text())['cases']
        assert len(cases) == 1 and cases[0]['phase'] == 'tuning'
        for arm in arms:
            jobs.append({'manifest': str(manifest), 'case': cases[0]['id'], 'arm': arm,
                         'identity': f"tuningOne/{arm}/{cases[0]['id']}"})
    assert len(jobs) == 8 and len({job['identity'] for job in jobs}) == 8
    save('ledgerBefore.json', ledger)
    save('prelaunch.json', {'at': stamp(), 'candidateBytes': len(candidate),
        'candidateSha256': hashlib.sha256(candidate).hexdigest(),
        'byteIdenticalReuseAblation': True, 'onlyRemovedSentence': removed.decode().strip(),
        'causalClaim': 'Unestablished/mixed narrow result; not a proven win.',
        'maxConcurrent': 6, 'processBudgetSeconds': 900,
        'model': 'openai-codex/gpt-6.1-sol', 'thinking': 'high', 'piVersion': '1.1.0',
        'tools': 'read,bash,edit,write', 'noRetriesOrRepairs': True,
        'reserveContentOpened': False, 'jobs': jobs})
    return jobs, ledger


def runJob(job):
    label = job['arm'] + '.' + job['case']
    argv = [shutil.which('python'), str(root / 'runTrial.py'), job['manifest'],
            job['arm'], 'tuningOne']
    record = {**job, 'argv': argv, 'cwd': str(root), 'startedAt': stamp(),
              'stdout': str(evidence / f'{label}.stdout'),
              'stderr': str(evidence / f'{label}.stderr')}
    started = time.monotonic()
    try:
        with Path(record['stdout']).open('xb') as output, Path(record['stderr']).open('xb') as errors:
            process = subprocess.Popen(argv, cwd=root, stdin=subprocess.DEVNULL,
                                       stdout=output, stderr=errors)
            record['pid'] = process.pid
            save(f'{label}.launch.json', record)
            record['exit'] = process.wait()
    except Exception:
        record['coordinatorError'] = traceback.format_exc()
    record['finishedAt'] = stamp()
    record['seconds'] = round(time.monotonic() - started, 3)
    save(f'{label}.command.json', record)
    print(json.dumps(record), flush=True)
    return record


def execution(folder, name):
    path = folder / f'{name}.json'
    if not path.exists():
        return None
    record = json.loads(path.read_text())
    return {key: record[key] for key in ['argv', 'cwd', 'startedAt', 'finishedAt',
                                         'seconds', 'timeoutSeconds', 'timedOut', 'exit']}


def summarize(record):
    folder = root / 'runs' / record['identity']
    path = folder / 'result.json'
    if not path.exists():
        return {'identity': record['identity'], 'runnerExit': record.get('exit'),
                'error': 'Missing result.json; retained without repair'}
    result = json.loads(path.read_text())
    fields = ['case', 'arm', 'status', 'startedAt', 'seconds', 'setupExit', 'agentExit',
              'acceptanceExit', 'nativeExit', 'agentSeconds', 'profileSha256',
              'profileBytes', 'manifestSha256', 'model', 'thinking', 'piVersion']
    row = {key: result[key] for key in fields}
    audit = result.get('profileAudit')
    row.update({'identity': record['identity'], 'runnerExit': record.get('exit'),
                'error': result.get('error'), 'profileAudit': audit,
                'agent': execution(folder, 'agent'),
                'acceptance': execution(folder, 'acceptance'),
                'native': execution(folder, 'native')})
    row['snapshotProfileSha256'] = digest(folder / 'currentProfile.md')
    row['expectedProfileSha256'] = digest(root / 'profiles' / f"{record['arm']}.md")
    row['profileHashesMatch'] = (row['snapshotProfileSha256'] == row['expectedProfileSha256']
                                 == result['profileSha256'] == audit['profileExpectedSha256']) if audit else False
    return row


def main():
    jobs, initialLedger = prelaunch()
    paths = frozenPaths()
    before = snapshot(paths)
    save('before.json', {'at': stamp(), **before})
    started = time.monotonic()
    # Six independent runner processes maximum; each also takes the harness global flock slot.
    with ThreadPoolExecutor(max_workers=6) as executor:
        records = list(executor.map(runJob, jobs))
    save('commands.json', records)
    after = snapshot(paths)
    save('after.json', {'at': stamp(), **after})
    ledger = json.loads((root / 'control/budget.json').read_text())
    save('ledgerAfter.json', ledger)
    newReservations = [identity for identity in ledger['runs'] if identity not in initialLedger['runs']]
    rows = [summarize(record) for record in records]
    summary = {'completedAt': stamp(), 'seconds': round(time.monotonic() - started, 3),
        'commandsAttempted': len(records), 'commandsExited': sum('exit' in row for row in records),
        'inputHashesUnchanged': before['frozenInputs'] == after['frozenInputs'],
        'launcherHashesUnchanged': before['launchers'] == after['launchers'],
        'ablationOutputsUnchanged': before['ablationOutputs'] == after['ablationOutputs'],
        'ablationEvidenceUnchanged': before['ablationEvidence'] == after['ablationEvidence'],
        'reservationsBefore': initialLedger['reserved'], 'reservationsAfter': ledger['reserved'],
        'newReservationCount': len(newReservations), 'newReservations': newReservations,
        'exactExpectedReservations': set(newReservations) == {job['identity'] for job in jobs},
        'maxConcurrentCoordinator': 6, 'harnessGlobalSlots': 6, 'runs': rows,
        'outputSelectionOrQualityAnalysis': False, 'retries': 0, 'repairs': 0,
        'reserveContentOpened': False, 'publicationReady': False}
    save('executionSummary.json', summary)
    print(json.dumps({key: value for key, value in summary.items() if key != 'runs'}), flush=True)
    integrity = all(summary[key] for key in ['inputHashesUnchanged', 'launcherHashesUnchanged',
                    'ablationOutputsUnchanged', 'ablationEvidenceUnchanged', 'exactExpectedReservations'])
    sys.exit(0 if integrity and all(row.get('exit') == 0 for row in records) else 1)


if __name__ == '__main__':
    main()
