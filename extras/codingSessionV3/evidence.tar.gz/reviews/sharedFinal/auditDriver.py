import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tarfile
import time

root = Path('/tmp/codingSessionV3')
review = root / 'reviews/sharedFinal'
excluded = ['--', '.', ':(exclude)node_modules', ':(exclude)atlas/.venv', ':(exclude)_build', ':(exclude)deps']
results = [json.loads(p.read_text()) for p in sorted((root / 'runs').glob('*/*/*/result.json'))]
commands = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (review / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def git(folder, *args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(folder), *args], stderr=subprocess.DEVNULL)


def changed(folder):
    names = git(folder, 'diff', 'HEAD', '--name-only', '-z', *excluded) + git(folder, 'ls-files', '--others', '--exclude-standard', '-z', *excluded)
    return sorted(set(filter(None, names.decode().split('\0'))))


def fileState(path):
    if path.is_symlink():
        return dict(kind='symlink', target=os.readlink(path))
    if not path.exists():
        return dict(kind='missing')
    return dict(kind='file', sha256=sha(path.read_bytes()), bytes=path.stat().st_size, mode=path.stat().st_mode)


def snapshot():
    files, states = {}, {}
    for result in results:
        source = Path(result['worktree'])
        names = git(source, 'ls-files', '-z').decode().split('\0') + changed(source)
        for name in set(names):
            if not name or name in ('node_modules', 'atlas/.venv') or name.startswith(('_build/', 'deps/')):
                continue
            files[str(source / name)] = fileState(source / name)
        states[str(source)] = dict(head=git(source, 'rev-parse', 'HEAD').decode().strip(), status=git(source, 'status', '--porcelain=v1', '-z').decode())
    for base in [root / 'runs', root / 'profiles']:
        for path in base.rglob('*'):
            if path.is_file():
                files[str(path)] = fileState(path)
    for path in root.rglob('*'):
        if path.is_file() and ((path.parent == root) or (path.is_relative_to(root / 'research') and not any(part in ('runtime', 'nativeTemp', '__pycache__') for part in path.parts))):
            files[str(path)] = fileState(path)
    for folder in ['roundOne', 'roundTwo', 'finalOne', 'finalTwo', 'mutation']:
        for path in (root / 'reviews' / folder).glob('*'):
            if path.is_file():
                files[str(path)] = fileState(path)
    return dict(files=files, states=states)


def prepare(result, label, original=False):
    source = Path(result['worktree'])
    target = review / 'copies' / label
    target.mkdir(parents=True)
    with tarfile.open(fileobj=io.BytesIO(git(source, 'archive', result['base']))) as archive:
        archive.extractall(target, filter='data')
    if not original:
        for name in changed(source):
            origin, destination = source / name, target / name
            if not origin.exists():
                destination.unlink(missing_ok=True)
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(origin, destination, follow_symlinks=False)
    (target / 'node_modules').symlink_to('/home/leon/workspace/projects/matato/node_modules')
    files = {str(p.relative_to(target)): fileState(p) for p in target.rglob('*') if p.is_file() or p.is_symlink()}
    save('transfers/' + label + '.json', files)
    return target, files


def execute(label, folder, args):
    scratch = review / 'scratch' / label
    for name in ['home', 'temp', 'cache']:
        (scratch / name).mkdir(parents=True)
    environment = dict(PATH=os.environ['PATH'], HOME=str(scratch / 'home'), TMPDIR=str(scratch / 'temp'), XDG_CACHE_HOME=str(scratch / 'cache'), CI='1', DO_NOT_TRACK='1', BUN_RUNTIME_TRANSPILER_CACHE_PATH=str(scratch / 'cache'), MATATO_TEST_STORAGE_PATH=str(scratch / 'home/.config/matato'))
    sandbox = ['/usr/bin/bwrap', '--die-with-parent', '--unshare-net', '--ro-bind', '/', '/', '--bind', str(review), str(review), '--proc', '/proc', '--dev', '/dev', '--clearenv']
    for name, value in environment.items():
        sandbox += ['--setenv', name, value]
    sandbox += ['--chdir', str(folder), '--', *args]
    log = review / 'commands' / (label + '.log')
    started = time.monotonic()
    with log.open('wb') as output:
        process = subprocess.Popen(sandbox, cwd=folder, env=environment, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        timedOut = False
        try:
            code = process.wait(timeout=120)
        except subprocess.TimeoutExpired:
            timedOut = True
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            code = 124
    record = dict(label=label, argv=args, sandboxArgv=sandbox, environment=environment, cwd=str(folder), exit=code, seconds=round(time.monotonic() - started, 3), timedOut=timedOut, output=str(log), outputSha256=sha(log.read_bytes()))
    commands.append(record)
    save('commands.json', commands)
    print(label, code, record['seconds'], flush=True)
    return record


def freezeProbes():
    frozen = {}
    for name in ['stableSessionConfirmation.ts', 'zeroIdProbe.ts']:
        source = root / 'reviews/finalOne' / name
        shutil.copy2(source, review / 'probes' / name)
        frozen[name] = dict(source=str(source), sourceSha256=sha(source.read_bytes()))
    zero = (review / 'probes/zeroIdProbe.ts').read_text()
    zero = zero.replace('const before = state()\n      expect(() => createMemoryBlock(input))', '''const before = state()
      expect((kind === 'room' ? before.rooms : before.topics).some((row) => row.id === 0)).toBe(true)
      console.log(JSON.stringify({ kind, home: fixture.homePath, storage: fixture.storagePath, seeded: before }))
      const invoke = () => {
        try {
          return createMemoryBlock(input)
        } finally {
          console.log(JSON.stringify({ kind, before, after: state() }))
        }
      }
      expect(invoke)''')
    (review / 'probes/observedZeroId.ts').write_text(zero)
    frozen['observedZeroId.ts'] = dict(sha256=sha(zero.encode()), change='Only seed-presence assertion and before/after diagnostic logs; original throw/message and five-table equality assertions retained.')
    save('probeFreeze.json', frozen)


def run():
    for folder in ['commands', 'probes', 'transfers', 'scratch']:
        (review / folder).mkdir(parents=True, exist_ok=True)
    assert len(results) == 72
    save('before.json', snapshot())
    freezeProbes()
    bun = shutil.which('bun')
    copies = []
    finals = [r for r in results if r['draw'] in ('finalOne', 'finalTwo') and r['case'] in ('sessionTreeConfinement', 'memoryReferenceResolution')]
    base = next(r for r in finals if r['case'] == 'sessionTreeConfinement')
    assert len({r['base'] for r in finals}) == 1
    selections = [(r, r['draw'] + r['arm'] + r['case'], False) for r in finals]
    selections += [(base, 'originalBase', True)]
    for result, label, original in selections:
        folder, files = prepare(result, label, original)
        copies.append((folder, files))
        suites = ['rootAnchor', 'zeroIds', 'workConsumer'] if original else (['rootAnchor', 'workConsumer'] if result['case'] == 'sessionTreeConfinement' else ['zeroIds'])
        for suite in suites:
            args = [bun, '--no-env-file', 'test']
            if suite == 'workConsumer':
                args += ['src/storage/work.test.ts']
            else:
                template = 'stableSessionConfirmation.ts' if suite == 'rootAnchor' else 'observedZeroId.ts'
                target = review / 'probes' / (label + suite + '.test.ts')
                target.write_text((review / 'probes' / template).read_text().replace('candidateRoot/', str(folder) + '/'))
                args += [str(target)]
            execute(label + suite, folder, args)
        after = {name: fileState(folder / name) for name in files}
        assert files == after, label
    save('copyIntegrity.json', dict(unchanged=True, copies=len(copies), note='All archived/transferred files and dependency symlink hashes/types/modes checked after execution; scratch-only writes excluded.'))
    save('after.json', snapshot())
    assert json.loads((review / 'before.json').read_text()) == json.loads((review / 'after.json').read_text())
    save('integrity.json', dict(originalsUnchanged=True, implementations=len(results), copiedSourcesUnchanged=True))


if __name__ == '__main__':
    run()
