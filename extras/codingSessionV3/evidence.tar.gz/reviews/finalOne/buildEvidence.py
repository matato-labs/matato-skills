import hashlib
import json
from pathlib import Path
import re
from runReview import fingerprint, review

before = json.loads((review / 'before.json').read_text())
after = fingerprint()
assert before == after
(review / 'finalIntegrity.json').write_text(json.dumps(dict(unchanged=True, files=len(after['files']), worktrees=len(after['states']), afterSupplements=True), indent=2))

commands = []
for filename in ['commands.json', 'extraCommands.json', 'confirmationCommands.json']:
    for record in json.loads((review / filename).read_text()):
        content = Path(record['output']).read_bytes()
        assert hashlib.sha256(content).hexdigest() == record['sha256']
        text = content.decode()
        record['collection'] = filename
        record['summaryLines'] = [line for line in text.splitlines() if re.search(r'\bpassed\b|\bfailed\b|^\s*\d+ (pass|fail)$|^Ran \d+ tests|Found \d+ errors|errors, \d+ warnings|All checks passed', line)][-12:]
        record['failingTests'] = [line for line in text.splitlines() if line.startswith('FAILED ') or line.startswith('(fail) ') or re.match(r'\s+\d+\) test ', line)]
        if 'Original' in record['label']:
            record['purpose'] = 'maintained original-production negative control; nonzero expected'
        elif 'ConfiguredLint' in record['label']:
            record['purpose'] = 'Ruff with repository fixture exclusion honored; zero expected'
        elif 'StableSession' in record['label'] or 'stableSessionProbe' in record['label']:
            record['purpose'] = 'supplemental stable root/ancestor symlink security contract; zero expected'
        elif 'zeroIdProbe' in record['label']:
            record['purpose'] = 'supplemental explicit-zero contract with directly seeded schema-valid zero rows; zero expected'
        elif record['label'] in ['mainpythonUnicodeGraphFindLint', 'ponytailpythonUnicodeGraphFindLint']:
            record['purpose'] = 'overbroad explicit fixture lint; intentional undefined sample names are excluded by repository config; retained failed invocation, not a production lint defect'
        else:
            record['purpose'] = 'focused current-production check; zero expected'
        commands.append(record)

metrics = json.loads((review / 'metrics.json').read_text())
aggregates = metrics['aggregates']
candidate = aggregates['candidateThree']
gates = {}
for arm in ['main', 'pr', 'ponytail']:
    baseline = aggregates[arm]
    production = candidate['production']['churn'] < baseline['production']['churn']
    combined = sum(candidate[k]['churn'] for k in candidate) < sum(baseline[k]['churn'] for k in baseline)
    gates[arm] = dict(productionStrictlyBelow=production, combinedStrictlyBelow=combined, candidateProduction=candidate['production']['churn'], baselineProduction=baseline['production']['churn'], candidateCombined=sum(candidate[k]['churn'] for k in candidate), baselineCombined=sum(baseline[k]['churn'] for k in baseline))

artifacts = {}
for p in review.iterdir():
    if p.is_file() and p.name not in ['evidence.json', 'evidenceBuild.log']:
        artifacts[p.name] = dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
snapshots = json.loads((review / 'snapshotAudit.json').read_text())
findings = [
    dict(id='R6', severity='high', title='Confinement boundary moves through a symlinked managed root or sessions ancestor', arms=['candidateThree', 'main'], source='sessionTreeConfinement/src/agent/matatoAgentSessions.ts:176-180', evidence=['candidateThreeStableSessionConfirmation', 'mainStableSessionConfirmation', 'prStableSessionConfirmation', 'ponytailStableSessionConfirmation'], result='Both outside target and its referenced child deleted in both stable cases for candidate/main; both preserved by PR/Ponytail. No race.'),
    dict(id='R7', severity='medium', title='Supplied zero IDs can resolve to persisted zero rows', arms=['candidateThree', 'main'], source='memoryReferenceResolution/src/storage/memoryBlock.ts:95,118', evidence=['candidateThreezeroIdProbe', 'mainzeroIdProbe', 'przeroIdProbe', 'ponytailzeroIdProbe'], result='Candidate/main return normally and commit for room ID zero and item-topic ID zero; PR/Ponytail reject atomically. Direct schema-valid SQLite seeding, not a claim normal creation APIs emit zero.'),
    dict(id='R8', severity='medium', title='Existing work cleanup regression has an unadapted out-of-root fixture', arms=['pr', 'ponytail'], source='sessionTreeConfinement/src/storage/work.test.ts:109-115', evidence=['prWorkSessionIntegration', 'ponytailWorkSessionIntegration', 'pureBaseWorkSessionIntegration', 'candidateThreeWorkSessionIntegration', 'mainWorkSessionIntegration'], result='PR/Ponytail fail 1/8; pinned original, main and candidate pass 8/8. Test integration gap, not permission to broaden deletion.'),
    dict(id='R9', severity='gate', title='Predeclared finalOne production AND combined churn gate fails', arms=['candidateThree'], result='Combined below all baselines; production exceeds main/Ponytail and ties PR112. Correctness supplements also fail. No revision or repair made.'),
]

result = dict(
    scope=dict(draw='finalOne', arms=['main', 'pr', 'ponytail', 'candidateThree'], implementations=24, cases=sorted({x['case'] for x in metrics['trials']}), pathsWrittenOnly=str(review), otherFinalReviewsRead=False, finalTwoIndependentlyReviewed=False, noRevisionsOrImplementationRepairs=True),
    conclusion='NOT MET: production strict-below gate fails against every baseline; combined line gate passes; candidate has stable symlink confinement and persisted-zero defects despite frozen acceptance passing.',
    findings=findings,
    checks=dict(frozenAcceptance=dict(executed=24, passed=24), manifestNative=dict(executed=24, passed=24), explicitMaintained=dict(executed=24, passed=24), pythonFixtureConsumers=dict(executed=4, passed=4), standalonePythonFixture=dict(executed=4, passed=4), pythonGeneratorRoutes=dict(executed=4, passed=4, emittedSnapshotsFullyParsedAndCompared=True, exactBytesAll=True), pythonTypes=dict(executed=8, passed=8), pythonConfiguredLint=dict(executed=8, passed=8), typeScriptNativeTypesAndSourceLint=dict(executed=8, passed=8), typeScriptMaintainedTestLint=dict(executed=8, passed=8), candidateOriginalProduction=dict(cases=6, allDetectOriginalBug=True, extraIndividualEctoControls=6, extraUnicodeCoffeeOnly=1), commandRecords=len(commands), timeouts=sum(x['exit']==124 for x in commands)),
    gates=dict(localFinalOne=gates, fullPredeclaredSuccess=False, sizeCeilingMet=True, candidateProfileBytes=2642, mainProfileBytes=5121, prProfileBytes=3161, otherDraw='Parent reports all48 frozen acceptance green across finalOne/finalTwo. This reviewer independently reran finalOne only. One failed mandatory finalOne gate already rules out the both-draw success gate.'),
    metrics=metrics,
    snapshots=dict(files=len(snapshots), bytesFullyParsed=sum(s['bytes'] for s in snapshots), leavesTraversed=sum(s['leaves'] for s in snapshots), detailedStructuralDiff='snapshotAudit.json'),
    integrity=dict(unchanged=True, fingerprintedFiles=len(after['files']), worktrees=24, before='before.json', after='after.json', afterSupplements='finalIntegrity.json', transferHashes='transfers/*.json', frozenHashes='freezeVerification.json', sharedDependencies='Linked into own copies and used read-only; no installs, dependency/profile/original-worktree edits. No full shared-dependency-tree checksum claim.'),
    limits=['Prior reviewer saw reserved TypeScript brief before freeze: no strict reviewer blindness.', 'No-discovery CLI flags and explicit append-system profile verified in all24 invocation records; final summaries only, not tool histories. Causal blindness/absence of contamination not externally proven.', 'Focused checks only; no blanket application suite, PostgreSQL, application startup, network or installs. Real prebuilt Ecto/Decimal/Telemetry runtime loaded into pure ExUnit.', 'Original-code negative controls are not Atlas manifest mutation adequacy; preserved valid behavior passing original production is expected.', 'Initial reviewer tmpfs quota interruption occurred between commands at log creation; only own runtime fixtures/copies removed, all checks completed on resume. Separate extra runner initially attempted a not-yet-created own PR cwd, spawned no command, then resumed after its copy existed. Both traces retained.', 'Two overbroad Python lint invocations explicitly included intentionally unresolved excluded fixture samples; configured --force-exclude reruns all green. Failed invocations retained.'],
    commands=commands,
    artifacts=artifacts,
)
(review / 'evidence.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(commands=len(commands), gates=gates, integrity=result['integrity']), indent=2))
