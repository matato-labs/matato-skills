# Independent review — round two

## Verdict

**No supported overall coding-session win.** Both final variants pass all four original oracles, every existing supplement, and the new frozen holdout checks. Coding uses Croner's actual callback-constructor semantics more precisely and substantially reduces its earlier test overhead. But it has **115 vs 100 production churn lines**, **344 vs 337 combined churn**, and no source-batch expensive-operation advantage. Its native `@cache` adaptation adds another full batch of intermediate dictionaries and an extra pass. The holdout algorithms are equivalent over the checked domain.

Coding has fewer net added lines overall, **240 vs 253**, mostly from tests, not a smaller production implementation: production net is **39 vs 38**. Report those distinctions, not a blanket “less code” or “more efficient” result. This pair does not establish profile causality, general superiority, or justify Ponytail removal/a superiority-labelled PR.

No implementations, profiles, briefs, original oracles, parent files or saved patches were edited. No fixes, cherry-picks, commits or pushes. Added only this review and review scripts/logs under `research/`.

## Audit and exact metrics

Read all eight production/test diffs. Audited every changed coffee snapshot structurally, not merely its one-line diff: both variants' eight snapshot files are byte-identical. Exactly one successful path response changes per language, only `nodes`, `edges`, `boundaries`; remaining nodes and edges are exact ordered prefixes, ending at the successful route edge. Routes, statuses, filters, metadata and other responses are unchanged. Earlier unresolved boundaries remain. These eight responses remove 45 gathered nodes and 61 gathered edges in aggregate; their eight minified one-line replacements count as **16 test churn lines**, not production changes. CLI snapshot labels correctly differ from service boundary labels through existing `graph_output`; no schema relaxation was applied.

Actual `git diff --binary HEAD` matches each saved patch after normalizing only diff prefixes. Actual `git diff --numstat HEAD` matches every `finalMetrics.json` entry; no untracked code files escape accounting. All worktree HEADs equal their respective base HEADs, all base trees remain clean, and all eight whitespace checks pass. Detailed paths, HEADs and hashes: `research/reviewRoundTwoLogs/hygiene.json`, `inputHashes.json`, `immutability.log`. Starting commits remain Atlas `64017b798a75fccff7d6d545172251851fcef615`, CSV `4b1e143abc40f4582d90bfcdc7c55b06d787a934`, scheduler `92ec28467170bb8b520ebe53dea234b7623dec46`.

Cells below are **added/deleted; churn; net**, physical lines relative to the common starting commits. Tests include `src/automationConfig.test.ts`, coffee assertions, and snapshots.

| Case / variant | Production | Tests | Combined |
|---|---:|---:|---:|
| sourceBatchReads / Ponytail | 22/8; 30; +14 | 33/0; 33; +33 | 55/8; 63; +47 |
| sourceBatchReads / coding | 29/14; 43; +15 | 38/0; 38; +38 | 67/14; 81; +53 |
| isinCsvRecords / Ponytail | 27/15; 42; +12 | 53/0; 53; +53 | 80/15; 95; +65 |
| isinCsvRecords / coding | 24/14; 38; +10 | 52/0; 52; +52 | 76/14; 90; +62 |
| scheduleTimeZones / Ponytail | 12/3; 15; +9 | 78/2; 80; +76 | 90/5; 95; +85 |
| scheduleTimeZones / coding | 15/3; 18; +12 | 76/4; 80; +72 | 91/7; 98; +84 |
| pathEarlyExit / Ponytail | 8/5; 13; +3 | 62/9; 71; +53 | 70/14; 84; +56 |
| pathEarlyExit / coding | 9/7; 16; +2 | 49/10; 59; +39 | 58/17; 75; +41 |
| **Total / Ponytail** | **69/31; 100; +38** | **226/11; 237; +215** | **295/42; 337; +253** |
| **Total / coding** | **77/38; 115; +39** | **215/14; 229; +201** | **292/52; 344; +240** |

Machine-readable accounting: `research/reviewRoundTwoLogs/verifiedMetrics.json`; verification script: `research/auditRoundTwo.py`.

For the original three tasks alone, initial → final churn is Ponytail **77→87 production, 179→166 tests, 256→253 combined**; coding **80→99 production, 252→170 tests, 332→269 combined**. Coding's 82-line test-churn reduction is real, but its final three-task combined patch is still 16 churn lines larger. Adding the holdout changes the overall test comparison; do not compare four-task totals against three-task totals as an improvement measure.

## Checks actually executed

Original oracle SHA-256 values remain source `5ea2cc05…`, CSV `74c82284…`, scheduling `0b4e4bac…`, holdout `1c2a425a…`. Prior supplemental manifests and the new frozen manifest all verify. No oracle was replaced or weakened.

| Suite | Base | Ponytail final | coding final |
|---|---|---|---|
| Original source, 5 methods | fails, 5 assertion failures including subtests | pass | pass |
| Original CSV, 13 scenarios | 7 fail / 6 pass | 13 pass | 13 pass |
| Original scheduler, 7 tests | 4 fail / 3 pass | 7 pass | 7 pass |
| Original holdout, 8 methods | 4 fail / 4 pass | 8 pass | 8 pass |
| Existing source supplement, 3 methods | 2 fail / 1 pass | 3 pass | 3 pass |
| Existing CSV supplement, 12 scenarios | 7 fail / 5 pass | 12 pass | 12 pass |
| Existing scheduler supplement, 9 tests | 4 fail / 5 pass | 9 pass | 9 pass |
| Existing real-SQL supplement, 4 cases | 2 fail / 2 pass | 4 pass | 4 pass |
| New holdout supplement, 6 methods | 12 assertion failures across 5 methods | 6 pass | 6 pass |

The ninth scheduler supplement observes dependency behavior rather than imposing another requirement. Base failures are expected negative controls, not infrastructure failures.

Native checks rerun with candidate imports explicitly selected:

| Native check | Ponytail | coding |
|---|---:|---:|
| Source case: `PYTHONPATH=src .venv/bin/python -m pytest tests/test_graph_navigation.py -q` | 49 pass | 50 pass |
| Holdout case: same focused test file | 52 pass | 49 pass |
| Coffee navigation snapshots, separately in both Python cases | 14 pass each | 14 pass each |
| `GOWORK=off GOPROXY=off GOSUMDB=off go test ./data -count=1 -v` | pass | pass |
| `bun test worker/scheduler.test.ts src/automationConfig.test.ts` | 14 pass | 13 pass |

The Bun native check passed in **Asia/Tokyo, UTC and America/Los_Angeles** for both variants. Native test counts are not coverage scores.

Logs: `research/reviewRoundTwoLogs/`. `research/runRoundTwoChecks.py` records exact commands, working directories, environment overrides and exit codes for originals, old supplements and native checks. Four preliminary native Python invocations omitted `PYTHONPATH=src`, so could select the linked editable installation; those logs are retained under `invalid-import/` and **excluded**. All reported native results are corrected reruns. Audit development also corrected diff-prefix and CLI-label assumptions; no candidate or oracle assertions were changed.

Reproduce from `/tmp/codingSessionV2`:

```sh
python research/runRoundTwoChecks.py
python research/auditRoundTwo.py
python research/supplementalRoundTwo/pathEarlyExit.py runs/ponytailFinal/pathEarlyExit
python research/supplementalRoundTwo/pathEarlyExit.py runs/codingFinal/pathEarlyExit
python research/supplementalRoundTwo/pathEarlyExit.py base/pathEarlyExit
sha256sum -c research/supplementalRoundTwo/SHA256SUMS
```

Coffee/resource/API observations were run separately; their exact commands and results are in `coffee-*`, `resources-*`, `semantics-*`, and `path-work-*` logs. The SQL wrapper uses the same installed test interpreter for all three arms and unchanged frozen SQL assertions.

## Source batch: correct bounded reuse, no coding efficiency win

The clarified brief explicitly bounds **reader.file verification records**, not every SQL query. Both satisfy it. Both reuse the original containment, pinned-descriptor open, size checks, hash verification, decoding and excerpt policy. External/pathless entries avoid verification; failures are shared per path; spans, pagination, duplicates and mutable response lists remain independent. Failed verification retains empty bytes rather than changed/unsafe bodies. Subsequent calls, including after failure, observe fresh bytes and indexed hashes. Existing safety tests and the failure-matrix supplement pass.

Measured repeated-path work is identical:

| Eligible same-file nodes | reader.file / local reads / hashes / full decodes, either variant |
|---:|---:|
| 1 | 1 / 1 / 1 / 1 |
| 10 | 1 / 1 / 1 / 10 |
| 100 | 1 / 1 / 1 / 100 |

For ten repeated file keys and separately ten repeated symbol keys, real SQL traces remain **42 SELECTs**, including **10 node-enrichment file-metadata queries** and **1 verification query**. Base is **51**, including 10 of each file-query category. One node is six SELECTs in all three arms. These are the same unresolved end-to-end costs as round one, now explicitly outside the clarified deduplication requirement. Do not describe either result as one total indexed-file query, global DB deduplication, or O(distinct paths) total batch work. Repeated full decoding/splitting remains O(nodes × file bytes), including repeated encoding failures.

Ponytail adds an optional cache argument to the module helper, plus a `verified_bytes` helper; its two cache-mode branches keep single-source calls uncached. The service owns the dictionary. Coding avoids caller-supplied cache plumbing using a local native `@cache`, but introduces `source_excerpts`, wraps single-source as `[node]`/`[0]`, materializes **all** excerpt dictionaries, then zips them with nodes to create final response dictionaries. This is an extra loop/list and temporary dictionary population, not a free native-composition improvement. Both already copy individual output dictionaries; coding additionally keeps a whole intermediate batch alive during the merge. No new generator is involved.

Review-only CPython 3.11 `tracemalloc` stress observations, same interpreter and script, GC disabled during each measurement:

| Workload | Ponytail traced peak | coding traced peak |
|---|---:|---:|
| 20,000 ineligible entries, no file work | 4,027,872 B | 7,880,192 B |
| Four distinct approximately 1 MiB files, one-line excerpts | 13,585,020 B | 13,586,092 B |

The first isolates adaptation overhead: almost twice the peak despite zero cache entries. The second is dominated by existing full-file line splitting, not meaningfully improved by either approach. Current traced allocation after the four-file call is only 4,672 / 4,944 B with the response retained: no evidence here of a cross-call large-buffer leak. These are allocation observations, **not latency, RSS, or representative workload benchmarks**.

Both retain successful bytes for distinct files during excerpt generation, potentially O(sum of verified file sizes); the 8 MiB limit is per file, not a batch cap. Coding releases that cache before final response merging, whereas Ponytail releases it on return from `sources`, so universal peak-memory rankings across arbitrary file/output mixtures would also be unjustified.

Semantically, coding removes explicit membership bookkeeping but adds batch orchestration and a second materialization seam; Ponytail adds an optional mode but keeps the existing single-node orchestration. Neither is an unqualified complexity improvement. Coding's +13 source churn and +5 test churn do not buy fewer measured expensive operations.

## CSV: same stdlib algorithm, small local patch difference

Both use strict `encoding/csv`, unrestricted header width then three data fields, checking errors before field indexing and the record limit before another `Read`. Both preserve whitespace and let the installed reader handle quoting, multiline records, CRLF and fields over 64 KiB. Original and supplemental public embedded-data overlays pass, including malformed headers under nonpositive limits and invalid/oversized tails after a completed prefix. Errors remain real CSV parse errors; no new dependency or custom parser.

Coding omits Ponytail's duplicate nonpositive-limit guard in the exported wrapper: its helper still returns before CSV consumption, but the wrapper opens/closes the embedded file first. Ponytail avoids that open for nonpositive limits. For positive limits, parsing work is equivalent. This explains a small local code saving, not superior parsing efficiency. Both helpers have one production caller and an input-injection test purpose.

The buffering distinction still matters: the reader can prefetch suffix bytes; neither promises an exact underlying byte-read bound. They avoid parsing later records or allowing them to invalidate a completed prefix, and do not call `ReadAll`.

Native tests differ rather than dominate: coding includes a multiline header; Ponytail tests a bad second record both inside/outside the requested prefix and more embedded limit values. Both reuse compact table tests; supplements cover their gaps. Coding saves four production churn lines and one test line here without weakening checked behavior.

## Scheduler: more precise real dependency reuse, bounded advantage

Both add `Automation.timezone?: string`, extend the existing factory seam and forward the zone directly to Croner, preserving paused candidates and five/six-part mode. Existing configuration spreading carries the field; the worker uses the default factory. No config-wide setting, date-conversion layer, daily-session change or new dependency. Candidate rollback, old schedules, overlap across reloads, disabled jobs, duplicates, monitor rejection and terminal stop all survive the real-timer supplements. Lord Howe's half-hour DST transition also passes in both cron widths.

Coding correctly uses the actual installed Croner 10.0.1 constructor **with callback**: it calls date logic while building even a paused job. Ordinary bad zones reject before timer ownership is established. Croner treats explicit `""` as omitted through its timezone fallback; coding closes just that gap in the default factory. Ponytail eagerly constructs an `Intl.DateTimeFormat` for every explicit zone in `buildSchedules`. Its comment that paused jobs defer validation until resume is inaccurate for the production callback path; `resume()` itself simply changes paused state.

Instrumented constructors for one real six-field job show **9 vs 8** formatter constructions for valid UTC and Kathmandu, Ponytail vs coding. Omitted zones use zero in both; explicit empty uses one versus zero before rejecting. This is a supported local reduction of one redundant formatter construction per valid zoned candidate, not a measured scheduler throughput improvement. Both still delegate all timezone scheduling to the same dependency. Coding's extra source lines are mostly factory block/formatting, not more timezone algorithm.

**Changed seam semantics must be disclosed:** with an injected factory that builds Croner without a callback, Ponytail rejects empty/ordinary bad zones independently; coding accepts them because validation lives in its default factory. `semantics-*` logs demonstrate it. There is no production injected-factory caller here, and existing cron validation was already factory-owned, so I have not invented a stronger injected-factory oracle. Nevertheless, coding's pass/validation claim must be bounded to the actual standalone-worker factory; it does not establish factory-independent rejection of every enabled invalid zone. If that is intended as part of the exported scheduler contract, coding has a remaining gap there.

Both final test patches reuse existing scheduler/config fixtures instead of coding's earlier separate timezone test file. Coding exercises actual resume/timer state and folds zone reloads into overlap coverage; Ponytail checks both widths at both DST transitions but its native capture leaves jobs paused. The independent lifecycle and original stored-config checks pass both. Equal 80-line test churn does not imply equal individual assertions, but neither suite was weakened to make a winner.

## Holdout: equally correct early completion, not differentiated generalization

Both pass only the path target through the existing internal traversal seam; `context` leaves it absent. Both stop the BFS before expansion if already complete, and return immediately after the target's **budget-checked admission**, before the next neighbor or speculative fetch-limit cutoff. Both preserve the existing FIFO/order/parent machinery and do not mistake a rejected target for discovery. They preserve gathered preceding edges and external boundaries, missing-key errors, direction/relation filtering and exhausted-versus-bounded outcomes.

Ponytail stores target on `Traversal`; coding threads it through `run`/`expand`. Both add optional target plumbing to internal `traverse`, not public requests or storage. There is no demonstrated native/dependency reuse difference or semantic algorithm saving. Coding's lower net line count here partly reflects signature replacement; both add the same loop condition and post-admission test. No implementation function grows beyond 100 lines.

Frozen new oracle: `research/supplementalRoundTwo/pathEarlyExit.py`, SHA-256 manifest beside it, made read-only **before execution on either candidate or base**. Six methods add a 36-combination depth/node/edge grid, directed diamond tie-order checks with cycles, both-direction edge deduplication, separate returned-row versus processed-row instrumentation, preceding external boundaries, exact success limits, self/external-self completion, missing start and target, full context traversal and unreachable exhaustion. All pass both; base fails 12 assertions. This was a post-implementation supplemental audit, not a newly blinded preregistered holdout.

On a branching six-node graph, base fetches adjacency for **root, a, b, target, noise, tail** and processes five distinct edge rows. Both candidates fetch only **root, a**, process three rows, and retain the same shortest route. Node-port calls fall **7→5**; both still separately validate the target up front and load it again on admission. Fetches may already return later rows in the current bounded adjacency batch; neither candidate processes them after discovery. No claim that storage avoids all prefetch work.

Coding's holdout test patch is 12 churn lines smaller. Ponytail adds explicit cannot-admit-at-budget tests; coding relies more on existing/oracle coverage for that contract. Replacing the old coffee membership assertion with an exact prefix assertion strengthens it; reviewed snapshots are behavioral updates, not oracle relaxation. Both satisfy the independent limits grid.

The prior metadata-blinding imperfection remains disclosed. Fresh agents and a previously unimplemented holdout help, but cannot turn these equivalent results into evidence of broad profile superiority.

## Compact, generalizable skill feedback — replacement only

Current profile independently measures **4417 UTF-8 bytes / 609 whitespace words / 33 lines**, within all three ceilings. Do not add another section or encode these tasks' exact solutions. The useful lesson is to evaluate **native composition together with its adapters**, and reusable results together with all remaining consumer transformations and retained data. A decorator is not an outcome metric. Keep the installed-API probe and existing-test reuse guidance; scheduling and the smaller final test patches show their practical value here.

Suggested replacement for the existing “Name expensive operations…” paragraph, **not an edit**:

> Name expensive work and its unit. Prefer native composition only when adapters stay simpler. Reuse stable results, not consumer-specific outcomes. Count whole-path expensive calls, repeated transformations, copies and peak retained data. Preserve failure semantics and ownership; bound reuse lifetime. Optimize only for a required benefit. A native decorator or fewer boundary calls alone proves no end-to-end saving.

This replaces 424 bytes / 65 words with **417 bytes / 57 words**, leaving the full proposed profile **4410 bytes / 601 words / 33 lines**. Size check: `research/reviewRoundTwoLogs/skill-proposal-size.log`. It shrinks rather than grows the skill and does not prescribe a particular cache, parser, traversal or scheduling implementation.

## Limits and disposition

No full-project suite/typecheck/lint rerun, live worker endurance run, concurrent filesystem-swap stress, production latency benchmark or peak-RSS measurement was performed by this reviewer. Implementers' full-suite claims were read but are not substituted for independently executed checks above. Allocation probes are synthetic; SQL harnesses reuse existing persisted fixtures. No additive patch-composition experiment was performed: each worktree implements its one case independently.

Original acceptance is met in both arms under the clarified verification boundary and actual worker scheduling path; the injected-factory caveat is explicit. Preserve the smaller-test and precise-dependency lessons, but do not market this round as an overall coding-session win. Any next iteration should retain frozen checks and compare complete adapters/resource paths without hand-fixing or cherry-picking candidates. Review temporary fixtures clean themselves up; retained scripts/logs are intentional audit artifacts.
