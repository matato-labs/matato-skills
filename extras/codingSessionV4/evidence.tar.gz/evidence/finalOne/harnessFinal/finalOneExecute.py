from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from finalOnePreflight import evidence, hashes, manifests, quota
from sandboxTrial import root

arms = ['v3', 'v2', 'ponytail', 'candidateTwo']

def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            value.update(block)
    return value.hexdigest()

def launch(job):
    manifest, arm = job
    case = json.loads(manifest.read_text())['cases'][0]
    label = arm + '.' + case['id']
    argv = [sys.executable, str(root / 'runTrial.py'), str(manifest), arm, 'finalOne']
    started = time.monotonic()
    record = {'argv': argv, 'cwd': str(root), 'manifest': str(manifest), 'case': case['id'], 'arm': arm, 'draw': 'finalOne', 'startedAt': datetime.now(timezone.utc).isoformat(), 'parentEnvironment': {'PYTHONDONTWRITEBYTECODE': '1'}, 'maxConcurrent': 6, 'agentTimeoutSeconds': 900, 'retries': 0}
    save(evidence / (label + '.command.json'), record)
    with (evidence / (label + '.stdout')).open('xb') as output, (evidence / (label + '.stderr')).open('xb') as errors:
        process = subprocess.Popen(argv, cwd=root, stdout=output, stderr=errors, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        record['pid'] = process.pid
        save(evidence / (label + '.launch.json'), record)
        code = process.wait()
    record.update({'runnerExit': code, 'seconds': round(time.monotonic() - started, 3), 'finishedAt': datetime.now(timezone.utc).isoformat()})
    save(evidence / (label + '.returned.json'), record)
    print(json.dumps(record), flush=True)
    return record

def launcherHashes():
    result = {}
    for name in ['pi', 'bun', 'bwrap', 'bash', 'python3', 'git']:
        path = Path(shutil.which(name)).resolve()
        result[str(path)] = digest(path)
    return result

def sourceHashes():
    result = {}
    for repo in sorted({json.loads(path.read_text())['cases'][0]['repo'] for path in manifests}):
        names = subprocess.check_output(['git', '-C', repo, 'ls-files', '-z']).decode().split('\0')
        for name in names:
            path = Path(repo) / name
            if name and path.is_file() and not path.is_symlink():
                result[str(path)] = digest(path)
        common = Path(subprocess.check_output(['git', '-C', repo, 'rev-parse', '--git-common-dir'], text=True).strip())
        common = (Path(repo) / common).resolve()
        for name in ['HEAD', 'index', 'config']:
            path = common / name
            if path.is_file():
                result[str(path)] = digest(path)
    return result

def main():
    assert json.loads((evidence / 'preflightComplete.json').read_text())['passed']
    assert json.loads((root / 'control/budget.json').read_text())['reserved'] == 19
    assert not list((root / 'runs/finalOne').iterdir())
    before = hashes()
    preflightHashes = json.loads((evidence / 'frozenAfterPreflight.json').read_text())
    assert all(before[path] == value for path, value in preflightHashes.items())
    save(evidence / 'before.json', before)
    launchers = launcherHashes()
    save(evidence / 'launcherBefore.json', launchers)
    originals = sourceHashes()
    save(evidence / 'originalBefore.json', originals)
    snapshot = evidence / 'harnessFinal'
    snapshot.mkdir()
    for path in [*root.glob('*.py'), root / 'dependencyMounts.json', root / 'runnerNotes.md', root / 'finalFreeze.json']:
        shutil.copy2(path, snapshot / path.name)
    for index, manifest in enumerate(manifests):
        target = evidence / 'frozenInputs' / str(index)
        target.mkdir(parents=True)
        for path in manifest.parent.iterdir():
            if path.is_file():
                shutil.copy2(path, target / path.name)
    save(evidence / 'ledgerBefore.json', json.loads((root / 'control/budget.json').read_text()))
    jobs = [(manifest, arm) for arm in arms for manifest in manifests]
    save(evidence / 'schedule.json', {'jobs': [[str(path), arm] for path, arm in jobs], 'count': 16, 'maxConcurrent': 6, 'noRetries': True})
    with ThreadPoolExecutor(max_workers=6) as pool:
        returned = list(pool.map(launch, jobs))
    save(evidence / 'runnerExits.json', returned)
    save(evidence / 'after.json', hashes())
    save(evidence / 'launcherAfter.json', launcherHashes())
    save(evidence / 'originalAfter.json', sourceHashes())
    ledger = json.loads((root / 'control/budget.json').read_text())
    save(evidence / 'ledgerAfter.json', ledger)
    results = [json.loads(path.read_text()) for path in sorted((root / 'runs/finalOne').glob('*/*/result.json'))]
    fields = ['case', 'arm', 'status', 'seconds', 'agentSeconds', 'setupExit', 'agentExit', 'acceptanceExit', 'nativeExit', 'profileSha256', 'profileBytes', 'profileAudit', 'error']
    save(evidence / 'executionSummary.json', [{key: result[key] for key in fields if key in result} for result in results])
    old = json.loads(Path('/home/leon/.cache/codingSessionV4Owned/relocationEvidence/oldBefore.json').read_text())
    oldAfter = {path: digest(Path(path)) for path in old}
    save(evidence / 'oldAfter.json', oldAfter)
    checks = {'results': len(results), 'reserved': ledger['reserved'], 'finalOneReservations': len([identity for identity in ledger['runs'] if identity.startswith('finalOne/')]), 'frozenUnchanged': hashes() == before, 'launchersUnchanged': launcherHashes() == launchers, 'originalsUnchanged': sourceHashes() == originals, 'oldOutputsUnchanged': oldAfter == old, 'publicationReady': False, 'independentReviewRequired': True, 'qualityScoringPerformed': False}
    save(evidence / 'integrity.json', checks)
    save(evidence / 'quotaAfter.json', {'/tmp': quota('/tmp'), '/home/leon/.cache/codingSessionV4Owned': quota('/home/leon/.cache/codingSessionV4Owned')})
    print(json.dumps(checks), flush=True)
    assert len(results) == 16 and ledger['reserved'] == 35 and all(checks[key] for key in ['frozenUnchanged', 'launchersUnchanged', 'originalsUnchanged', 'oldOutputsUnchanged'])

if __name__ == '__main__':
    main()
