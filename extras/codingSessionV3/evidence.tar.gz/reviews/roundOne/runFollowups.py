import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

review = Path('/tmp/codingSessionV3/reviews/roundOne')
source = (review / 'runReview.py').read_text().split('\ncases = {}')[0]
exec(source.replace("'commands.json'", "'followupCommands.json'"))
base = review / 'pureBase/pythonUnicodeGraphFind'
base.mkdir(parents=True)
trial = root / 'worktrees/tuningOne/candidateOne/pythonUnicodeGraphFind'
with tarfile.open(fileobj=io.BytesIO(git(trial, 'archive', 'HEAD'))) as stream:
    stream.extractall(base, filter='data')
command = f'cd "{base}/atlas" && PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTEST_ADDOPTS= PYTHONPATH="{base}/atlas/src:{base}/atlas" /home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B -m pytest -q -p no:cacheprovider --basetemp="{review}/temp/baseFixtureIntegration" tests/test_coffee_pipeline.py::test_each_physical_project_has_analysis_seams'
run('pureBaseFixtureIntegration', command, base)
for arm in ['candidateOne', 'main', 'pr', 'ponytail']:
    folder = review / 'copies' / arm / 'memoryReferenceResolution'
    run(arm + 'MaintainedTestLint', 'bun node_modules/eslint/bin/eslint.js src/storage/memoryBlock.test.ts', folder)
    folder = review / 'copies' / arm / 'pythonUnicodeGraphFind'
    prefix = f'cd "{folder}/atlas" && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="{folder}/atlas/src:{folder}/atlas" '
    run(arm + 'PythonLint', prefix + '/home/leon/workspace/projects/atlas/atlas/.venv/bin/ruff check .', folder)
    run(arm + 'PythonTypes', prefix + '/home/leon/workspace/projects/atlas/atlas/.venv/bin/pyright', folder)
# Restore one original schema at a time, never manufacture altered logic.
caseId = 'elixirQuantityBoundaries'
result = json.loads((root / 'runs/tuningOne/candidateOne' / caseId / 'result.json').read_text())
for name in ['order.ex', 'cpu_orders_data.ex', 'player.ex']:
    folder = review / 'schemaNegative' / name.removesuffix('.ex')
    shutil.copytree(review / 'copies/candidateOne' / caseId, folder, symlinks=True)
    path = 'lib/beer_game/game/' + name
    (folder / path).write_bytes(git(Path(result['worktree']), 'show', result['base'] + ':' + path))
    run('candidateSchemaOriginal' + name, maintained(caseId, folder, result), folder)
