#!/usr/bin/env python3
"""Supplement: explicit bad zones reject transactionally at BOTH scheduler seams.
The injected factory deliberately validates only the original cron contract, not zones.
Real Croner still owns cron parsing; the recording subclass changes no validation.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

repo = Path(sys.argv[1]).resolve()
source = r'''
import { afterEach, expect, mock, test } from 'bun:test';
import { Cron as RealCron } from __cron__;
const instances: RealCron[] = [];
class ObservedCron extends RealCron {
 constructor(...args: ConstructorParameters<typeof RealCron>) { super(...args); instances.push(this); }
}
mock.module(__cron__, () => ({Cron:ObservedCron}));
const {createScheduler} = await import(__scheduler__);
const cleanups: Array<() => void> = [];
afterEach(() => { for (const cleanup of cleanups.splice(0)) cleanup(); for (const job of instances.splice(0)) job.stop(); });
function job(overrides: any = {}) {
 return {jobName:'daily',enabled:true,schedule:'0 9 * * *',userPrompt:'run',canOverlap:false,model:'test',thinkingLevel:'off',canLaunchSubAgents:false,useSkill:false,...overrides};
}
function make(injected: boolean) {
 // Original factory seam: real five/six-field cron construction; intentionally
 // ignorant of timezone. Scheduler must enforce its config contract itself.
 const factory = (pattern: string, run: () => Promise<void>) => new ObservedCron(pattern, {paused:true,mode:'5-or-6-parts'},run);
 const scheduler = createScheduler({run:async () => {},onError:() => {},...(injected ? {createSchedule:factory} : {})});
 cleanups.push(scheduler.stop); return scheduler;
}
for (const injected of [false,true]) {
 const seam = injected ? 'injected' : 'default';
 for (const timezone of ['', 'Mars/Olympus']) {
  test(`${seam}: enabled explicit ${JSON.stringify(timezone)} rolls back all candidates`, async () => {
   let runs = 0;
   const factory = (pattern: string, run: () => Promise<void>) => new ObservedCron(pattern,{paused:true,mode:'5-or-6-parts'},run);
   const scheduler = createScheduler({run:async () => {runs++;},onError:() => {},...(injected ? {createSchedule:factory} : {})});
   cleanups.push(scheduler.stop);
   scheduler.replace([job({jobName:'old',timezone:'UTC'})]);
   const old = instances[0];
   expect(() => scheduler.replace([
    job({jobName:'first',timezone:'Europe/Berlin'}),
    job({jobName:'second',schedule:'0 0 9 * * *'}),
    job({jobName:'bad',timezone}),
   ])).toThrow();
   expect(scheduler.names()).toEqual(['old']);
   expect(old.isStopped()).toBe(false);
   // Eager prevalidation may create no candidates; any actually created must stop.
   for (const candidate of instances.slice(1)) expect(candidate.isStopped()).toBe(true);
   await old.trigger(); expect(runs).toBe(1);
   scheduler.stop(); expect(old.isStopped()).toBe(true); expect(scheduler.names()).toEqual([]);
  });
 }
 test(`${seam}: disabled bad zones and bad cron are inert`, () => {
  const scheduler = make(injected);
  scheduler.replace([job({jobName:'good',timezone:'UTC'}),
   job({jobName:'empty',enabled:false,timezone:'',schedule:'not cron',monitor:true}),
   job({jobName:'invalid',enabled:false,timezone:'Mars/Olympus',schedule:'not cron'})]);
  expect(scheduler.names()).toEqual(['good']); expect(instances.length).toBe(1);
  expect(instances[0].isStopped()).toBe(false);
 });
 test(`${seam}: valid five/six-field and omitted zone retain cron/duplicate rollback`, () => {
  const scheduler = make(injected);
  scheduler.replace([job({jobName:'five',timezone:'Asia/Kathmandu'}),job({jobName:'six',schedule:'0 0 9 * * *'})]);
  expect(scheduler.names()).toEqual(['five','six']);
  expect(instances.slice(0,2).every(job => !job.isStopped())).toBe(true);
  expect(() => scheduler.replace([job({jobName:'candidate'}),job({jobName:'badCron',schedule:'0 0 0 * * * 2026'})])).toThrow();
  expect(instances[2].isStopped()).toBe(true);
  expect(scheduler.names()).toEqual(['five','six']);
  expect(() => scheduler.replace([job(),job({enabled:false})])).toThrow('Duplicate jobName');
  expect(scheduler.names()).toEqual(['five','six']);
  expect(instances.slice(0,2).every(job => !job.isStopped())).toBe(true);
 });
}
'''
for token, value in {'__cron__':str(repo / 'node_modules/croner/dist/croner.js'), '__scheduler__':str(repo / 'worker/scheduler.ts')}.items():
    source = source.replace(token, json.dumps(value))
with tempfile.TemporaryDirectory(prefix='finalFactoryOracle-') as folder:
    test = Path(folder) / 'scheduleFactoryContract.test.ts'
    test.write_text(source)
    result = subprocess.run(['bun','test',str(test)], cwd=repo, env={**os.environ,'TZ':'Asia/Tokyo'}, timeout=30)
sys.exit(result.returncode)
