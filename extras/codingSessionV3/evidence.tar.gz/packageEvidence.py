import hashlib
import io
import json
from pathlib import Path
import re
import tarfile


root = Path('/tmp/codingSessionV3')
destination = Path('/home/leon/.t3/worktrees/matato-pi/t3-eefce132/extras/codingSessionV3')
textSuffixes = {'.json', '.py', '.ts', '.exs', '.sh', '.md', '.txt', '.log', '.exit', '.sha256', '.patch'}
secretPatterns = [re.compile(rb'gh[pousr]_[A-Za-z0-9]{35,}'),
                  re.compile(rb'github_pat_[A-Za-z0-9_]{40,}'),
                  re.compile(rb'sk-(?:proj-|ant-)?[A-Za-z0-9_-]{45,}'),
                  re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')]


def filesForArchive() -> list[Path]:
    files = {path for path in root.iterdir() if path.is_file() and path.suffix in textSuffixes}
    files.update((root / 'profiles').glob('*.md'))
    for language in (root / 'research').iterdir():
        if not language.is_dir():
            continue
        files.update(path for path in language.iterdir() if path.is_file())
        for phase in ['tuning', 'validation', 'logs']:
            folder = language / phase
            if folder.is_dir():
                files.update(path for path in folder.iterdir() if path.is_file())
        for name in ['provenance.json', 'checksums.sha256']:
            path = language / 'runtime' / name
            if path.is_file():
                files.add(path)
    for folder in (root / 'runs').glob('*/*/*'):
        files.update(path for path in folder.iterdir() if path.is_file())
    for review in (root / 'reviews').iterdir():
        files.update(path for path in review.iterdir() if path.is_file())
        for name in ['commands', 'probes', 'tooling', 'transfers',
                     'memoryReferenceResolution', 'sessionTreeConfinement']:
            folder = review / name
            if folder.is_dir():
                files.update(path for path in folder.iterdir()
                             if path.is_file() and path.suffix in textSuffixes)
        checks = review / 'checks'
        if checks.is_dir():
            files.update(path for path in checks.rglob('*')
                         if path.is_file() and not path.is_symlink()
                         and path.suffix in textSuffixes)
    return sorted(path for path in files if not path.is_symlink()
                  and (path.suffix in textSuffixes or path.name in {'native', 'oracle'})
                  and path.name not in {'README.md', 'ponytail.md'})


def main() -> None:
    paths = filesForArchive()
    records = []
    findings = []
    for path in paths:
        data = path.read_bytes()
        ponytailMarker = b' '.join([b'You are a lazy senior developer.',
                                   b'The best code is the code never written.'])
        assert ponytailMarker not in data, path
        for pattern in secretPatterns:
            if pattern.search(data):
                findings.append(str(path.relative_to(root)))
        records.append({'path': str(path.relative_to(root)), 'bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()})
    assert not findings, sorted(set(findings))
    assert len([path for path in paths if path.name == 'changes.patch']) == 72
    for phase in ['tuning', 'validation']:
        for name in ['native', 'oracle']:
            assert root / 'research/typescript' / phase / name in paths
    archive = destination / 'evidence.tar.gz'
    with tarfile.open(archive, 'w:gz') as output:
        for path in paths:
            output.add(path, arcname=str(path.relative_to(root)), recursive=False)
        data = (json.dumps(records, separators=(',', ':')) + '\n').encode()
        member = tarfile.TarInfo('memberManifest.json')
        member.size = len(data)
        member.mode = 0o644
        output.addfile(member, io.BytesIO(data))
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (destination / 'evidence.sha256').write_text(f'{digest}  evidence.tar.gz\n')
    with tarfile.open(archive) as source:
        for record in records:
            stream = source.extractfile(record['path'])
            assert stream is not None
            assert hashlib.sha256(stream.read()).hexdigest() == record['sha256']
    audit = {'members': len(records) + 1, 'patches': 72,
             'uncompressedBytes': sum(record['bytes'] for record in records),
             'archiveBytes': archive.stat().st_size, 'sha256': digest,
             'credentialPatternMatches': 0, 'memberHashesVerified': True,
             'excluded': ['Ponytail checkout/profile', 'worktrees and review source copies',
                          'dependency binaries', 'credentials', 'raw chat sessions'],
             'replay': 'Non-hermetic; see evaluation.md for pinned sources and local dependencies.'}
    (destination / 'archiveAudit.json').write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps(audit))


if __name__ == '__main__':
    main()
