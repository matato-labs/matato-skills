# Fixed-profile replication: ponytail, full

Implemented all six cases in brief order, independently under `/tmp/codingSessionV2/runs/ponytailReplication`. Used only the requested ponytail coding skill. Read each available local `AGENTS.md`, affected implementations, and callers. No delegation, source transplant, commits, or pushes. Production changes are confined to each brief's allowedScope; additional changes are focused native tests. README files, production CSV data, shared briefs, profiles, external oracles, originals, and Git configuration were not edited.

Commands below use:

```sh
ROOT=/tmp/codingSessionV2/runs/ponytailReplication
```

All seven external acceptance commands passed on the final verification run. External oracle source was not edited.

## 1. sourceBatchReads

Changed `atlas/src/atlas/services/navigation.py` and `navigation_source.py`. A call-local cache stores verification status and bytes per eligible path, including failures. Excerpt rendering remains per node, so spans, pagination, duplicates, and file-level rendering remain independent. The single-source path does not retain a cache.

```text
sources call -> verify each eligible path once -> render each input node in order
```

Extended `atlas/tests/test_graph_navigation.py` using its existing persisted graph fixture. Tests count indexed-file queries and local reads for success/changed/missing results, check missing-span independence, and verify that the next call reads again.

```sh
python /tmp/codingSessionV2/research/oracles/sourceBatchReads.py "$ROOT/sourceBatchReads"
(cd "$ROOT/sourceBatchReads/atlas" && PYTHONPATH=src uv run pytest tests/test_graph_navigation.py -q)
(cd "$ROOT/sourceBatchReads/atlas" && PYTHONPATH=src timeout 240 uv run pytest -q)
(cd "$ROOT/sourceBatchReads/atlas" && PYTHONPATH=src uv run pyright)
(cd "$ROOT/sourceBatchReads/atlas" && uv run ruff check .)
(cd "$ROOT/sourceBatchReads" && PYTHONPATH=atlas/src uv run --project atlas atlas report --f .)
```

Outcomes: oracle passed; focused tests passed; full Python suite passed (1827 tests and 667 subtests); pyright and Ruff passed; whole-project Atlas report completed successfully. Full pytest emitted nine existing SQLite/index-reflection warnings. An earlier full-suite attempt exceeded the tool's 120-second timeout; the later bounded 240-second run completed.

Initial Python setup attempts lacked pytest/pyright/Ruff. `uv sync` installed dependencies into the candidate-local environment; `PYTHONPATH=src` selected candidate imports. An attempted original-venv link was removed; the original environment was not modified.

Dashboard checks were also attempted as local guidance requests:

```sh
(cd "$ROOT/sourceBatchReads/dashboard" && bun run build)
(cd "$ROOT/sourceBatchReads/dashboard" && bun test)
(cd "$ROOT/sourceBatchReads/dashboard" && bun run typecheck)
(cd "$ROOT/sourceBatchReads/dashboard" && bun lint --fix)
```

Outcomes: build blocked by missing Vite; tests had 64 passes and 12 dependency-loading failures; typecheck and lint blocked by missing `tsc`/ESLint. No dashboard files changed.

## 2. isinCsvRecords

Changed only production `commons/data/isin_loader.go`. Replaced physical-line scanning with `encoding/csv`, skipped one header record, then required three fields. The limit check precedes each data-record read; nonpositive limits return immediately. No trimming, scanner-size limit, dependency, or production-data change.

Added `commons/data/isin_loader_test.go` for native limit and ordinary-record coverage. The external acceptance exercises quoting, multiline/large records, whitespace, bad field counts, malformed records, and completed-prefix isolation.

```sh
gofmt -w "$ROOT/isinCsvRecords/commons/data/isin_loader.go" "$ROOT/isinCsvRecords/commons/data/isin_loader_test.go"
python /tmp/codingSessionV2/research/oracles/isinCsvRecords.py "$ROOT/isinCsvRecords"
(cd "$ROOT/isinCsvRecords/commons" && go test ./data)
```

Outcomes: all oracle scenarios passed; native package test passed.

## 3. scheduleTimeZones

Changed `src/automation.ts` and `worker/scheduler.ts`. Added optional `timezone`, forwarded it to the schedule factory and Croner, and validated explicit enabled-job zones with `Intl.DateTimeFormat` inside candidate construction. Thus injected factories cannot bypass invalid-zone rejection, and existing rollback disposes candidates without stopping old schedules. Disabled jobs still bypass zone/schedule construction. Stored configuration already preserves the optional field, so no loader change was needed.

Extended `worker/scheduler.test.ts` and its fake schedule with timezone forwarding and atomic invalid-zone rejection coverage.

```sh
python /tmp/codingSessionV2/research/oracles/scheduleTimeZones.py "$ROOT/scheduleTimeZones"
python /tmp/codingSessionV2/research/finalOracles/scheduleFactoryContract.py "$ROOT/scheduleTimeZones"
(cd "$ROOT/scheduleTimeZones" && bun test worker/scheduler.test.ts worker/watcher.test.ts)
(cd "$ROOT/scheduleTimeZones" && bun test worker)
(cd "$ROOT/scheduleTimeZones" && bun run check)
(cd "$ROOT/scheduleTimeZones" && bun run lint)
```

Outcomes: both required oracles passed; focused scheduler/watcher tests passed (11 tests). Broader worker run had 24 passes and one module-loading failure for missing `@earendil-works/pi-coding-agent`. Typecheck and lint were blocked by missing `tsc`/ESLint. No dependency manifests were changed.

## 4. pathEarlyExit

Changed `atlas/src/atlas/services/navigation.py` and `navigation_walk.py`. Only path searches supply an internal traversal target. The walk stops before expansion for an already-present target, and immediately after an edge admits the target within existing budgets. It does not process later neighbors or add post-completion cutoffs. Context traversals omit the target and retain full bounded traversal.

Extended `atlas/tests/test_graph_navigation.py` to check zero-expansion self paths and discovery at the depth/edge budget boundary. Updated `test_coffee_navigation_snapshots.py` to project the exact discovery prefix from the existing full-walk fixtures; snapshot files themselves remain unchanged. Before making that test adjustment, compared all eight language responses: only successful path graph nodes, edges, and external boundaries changed; routes, path edges, metadata, filters, and non-path responses were unchanged. The expected projection is derived from fixture target/path-edge positions, never from actual output lengths.

```sh
python /tmp/codingSessionV2/research/oracles/pathEarlyExit.py "$ROOT/pathEarlyExit"
(cd "$ROOT/pathEarlyExit/atlas" && uv sync)
(cd "$ROOT/pathEarlyExit/atlas" && PYTHONPATH=src uv run pytest tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py -q)
(cd "$ROOT/pathEarlyExit/atlas" && PYTHONPATH=src timeout 240 uv run pytest -q)
(cd "$ROOT/pathEarlyExit/atlas" && PYTHONPATH=src uv run pyright)
(cd "$ROOT/pathEarlyExit/atlas" && uv run ruff check .)
(cd "$ROOT/pathEarlyExit" && PYTHONPATH=atlas/src uv run --project atlas atlas report --f .)
```

Outcomes: oracle passed; focused tests passed (61); full Python suite passed (1826 tests and 667 subtests); pyright and Ruff passed; whole-project Atlas report completed successfully. Same nine SQLite/index-reflection warnings as the other Atlas case. The initial snapshot run failed as expected because old fixtures contained traversal after discovery; the reviewed discovery-prefix expectation resolved those differences.

```sh
(cd "$ROOT/pathEarlyExit/dashboard" && bun run build)
(cd "$ROOT/pathEarlyExit/dashboard" && bun test)
(cd "$ROOT/pathEarlyExit/dashboard" && bun run typecheck)
(cd "$ROOT/pathEarlyExit/dashboard" && bun lint --fix)
```

Dashboard outcomes: same missing-dependency blockers as sourceBatchReads (64 tests passed, 12 loading failures; Vite/tsc/ESLint absent). No dashboard files changed.

## 5. pollProcessContract

Changed only production `commons/sintropy/messages.go`. Polling now uses the receiver. ID collection assigns into the allocated slice, preserving order/duplicates without synthetic entries. Processor failure is returned unchanged when marking failed succeeds; `errors.Join` retains both causes when it fails. Existing poll/dequeue wrapping, payloads, endpoints, and empty-poll backoff remain intact.

Added `commons/sintropy/messages_test.go`, covering receiver HTTP configuration, unchanged poll payload, ordered duplicate IDs, processor invocation, both acknowledgement paths, empty/poll failure behavior, and discoverable processor/API errors.

```sh
gofmt -w "$ROOT/pollProcessContract/commons/sintropy/messages.go" "$ROOT/pollProcessContract/commons/sintropy/messages_test.go"
python /tmp/codingSessionV2/research/finalOracles/pollProcessContract.py "$ROOT/pollProcessContract"
(cd "$ROOT/pollProcessContract/commons" && go test -vet=off ./sintropy)
```

Outcomes: oracle and native package tests passed. Used `-vet=off` as instructed for unrelated existing vet blockers; did not modify unrelated methods or logging.

## 6. preScriptIsolation

Changed only production `src/worker/preScript.ts`. Awaiting `module.run()` keeps the existing mutex and environment override through asynchronous settlement. Saved values now retain `undefined`, and restoration tests it explicitly, preserving present empty strings separately from absent variables. Shell execution, import URL/cache behavior, results, and skip interpretation were not changed.

Added `src/worker/preScript.test.ts` for concurrent async overrides, exact restoration through both environment views, synchronous throw, async rejection, import failure, and queue recovery.

```sh
python /tmp/codingSessionV2/research/finalOracles/preScriptIsolation.py "$ROOT/preScriptIsolation"
(cd "$ROOT/preScriptIsolation" && bun test src/worker/preScript.test.ts)
(cd "$ROOT/preScriptIsolation" && bun test src/worker/preScript.test.ts src/worker/scheduledJobs/preScript.test.ts src/worker/bus/preScript.test.ts)
(cd "$ROOT/preScriptIsolation" && bun run typecheck)
(cd "$ROOT/preScriptIsolation" && bun lint)
```

Outcomes: oracle passed; direct regression tests passed (4 tests). Caller integration tests were attempted but two files could not load missing `drizzle-orm`; the direct tests still passed. Typecheck was blocked by missing Bun type definitions; lint by missing `@eslint/js`. Telemetry dependencies already linked were left untouched.

## Final checks and remaining limits

Re-ran all six case oracles plus scheduler additionalAcceptance after implementation; all passed. Re-ran native Go packages, scheduler/watcher tests, and direct pre-script tests after final test edits; all passed. `git diff --check` passed in all six candidates. Diffs and new test files remain uncommitted.

Skipped unrelated refactors, new configuration behavior, and dependency-manifest changes. Broader TypeScript/dashboard validation remains limited by the missing dependencies listed above; no claim of a clean whole-project TypeScript build or integration suite.
