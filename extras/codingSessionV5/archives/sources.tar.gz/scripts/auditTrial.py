"""Allowlist evidence extraction; raw streams/auth never become report inputs."""
import json
from pathlib import Path
import re

from common import digest, model, profileAlias, save
from evidenceTypes import Event, Message

secretPattern = re.compile(
    r'(?i)(?:Bearer\s+\S+|(?:sk|ghp|gho|xoxb|xoxp)[-][A-Za-z0-9_-]{12,}'
    r'|eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+'
    r'|(?:api[_-]?key|access[_-]?token|refresh[_-]?token|password|secret)'
    r'\s*[=:]\s*[\"\']?[^\s\"\']{6,})')
sensitive = re.compile(r'(?i)(auth\.json|/proc/|\benv\b|printenv|credential|token|secret|password|set\s*[+-]x)')
tokenFields = ('input', 'output', 'cacheRead', 'cacheWrite', 'cacheWrite1h', 'reasoning', 'totalTokens')
costFields = ('input', 'output', 'cacheRead', 'cacheWrite', 'total')


def scrub(text: str, secrets: list[str]) -> str:
    for value in sorted(set(secrets), key=len, reverse=True):
        if value:
            text = text.replace(value, '[REDACTED]')
    return secretPattern.sub('[REDACTED]', text)


def publish(record, label: str, folder: Path, secrets: list[str]) -> None:
    public = record.copy()
    for name in ['stdout', 'stderr']:
        target = folder / f'{label}.{name}'
        target.write_text(scrub(Path(record[name]).read_text(errors='replace'), secrets))
        public[name] = target.name
    save(folder / f'{label}.json', public)


def usageTotals(messages: list[Message]):
    usages = [message.get('usage', {}) for message in messages]
    tokens = {key: sum(item[key] for item in usages) if usages and
              all(key in item for item in usages) else None for key in tokenFields}
    costs = [item.get('cost', {}) for item in usages]
    reported = {key: sum(item[key] for item in costs) if costs and
                all(key in item for item in costs) else None for key in costFields}
    return {'tokens': tokens, 'piReportedCostUsd': reported, 'actualBilledCostUsd': None,
            'unavailable': [key for key, value in tokens.items() if value is None],
            'unavailableCost': [key for key, value in reported.items() if value is None],
            'costNote': 'Pi message cost as reported, not a provider invoice. Actual billed cost unavailable.',
            'reasoningNote': 'Reasoning is a subset of output; cacheWrite1h a subset of cacheWrite.'}


def rawLines(raw: Path):
    with raw.open('rb') as stream:
        yield from stream


def audit(raw: Path, folder: Path, profile: bytes, secrets: list[str]):
    starts: dict[str, str] = {}
    ends: set[str] = set()
    messages: list[Message] = []
    firstId, firstRead, observed = '', False, False
    malformed, turns = 0, 0
    settled, aborted, unexpected = False, False, False
    traces = []
    for line in rawLines(raw):
        try:
            event: Event = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError):
            malformed += 1
            continue
        kind = event['type']
        if kind == 'message_end' and event['message']['role'] == 'assistant':
            messages.append(event['message'])
        if kind == 'turn_end':
            turns += 1
        if kind == 'agent_settled':
            settled, aborted = True, event.get('aborted', False)
        if kind in {'compaction_start', 'auto_retry_start', 'summarization_retry_scheduled'}:
            unexpected = True
        if kind not in {'tool_execution_start', 'tool_execution_end'}:
            continue
        trace = toolTrace(event, line, secrets)
        traces.append(trace)
        callId = event['toolCallId']
        if kind == 'tool_execution_start':
            args = event['args']
            if not starts:
                firstId = callId
                firstRead = (event['toolName'] == 'read' and args.get('path') == str(profileAlias)
                             and args.get('offset', 1) == 1)
            starts[callId] = event['toolName']
            continue
        ends.add(callId)
        if callId == firstId and firstRead and not event.get('isError', False):
            text = '\n'.join(block.get('text', '') for block in event['result']['content'])
            observed = text == profile.decode()
    identities = [{key: message.get(key) for key in ['provider', 'model', 'responseModel',
                  'responseId', 'thinkingLevel', 'providerThinkingLevel', 'stopReason']}
                  for message in messages]
    validIdentity = bool(messages) and all(item['provider'] + '/' + item['model'] == model
                                          and item['thinkingLevel'] == 'high' for item in identities)
    finalText = textOf(messages[-1]) if messages else ''
    safeText = scrub(finalText, secrets)
    (folder / 'finalSummary.txt').write_text(safeText)
    (folder / 'toolTrace.jsonl').write_text(''.join(json.dumps(item) + '\n' for item in traces))
    valid = (firstRead and observed and validIdentity and settled and not aborted and
             not malformed and not unexpected and set(starts) == ends and
             set(starts.values()) <= {'read', 'bash', 'edit', 'write'} and
             identities[-1]['stopReason'] == 'stop')
    result = {'valid': valid, 'firstToolIsProfileRead': firstRead, 'fullFirstReadObserved': observed,
              'profileSha256': digest(profile), 'identities': identities,
              'responseModelNote': 'null means upstream identity unreported, not independently verified',
              'malformedRecords': malformed, 'settled': settled, 'aborted': aborted,
              'unexpectedRecovery': unexpected, 'toolStarts': len(starts), 'toolEnds': len(ends),
              'turns': turns, 'assistantMessages': len(messages), 'replyWords': len(finalText.split()),
              'outputWords': sum(len(textOf(message).split()) for message in messages),
              'usage': usageTotals(messages), 'rawSha256': digest(raw.read_bytes()),
              'rawBytes': raw.stat().st_size, 'permissionDenials': None,
              'permissionsNote': 'Pi has no per-call approval gate. Tool errors are not permission-denial counts.'}
    # Identities can contain provider-controlled strings; apply the same publication redaction.
    result = json.loads(scrub(json.dumps(result), secrets))
    save(folder / 'audit.json', result)
    return result


def textOf(message: Message) -> str:
    return '\n'.join(block['text'] for block in message['content'] if block['type'] == 'text')


def toolTrace(event: Event, raw: bytes, secrets: list[str]):
    trace = {'event': event['type'], 'id': scrub(event['toolCallId'], secrets),
             'name': scrub(event['toolName'], secrets), 'payloadSha256': digest(raw),
             'payloadBytes': len(raw)}
    if event['type'] == 'tool_execution_end':
        trace.update(isError=event.get('isError', False), durationMs=event.get('durationMs'))
        return trace
    args = event['args']
    for key in ['path', 'command']:
        value = args.get(key)
        if value and not sensitive.search(value):
            trace[key] = scrub(value, secrets)
    for key in ['offset', 'limit', 'timeout']:
        if key in args:
            trace[key] = args[key]
    return trace
