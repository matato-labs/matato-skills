"""Behavioral boundary checks; invoked with the candidate repository root."""

import json
import os
from pathlib import Path
import shutil
import sys
from tempfile import TemporaryDirectory
import unittest

candidateRoot = Path(sys.argv.pop(1)).resolve()
sys.path.insert(0, str(candidateRoot / "atlas/src"))

import atlas
from atlas.bootstrap import migrate_database, repository_service
from atlas.cli import main
from atlas.parsing.discovery import discover_files, validate_repository
from click.testing import CliRunner

assert Path(atlas.__file__).resolve().is_relative_to(candidateRoot / "atlas/src")
artifactRoot = Path(__file__).resolve().parent


def writeSource(root: Path, name: str) -> None:
    target = root / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("def brew():\n    return 1\n", encoding="utf-8")


def sourcePaths(root: Path) -> set[str]:
    return {source.path for source in discover_files(validate_repository(root))}


def linkPolicy(root: Path, name: str, target: Path) -> None:
    entry = root / name
    entry.parent.mkdir(parents=True, exist_ok=True)
    entry.symlink_to(target)


class BoundaryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.scratch = TemporaryDirectory(prefix="oracle", dir=artifactRoot)
        self.addCleanup(self.scratch.cleanup)
        self.scratchRoot = Path(self.scratch.name)
        self.root = self.scratchRoot / "project"
        self.root.mkdir()
        self.outside = self.scratchRoot / "outside"
        self.outside.mkdir()

    def testExternalRootGitignoreKeepsFallback(self) -> None:
        for chained in (False, True):
            with self.subTest(chained=chained):
                root = self.root / ("chained" if chained else "direct")
                root.mkdir()
                for name in ("main.py", "src/keep.py", "node_modules/no.py", "generatedCode/no.py"):
                    writeSource(root, name)
                policy = self.outside / "policy"
                policy.write_text("*.py\n", encoding="utf-8")
                target = policy
                if chained:
                    target = root / "policyLink"
                    target.symlink_to(policy)
                linkPolicy(root, ".gitignore", target)
                self.assertEqual(sourcePaths(root), {"main.py", "src/keep.py"})
                self.assertEqual(policy.read_text(), "*.py\n")

    def testExternalRootAtlasignoreCannotExclude(self) -> None:
        (self.root / ".gitignore").touch()
        for name in ("main.py", "dist/keep.py"):
            writeSource(self.root, name)
        policy = self.outside / "atlasPolicy"
        policy.write_text("main.py\n/dist/\n", encoding="utf-8")
        linkPolicy(self.root, ".atlasignore", policy)
        self.assertEqual(sourcePaths(self.root), {"main.py", "dist/keep.py"})

    def testNestedExternalRulesCannotOverrideEitherLayer(self) -> None:
        (self.root / ".gitignore").write_text("*.skip.py\n", encoding="utf-8")
        (self.root / ".atlasignore").write_text("*.ban.py\n", encoding="utf-8")
        for name in ("main.py", "src/local.py", "src/other.py", "src/a.skip.py", "src/b.ban.py"):
            writeSource(self.root, name)
        gitPolicy = self.outside / "gitPolicy"
        gitPolicy.write_text("!*.skip.py\nlocal.py\n", encoding="utf-8")
        atlasPolicy = self.outside / "atlasPolicy"
        atlasPolicy.write_text("!*.ban.py\nother.py\n", encoding="utf-8")
        linkPolicy(self.root, "src/.gitignore", gitPolicy)
        linkPolicy(self.root, "src/.atlasignore", atlasPolicy)
        self.assertEqual(sourcePaths(self.root), {"main.py", "src/local.py", "src/other.py"})

    def testConfinedLinksKeepEntryRelativeRulesAndPruning(self) -> None:
        policies = self.root / "policies"
        policies.mkdir()
        (policies / "rootGit").write_text("*.skip.py\nblocked/\n", encoding="utf-8")
        (policies / "nestedGit").write_text("!keep.skip.py\n/local.py\n", encoding="utf-8")
        (policies / "rootAtlas").write_text("*.ban.py\n", encoding="utf-8")
        (policies / "nestedAtlas").write_text("!keep.ban.py\n!bad.skip.py\n/atlas.py\n", encoding="utf-8")
        for name in ("main.py", "src/keep.skip.py", "src/drop.skip.py", "src/bad.skip.py",
                     "src/keep.ban.py", "src/drop.ban.py", "src/local.py", "src/atlas.py",
                     "src/deep/local.py", "other/local.py", "blocked/keep.skip.py", "dist/ok.py"):
            writeSource(self.root, name)
        for entry, target in ((".gitignore", "rootGit"), ("src/.gitignore", "nestedGit"),
                              (".atlasignore", "rootAtlas"), ("src/.atlasignore", "nestedAtlas")):
            linkPolicy(self.root, entry, policies / target)
        (self.root / "blocked/.gitignore").write_text("!keep.skip.py\n", encoding="utf-8")
        alias = self.scratchRoot / "alias"
        alias.symlink_to(self.root, target_is_directory=True)
        self.assertEqual(sourcePaths(alias), {"main.py", "src/keep.skip.py", "src/keep.ban.py",
                                             "src/deep/local.py", "other/local.py", "dist/ok.py"})

    def testUnusableIgnorePathsBehaveAsAbsent(self) -> None:
        for filename in (".gitignore", ".atlasignore"):
            for kind in ("missing", "dangling", "cyclic", "directory"):
                with self.subTest(filename=filename, kind=kind):
                    root = self.root / (filename[1:] + kind)
                    root.mkdir()
                    writeSource(root, "main.py")
                    writeSource(root, "node_modules/no.py")
                    entry = root / filename
                    if kind == "dangling":
                        entry.symlink_to(self.outside / "absent")
                    if kind == "cyclic":
                        entry.symlink_to(filename)
                    if kind == "directory":
                        entry.mkdir()
                    self.assertEqual(sourcePaths(root), {"main.py"})

    def testExternalUndecodableRulesAreNeverConsumed(self) -> None:
        for filename in (".gitignore", ".atlasignore"):
            for nested in (False, True):
                with self.subTest(filename=filename, nested=nested):
                    root = self.root / (filename[1:] + str(nested))
                    root.mkdir()
                    writeSource(root, "main.py")
                    writeSource(root, "src/keep.py")
                    if nested:
                        (root / ".gitignore").touch()
                    policy = self.outside / (filename[1:] + str(nested))
                    policy.write_bytes(b"\xff\xfe\x80")
                    linkPolicy(root, ("src/" if nested else "") + filename, policy)
                    self.assertEqual(sourcePaths(root), {"main.py", "src/keep.py"})
                    self.assertEqual(policy.read_bytes(), b"\xff\xfe\x80")

    def testExternalRuleChangesNeverAffectDiscovery(self) -> None:
        for filename in (".gitignore", ".atlasignore"):
            with self.subTest(filename=filename):
                root = self.root / filename[1:]
                root.mkdir()
                writeSource(root, "main.py")
                writeSource(root, "node_modules/no.py")
                policy = self.outside / filename[1:]
                policy.write_text("", encoding="utf-8")
                linkPolicy(root, filename, policy)
                before = sourcePaths(root)
                policy.write_text("*.py\n", encoding="utf-8")
                self.assertEqual(sourcePaths(root), before)
                self.assertEqual(before, {"main.py"})

    def testProductionReanalysisRestoresPersistedFiles(self) -> None:
        fixtureRoot = candidateRoot / "atlas/tests/fixtures/coffee/python"
        for command in ("index", "report"):
            with self.subTest(command=command):
                root = self.root / command
                shutil.copytree(fixtureRoot, root)
                physical = {path.relative_to(root).as_posix() for path in root.rglob("*.py")}
                excluded = {path for path in physical if "/reporting/" in path}
                self.assertTrue(excluded)
                original = {path: (root / path).read_bytes() for path in physical}
                policy = self.outside / (command + "Policy")
                policy.write_text("/src/coffee/reporting/\n", encoding="utf-8")
                linkPolicy(root, ".atlasignore", policy)
                database = self.scratchRoot / (command + ".sqlite")
                migrate_database(database)
                runner = CliRunner(env={"DATABASE_PATH": str(database)})
                self.assertReportPaths(runner, root, physical)
                self.assertSavedPaths(runner, root, database, command, physical)
                (root / ".atlasignore").unlink()
                (root / ".atlasignore").write_text(policy.read_text(), encoding="utf-8")
                self.assertSavedPaths(runner, root, database, command, physical - excluded)
                (root / ".atlasignore").unlink()
                linkPolicy(root, ".atlasignore", policy)
                self.assertSavedPaths(runner, root, database, command, physical)
                self.assertEqual({path: (root / path).read_bytes() for path in physical}, original)
                self.assertEqual(policy.read_text(), "/src/coffee/reporting/\n")

    def assertReportPaths(self, runner: CliRunner, root: Path, expected: set[str]) -> None:
        result = runner.invoke(main, ["report", "-f", str(root), "--format", "json"])
        self.assertEqual(result.exit_code, 0, result.output)
        report = json.loads(result.output)
        self.assertEqual({node["path"] for node in report["nodes"] if node["kind"] == "file"}, expected)

    def assertSavedPaths(self, runner: CliRunner, root: Path, database: Path,
                         command: str, expected: set[str]) -> None:
        args = [command, "-f", str(root)]
        if command == "report":
            args += ["--save", "--format", "json"]
        result = runner.invoke(main, args)
        self.assertEqual(result.exit_code, 0, result.output)
        with repository_service(database) as service:
            projects = service.list()
            self.assertEqual(len(projects), 1)
            facts = service.get_report_facts(projects[0].id)
            self.assertIsNotNone(facts)
            self.assertEqual({node.path for node in facts.nodes if node.level == "file"}, expected)


if __name__ == "__main__":
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    unittest.main(verbosity=2)
