from datetime import datetime
import hashlib
import json
from pathlib import Path

root = Path('/tmp/codingSessionV4')
out = Path('/home/leon/.cache/codingSessionV4Owned/reviews/finalOne')
inputPaths = [root / name for name in ['reviewContract.md', 'plan.json', 'finalFreeze.json', 'historicalInspection.md', 'candidateOneDecision.json', 'candidateTwoDecision.json', 'profilePins.json', 'sandboxTrial.py']]
inputPaths += [root / 'reviews' / roundName / 'review.md' for roundName in ['ablationOne', 'tuningOne', 'tuningTwo']]
inputPaths += list((root / 'reviews/tuningTwo').glob('*.partial.patch'))
for folder in ['research/python', 'research/typescript/tuning', 'research/typescript/reserve', 'research/additional/reserve']:
    inputPaths += [path for path in (root / folder).iterdir() if path.is_file()]
inputs = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputPaths}
(out / 'inputHashes.json').write_text(json.dumps(inputs, indent=2) + '\n')
audit = json.loads((out / 'audit.json').read_text())
pins = json.loads((root / 'profilePins.json').read_text())
for identity, record in audit.items():
    trial = root / 'runs/finalOne' / identity
    assert record['result'] == json.loads((trial / 'result.json').read_text())
    assert record['profileSha256'] == pins[identity.split('/')[0]]['sha256']
    assert hashlib.sha256((trial / 'changes.patch').read_bytes()).hexdigest() == record['result']['patchSha256']
    for name, key in [('agent', 'agentExit'), ('acceptance', 'acceptanceExit'), ('native', 'nativeExit')]:
        assert json.loads((trial / (name + '.json')).read_text())['exit'] == record['result'][key]
checks = json.loads((out / 'allCommands.json').read_text())
start = min(datetime.fromisoformat(record['startedAt']) for record in checks)
end = max(datetime.fromisoformat(record['finishedAt']) for record in checks)
limits = json.loads((out / 'executionLimits.json').read_text())
limits.update({'firstCommand': start.isoformat(), 'lastCommand': end.isoformat(), 'commandWallSeconds': round((end - start).total_seconds(), 3), 'all16FrozenResultsStillMatch': True})
(out / 'executionLimits.json').write_text(json.dumps(limits, indent=2) + '\n')
paths = [path for path in out.iterdir() if path.is_file() and path.name not in ['artifacts.sha256', 'artifactHashes.json']]
paths += [path for path in (out / 'logs').rglob('*') if path.is_file()]
hashes = {str(path.relative_to(out)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)}
(out / 'artifactHashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
(out / 'artifacts.sha256').write_text(''.join(value + '  ' + name + '\n' for name, value in hashes.items()))
print('Frozen originals unchanged; artifact hashes:', len(hashes), 'command wall seconds:', limits['commandWallSeconds'])
