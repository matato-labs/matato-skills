"""V4 change accounting. No checkout mutation; intent-to-add uses a private index."""
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
from typing import TypedDict


class FileMeasure(TypedDict):
    path: str
    category: str
    added: int
    deleted: int
    churn: int
    baseBytes: int
    resultBytes: int
    byteGrowth: int
    normalizedAdded: int
    normalizedDeleted: int
    binary: bool


class Measurement(TypedDict):
    files: list[FileMeasure]
    patchSha256: str
    patchBytes: int
    sourcePaths: list[str]
    excludedDependencyLinks: list[str]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(worktree: Path, args: list[str], env: dict[str, str] | None = None) -> bytes:
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(worktree),
                                    *args], env=env, stderr=subprocess.PIPE)


def category(path: str) -> str:
    name = Path(path).name.lower()
    parts = {part.lower() for part in Path(path).parts}
    if parts & {'snapshots', '__snapshots__'} or name.endswith('.snap'):
        return 'snapshots'
    if parts & {'fixtures', 'fixture', 'testdata', 'golden', 'goldens', '__fixtures__'}:
        return 'fixtures'
    if (parts & {'test', 'tests', '__tests__', 'spec', 'specs'} or
            name.startswith('test_') or '.test.' in name or '.spec.' in name or
            name.endswith(('_test.go', '_test.rs', '_test.exs', '_spec.rb', 'test.java'))):
        return 'tests'
    sources = {'.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.py', '.pyi', '.go', '.rs',
               '.sh', '.bash', '.zsh', '.fish', '.ex', '.exs', '.erl', '.hrl', '.rb',
               '.java', '.kt', '.kts', '.scala', '.c', '.h', '.cpp', '.hpp', '.cc',
               '.cs', '.fs', '.swift', '.m', '.mm', '.php', '.lua', '.pl', '.r',
               '.sql', '.vue', '.svelte', '.css', '.scss', '.html', '.heex', '.eex',
               '.coffee', '.graphql', '.proto', '.zig', '.clj', '.cljs', '.dart'}
    return 'production' if Path(path).suffix.lower() in sources else 'other'


def counts(before: list[bytes], after: list[bytes]) -> tuple[int, int]:
    added, deleted = 0, 0
    for tag, start, end, newStart, newEnd in difflib.SequenceMatcher(
            a=before, b=after, autojunk=False).get_opcodes():
        if tag in {'replace', 'delete'}:
            deleted += end - start
        if tag in {'replace', 'insert'}:
            added += newEnd - newStart
    return added, deleted


def fileBytes(path: Path) -> bytes:
    if path.is_symlink():
        return os.fsencode(os.readlink(path))
    return path.read_bytes() if path.is_file() else b''


def measureFile(worktree: Path, base: str, path: str) -> FileMeasure:
    exists = subprocess.run(['git', '--no-optional-locks', '-C', str(worktree),
                             'cat-file', '-e', f'{base}:{path}'], capture_output=True)
    before = git(worktree, ['show', f'{base}:{path}']) if exists.returncode == 0 else b''
    after = fileBytes(worktree / path)
    oldLines, newLines = before.splitlines(keepends=True), after.splitlines(keepends=True)
    added, deleted = counts(oldLines, newLines)
    normalAdded, normalDeleted = counts([line.strip() for line in oldLines if line.strip()],
                                        [line.strip() for line in newLines if line.strip()])
    return {'path': path, 'category': category(path), 'added': added, 'deleted': deleted,
            'churn': added + deleted, 'baseBytes': len(before), 'resultBytes': len(after),
            'byteGrowth': len(after) - len(before), 'normalizedAdded': normalAdded,
            'normalizedDeleted': normalDeleted, 'binary': b'\0' in before or b'\0' in after}


def capture(worktree: Path, folder: Path, private: Path, base: str,
            sourcePaths: list[str]) -> Measurement:
    index = private / 'measurementIndex'
    original = Path(os.fsdecode(git(worktree, ['rev-parse', '--git-path', 'index'])).strip())
    if not original.is_absolute():
        original = worktree / original
    shutil.copyfile(original, index)
    env = dict(os.environ, GIT_INDEX_FILE=str(index), GIT_OPTIONAL_LOCKS='0')
    # Git enumerates nonignored files without following directory symlinks.
    newPaths = git(worktree, ['ls-files', '--others', '--exclude-standard', '-z']).split(b'\0')
    candidates = [os.fsdecode(path) for path in newPaths if path]
    excluded = [path for path in candidates
                if (worktree / path).is_symlink() and (worktree / path).is_dir()]
    paths = [path for path in candidates if path not in excluded]
    for start in range(0, len(paths), 100):
        git(worktree, ['add', '-N', '--', *paths[start:start + 100]], env)
    patch = git(worktree, ['diff', '--binary', '--no-ext-diff', '--no-textconv',
                           '--no-renames', base, '--'], env)
    (folder / 'changes.patch').write_bytes(patch)
    changed = git(worktree, ['diff', '--name-only', '-z', '--no-ext-diff', '--no-textconv',
                             '--no-renames', base, '--'], env).split(b'\0')
    files = [measureFile(worktree, base, os.fsdecode(path)) for path in changed if path]
    (folder / 'fileMetrics.json').write_text(json.dumps(files, indent=2) + '\n')
    return {'files': files, 'patchSha256': digest(patch), 'patchBytes': len(patch),
            'sourcePaths': sourcePaths, 'excludedDependencyLinks': excluded}
