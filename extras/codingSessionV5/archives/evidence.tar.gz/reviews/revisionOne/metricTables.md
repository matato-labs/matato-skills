### Runtime and communication

| Patch | Seconds | Turns/tools | Input/output/cache-read/total tokens | Pi USD | Final words | Density |
|---|---:|---:|---|---:|---:|---:|
| R installerDownloadFailures | 92.601 | 11/17 | 33951/3465/87936/125352 | 0.1113456 | 63 | 0.630 |
| R navigationUnseenEdgeBudget | 581.958 | 33/50 | 56166/11456/943872/1011494 | 0.3212792 | 89 | 0.590 |
| R workspaceCheckoutRoots | 120.163 | 15/28 | 32271/4480/150656/187407 | 0.1244076 | 68 | 0.614 |
| P installerDownloadFailures | 113.239 | 14/18 | 28507/4081/131968/164556 | 0.1110208 | 65 | 0.615 |
| P navigationUnseenEdgeBudget | 583.889 | 22/42 | 78122/8904/676352/763378 | 0.3129192 | 87 | 0.594 |
| P workspaceCheckoutRoots | 143.666 | 13/28 | 38009/5133/120832/163974 | 0.1394312 | 65 | 0.612 |

### Delivered size

Each cell reports `add/delete/churn; addedBytes/deletedBytes; resultBytes; physical/nonblank/code LOC; files; rawDEFLATE-addedBytes`.

| Patch | Production | Maintained test/support code | Snapshots | Combined frozen |
|---|---|---|---|---|
| R installerDownloadFailures | 7/3/10; 369/369; 1730; 65/47/39; 1; 153 | 170/0/170; 7472/0; 7472; 170/152/151; 2; 2338 | 0/0/0; 0/0; 0; 0/0/0; 0; 0 | 177/3/180; 7841/369; 9202; 235/199/190; 3; 2432 |
| R navigationUnseenEdgeBudget | 2/4/6; 218/279; 3507; 81/67/66; 1; 143 | 52/0/52; 3672/0; 23354; 421/362/358; 1; 1031 | 1/1/2; 131348/67703; 131348; 1/1/1; 1; 8222 | 55/5/60; 135238/67982; 158209; 503/430/425; 3; 9273 |
| R workspaceCheckoutRoots | 11/1/12; 349/44; 2222; 81/75/75; 1; 188 | 97/4/101; 3444/165; 4898; 140/132/132; 1; 1015 | 0/0/0; 0/0; 0; 0/0/0; 0; 0 | 109/5/114; 3845/209; 7172; 222/208/208; 3; 1165 |
| P installerDownloadFailures | 7/3/10; 369/369; 1730; 65/47/39; 1; 153 | 171/0/171; 7798/0; 7798; 171/154/153; 2; 2395 | 0/0/0; 0/0; 0; 0/0/0; 0; 0 | 178/3/181; 8167/369; 9528; 236/201/192; 3; 2500 |
| P navigationUnseenEdgeBudget | 2/4/6; 219/279; 3508; 81/67/66; 1; 141 | 70/0/70; 4840/0; 24522; 439/380/375; 1; 1407 | 1/1/2; 284781/67703; 284781; 1/1/1; 1; 9774 | 73/5/78; 289840/67982; 312811; 521/448/442; 3; 11247 |
| P workspaceCheckoutRoots | 12/1/13; 362/44; 2235; 82/75/75; 1; 191 | 104/10/114; 4025/336; 5308; 141/132/131; 1; 1217 | 0/0/0; 0/0; 0; 0/0/0; 0; 0 | 117/11/128; 4439/380; 7595; 224/208/207; 3; 1363 |
