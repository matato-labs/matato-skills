import { expect, test } from "bun:test";
import { join } from "node:path";

const root = process.env.CASE_ROOT!;
const { createScheduler } = await import(join(root, "worker/scheduler.ts")) as typeof import("../../../../worker/scheduler.ts");
const { automation, deferred } = await import(join(root, "worker/testFixtures.ts")) as typeof import("../../../../worker/testFixtures.ts");
type Job = { callback: () => Promise<void>; stopped: boolean; resumed: boolean };

function fixture(run: Parameters<typeof createScheduler>[0]["run"] = async () => {}) {
  const jobs: Array<Job> = [];
  const errors: Array<string> = [];
  const scheduler = createScheduler({
    run,
    onError: (message: string) => errors.push(message),
    createSchedule: (pattern: string, callback: () => Promise<void>) => {
      if (pattern === "invalid") throw new Error("bad schedule");
      const job = { callback, stopped: false, resumed: false };
      jobs.push(job);
      return { stop: () => { job.stopped = true; }, resume: () => { job.resumed = true; } };
    },
  });
  return { scheduler, jobs, errors };
}

test("removed and replaced schedule callbacks cannot launch stale work", async () => {
  const prompts: Array<string> = [];
  const { scheduler, jobs } = fixture(async (job: { userPrompt: string }) => { prompts.push(job.userPrompt); });
  try {
    scheduler.replace([automation({ userPrompt: "old", canOverlap: true })]);
    const stale = jobs[0].callback;
    scheduler.replace([]);
    await stale();
    scheduler.replace([automation({ userPrompt: "current", canOverlap: true })]);
    await stale();
    await jobs[1].callback();
    expect(prompts).toEqual(["current"]);
  } finally { scheduler.stop(); }
});

test("a failed replacement leaves current callbacks live and discarded candidates inert", async () => {
  const prompts: Array<string> = [];
  const { scheduler, jobs } = fixture(async (job: { userPrompt: string }) => { prompts.push(job.userPrompt); });
  try {
    scheduler.replace([automation({ userPrompt: "current" })]);
    expect(() => scheduler.replace([
      automation({ jobName: "candidate", userPrompt: "discarded" }),
      automation({ jobName: "bad", schedule: "invalid" }),
    ])).toThrow("bad schedule");
    await jobs[1].callback();
    await jobs[0].callback();
    expect(prompts).toEqual(["current"]);
    expect(scheduler.names()).toEqual(["example"]);
  } finally { scheduler.stop(); }
});

test("positive control: in-flight jobs settle across replacement and retain overlap accounting", async () => {
  const pending = deferred();
  const prompts: Array<string> = [];
  const { scheduler, jobs, errors } = fixture(async (job: { userPrompt: string }) => {
    prompts.push(job.userPrompt);
    if (job.userPrompt === "old") await pending.promise;
  });
  try {
    scheduler.replace([automation({ userPrompt: "old" })]);
    const active = jobs[0].callback();
    scheduler.replace([automation({ userPrompt: "current" })]);
    await jobs[1].callback();
    expect(prompts).toEqual(["old"]);
    pending.resolve();
    await active;
    await jobs[1].callback();
    scheduler.stop();
    await jobs[1].callback();
    expect(prompts).toEqual(["old", "current"]);
    expect(errors).toEqual([]);
  } finally { pending.resolve(); scheduler.stop(); }
});
