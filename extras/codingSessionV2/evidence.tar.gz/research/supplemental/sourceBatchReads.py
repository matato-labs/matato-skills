#!/usr/bin/env python3
"""Supplemental public-service checks; no candidate files are modified."""
import hashlib
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

repo = Path(sys.argv.pop(1)).resolve()
sys.path.insert(0, str(repo / "atlas/src"))
from atlas.domain.navigation import GraphSnapshot
from atlas.services.navigation import NavigationService
from atlas.services import navigation_source as source


class Reader:
    def __init__(self, root):
        self.snapshot = GraphSnapshot("repo", "revision", None, str(root))
        self.nodes, self.rows, self.calls = {}, {}, []

    def node(self, key):
        return self.nodes[key]

    def file(self, path):
        self.calls.append(path)
        return self.rows.get(path, [])

    def diagnostics(self, paths, limit):
        return [{"path": p} for p in paths]


class Supplemental(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.root = Path(folder.name)
        self.reader = Reader(self.root)
        self.service = NavigationService(self.reader)

    def node(self, key, path, level="file", first=None, last=None):
        self.reader.nodes[key] = dict(stableKey=key, path=path, level=level,
                                      startLine=first, endLine=last)

    def indexed(self, path, data):
        (self.root / path).write_bytes(data)
        self.reader.rows[path] = [{"sha256": hashlib.sha256(data).hexdigest()}]

    def testFailureMatrixAndRecovery(self):
        data = b"restored\n"
        self.indexed("ok", data)
        self.node("ok", "ok")
        outside = tempfile.TemporaryDirectory()
        self.addCleanup(outside.cleanup)
        (Path(outside.name) / "secret").write_text("secret")
        (self.root / "escape").symlink_to(Path(outside.name) / "secret")
        (self.root / "directory").mkdir()
        (self.root / "loop").symlink_to("loop")
        self.indexed("encoding", b"\xff")
        self.indexed("large", b"x" * (source.MAX_FILE_BYTES + 1))
        paths = {"escape": "unsafe", "directory": "unreadable", "loop": "unreadable",
                 "encoding": "unsupported_encoding", "large": "too_large",
                 "emptyHash": "unverified", "ambiguous": "unverified"}
        for path in paths:
            self.node(path, path)
            self.reader.rows.setdefault(path, [{"sha256": "indexed"}])
        self.reader.rows["emptyHash"] = [{"sha256": ""}]
        self.reader.rows["ambiguous"] *= 2
        for key, path in [("external", "ok"), ("noPath", None), ("emptyPath", "")]:
            self.node(key, path, "external" if key == "external" else "symbol")
        keys = ["external", "noPath", "emptyPath", *paths, "ok", *paths]
        with patch.object(source, "local_bytes", wraps=source.local_bytes) as reads:
            result = self.service.sources(keys, 2, None)
        rows = result["sources"]
        self.assertEqual([r["stableKey"] for r in rows], keys)
        expected = ["unavailable"] * 3 + list(paths.values()) + ["ok"] + list(paths.values())
        self.assertEqual([r["status"] for r in rows], expected)
        self.assertEqual(reads.call_count, 6)
        self.assertEqual(self.reader.calls, [*paths, "ok"])
        for row in rows:
            if row["status"] != "ok":
                self.assertNotIn("lines", row)
            if row["status"] == "too_large":
                self.assertEqual(row["maxFileBytes"], source.MAX_FILE_BYTES)
                self.assertEqual(row["maxExcerptBytes"], source.MAX_EXCERPT_BYTES)
        # Recovery must invalidate every failure, including indexed-row failures.
        for path in paths:
            target = self.root / path
            if target.is_symlink():
                target.unlink()
            elif target.is_dir():
                target.rmdir()
            self.indexed(path, data)
        self.assertTrue(all(r["lines"] == ["restored"] for r in
                            self.service.sources(list(paths), 2, None)["sources"]))

    def testExcerptFailureIsNotFileFailureAndResponsesAreIndependent(self):
        self.indexed("shared", b"x" * (source.MAX_EXCERPT_BYTES + 1) + b"\nshort\n")
        self.node("wide", "shared", "symbol", 1, 1)
        self.node("short", "shared", "symbol", 2, 2)
        self.node("noSpan", "shared", "symbol")
        keys = ["noSpan", "wide", "short", "short"]
        rows = self.service.sources(keys, 2, None)["sources"]
        self.assertEqual([r["status"] for r in rows], ["span_unavailable", "too_large", "ok", "ok"])
        rows[2]["lines"].append("mutated")
        self.assertEqual(rows[3]["lines"], ["short"])
        # Same reader, distinct services/calls still observe changed bytes.
        (self.root / "shared").write_bytes(b"new\n")
        self.assertEqual(NavigationService(self.reader).source("short", 1, None)["source"]["status"], "changed")

    def testActualWorkCounts(self):
        self.indexed("shared", b"one\ntwo\n")
        self.node("item", "shared", "symbol", 1, 2)
        for size in (1, 10, 100):
            self.reader.calls.clear()
            with patch.object(source, "local_bytes", wraps=source.local_bytes) as reads, \
                 patch.object(source.hashlib, "sha256", wraps=hashlib.sha256) as hashes, \
                 patch.object(source, "source_lines", wraps=source.source_lines) as decodes:
                self.service.sources(["item"] * size, 1, None)
            print(f"WORK nodes={size} lookups={len(self.reader.calls)} reads={reads.call_count} hashes={hashes.call_count} decodes={decodes.call_count}", flush=True)
            self.assertEqual((len(self.reader.calls), reads.call_count, hashes.call_count), (1, 1, 1))
            # Decode count is observational, not a new acceptance requirement.


if __name__ == "__main__":
    unittest.main(verbosity=2)
