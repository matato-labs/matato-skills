from collections import Counter
from pathlib import Path
import json

root = Path(__file__).parent
rows = []
for p in sorted((root/'checks').glob('*/*/*/*.json')):
    value = json.loads(p.read_text())
    rows.append({'check': str(p.relative_to(root)), **value})
(root/'checkResults.json').write_text(json.dumps(rows, indent=2)+'\n')

# Structural snapshot review, without dumping large one-line JSON snapshots.
run = Path(next(x['path'] for x in json.loads((root/'inventory.json').read_text()) if x['label'] == 'A' and x['path'].endswith('navigationUnseenEdgeBudget')))
patch = (run/'evidence/changes.patch').read_text()
report = []
def changes(a, b, path, result):
    if a == b:
        return
    if isinstance(a, dict) and isinstance(b, dict):
        for k in a.keys() | b.keys():
            if k not in a or k not in b:
                result.append((path+'/'+k, 'added' if k in b else 'removed'))
            else:
                changes(a[k], b[k], path+'/'+k, result)
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            result.append((path, f'length {len(a)} -> {len(b)}'))
        for i, (x, y) in enumerate(zip(a, b)):
            changes(x, y, path+'/*', result)
    else:
        result.append((path, f'{str(a)[:100]} -> {str(b)[:100]}'))
for chunk in patch.split('diff --git ')[1:]:
    path = chunk.splitlines()[0].split(' b/')[1]
    if '/snapshots/' not in path:
        continue
    before = json.loads('\n'.join(x[1:] for x in chunk.splitlines() if x.startswith('-') and not x.startswith('---')))
    after = json.loads('\n'.join(x[1:] for x in chunk.splitlines() if x.startswith('+') and not x.startswith('+++')))
    differences = []
    changes(before, after, '', differences)
    report.append(path)
    report.extend(f'{count}x {key}' for key, count in Counter(key for key, text in differences).most_common())
    if path.endswith('navigation.json'):
        for k in before:
            if before[k] == after[k]:
                continue
            detail = []
            changes(before[k], after[k], k, detail)
            report.append('\n'+k)
            report.extend(f'{key}: {text}' for key, text in detail)
(root/'snapshotDetails.txt').write_text('\n'.join(report)+'\n')
print('Saved checkResults.json and snapshotDetails.txt')
