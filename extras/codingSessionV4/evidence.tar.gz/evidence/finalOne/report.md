# finalOne execution report

Exactly 16 fresh implementation processes; ledger 19 → 35. No retry, repair, extra model probe, tuningTwo recreation, finalTwo launch, quality scoring or winner selection. Four original-base preflights: frozen acceptance exit 1 and native exit 0 each. Storage-only amendment and preserved harness documented in storageAmendment.md.

Runtime invocation settings, first complete profile observation and profile hashes pass 16/16. Fresh private configs: 16. Observed maximum concurrency: 6. Fifteen agents settled with final stop; V2 Python timed out at 900 seconds, remains invalidAgentRun. Acceptance 16/16 exits 0; native 10/16 exits 0 and six exits 124 (120-second caps). This is not a valid complete paired comparison.

Candidate profile remains exact 2630 bytes / 6efa072c53b7e83aae7a17f4f60a45efd113cd8dc927c1c1ebf815ec3cd25643. Frozen inputs, launchers including extensionless files, original tracked source/index/config, and historical outputs verified unchanged. No source cleanup/README/PR changes. Raw credentials/streams remain private; publicationReady false.

Per-run records below: total runner seconds, agent seconds; exits agent/acceptance/native; invocation/profile audit pass. Full exact timings/commands/timeouts under runtimeAudits.json and runs/finalOne.

## pythonConfinedIgnoreFiles (Python)

v3: runner 843.847s, agent 715.229s; exits 0/0/124; runtime/profile pass/pass; completed.
v2: runner 1028.309s, agent 900.001s; exits 124/0/124; runtime/profile pass/pass; invalidAgentRun.
ponytail: runner 859.626s, agent 732.433s; exits 0/0/124; runtime/profile pass/pass; completed.
candidateTwo: runner 871.899s, agent 772.487s; exits 0/0/0; runtime/profile pass/pass; completed.

## preScriptEnvironmentLifetime (TypeScript)

v3: runner 592.737s, agent 507.593s; exits 0/0/0; runtime/profile pass/pass; completed.
v2: runner 506.606s, agent 415.564s; exits 0/0/0; runtime/profile pass/pass; completed.
ponytail: runner 334.754s, agent 258.100s; exits 0/0/0; runtime/profile pass/pass; completed.
candidateTwo: runner 358.892s, agent 277.990s; exits 0/0/0; runtime/profile pass/pass; completed.

## sequenceCreateRecovery (TypeScript)

v3: runner 523.674s, agent 389.672s; exits 0/0/124; runtime/profile pass/pass; completed.
v2: runner 516.744s, agent 380.791s; exits 0/0/124; runtime/profile pass/pass; completed.
ponytail: runner 636.996s, agent 503.098s; exits 0/0/124; runtime/profile pass/pass; completed.
candidateTwo: runner 470.784s, agent 341.085s; exits 0/0/0; runtime/profile pass/pass; completed.

## shellBootstrapLocation (Bash)

v3: runner 63.982s, agent 62.210s; exits 0/0/0; runtime/profile pass/pass; completed.
v2: runner 55.670s, agent 54.197s; exits 0/0/0; runtime/profile pass/pass; completed.
ponytail: runner 50.075s, agent 48.693s; exits 0/0/0; runtime/profile pass/pass; completed.
candidateTwo: runner 47.670s, agent 46.214s; exits 0/0/0; runtime/profile pass/pass; completed.

Independent review required. Preserve all failures; do not convert acceptance passes into completed model runs. See reviewerHandoff.md, including extensionless setup production-category accounting limitation.
