#!/usr/bin/env python3
"""Independent frozen review; artifacts only, no candidate edits."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
LOGS = ROOT/'research/reviewFrozenLogs'
LOGS.mkdir(exist_ok=True)
VARIANTS = ['ponytailFrozen','codingFrozen','ponytailReplication','codingReplication']
BRIEFS = json.loads((ROOT/'frozenBriefs.json').read_text())

def git(repo,*args):
    return subprocess.check_output(['git','-C',str(repo),*args],stderr=subprocess.DEVNULL).decode()

def manifest():
    paths = [ROOT/'frozenBriefs.json',ROOT/'frozenMetrics.json']
    for folder in ['profiles','research/oracles','research/supplemental','research/supplementalRoundTwo','research/finalOracles']:
        paths += [p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in str(p)]
    for variant in VARIANTS:
        paths += list((ROOT/'patches'/variant).glob('*.patch'))
        for brief in BRIEFS:
            repo = ROOT/'runs'/variant/brief['caseName']
            paths += [repo/p for p in git(repo,'diff','--name-only','HEAD').splitlines()]
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}

def run(job):
    name,cmd,cwd,extra = job
    try:
        p = subprocess.run(cmd,cwd=cwd,env={**os.environ,**extra},capture_output=True,timeout=240)
        output,rc = p.stdout+p.stderr,p.returncode
    except subprocess.TimeoutExpired as e:
        output,rc = (e.stdout or b'')+(e.stderr or b'')+b'\nTIMEOUT\n',124
    (LOGS/(name+'.log')).write_bytes(('COMMAND '+json.dumps(cmd)+'\nCWD '+str(cwd)+'\nENV '+json.dumps(extra)+'\nEXIT '+str(rc)+'\n').encode()+output)
    print(name,rc,flush=True)
    return dict(name=name,exit=rc)

def jobs():
    result=[]
    for variant in VARIANTS:
        for brief in BRIEFS:
            case=brief['caseName']; repo=ROOT/'runs'/variant/case
            for suite in ['oracles','supplemental','supplementalRoundTwo','finalOracles']:
                script=ROOT/'research'/suite/(case+'.py')
                if script.exists(): result.append((f'{suite}-{variant}-{case}',[sys.executable,str(script),str(repo)],ROOT,{}))
            if case=='scheduleTimeZones':
                result.append((f'factory-{variant}',[sys.executable,str(ROOT/'research/finalOracles/scheduleFactoryContract.py'),str(repo)],ROOT,{}))
                for zone in ['Asia/Tokyo','UTC','America/Los_Angeles']:
                    result.append((f'native-{variant}-{case}-{zone.replace("/","-")}', ['bun','test','worker/scheduler.test.ts','src/automationConfig.test.ts'],repo,{'TZ':zone}))
                result.append((f'semantics-{variant}',[sys.executable,str(ROOT/'research/schedulerSemanticsRoundTwo.py'),str(repo)],ROOT,{}))
            elif case in ['sourceBatchReads','pathEarlyExit']:
                py=str(repo/'atlas/.venv/bin/python')
                for test,label in [('tests/test_graph_navigation.py','native'),('tests/test_coffee_navigation_snapshots.py','coffee')]:
                    result.append((f'{label}-{variant}-{case}',[py,'-m','pytest',test,'-q'],repo/'atlas',{'PYTHONPATH':'src'}))
                if case=='sourceBatchReads':
                    for script,label in [('sourceResourcesRoundThree.py','resources'),('supplemental/sourceSqlWorkPortable.py','sql')]:
                        result.append((f'{label}-{variant}',[py,str(ROOT/'research'/script),str(repo)],ROOT,{}))
            elif case in ['isinCsvRecords','pollProcessContract']:
                package='./data' if case=='isinCsvRecords' else './sintropy'
                result.append((f'native-{variant}-{case}',['go','test','-vet=off',package,'-count=1','-v'],repo/'commons',{'GOWORK':'off','GOPROXY':'off','GOSUMDB':'off'}))
            else:
                result.append((f'native-{variant}-{case}',['bun','test','src/worker/preScript.test.ts'],repo,{'OTEL_SDK_DISABLED':'true','MATATO_TEST_STORAGE_PATH':str(LOGS/('storage-'+variant))}))
    return result

if __name__=='__main__':
    before=manifest(); (LOGS/'inputHashes.json').write_text(json.dumps(before,indent=2)+'\n')
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: results=list(pool.map(run,jobs()))
    (LOGS/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    after=manifest(); changed=[p for p in before.keys()|after.keys() if before.get(p)!=after.get(p)]
    (LOGS/'immutability.json').write_text(json.dumps(dict(files=len(before),changed=changed),indent=2)+'\n')
    assert not changed
    sys.exit(any(r['exit'] for r in results))
