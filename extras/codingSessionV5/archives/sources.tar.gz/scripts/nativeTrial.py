"""Pinned native-package snapshots and activation evidence; never reads credentials."""
import json
from pathlib import Path
from typing import Literal, NotRequired, TypedDict

from common import digest, save
from sandboxTrial import Sandbox, environment, execute, sandbox

packageAlias = Path('/experiment/package')
traceAlias = Path('/experiment/nativeTrace.ts')
primarySkill = 'skills/ponytail/SKILL.md'
baseline = Path(__file__).resolve().parent.parent / 'baseline'


class PackageFile(TypedDict):
    sourcePath: str
    sha256: str
    bytes: int


class Provenance(TypedDict):
    files: list[PackageFile]


class Activation(TypedDict):
    phase: Literal['before', 'context']
    run: int
    sha256: str
    valid: bool


class ActivationEntry(TypedDict):
    customType: str
    data: Activation


class ActivationMessage(TypedDict):
    role: str


class ActivationEvent(TypedDict):
    type: str
    entry: NotRequired[ActivationEntry]
    message: NotRequired[ActivationMessage]


class ActivationReport(TypedDict):
    valid: bool
    expectedSha256: str
    expectedContextSha256: str
    agentStarts: int
    assistantMessages: int
    beforeAgentStartObservations: int
    requestContextObservations: int
    observations: list[Activation]
    boundary: str


def packageFiles(package: Path, profile: bytes) -> dict[str, bytes]:
    package = package.resolve(strict=True)
    provenance: Provenance = json.loads((baseline / 'provenance.json').read_text())
    files = {}
    for item in provenance['files']:
        name = item['sourcePath']
        path = package / name
        if path.is_symlink() or not path.resolve(strict=True).is_relative_to(package):
            raise ValueError('Package resources must be regular files inside the selected root')
        data = path.read_bytes()
        if name != primarySkill and digest(data) != item['sha256']:
            raise ValueError('Native mechanism differs from the pinned package: ' + name)
        files[name] = data
    if files[primarySkill] != profile:
        raise ValueError('Native profile must exactly match package skills/ponytail/SKILL.md')
    return files


def packageHash(files: dict[str, bytes]) -> str:
    return digest(json.dumps({name: digest(data) for name, data in sorted(files.items())},
                             sort_keys=True).encode())


def freezePackage(package: Path, profile: bytes, private: Path, folder: Path) -> Path:
    files = packageFiles(package, profile)
    snapshot = private / 'package'
    snapshot.mkdir()
    for name, data in files.items():
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    original = (baseline / 'upstream' / primarySkill).read_bytes()
    save(folder / 'package.json', {'sourceRoot': str(package), 'sha256': packageHash(files),
         'arm': 'nativePonytail' if profile == original else 'nativeVariant',
         'scope': 'Pinned Pi subset from baseline/provenance.json; extra source files not mounted',
         'onlyPermittedVariant': primarySkill,
         'files': {name: {'sha256': digest(data), 'bytes': len(data)} for name, data in sorted(files.items())}})
    return snapshot


def nativeEnvironment(stage: Path) -> dict[str, str]:
    env = environment(stage)
    config = stage / 'config/ponytail/config.json'
    config.parent.mkdir(parents=True, exist_ok=True)
    save(config, {'defaultMode': 'full', 'quietStartup': True, 'hideStatus': True})
    env.update(PONYTAIL_DEFAULT_MODE='full', PONYTAIL_QUIET_STARTUP='1', PONYTAIL_HIDE_STATUS='1')
    return env


def prepareNative(spec: Sandbox, package: Path, profile: bytes, private: Path, folder: Path) -> None:
    spec.package = freezePackage(package, profile, private, folder)
    spec.nativeTrace = Path(__file__).with_name('nativeTrace.ts')
    probe = Path(__file__).with_name('nativeProbe.mjs')
    spec.inputs.append((probe, Path('/experiment/nativeProbe.mjs')))
    stage = spec.runtime / 'nativeProof'
    env = nativeEnvironment(stage)
    try:
        record = execute(sandbox(spec, stage) + ['node', '/experiment/nativeProbe.mjs'],
                         env, private, 'nativeProof', 20)
    finally:
        spec.inputs.pop()
    if record['exit']:
        raise RuntimeError('Offline native activation proof failed; inspect private nativeProof stderr')
    proof = json.loads(Path(record['stdout']).read_text())
    spec.nativeInstructions = private / 'nativeInstructions.txt'
    spec.nativeInstructions.write_text(proof.pop('instructions'))
    (folder / 'nativeInstructions.txt').write_bytes(spec.nativeInstructions.read_bytes())
    proof.update(instructionsSha256=digest(spec.nativeInstructions.read_bytes()),
                 traceSha256=digest(spec.nativeTrace.read_bytes()), probeSha256=digest(probe.read_bytes()),
                 piRuntimeInjectionProven=False, providerRequestTested=False, actualAuthRead=False)
    save(folder / 'nativeProof.json', proof)


def nativeArgs() -> list[str]:
    return ['-e', str(packageAlias / 'pi-extension/index.js'),
            '--skill', str(packageAlias / 'skills'), '-e', str(traceAlias)]


def auditActivation(raw: Path, expected: bytes) -> ActivationReport:
    events: list[ActivationEvent] = [json.loads(line) for line in raw.read_bytes().split(b'\n') if line.strip()]
    traces = [event['entry']['data'] for event in events if event['type'] == 'entry_appended'
              and event['entry']['customType'] == 'v5NativeActivation']
    starts = sum(event['type'] == 'agent_start' for event in events)
    before = [trace for trace in traces if trace['phase'] == 'before']
    contexts = [trace for trace in traces if trace['phase'] == 'context']
    messages = sum(event['type'] == 'message_end' and event['message']['role'] == 'assistant' for event in events)
    expectedHash = digest(expected)
    contextHash = digest(b'<ponytail>\n' + expected + b'\n</ponytail>')
    valid = bool(before and contexts) and len(before) == starts and len(contexts) == messages
    valid = valid and [trace['run'] for trace in before] == list(range(1, starts + 1))
    valid = valid and all(trace['valid'] and trace['sha256'] ==
                          (expectedHash if trace['phase'] == 'before' else contextHash) for trace in traces)
    valid = valid and all(any(item['run'] == trace['run'] for item in contexts) for trace in before)
    active = 0
    for trace in traces:
        if trace['phase'] == 'before':
            active += 1
        valid = valid and trace['run'] == active
    return {'valid': valid, 'expectedSha256': expectedHash, 'expectedContextSha256': contextHash,
            'agentStarts': starts, 'assistantMessages': messages,
            'beforeAgentStartObservations': len(before), 'requestContextObservations': len(contexts),
            'observations': traces,
            'boundary': 'Read-only observer after Ponytail; full system transcript before provider conversion. Not wire/billing proof.'}
