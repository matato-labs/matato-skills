import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/tmp/codingSessionV4')
out = root / 'reviews/tuningTwo'


class Dqblk(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint64) for name in ['blockHard', 'blockSoft', 'currentSpace', 'inodeHard', 'inodeSoft', 'currentInodes', 'blockTime', 'inodeTime']] + [('valid', ctypes.c_uint32)]


def quota(path: str) -> dict:
    data = Dqblk()
    libc = ctypes.CDLL(None, use_errno=True)
    descriptor = os.open(path, os.O_RDONLY)
    result = libc.syscall(443, descriptor, 0x80000700, os.getuid(), ctypes.byref(data))
    error = ctypes.get_errno()
    os.close(descriptor)
    return {'result': result, 'errno': error, 'uid': os.getuid(), 'hardBytes': data.blockHard * 1024, 'softBytes': data.blockSoft * 1024, 'usedBytes': data.currentSpace, 'remainingBytes': data.blockHard * 1024 - data.currentSpace, 'inodeHard': data.inodeHard, 'usedInodes': data.currentInodes, 'valid': data.valid}


report = {'quotaMethod': 'Linux x86_64 quotactl_fd syscall 443, QCMD(Q_GETQUOTA, USRQUOTA)=0x80000700; read-only', 'quota': {path: quota(path) for path in ['/tmp', '/dev/shm']}}
report['mounts'] = {path: subprocess.check_output(['findmnt', '-T', path, '-o', 'TARGET,SOURCE,FSTYPE,OPTIONS']).decode() for path in ['/tmp', '/dev/shm', '/home']}
report['df'] = subprocess.check_output(['df', '-B1', '/tmp', '/dev/shm', '/home']).decode()
report['runtimeAllocations'] = {}
for folder in (root / 'private').iterdir():
    runtime = folder / 'runtime'
    if not runtime.exists():
        continue
    files = [path for path in runtime.rglob('*') if path.is_file() and not path.is_symlink()]
    allocated = sum(path.stat().st_blocks * 512 for path in files)
    largest = sorted(files, key=lambda path: path.stat().st_blocks, reverse=True)[:3]
    report['runtimeAllocations'][folder.name] = {'allocatedFileBytes': allocated, 'fileCount': len(files), 'largest': [{'path': str(path.relative_to(runtime)), 'bytes': path.stat().st_size, 'allocatedBytes': path.stat().st_blocks * 512} for path in largest]}
report['v4DiskUsage'] = subprocess.check_output(['du', '-s', '-B1', str(root)]).decode()
(out / 'incident.json').write_text(json.dumps(report, indent=2) + '\n')

before = json.loads((root / 'evidence/tuningTwo/before.json').read_text())
verification = {}
for group, values in before.items():
    if not isinstance(values, dict):
        continue
    count = 0
    mismatches = []
    for path, expected in values.items():
        if not path.startswith('/') or not isinstance(expected, str) or len(expected) != 64:
            continue
        count += 1
        actual = hashlib.sha256(Path(path).read_bytes()).hexdigest() if Path(path).is_file() else None
        if actual != expected:
            mismatches.append({'path': path, 'expected': expected, 'actual': actual})
    if count:
        verification[group] = {'checked': count, 'mismatches': mismatches}
verification['launchers'] = [{'path': row['path'], 'matches': hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256']} for row in before['launchers'].values()]
(out / 'knownArtifactVerification.json').write_text(json.dumps(verification, indent=2) + '\n')
print(json.dumps({'quota': report['quota'], 'verification': verification}, indent=2))
