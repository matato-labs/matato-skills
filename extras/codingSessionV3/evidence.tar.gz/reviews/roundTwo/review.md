# Independent V3 review — round two

**Do not freeze candidateTwo as a demonstrated size winner.** The preliminary production/test churn sums are correct: main **60/594**, PR112 **63/648**, Ponytail **60/592**, candidateTwo **61/647**. Candidate passes the executable behavior, maintained regressions and fixture-consumer checks, but loses combined churn to main and Ponytail. Its new Python snapshot still lacks a maintained regeneration route. No experiment implementation was edited, repaired or selected piecemeal.

## Findings

**R4 — candidateTwo: snapshot maintenance remains incomplete.** `atlas/tests/test_coffee_navigation_snapshots.py:27–72` implements the new Unicode scenario and reads `snapshots/coffee/python/unicode_find.json`. Neither the scenario nor this output is connected to `tests/update_coffee_snapshots.py:26–33`, whose `write_navigation` calls the unchanged `navigation_responses` and writes only `navigation.json`. I executed that real Python navigation generator with writes intercepted in memory: it emits only `python/navigation.json`, never the new snapshot. See `commands/candidateSnapshotGeneratorRoute.log`. This is a maintenance/integration gap, **not** an observed search defect or failing snapshot comparison. Moving the shared scenario into a callable producer used by test and generator would close it; that would add implementation/test machinery, not create a free size win. No such repair was made.

Unlike historical candidateOne, this candidate uses an existing fixture root, `script_members/python`. Its added class has no call/inheritance edges, so the existing standalone call snapshot remains valid. Both the shared 11-case consumer command and the additional standalone Python snapshot test pass. Main, PR112 and Ponytail now update their dependent variant snapshots and also pass those checks. These are **new draws**, not repairs or retroactive passes for R1/R2. All 62 historical changed-file hashes still match round one's recorded outputs. R3 remains a historical whitespace-only apparent production win and combined loss.

**R5 — candidateTwo: the size gate still fails.** Combined churn is 708 versus main 654, PR112 711 and Ponytail 652: candidate deltas **+54/−3/+56**. Production also loses to main and Ponytail by one line. TypeScript's 402 test lines dominate; “use builders/case tables” did not prevent a broad companion suite. This observation supports another bounded hypothesis, not a causal conclusion about prompt wording from one draw.

No additional production correctness defect or removed safeguard was found in the affected paths reviewed. Green focused checks do not establish full application correctness or complete maintained coverage of every acceptance assertion.

## Independent metrics

Physical git additions/deletions include new files and Unicode paths, excluding dependency/build artifacts. Fixtures, helpers and snapshots count as tests; other churn is zero. `metrics.json` contains every file, additions, deletions, churn, net growth, bytes and hashes. The changed JSON snapshots were parsed completely and compared structurally (`snapshotAudit.json`); large single-line JSON changes were not ignored.

| Arm | Production +/− | Prod churn | Tests +/− | Test churn | Combined churn | Combined net | Added lines | Combined byte growth |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| main | 47/13 | 60 | 585/9 | 594 | 654 | +610 | 632 | +219,384 |
| PR112 | 50/13 | 63 | 642/6 | 648 | 711 | +673 | 692 | +182,438 |
| Ponytail | 47/13 | 60 | 582/10 | 592 | 652 | +606 | 629 | +209,782 |
| candidateTwo | 46/15 | 61 | 640/7 | 647 | 708 | +664 | 686 | +77,816 |

| Case | main prod/tests | PR112 prod/tests | Ponytail prod/tests | candidateTwo prod/tests |
|---|---:|---:|---:|---:|
| Python | 14/97 | 18/110 | 15/123 | 15/87 |
| TypeScript | 40/350 | 39/356 | 39/310 | 40/402 |
| Elixir | 6/147 | 6/182 | 6/159 | 6/158 |

Candidate combined per-case deltas against main/PR112/Ponytail: Python **−9/−26/−36**, TypeScript **+52/+47/+93**, Elixir **+11/−24/−1**. Its smaller Python fixture fan-out genuinely reduces snapshot bytes, but that benefit does not excuse missing regeneration. Line counts alone hide the large shared snapshot cost.

## Actual reuse, composition and headroom

**Python:** every arm uses `str.casefold`, SQLite `Connection.create_function(..., deterministic=True)` and the existing SQLAlchemy connection event in `readonly_session`. NULLs remain NULL; the UDF is local to fresh graph-reader connections, not a global replacement of SQLite `lower`. `GraphReader.find` retains SQL `instr` for literal punctuation, raw exact stable keys, repository scope, SQL ranking/tie ordering and limits. Service/CLI boundaries stay intact. Candidate and Ponytail bind three SQL expressions through tuple/generator composition; PR112 uses three separate assignments, main repeats the expressions. Candidate's three-line Python advantage over PR112 is two fewer assignment lines plus an omitted explanatory comment, **not a different algorithm or dependency reuse**. Candidate ties Ponytail here and costs one more line than main. Reusing SQL expression objects does not materialize folded database values or prove fewer SQLite calls per row. There is little honest additional production size headroom without changing boundaries or readability.

**TypeScript:** all arms reuse `withStorageTransaction`, its existing `begin immediate`/commit/rollback policy, exact-name Maps, existing create/link stores, `mergeNumbers` and `Set` deduplication. Schema unique names make deriving ID membership from Map values sound. Authoritative explicit IDs use `id !== undefined`; zero is unresolved, missing names are exact, errors occur inside the transaction, and late item-topic failures roll back earlier work. Store conflict/foreign-key behavior and agent contracts are untouched.

Candidate genuinely improves composition: `createTopics` constructs `validRoomIds` **once outside** the topic loop and passes it to `resolveRoomIds`; every comparator reconstructs that Set for each topic. This shares a derived result at its existing common lifetime. It costs signature/call-site churn and does not prove measured throughput or memory savings. Item-topic membership is already built once. Room and item-topic policies differ, so a generic resolver would not obviously reduce machinery. Beyond this lookup-lifetime improvement in the comparison arms, there is no evidenced large source-size opportunity; do not demand a generic abstraction or whitespace squeezing to manufacture one.

**Elixir:** all four patches are identical six-call compositions of `Ecto.Changeset.validate_number(field, greater_than_or_equal_to: 0)` after existing casting/required checks. No custom parser, validator, upper bound, DB activity or migration. No credible production headroom remains.

## What test churn means

Python candidate does extend existing graph tests: one rank test gains a Unicode parameter and repository isolation now includes a positive Unicode match in the other repository. Its production-indexed snapshot covers expansion, accented/Cyrillic/sigma matching, path/qualified matching, literal punctuation, normalization negatives, raw keys, limits, diagnostics, service/CLI parity and unchanged DB bytes. These are substantive assertions, not disposable volume. The missed generator seam is more important than its 87 test churn lines.

All TypeScript arms reuse `createTestDatabaseFixture`; none invents a database harness. Candidate additionally uses `createBlockInput`, `readMemoryTables`, a 14-row missing-reference table and shared rollback/recovery assertions. These are real reuse, but the suite still separately sets up a successful mixed-resolution flow, exclusive ID-authority cases, persisted-only linking, empty variants and find/unlink. Its all-five-table equality, late failure/recovery and preservation/link assertions are legitimate orchestration coverage; direct store or transaction tests do not prove that this caller throws inside the transaction.

There is room to compose the successful flow's later find/unlink assertions using its already-created records and before/after state, and derive expected item fields from the typed input instead of redeclaring each field. Reuse the assertion body, not fewer contracts. **Do not blindly copy Ponytail's shorter combined success test:** when both topics are already expected to be linked, a conflicting ID/name reference can choose the wrong topic unnoticed. Candidate's exclusive-ID cases assert that the unintended topic stays unlinked; keep that discriminating assertion if scenarios are combined. Main and PR112 also have targeted precedence cases. Candidate's persisted-only success is a distinct branch from creating new collections, not automatically duplicate setup.

Elixir candidate's `@cases`, `scenarios`, `parameter_maps` and `assert_rejected` share construction and assertions effectively. Individual fields, simultaneous errors, partial updates, form casting, zero/unbounded positives and action rejection are required distinctions. Multiplying every magnitude by schema × field × key representation × action largely rechecks Ecto's common casting/action machinery; it need not become a parallel framework acceptance suite. Keep field-specific validators, representative compatibility assertions and risky mixed-error interactions; reorganize around the changed seam rather than remove meaningful assertions. Candidate's 158 lines are already close to Ponytail's 159, not evidence of a major regression or major improvement.

## Independently executed checks

All commands ran in my own disposable archive copies, with 120-second caps. Exact command, cwd, exit, timing, combined output and SHA-256 are recorded in `evidence.json` and `commands/*.log`. No timeout occurred. No services, application startup, network, installs or database server was used; tests used temporary local SQLite files.

All **12 frozen acceptance**, **12 original manifest-native**, **12 explicitly loaded maintained suites**, and **4 shared Python fixture-consumer commands** passed. The later-arm appended consumer command was executed separately after the manifest-native command, with review-local unique basetemps; behavior/selection was unchanged. All four additional standalone Python fixture snapshot consumers passed too.

| Arm | Python acceptance / native / maintained | TS acceptance / native / maintained | Elixir acceptance / native / maintained |
|---|---|---|---|
| main | 8 / 57 / 64 | 12 / 18 / 38 | 249 / 249 / 6 |
| PR112 | 8 / 58 / 65 | 12 / 18 / 39 | 249 / 249 / 6 |
| Ponytail | 8 / 60 / 67 | 12 / 18 / 31 | 249 / 249 / 6 |
| candidateTwo | 8 / 54 / 61 | 12 / 18 / 40 | 249 / 249 / 6 |

Counts are test cases, not coverage scores. Python native deselects seven language snapshots; maintained execution includes them. TypeScript native also runs `tsc --noEmit` and production ESLint; all pass. I explicitly linted every added TS test file too. Python Ruff passes on changed Python files, including fixtures; Pyright passes on changed production/helpers/maintained tests for every arm using the shared venv read-only. One initial candidate Pyright invocation also supplied the fixture filename containing a literal backslash: Pyright normalized it as a separator and exited 4 before analysis. That failed invocation is retained, not called a pass. All arms were then checked with the consistent production/maintained-test scope, excluding sample fixtures. Elixir native is the oracle again, **not** discovery of the new domain tests; those were explicitly loaded service-free.

### Maintained original-production controls

Only in separate disposable copies, I restored candidate production to the pinned original while retaining its tests/fixtures. Python fails **3/61** cases (Unicode rank, other-repository positive match, production-indexed snapshot); the coffee test alone independently fails **1/15**. TypeScript fails **14/40**, the missing-reference cases. Elixir fails **2/6**; restoring only Order or CpuOrderData separately fails one case each, restoring only Player fails two. Compatibility cases that already pass original production are expected to stay green. These controls establish detection of the original holes, not mutation adequacy.

## Proposed last hypothesis: a decision process, not a coverage checklist

**Proposed complete skill: `proposedSkill.md`, 2,642 UTF-8 bytes**, including frontmatter. CandidateTwo is 3,043, PR112 3,161 and main 5,121 bytes. This proposal is review-only, not a frozen or tested candidate revision. It adds no runtime script/reference and names no language, task, dataset or example implementation.

```mermaid
flowchart LR
  Read[Read owning code + maintained coverage] --> Reuse[First complete existing composition]
  Reuse --> Seam[Extend the maintained test seam]
  Seam --> Gap{Distinct uncovered risk?}
  Gap -->|yes| Case[Add a focused scenario]
  Gap -->|no| Checks[Run checks + review complete diff]
  Case --> Checks
```

The pivotal instruction is: **“Choose the maintained test seam before writing tests.”** Then extend its fixtures/builders/assertions for the bug and threatened contracts. A new file may fit the seam; a second harness or acceptance matrix needs an actual gap. External checks neither replace owned regressions nor prescribe a duplicate suite. This retains necessary independent maintained coverage even when an external oracle also tests the behavior.

What can be removed without weakening guarantees: merge the repeated addition-justification and final necessity-review rules; replace the separate efficiency paragraph with common-lifetime composition plus one measurement sentence; collapse repeated native-value/authoritative-policy advice into one reuse rule; remove the exhaustive observable-behavior catalogue in favor of preserving observable contracts with a few key distinctions; replace the imperative “cover the bug, distinct contracts and risky interactions” checklist with the seam/gap decision. Retain the explicit safeguard prohibition, fixture-consumer/generator obligation, meaningful assertions/integration coverage, relevant checks and honest limits. The complete proposal demonstrates the byte saving rather than appending more guidance.

Ponytail inspiration is its first-complete-option decision and stopping rule, not its persona, modes, shortest-diff slogan or one-test quota. The candidate already demonstrates some real composition; the remaining opportunity is primarily **test organization**, not a missing production library.

If the parent spends the final permitted revision, test this one general replacement in another isolated, unselected comparison; keep every output and the shared integration command for all arms. Require complete behavior/maintained checks and the original production **and** combined-churn gates, including per-case/byte reporting. Do not remove assertions, repair outputs or select the best case from multiple draws. This review does not establish that a shorter process will improve results or pass the planned complete-draw gate.

## Scope and integrity

Exactly **12** tuningTwo source outputs were reviewed and retained unchanged. `before.json`/`after.json` match across 1,006 artifact/changed-source files; supplemental checks were followed by another integrity verification. Historical tuningOne implementations remain unchanged too. Only `reviews/roundTwo/` artifacts were created; no user checkout, README, profile, runtime skill or experiment implementation was edited.

Only tuning manifests were read. No aggregate research manifest, validation directory, freeze file or reserve detail was opened in this review. The prior reviewer's disclosed accidental reserved TypeScript brief exposure remains a limitation of the experiment's reviewer holdout blindness; this round does not erase it. No reserve implementation exists according to the supplied experiment status, which this review did not inspect independently. No full application suite, optional mutation run, effectiveness equivalence claim or universal superiority claim is made.
