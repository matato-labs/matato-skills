#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 1 || "$1" != /* || ! -d "$1/lib/beer_game/game" ]]; then
  printf 'Usage: %s /absolute/worktree/path\n' "$0" >&2
  exit 2
fi
here=$(cd -- "$(dirname -- "$0")" && pwd)
cd "$here"
sha256sum --check runtime/checksums.sha256 >/dev/null
elixir -pa "$here/runtime/lib/decimal/ebin" -pa "$here/runtime/lib/ecto/ebin" -pa "$here/runtime/lib/telemetry/ebin" -e '
for {app, version} <- [decimal: ~c"3.2.0", ecto: ~c"3.14.2", telemetry: ~c"1.4.2"] do
  :ok = Application.load(app)
  ^version = Application.spec(app, :vsn)
  IO.puts("#{app} #{version}")
end
'
