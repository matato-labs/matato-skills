import concurrent.futures
import hashlib
import io
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import subprocess
import tarfile
import time

ROOT = Path('/tmp/codingSessionV3')
OUT = ROOT / 'reviews/finalTwo'
ARMS = ['main', 'pr', 'ponytail', 'candidateThree']
PYTHON = '/home/leon/workspace/projects/atlas/atlas/.venv/bin/python'
VENV = Path(PYTHON).parent.parent
CASES = {}
for manifest in sorted((ROOT / 'research').glob('*/*/manifest.json')):
    if manifest.parent.name in ('tuning', 'validation'):
        for case in json.loads(manifest.read_text())['cases']:
            CASES[case['id']] = case | {'language': manifest.parent.parent.name}
EXCLUDES = ['--', '.', ':(exclude)node_modules', ':(exclude)atlas/.venv', ':(exclude)_build', ':(exclude)deps']


def git(source, *args):
    return subprocess.check_output(['git', '-C', str(source), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def category(path):
    if any(part in ('test', 'tests', 'fixtures', 'snapshots') for part in Path(path).parts) or '.test.' in path or path.endswith('_test.exs'):
        return 'tests'
    return 'production' if path.endswith(('.py', '.ts', '.tsx', '.ex', '.exs', '.js')) else 'other'


def changed(source):
    result = []
    for entry in git(source, 'diff', '--numstat', '-z', *EXCLUDES).split(b'\0'):
        if not entry:
            continue
        added, deleted, name = entry.decode().split('\t', 2)
        path = source / name
        try:
            original = git(source, 'show', 'HEAD:' + name)
        except subprocess.CalledProcessError:
            original = b''
        current = path.read_bytes() if path.exists() else b''
        result.append(dict(path=name, category=category(name), added=int(added), deleted=int(deleted), churn=int(added)+int(deleted), net=int(added)-int(deleted), beforeBytes=len(original), afterBytes=len(current), byteGrowth=len(current)-len(original), sha256=sha(current), whitespaceOnly=original.split()==current.split()))
    return result


def fingerprint():
    result = {}
    for arm in ARMS:
        for case in CASES:
            source = ROOT / 'worktrees/finalTwo' / arm / case
            for name in git(source, 'ls-files', '-z').decode().split('\0'):
                path = source / name
                if not name or name.startswith(('node_modules', 'atlas/.venv', '_build/', 'deps/')):
                    continue
                result[str(path)] = sha(path.read_bytes()) if path.is_file() else 'missing'
            result[str(source) + ':status'] = sha(git(source, 'status', '--porcelain=v1', '-z'))
        for path in (ROOT / 'runs/finalTwo' / arm).rglob('*'):
            if path.is_file():
                result[str(path)] = sha(path.read_bytes())
    for path in (ROOT / 'profiles').glob('*.md'):
        result[str(path)] = sha(path.read_bytes())
    for name in ('plan.json', 'finalFreeze.json', 'runTrial.py', 'revisionTwo.md'):
        result[str(ROOT / name)] = sha((ROOT / name).read_bytes())
    for language in ('python', 'typescript', 'elixir'):
        for phase in ('tuning', 'validation'):
            for path in (ROOT / 'research' / language / phase).iterdir():
                if path.is_file():
                    result[str(path)] = sha(path.read_bytes())
    return result


def prepare():
    (OUT / 'before.json').write_text(json.dumps(fingerprint(), indent=2) + '\n')
    metrics = {}
    production = []
    for arm in ARMS:
        metrics[arm] = {}
        for case in CASES:
            source = ROOT / 'worktrees/finalTwo' / arm / case
            target = OUT / 'copies' / arm / case
            target.mkdir(parents=True)
            archive = tarfile.open(fileobj=io.BytesIO(git(source, 'archive', 'HEAD')))
            archive.extractall(target, filter='data')
            files = changed(source)
            metrics[arm][case] = files
            for item in files:
                src, dest = source / item['path'], target / item['path']
                if src.exists():
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dest)
                elif dest.exists():
                    dest.unlink()
            if CASES[case]['language'] == 'typescript':
                (target / 'node_modules').symlink_to('/home/leon/workspace/projects/matato/node_modules')
            if CASES[case]['language'] == 'python':
                (target / 'atlas/.venv').symlink_to(VENV)
            paths = [item['path'] for item in files if item['category'] == 'production']
            production.append(f'\n### {arm} {case}\n' + git(source, 'diff', '--no-ext-diff', '--', *paths).decode())
    (OUT / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
    (OUT / 'productionDiffs.txt').write_text(''.join(production))
    shared = OUT / 'checks'
    for language in ('python', 'typescript', 'elixir'):
        for phase in ('tuning', 'validation'):
            dest = shared / language / phase
            dest.mkdir(parents=True)
            for source in (ROOT / 'research' / language / phase).iterdir():
                if source.name in ('oracle.py', 'oracle', 'native', 'behavior.ts', 'oracle.sh', 'oracleTest.exs'):
                    shutil.copy2(source, dest / source.name)
    (shared / 'elixir/runtime').symlink_to(ROOT / 'research/elixir/runtime')
    shutil.copy2(ROOT / 'research/elixir/run.exs', shared / 'elixir/run.exs')


def execute(label, command, cwd, budget=120):
    folder = OUT / 'commands'
    folder.mkdir(exist_ok=True)
    log = folder / (label + '.log')
    recordFile = folder / (label + '.json')
    if recordFile.exists() and recordFile.stat().st_size:
        record = json.loads(recordFile.read_text())
        if record['exit'] == 0 or 'Original' in label:
            return record
    while log.exists():
        label += 'Retry'
        log = folder / (label + '.log')
    home = OUT / 'homes' / label
    home.mkdir(parents=True)
    temporary = OUT / 'temps' / label
    temporary.mkdir(parents=True)
    env = {'PATH': os.environ['PATH'], 'HOME': str(home), 'TMPDIR': str(temporary), 'DO_NOT_TRACK': '1', 'CI': '1', 'PYTHONDONTWRITEBYTECODE': '1', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1', 'PYTEST_ADDOPTS': '', 'PYTHONPATH': str(cwd / 'src') + ':' + str(cwd), 'MIX_DEPS_PATH': str(ROOT / 'research/elixir/runtime/lib')}
    started = time.monotonic()
    with log.open('wb') as output:
        process = subprocess.Popen(['bash', '-euc', command], cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            status = process.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            status = 124
    record = dict(label=label, command=command, cwd=str(cwd), exit=status, seconds=round(time.monotonic()-started, 3), log=str(log), logSha256=sha(log.read_bytes()), environment=env)
    (folder / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    shutil.rmtree(home)
    shutil.rmtree(temporary)
    print(f'{label}: {status} ({record["seconds"]}s)', flush=True)
    return record


def pytests(target, paths):
    return shlex.join([PYTHON, '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider', *paths])


def maintained(target, files, case):
    language = CASES[case]['language']
    paths = [f['path'] for f in files if f['category'] == 'tests']
    if language == 'python':
        tests = [str(Path(p).relative_to('atlas')) for p in paths if Path(p).name.startswith('test_') and p.endswith('.py') and '/fixtures/' not in p]
        return pytests(target, tests), target / 'atlas'
    if language == 'typescript':
        tests = [p for p in paths if p.endswith('.test.ts')]
        return shlex.join(['bun', 'test', *tests]), target
    tests = [p for p in paths if p.endswith('.exs')]
    return shlex.join(['elixir', '-pa', str(ROOT / 'research/elixir/runtime/lib/*/ebin'), '-r', 'lib/beer_game/game/*.ex', '-e', 'ExUnit.start(seed: 0); ' + '; '.join('Code.require_file(' + json.dumps(p) + ')' for p in tests)]), target


def checks(arm, case):
    target = OUT / 'copies' / arm / case
    spec = CASES[case]
    metrics = json.loads((OUT / 'metrics.json').read_text())[arm][case]
    language = spec['language']
    label = arm + case
    oracle = spec['checkCommand'].format(root=target).replace(str(ROOT / 'research'), str(OUT / 'checks'))
    execute(label+'Acceptance', oracle, target)
    native = spec['nativeCommand'].format(root=target).replace(str(ROOT / 'research/python' / spec['phase'] / 'nativeTemp'), str(OUT / 'temps' / (label+'NativePytest')))
    native = native.replace(str(ROOT / 'research/typescript'), str(OUT / 'checks/typescript'))
    execute(label+'Native', native, target)
    command, cwd = maintained(target, metrics, case)
    execute(label+'Maintained', command, cwd)
    if language == 'python':
        paths = [f['path'].removeprefix('atlas/') for f in metrics if f['path'].endswith('.py') and '/fixtures/' not in f['path']]
        execute(label+'Ruff', shlex.join([str(VENV / 'bin/ruff'), 'check', *paths]), target / 'atlas')
        execute(label+'Pyright', shlex.join([str(VENV / 'bin/pyright'), *paths]), target / 'atlas')
        execute(label+'FixtureConsumers', pytests(target, ['tests/test_coffee_pipeline.py', 'tests/test_variant_snapshots.py', 'tests/test_declaration_coffee.py', '-k', 'python or each_physical']), target / 'atlas')
        if case == 'pythonUnicodeGraphFind':
            execute(label+'StandaloneSnapshot', pytests(target, ['tests/test_script_member_coffee_snapshots.py', '-k', 'python']), target / 'atlas')
    if language == 'typescript':
        paths = [f['path'] for f in metrics if f['path'].endswith('.ts')]
        execute(label+'ChangedLint', shlex.join(['bun', 'node_modules/eslint/bin/eslint.js', *paths]), target)


def controls():
    arm = 'candidateThree'
    metrics = json.loads((OUT / 'metrics.json').read_text())[arm]
    for case, files in metrics.items():
        source = ROOT / 'worktrees/finalTwo' / arm / case
        target = OUT / 'controls' / case
        shutil.copytree(OUT / 'copies' / arm / case, target, symlinks=True, ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache', '.ruff_cache'))
        production = [f['path'] for f in files if f['category'] == 'production']
        for path in production:
            (target / path).write_bytes(git(source, 'show', 'HEAD:' + path))
        command, cwd = maintained(target, files, case)
        execute(case+'OriginalProduction', command, cwd)
        if CASES[case]['language'] == 'python':
            tests = [f['path'].removeprefix('atlas/') for f in files if Path(f['path']).name.startswith('test_') and f['path'].endswith('.py')]
            for index, test in enumerate(tests):
                execute(case+f'OriginalTest{index}', pytests(target, [test]), target / 'atlas')
        if CASES[case]['language'] == 'elixir':
            for path in production:
                for other in production:
                    (target / other).write_bytes((source / other).read_bytes())
                (target / path).write_bytes(git(source, 'show', 'HEAD:' + path))
                execute(case+'Original'+Path(path).stem.replace('_','').title(), command, cwd)


def collect():
    records = [json.loads(path.read_text()) for path in sorted((OUT / 'commands').glob('*.json')) if path.stat().st_size]
    (OUT / 'commandEvidence.json').write_text(json.dumps(records, indent=2) + '\n')
    after = fingerprint()
    (OUT / 'after.json').write_text(json.dumps(after, indent=2) + '\n')
    before = json.loads((OUT / 'before.json').read_text())
    print('Integrity match:', before == after, 'files:', len(after))


if __name__ == '__main__':
    import sys
    mode = sys.argv[1]
    if mode == 'prepare':
        prepare()
    elif mode == 'checks':
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            list(pool.map(lambda pair: checks(*pair), [(arm, case) for arm in ARMS for case in CASES]))
    elif mode == 'controls':
        controls()
    elif mode == 'collect':
        collect()
