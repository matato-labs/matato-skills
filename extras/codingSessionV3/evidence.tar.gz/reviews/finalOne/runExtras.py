import hashlib
import io
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import subprocess
import tarfile
import time
from runReview import root, review, results, paths, git, pythonPrefix

records = json.loads((review / 'extraCommands.json').read_text()) if (review / 'extraCommands.json').exists() else []
extraTemp = review / 'extraTemp'
extraTemp.mkdir(exist_ok=True)

def run(label, command, folder):
    if any(r['label'] == label for r in records):
        return
    log = review / 'commands' / (label + '.log')
    start = time.monotonic()
    with log.open('w') as output:
        output.write(f'CWD {folder}\nCOMMAND {command}\n')
        output.flush()
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', CI='1', DO_NOT_TRACK='1', TMPDIR=str(extraTemp))
        process = subprocess.Popen(['bash', '-c', command], cwd=folder, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=120)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            code = 124
        seconds = round(time.monotonic() - start, 3)
        output.write(f'\nEXIT {code}\nSECONDS {seconds}\n')
    records.append(dict(label=label, command=command, cwd=str(folder), exit=code, seconds=seconds, output=str(log), sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    (review / 'extraCommands.json').write_text(json.dumps(records, indent=2))
    print(label, code, seconds, flush=True)
    for p in extraTemp.iterdir():
        shutil.rmtree(p) if p.is_dir() and not p.is_symlink() else p.unlink()

for arm in ['candidateThree', 'main', 'pr', 'ponytail']:
    for case, template in [('sessionTreeConfinement', 'stableSessionProbe.ts'), ('memoryReferenceResolution', 'zeroIdProbe.ts')]:
        folder = review / 'copies' / arm / case
        source = (review / template).read_text()
        target = review / 'probes' / (arm + template.removesuffix('.ts') + '.test.ts')
        target.parent.mkdir(exist_ok=True)
        target.write_text(source.replace('candidateRoot/', str(folder) + '/'))
        home = extraTemp / 'home'
        home.mkdir(exist_ok=True)
        run(arm + template.removesuffix('.ts'), f'HOME="{home}" bun test "{target}"', folder)
    folder = review / 'copies' / arm / 'sessionTreeConfinement'
    home = extraTemp / 'home'
    home.mkdir(exist_ok=True)
    run(arm + 'WorkSessionIntegration', f'HOME="{home}" bun test src/storage/work.test.ts', folder)
    folder = review / 'copies' / arm / 'pythonUnicodeGraphFind'
    run(arm + 'SnapshotGeneratorRoute', pythonPrefix(folder) + f'/home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B "{review}/generatorRoute.py"', folder)
    for case in ['pythonUnicodeGraphFind', 'pythonLiteralDatabasePaths']:
        folder = review / 'copies' / arm / case
        result = next(r for r in results if r['arm'] == arm and r['case'] == case)
        files = [p.removeprefix('atlas/') for p in paths(Path(result['worktree'])) if p.endswith('.py')]
        command = pythonPrefix(folder) + '/home/leon/workspace/projects/atlas/atlas/.venv/bin/ruff check --no-cache --force-exclude ' + ' '.join(shlex.quote(p) for p in files)
        run(arm + case + 'ConfiguredLint', command, folder)

folder = review / 'pureBaseMemory'
folder.mkdir(exist_ok=True)
result = next(r for r in results if r['case'] == 'sessionTreeConfinement')
with tarfile.open(fileobj=io.BytesIO(git(Path(result['worktree']), 'archive', result['base']))) as stream:
    stream.extractall(folder, filter='data')
(folder / 'node_modules').symlink_to('/home/leon/workspace/projects/matato/node_modules', target_is_directory=True)
home = extraTemp / 'home'
home.mkdir(exist_ok=True)
run('pureBaseWorkSessionIntegration', f'HOME="{home}" bun test src/storage/work.test.ts', folder)
