import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from typing import TypedDict


class Case(TypedDict):
    id: str
    phase: str
    repo: str
    base: str
    brief: str
    setupCommands: list[str]
    checkCommand: str
    nativeCommand: str
    sourcePaths: list[str]


root = Path('/tmp/codingSessionV3')


def execute(command: list[str], cwd: Path, log: Path, budget: int) -> int:
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(('T3_', 'PI_SESSION', 'PI_MCP'))}
    env.update(PI_OFFLINE='1', PI_TELEMETRY='0', PI_SKIP_VERSION_CHECK='1',
               PYTHONDONTWRITEBYTECODE='1')
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=output,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            return process.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            return 124


def git(worktree: Path, *args: str) -> str:
    return subprocess.check_output(['git', '-C', str(worktree), *args], text=True)


def category(path: str) -> str:
    parts = Path(path).parts
    if ('test' in parts or 'tests' in parts or 'snapshots' in parts
            or 'fixtures' in parts or '.test.' in path or path.endswith('_test.exs')):
        return 'tests'
    if path.endswith(('.ts', '.tsx', '.js', '.py', '.ex', '.exs')):
        return 'production'
    return 'other'


def capture(case: Case, arm: str, draw: str, worktree: Path, folder: Path,
            agentExit: int | None, acceptanceExit: int, seconds: float | None) -> None:
    git(worktree, 'add', '-N', '.')
    exclusions = ['--', '.', ':(exclude)node_modules', ':(exclude)atlas/.venv',
                  ':(exclude)_build', ':(exclude)deps']
    patch = git(worktree, 'diff', '--no-ext-diff', *exclusions)
    (folder / 'changes.patch').write_text(patch)
    files = []
    for line in git(worktree, 'diff', '--numstat', *exclusions).splitlines():
        added, removed, path = line.split('\t', 2)
        files.append({'path': path, 'added': int(added), 'removed': int(removed),
                      'category': category(path)})
    result = {'case': case['id'], 'phase': case['phase'], 'arm': arm, 'draw': draw,
              'base': case['base'], 'worktree': str(worktree), 'agentExit': agentExit,
              'acceptanceExit': acceptanceExit,
              'seconds': round(seconds, 2) if seconds is not None else None,
              'files': files, 'patchSha256': hashlib.sha256(patch.encode()).hexdigest()}
    (folder / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


def trial(case: Case, arm: str, draw: str) -> None:
    folder = root / 'runs' / draw / arm / case['id']
    if (folder / 'result.json').exists():
        print((folder / 'result.json').read_text(), flush=True)
        return
    folder.mkdir(parents=True, exist_ok=False)
    worktree = root / 'worktrees' / draw / arm / case['id']
    worktree.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['git', '-C', case['repo'], 'worktree', 'add', '--detach',
                    str(worktree), case['base']], check=True, capture_output=True)
    setup = '\n'.join(case['setupCommands']).format(root=worktree)
    setupExit = execute(['bash', '-euc', setup], worktree, folder / 'setup.log', 120)
    if setupExit:
        raise RuntimeError(f'Setup failed: {folder}, exit {setupExit}')
    oracle = case['checkCommand'].format(root=worktree)
    native = case['nativeCommand'].format(root=worktree).replace(
        f"/tmp/codingSessionV3/research/python/{case['phase']}/nativeTemp",
        str(folder / 'nativeTemp'))
    if case['id'] == 'pythonUnicodeGraphFind':
        native += (' && cd "' + str(worktree / 'atlas') + '" && '
                   'PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 '
                   'PYTEST_ADDOPTS= PYTHONPATH="' + str(worktree / 'atlas/src') + ':'
                   + str(worktree / 'atlas') + '" '
                   '/home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B -m pytest '
                   '-q -p no:cacheprovider --basetemp="' + str(folder / 'integrationTemp')
                   + '" tests/test_coffee_pipeline.py tests/test_variant_snapshots.py '
                   'tests/test_declaration_coffee.py -k "python or each_physical"')
    prompt = f'''Implement this task in the current checkout:\n\n{case['brief']}
Read and follow target repository-local AGENTS.md/CLAUDE.md instructions. Add maintained regressions using its framework and run relevant checks.
Independent acceptance command: {oracle}
Existing focused native smoke command: {native}
Shared dependencies are already prepared; do not install or modify them. Use offline commands and existing binaries. Elixir cases have an offline Ecto runtime at /tmp/codingSessionV3/research/elixir/runtime/lib/*/ebin; use service-free ExUnit without starting the application, Mix aliases or a database. Atlas Python is /home/leon/workspace/projects/atlas/atlas/.venv/bin/python with PYTHONPATH set to this checkout's atlas/src; do not install dependencies or run dashboard setup. Available checks are not blanket full-suite coverage.
Isolation: edit only this checkout. Do not edit independent checks, other experiment directories, source checkouts, profiles or skills. Do not inspect rival profiles/results, research rationales, reserve tasks, earlier trials, or the parent conversation. Do not load other skills, use network/services/credentials, commit, push or create PRs. Existing dependencies may be read, not modified. Do not change README. Report changed files, checks actually run and blockers. Stop when complete.
'''
    profile = root / 'profiles' / f'{arm}.md'
    args = ['pi', '--print', '--no-session', '--no-extensions', '--no-skills',
            '--no-prompt-templates', '--no-context-files', '--no-mcp',
            '--no-approve', '--offline', '--model', 'openai-codex/gpt-6.1-sol',
            '--thinking', 'high', '--tools', 'read,bash,edit,write',
            '--append-system-prompt', str(profile)]
    (folder / 'prompt.txt').write_text(prompt)
    (folder / 'invocation.json').write_text(json.dumps(args, indent=2) + '\n')
    (folder / 'profile.sha256').write_text(hashlib.sha256(profile.read_bytes()).hexdigest() + '\n')
    started = time.monotonic()
    agentExit = execute(args + ['--', prompt], worktree, folder / 'agent.log', 900)
    acceptanceExit = execute(['bash', '-c', oracle], worktree, folder / 'acceptance.log', 120)
    elapsed = time.monotonic() - started
    (folder / 'execution.json').write_text(json.dumps({
        'agentExit': agentExit, 'acceptanceExit': acceptanceExit, 'seconds': elapsed}) + '\n')
    capture(case, arm, draw, worktree, folder, agentExit, acceptanceExit, elapsed)


def main() -> None:
    phase, arm, draw = sys.argv[1:]
    manifests = sorted((root / 'research').glob(f'*/{phase}/manifest.json'))
    for manifest in manifests:
        cases: list[Case] = json.loads(manifest.read_text())['cases']
        for case in cases:
            trial(case, arm, draw)


if __name__ == '__main__':
    main()
