import { test, expect } from 'bun:test'
import { createTestDatabaseFixture } from '/tmp/codingSessionV3/reviews/sharedFinal/copies/finalTwomainmemoryReferenceResolution/src/storage/databaseTestUtils'
import { withDatabaseConnection } from '/tmp/codingSessionV3/reviews/sharedFinal/copies/finalTwomainmemoryReferenceResolution/src/storage/database'
import { createMemoryBlock, type CreateMemoryBlockInput } from '/tmp/codingSessionV3/reviews/sharedFinal/copies/finalTwomainmemoryReferenceResolution/src/storage/memoryBlock'
import { memoryRoom, memoryTopic, memoryItem, memoryTopicRoom, memoryItemTopic } from '/tmp/codingSessionV3/reviews/sharedFinal/copies/finalTwomainmemoryReferenceResolution/src/storage/schema'

const state = () => withDatabaseConnection((database) => ({
  rooms: database.select().from(memoryRoom).all(),
  topics: database.select().from(memoryTopic).all(),
  items: database.select().from(memoryItem).all(),
  topicRooms: database.select().from(memoryTopicRoom).all(),
  itemTopics: database.select().from(memoryItemTopic).all(),
}))

for (const kind of ['room', 'topic']) {
  test(`supplied zero ${kind} ID is unresolved even if a schema-valid zero row already exists`, async () => {
    const fixture = await createTestDatabaseFixture({ prefix: `zeroId${kind}` })
    try {
      withDatabaseConnection((database) => {
        database.insert(kind === 'room' ? memoryRoom : memoryTopic).values({
          id: 0, name: 'Zero', summary: '', keywords: '[]', createdAt: '2026-01-01', updatedAt: '2026-01-01',
        }).run()
      })
      const input: CreateMemoryBlockInput = {
        rooms: [{ name: 'New', summary: '', keywords: [] }],
        topics: [{ name: 'New', summary: '', keywords: [], roomIds: kind === 'room' ? [0] : [] }],
        item: { title: 'New', content: 'text', summary: '', keywords: [], topics: kind === 'topic' ? [{ id: 0, name: 'New' }] : [] },
      }
      const before = state()
      expect((kind === 'room' ? before.rooms : before.topics).some((row) => row.id === 0)).toBe(true)
      console.log(JSON.stringify({ kind, home: fixture.homePath, storage: fixture.storagePath, seeded: before }))
      const invoke = () => {
        try {
          return createMemoryBlock(input)
        } finally {
          console.log(JSON.stringify({ kind, before, after: state() }))
        }
      }
      expect(invoke).toThrow(new RegExp(`${kind}.*0`))
      expect(state()).toEqual(before)
    } finally {
      await fixture.cleanup()
    }
  })
}
