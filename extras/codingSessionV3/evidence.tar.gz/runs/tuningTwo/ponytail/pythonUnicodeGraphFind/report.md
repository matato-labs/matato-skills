# Metrics

- files: 328
- modules: 41
- types: 144
- callables: 2727
- circularImportGroups: 0
- parseErrors: 0

## Files

| Item | Location | Lines | Functions/methods | Measured functions/methods | Weighted complexity sum |
| --- | --- | --- | --- | --- | --- |
| `.agents/skills/atlas-navigate/SKILL.md` | `.agents/skills/atlas-navigate/SKILL.md` | 74 | 0 | 0 | 0 |
| `.agents/skills/atlas-navigate/references/commands.md` | `.agents/skills/atlas-navigate/references/commands.md` | 67 | 0 | 0 | 0 |
| `.github/dependabot.yml` | `.github/dependabot.yml` | 11 | 0 | 0 | 0 |
| `.github/workflows/atlas-ci.yml` | `.github/workflows/atlas-ci.yml` | 44 | 0 | 0 | 0 |
| `.github/workflows/ci.yml` | `.github/workflows/ci.yml` | 39 | 0 | 0 | 0 |
| `.github/workflows/dashboard-ci.yml` | `.github/workflows/dashboard-ci.yml` | 44 | 0 | 0 | 0 |
| `AGENTS.md` | `AGENTS.md` | 44 | 0 | 0 | 0 |
| `DESIGN.md` | `DESIGN.md` | 9 | 0 | 0 | 0 |
| `PRODUCT.md` | `PRODUCT.md` | 29 | 0 | 0 | 0 |
| `README.md` | `README.md` | 158 | 0 | 0 | 0 |
| `SECURITY.md` | `SECURITY.md` | 21 | 0 | 0 | 0 |
| `atlas/alembic.ini` | `atlas/alembic.ini` | 27 | 0 | 0 | 0 |
| `atlas/mise.toml` | `atlas/mise.toml` | 2 | 0 | 0 | 0 |
| `atlas/pyproject.toml` | `atlas/pyproject.toml` | 50 | 0 | 0 | 0 |
| `atlas/src/atlas/__init__.py` | `atlas/src/atlas/__init__.py` | 7 | 0 | 0 | 0 |
| `atlas/src/atlas/__main__.py` | `atlas/src/atlas/__main__.py` | 8 | 0 | 0 | 0 |
| `atlas/src/atlas/bootstrap.py` | `atlas/src/atlas/bootstrap.py` | 7 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/__init__.py` | `atlas/src/atlas/cli/__init__.py` | 5 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/commands.py` | `atlas/src/atlas/cli/commands.py` | 112 | 6 | 6 | 15 |
| `atlas/src/atlas/cli/graph.py` | `atlas/src/atlas/cli/graph.py` | 130 | 13 | 13 | 23 |
| `atlas/src/atlas/cli/graph_output.py` | `atlas/src/atlas/cli/graph_output.py` | 32 | 2 | 2 | 11 |
| `atlas/src/atlas/cli/graph_source_output.py` | `atlas/src/atlas/cli/graph_source_output.py` | 22 | 2 | 2 | 9 |
| `atlas/src/atlas/domain/__init__.py` | `atlas/src/atlas/domain/__init__.py` | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/models.py` | `atlas/src/atlas/domain/models.py` | 286 | 5 | 5 | 13 |
| `atlas/src/atlas/domain/navigation.py` | `atlas/src/atlas/domain/navigation.py` | 63 | 8 | 8 | 8 |
| `atlas/src/atlas/domain/repositories.py` | `atlas/src/atlas/domain/repositories.py` | 98 | 9 | 9 | 9 |
| `atlas/src/atlas/indexer.py` | `atlas/src/atlas/indexer.py` | 33 | 1 | 1 | 1 |
| `atlas/src/atlas/language_syntax.py` | `atlas/src/atlas/language_syntax.py` | 50 | 3 | 3 | 16 |
| `atlas/src/atlas/metrics/__init__.py` | `atlas/src/atlas/metrics/__init__.py` | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/__init__.py` | `atlas/src/atlas/metrics/adapters/__init__.py` | 69 | 3 | 3 | 4 |
| `atlas/src/atlas/metrics/adapters/base.py` | `atlas/src/atlas/metrics/adapters/base.py` | 156 | 9 | 9 | 27 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py` | `atlas/src/atlas/metrics/adapters/callable_selection.py` | 313 | 29 | 29 | 139 |
| `atlas/src/atlas/metrics/adapters/elixir.py` | `atlas/src/atlas/metrics/adapters/elixir.py` | 274 | 26 | 26 | 97 |
| `atlas/src/atlas/metrics/adapters/generic.py` | `atlas/src/atlas/metrics/adapters/generic.py` | 39 | 5 | 5 | 11 |
| `atlas/src/atlas/metrics/adapters/go.py` | `atlas/src/atlas/metrics/adapters/go.py` | 113 | 11 | 11 | 53 |
| `atlas/src/atlas/metrics/adapters/java.py` | `atlas/src/atlas/metrics/adapters/java.py` | 121 | 13 | 13 | 31 |
| `atlas/src/atlas/metrics/adapters/javascript.py` | `atlas/src/atlas/metrics/adapters/javascript.py` | 371 | 43 | 43 | 153 |
| `atlas/src/atlas/metrics/adapters/kotlin.py` | `atlas/src/atlas/metrics/adapters/kotlin.py` | 132 | 9 | 9 | 37 |
| `atlas/src/atlas/metrics/adapters/module_index.py` | `atlas/src/atlas/metrics/adapters/module_index.py` | 99 | 10 | 10 | 36 |
| `atlas/src/atlas/metrics/adapters/parameters.py` | `atlas/src/atlas/metrics/adapters/parameters.py` | 25 | 3 | 3 | 11 |
| `atlas/src/atlas/metrics/adapters/python.py` | `atlas/src/atlas/metrics/adapters/python.py` | 526 | 52 | 52 | 206 |
| `atlas/src/atlas/metrics/adapters/resolution.py` | `atlas/src/atlas/metrics/adapters/resolution.py` | 202 | 17 | 17 | 54 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py` | `atlas/src/atlas/metrics/adapters/resolution_paths.py` | 117 | 13 | 13 | 54 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py` | `atlas/src/atlas/metrics/adapters/resolution_policy.py` | 236 | 41 | 41 | 77 |
| `atlas/src/atlas/metrics/adapters/rust.py` | `atlas/src/atlas/metrics/adapters/rust.py` | 432 | 45 | 45 | 169 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py` | `atlas/src/atlas/metrics/adapters/script_python_selection.py` | 117 | 15 | 15 | 62 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py` | `atlas/src/atlas/metrics/adapters/script_resolution.py` | 232 | 26 | 26 | 116 |
| `atlas/src/atlas/metrics/adapters/typescript.py` | `atlas/src/atlas/metrics/adapters/typescript.py` | 31 | 2 | 2 | 10 |
| `atlas/src/atlas/metrics/artifact.py` | `atlas/src/atlas/metrics/artifact.py` | 526 | 27 | 27 | 87 |
| `atlas/src/atlas/metrics/callables.py` | `atlas/src/atlas/metrics/callables.py` | 36 | 2 | 2 | 8 |
| `atlas/src/atlas/metrics/check.py` | `atlas/src/atlas/metrics/check.py` | 122 | 10 | 10 | 34 |
| `atlas/src/atlas/metrics/complexity.py` | `atlas/src/atlas/metrics/complexity.py` | 71 | 3 | 3 | 10 |
| `atlas/src/atlas/metrics/config.py` | `atlas/src/atlas/metrics/config.py` | 32 | 1 | 1 | 3 |
| `atlas/src/atlas/metrics/cycles.py` | `atlas/src/atlas/metrics/cycles.py` | 304 | 21 | 21 | 75 |
| `atlas/src/atlas/metrics/dependency_metrics.py` | `atlas/src/atlas/metrics/dependency_metrics.py` | 80 | 5 | 5 | 22 |
| `atlas/src/atlas/metrics/receiver_resolution.py` | `atlas/src/atlas/metrics/receiver_resolution.py` | 301 | 39 | 39 | 178 |
| `atlas/src/atlas/metrics/receiver_syntax.py` | `atlas/src/atlas/metrics/receiver_syntax.py` | 220 | 22 | 22 | 106 |
| `atlas/src/atlas/metrics/report.py` | `atlas/src/atlas/metrics/report.py` | 146 | 9 | 9 | 44 |
| `atlas/src/atlas/metrics/report_markdown.py` | `atlas/src/atlas/metrics/report_markdown.py` | 102 | 10 | 10 | 38 |
| `atlas/src/atlas/metrics/resolution_contract.py` | `atlas/src/atlas/metrics/resolution_contract.py` | 74 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolution_syntax.py` | `atlas/src/atlas/metrics/resolution_syntax.py` | 236 | 24 | 24 | 80 |
| `atlas/src/atlas/metrics/resolver.py` | `atlas/src/atlas/metrics/resolver.py` | 526 | 35 | 35 | 141 |
| `atlas/src/atlas/parsing/__init__.py` | `atlas/src/atlas/parsing/__init__.py` | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/__init__.py` | `atlas/src/atlas/parsing/adapters/__init__.py` | 25 | 1 | 1 | 1 |
| `atlas/src/atlas/parsing/adapters/base.py` | `atlas/src/atlas/parsing/adapters/base.py` | 51 | 2 | 2 | 2 |
| `atlas/src/atlas/parsing/adapters/elixir.py` | `atlas/src/atlas/parsing/adapters/elixir.py` | 116 | 6 | 6 | 26 |
| `atlas/src/atlas/parsing/adapters/go.py` | `atlas/src/atlas/parsing/adapters/go.py` | 72 | 4 | 4 | 15 |
| `atlas/src/atlas/parsing/adapters/java.py` | `atlas/src/atlas/parsing/adapters/java.py` | 62 | 3 | 3 | 5 |
| `atlas/src/atlas/parsing/adapters/javascript.py` | `atlas/src/atlas/parsing/adapters/javascript.py` | 133 | 9 | 9 | 33 |
| `atlas/src/atlas/parsing/adapters/kotlin.py` | `atlas/src/atlas/parsing/adapters/kotlin.py` | 122 | 8 | 8 | 28 |
| `atlas/src/atlas/parsing/adapters/python.py` | `atlas/src/atlas/parsing/adapters/python.py` | 58 | 2 | 2 | 9 |
| `atlas/src/atlas/parsing/adapters/rust.py` | `atlas/src/atlas/parsing/adapters/rust.py` | 293 | 19 | 19 | 76 |
| `atlas/src/atlas/parsing/adapters/typescript.py` | `atlas/src/atlas/parsing/adapters/typescript.py` | 37 | 1 | 1 | 4 |
| `atlas/src/atlas/parsing/discovery.py` | `atlas/src/atlas/parsing/discovery.py` | 201 | 13 | 13 | 38 |
| `atlas/src/atlas/parsing/parser.py` | `atlas/src/atlas/parsing/parser.py` | 222 | 7 | 7 | 35 |
| `atlas/src/atlas/parsing/structure.py` | `atlas/src/atlas/parsing/structure.py` | 235 | 18 | 18 | 66 |
| `atlas/src/atlas/parsing/syntax.py` | `atlas/src/atlas/parsing/syntax.py` | 424 | 29 | 29 | 116 |
| `atlas/src/atlas/persistence/__init__.py` | `atlas/src/atlas/persistence/__init__.py` | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/database.py` | `atlas/src/atlas/persistence/database.py` | 88 | 7 | 7 | 16 |
| `atlas/src/atlas/persistence/graph_queries.py` | `atlas/src/atlas/persistence/graph_queries.py` | 86 | 6 | 6 | 16 |
| `atlas/src/atlas/persistence/graph_records.py` | `atlas/src/atlas/persistence/graph_records.py` | 178 | 15 | 15 | 50 |
| `atlas/src/atlas/persistence/migrations/env.py` | `atlas/src/atlas/persistence/migrations/env.py` | 44 | 3 | 3 | 4 |
| `atlas/src/atlas/persistence/migrations/versions/0001_initial.py` | `atlas/src/atlas/persistence/migrations/versions/0001_initial.py` | 37 | 2 | 2 | 2 |
| `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py` | `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py` | 72 | 2 | 2 | 2 |
| `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py` | `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py` | 71 | 2 | 2 | 2 |
| `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py` | `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py` | 18 | 2 | 2 | 2 |
| `atlas/src/atlas/persistence/models.py` | `atlas/src/atlas/persistence/models.py` | 157 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/navigation.py` | `atlas/src/atlas/persistence/navigation.py` | 146 | 12 | 12 | 35 |
| `atlas/src/atlas/persistence/navigation_database.py` | `atlas/src/atlas/persistence/navigation_database.py` | 67 | 6 | 6 | 14 |
| `atlas/src/atlas/persistence/navigation_queries.py` | `atlas/src/atlas/persistence/navigation_queries.py` | 61 | 3 | 3 | 5 |
| `atlas/src/atlas/persistence/repositories.py` | `atlas/src/atlas/persistence/repositories.py` | 164 | 11 | 11 | 21 |
| `atlas/src/atlas/services/__init__.py` | `atlas/src/atlas/services/__init__.py` | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/factories.py` | `atlas/src/atlas/services/factories.py` | 30 | 3 | 3 | 4 |
| `atlas/src/atlas/services/navigation.py` | `atlas/src/atlas/services/navigation.py` | 73 | 11 | 11 | 20 |
| `atlas/src/atlas/services/navigation_source.py` | `atlas/src/atlas/services/navigation_source.py` | 106 | 7 | 7 | 39 |
| `atlas/src/atlas/services/navigation_walk.py` | `atlas/src/atlas/services/navigation_walk.py` | 83 | 7 | 7 | 24 |
| `atlas/src/atlas/services/repositories.py` | `atlas/src/atlas/services/repositories.py` | 94 | 10 | 10 | 24 |
| `atlas/src/atlas/syntax.py` | `atlas/src/atlas/syntax.py` | 30 | 3 | 3 | 8 |
| `atlas/tests/__init__.py` | `atlas/tests/__init__.py` | 0 | 0 | 0 | 0 |
| `atlas/tests/coffee_consolidation.py` | `atlas/tests/coffee_consolidation.py` | 42 | 4 | 4 | 9 |
| `atlas/tests/coffee_fixture.py` | `atlas/tests/coffee_fixture.py` | 43 | 3 | 3 | 4 |
| `atlas/tests/coffee_integrity.py` | `atlas/tests/coffee_integrity.py` | 83 | 8 | 8 | 22 |
| `atlas/tests/coffee_navigation.py` | `atlas/tests/coffee_navigation.py` | 399 | 33 | 33 | 132 |
| `atlas/tests/coffee_pipeline.py` | `atlas/tests/coffee_pipeline.py` | 120 | 8 | 8 | 26 |
| `atlas/tests/coffee_scenarios.py` | `atlas/tests/coffee_scenarios.py` | 48 | 2 | 2 | 8 |
| `atlas/tests/coffee_semantic_assertions.py` | `atlas/tests/coffee_semantic_assertions.py` | 258 | 20 | 20 | 85 |
| `atlas/tests/coffee_snapshot_assertions.py` | `atlas/tests/coffee_snapshot_assertions.py` | 231 | 18 | 18 | 55 |
| `atlas/tests/coffee_tsx_assertions.py` | `atlas/tests/coffee_tsx_assertions.py` | 71 | 6 | 6 | 24 |
| `atlas/tests/database_boundary_policy.py` | `atlas/tests/database_boundary_policy.py` | 524 | 60 | 60 | 287 |
| `atlas/tests/database_boundary_syntax.py` | `atlas/tests/database_boundary_syntax.py` | 133 | 16 | 16 | 73 |
| `atlas/tests/graph_storage_fixture.py` | `atlas/tests/graph_storage_fixture.py` | 72 | 4 | 4 | 5 |
| `atlas/tests/import_project_support.py` | `atlas/tests/import_project_support.py` | 81 | 10 | 10 | 31 |
| `atlas/tests/metric_test_support.py` | `atlas/tests/metric_test_support.py` | 20 | 4 | 4 | 8 |
| `atlas/tests/project_snapshot_support.py` | `atlas/tests/project_snapshot_support.py` | 31 | 2 | 2 | 6 |
| `atlas/tests/source_snapshot_fixture.py` | `atlas/tests/source_snapshot_fixture.py` | 47 | 4 | 4 | 18 |
| `atlas/tests/test_adapter_boundaries.py` | `atlas/tests/test_adapter_boundaries.py` | 77 | 6 | 6 | 19 |
| `atlas/tests/test_adapter_complexity_cleanup.py` | `atlas/tests/test_adapter_complexity_cleanup.py` | 86 | 6 | 6 | 23 |
| `atlas/tests/test_adapter_indexes.py` | `atlas/tests/test_adapter_indexes.py` | 73 | 5 | 5 | 14 |
| `atlas/tests/test_adapter_ownership.py` | `atlas/tests/test_adapter_ownership.py` | 71 | 5 | 5 | 13 |
| `atlas/tests/test_adapters.py` | `atlas/tests/test_adapters.py` | 205 | 15 | 15 | 36 |
| `atlas/tests/test_architecture.py` | `atlas/tests/test_architecture.py` | 216 | 19 | 19 | 58 |
| `atlas/tests/test_atlasignore.py` | `atlas/tests/test_atlasignore.py` | 178 | 10 | 10 | 28 |
| `atlas/tests/test_autogenerate.py` | `atlas/tests/test_autogenerate.py` | 35 | 1 | 1 | 1 |
| `atlas/tests/test_bootstrap.py` | `atlas/tests/test_bootstrap.py` | 73 | 9 | 9 | 12 |
| `atlas/tests/test_call_resolution.py` | `atlas/tests/test_call_resolution.py` | 79 | 6 | 6 | 31 |
| `atlas/tests/test_callable_metric_boundaries.py` | `atlas/tests/test_callable_metric_boundaries.py` | 105 | 4 | 4 | 12 |
| `atlas/tests/test_callable_metrics.py` | `atlas/tests/test_callable_metrics.py` | 162 | 7 | 7 | 21 |
| `atlas/tests/test_callback_carrier_regression.py` | `atlas/tests/test_callback_carrier_regression.py` | 274 | 17 | 17 | 71 |
| `atlas/tests/test_check.py` | `atlas/tests/test_check.py` | 119 | 12 | 12 | 26 |
| `atlas/tests/test_check_cli.py` | `atlas/tests/test_check_cli.py` | 185 | 15 | 15 | 34 |
| `atlas/tests/test_check_config.py` | `atlas/tests/test_check_config.py` | 51 | 5 | 5 | 5 |
| `atlas/tests/test_cli.py` | `atlas/tests/test_cli.py` | 27 | 2 | 2 | 3 |
| `atlas/tests/test_coffee.py` | `atlas/tests/test_coffee.py` | 96 | 11 | 11 | 24 |
| `atlas/tests/test_coffee_check_snapshots.py` | `atlas/tests/test_coffee_check_snapshots.py` | 23 | 1 | 1 | 1 |
| `atlas/tests/test_coffee_go_rust_receiver_snapshots.py` | `atlas/tests/test_coffee_go_rust_receiver_snapshots.py` | 58 | 1 | 1 | 5 |
| `atlas/tests/test_coffee_navigation_snapshots.py` | `atlas/tests/test_coffee_navigation_snapshots.py` | 63 | 4 | 4 | 7 |
| `atlas/tests/test_coffee_pipeline.py` | `atlas/tests/test_coffee_pipeline.py` | 157 | 15 | 15 | 59 |
| `atlas/tests/test_coffee_report_snapshots.py` | `atlas/tests/test_coffee_report_snapshots.py` | 54 | 3 | 3 | 16 |
| `atlas/tests/test_coffee_safety_review_snapshots.py` | `atlas/tests/test_coffee_safety_review_snapshots.py` | 53 | 3 | 3 | 13 |
| `atlas/tests/test_coffee_semantics.py` | `atlas/tests/test_coffee_semantics.py` | 142 | 10 | 10 | 31 |
| `atlas/tests/test_complexity.py` | `atlas/tests/test_complexity.py` | 98 | 11 | 11 | 17 |
| `atlas/tests/test_complexity_regression.py` | `atlas/tests/test_complexity_regression.py` | 159 | 20 | 20 | 32 |
| `atlas/tests/test_cycles.py` | `atlas/tests/test_cycles.py` | 124 | 10 | 10 | 26 |
| `atlas/tests/test_database_boundaries.py` | `atlas/tests/test_database_boundaries.py` | 157 | 7 | 7 | 15 |
| `atlas/tests/test_database_cli.py` | `atlas/tests/test_database_cli.py` | 28 | 2 | 2 | 4 |
| `atlas/tests/test_declaration_callbacks.py` | `atlas/tests/test_declaration_callbacks.py` | 250 | 20 | 20 | 64 |
| `atlas/tests/test_declaration_canonical.py` | `atlas/tests/test_declaration_canonical.py` | 161 | 12 | 12 | 30 |
| `atlas/tests/test_declaration_coffee.py` | `atlas/tests/test_declaration_coffee.py` | 104 | 9 | 9 | 24 |
| `atlas/tests/test_dependency_metric_persistence.py` | `atlas/tests/test_dependency_metric_persistence.py` | 183 | 8 | 8 | 26 |
| `atlas/tests/test_dependency_metrics.py` | `atlas/tests/test_dependency_metrics.py` | 329 | 26 | 26 | 75 |
| `atlas/tests/test_discovery.py` | `atlas/tests/test_discovery.py` | 68 | 6 | 6 | 14 |
| `atlas/tests/test_extraction_adapters.py` | `atlas/tests/test_extraction_adapters.py` | 116 | 7 | 7 | 23 |
| `atlas/tests/test_extraction_integration.py` | `atlas/tests/test_extraction_integration.py` | 71 | 6 | 6 | 32 |
| `atlas/tests/test_folder_cli.py` | `atlas/tests/test_folder_cli.py` | 99 | 6 | 6 | 13 |
| `atlas/tests/test_folder_report_cli.py` | `atlas/tests/test_folder_report_cli.py` | 255 | 16 | 16 | 32 |
| `atlas/tests/test_graph_contracts.py` | `atlas/tests/test_graph_contracts.py` | 88 | 5 | 5 | 11 |
| `atlas/tests/test_graph_migrations.py` | `atlas/tests/test_graph_migrations.py` | 51 | 4 | 4 | 5 |
| `atlas/tests/test_graph_navigation.py` | `atlas/tests/test_graph_navigation.py` | 463 | 38 | 38 | 106 |
| `atlas/tests/test_graph_output.py` | `atlas/tests/test_graph_output.py` | 23 | 1 | 1 | 1 |
| `atlas/tests/test_graph_persistence.py` | `atlas/tests/test_graph_persistence.py` | 286 | 17 | 17 | 35 |
| `atlas/tests/test_graph_project_discovery.py` | `atlas/tests/test_graph_project_discovery.py` | 102 | 7 | 7 | 7 |
| `atlas/tests/test_graph_schema.py` | `atlas/tests/test_graph_schema.py` | 146 | 6 | 6 | 19 |
| `atlas/tests/test_graph_transactions.py` | `atlas/tests/test_graph_transactions.py` | 144 | 8 | 8 | 19 |
| `atlas/tests/test_import_binding_guard.py` | `atlas/tests/test_import_binding_guard.py` | 120 | 4 | 4 | 21 |
| `atlas/tests/test_import_cycle_semantics.py` | `atlas/tests/test_import_cycle_semantics.py` | 123 | 11 | 11 | 31 |
| `atlas/tests/test_import_performance.py` | `atlas/tests/test_import_performance.py` | 186 | 13 | 13 | 54 |
| `atlas/tests/test_import_resolution.py` | `atlas/tests/test_import_resolution.py` | 157 | 13 | 13 | 42 |
| `atlas/tests/test_import_source_order.py` | `atlas/tests/test_import_source_order.py` | 52 | 3 | 3 | 16 |
| `atlas/tests/test_indexer.py` | `atlas/tests/test_indexer.py` | 428 | 33 | 33 | 140 |
| `atlas/tests/test_invalid_utf8.py` | `atlas/tests/test_invalid_utf8.py` | 96 | 1 | 1 | 4 |
| `atlas/tests/test_jvm_callable_selection_snapshots.py` | `atlas/tests/test_jvm_callable_selection_snapshots.py` | 35 | 2 | 2 | 5 |
| `atlas/tests/test_metric_adapters.py` | `atlas/tests/test_metric_adapters.py` | 36 | 3 | 3 | 6 |
| `atlas/tests/test_metric_phases.py` | `atlas/tests/test_metric_phases.py` | 73 | 4 | 4 | 9 |
| `atlas/tests/test_metric_snapshots.py` | `atlas/tests/test_metric_snapshots.py` | 222 | 13 | 13 | 32 |
| `atlas/tests/test_models.py` | `atlas/tests/test_models.py` | 93 | 7 | 7 | 12 |
| `atlas/tests/test_normalized_runtime.py` | `atlas/tests/test_normalized_runtime.py` | 90 | 4 | 4 | 10 |
| `atlas/tests/test_parsing_snapshots.py` | `atlas/tests/test_parsing_snapshots.py` | 236 | 17 | 17 | 51 |
| `atlas/tests/test_persistence.py` | `atlas/tests/test_persistence.py` | 150 | 7 | 7 | 10 |
| `atlas/tests/test_persistence_entity_boundaries.py` | `atlas/tests/test_persistence_entity_boundaries.py` | 149 | 6 | 6 | 24 |
| `atlas/tests/test_policy_snapshots.py` | `atlas/tests/test_policy_snapshots.py` | 289 | 35 | 35 | 62 |
| `atlas/tests/test_primary_import_parsing.py` | `atlas/tests/test_primary_import_parsing.py` | 187 | 14 | 14 | 37 |
| `atlas/tests/test_project_names_cli.py` | `atlas/tests/test_project_names_cli.py` | 54 | 4 | 4 | 6 |
| `atlas/tests/test_projects_cli.py` | `atlas/tests/test_projects_cli.py` | 55 | 4 | 4 | 6 |
| `atlas/tests/test_python_project_imports.py` | `atlas/tests/test_python_project_imports.py` | 167 | 14 | 14 | 48 |
| `atlas/tests/test_receiver_remaining_blockers.py` | `atlas/tests/test_receiver_remaining_blockers.py` | 96 | 8 | 8 | 17 |
| `atlas/tests/test_receiver_resolution.py` | `atlas/tests/test_receiver_resolution.py` | 114 | 6 | 6 | 12 |
| `atlas/tests/test_receiver_review_fixes.py` | `atlas/tests/test_receiver_review_fixes.py` | 108 | 12 | 12 | 14 |
| `atlas/tests/test_receiver_safety.py` | `atlas/tests/test_receiver_safety.py` | 145 | 11 | 11 | 19 |
| `atlas/tests/test_report.py` | `atlas/tests/test_report.py` | 131 | 9 | 9 | 24 |
| `atlas/tests/test_report_cli.py` | `atlas/tests/test_report_cli.py` | 96 | 5 | 5 | 11 |
| `atlas/tests/test_resolution_adapter_dispatch.py` | `atlas/tests/test_resolution_adapter_dispatch.py` | 74 | 6 | 6 | 22 |
| `atlas/tests/test_resolution_complexity_cleanup.py` | `atlas/tests/test_resolution_complexity_cleanup.py` | 175 | 15 | 15 | 46 |
| `atlas/tests/test_resolution_lexical_safety.py` | `atlas/tests/test_resolution_lexical_safety.py` | 183 | 17 | 17 | 49 |
| `atlas/tests/test_resolution_modules.py` | `atlas/tests/test_resolution_modules.py` | 183 | 18 | 18 | 47 |
| `atlas/tests/test_resolution_review_regressions.py` | `atlas/tests/test_resolution_review_regressions.py` | 88 | 11 | 11 | 30 |
| `atlas/tests/test_rust_root_streaming.py` | `atlas/tests/test_rust_root_streaming.py` | 49 | 3 | 3 | 10 |
| `atlas/tests/test_script_member_coffee_snapshots.py` | `atlas/tests/test_script_member_coffee_snapshots.py` | 69 | 4 | 4 | 18 |
| `atlas/tests/test_semantic_contracts.py` | `atlas/tests/test_semantic_contracts.py` | 79 | 9 | 9 | 31 |
| `atlas/tests/test_semantic_resolution.py` | `atlas/tests/test_semantic_resolution.py` | 330 | 30 | 30 | 78 |
| `atlas/tests/test_size_report.py` | `atlas/tests/test_size_report.py` | 105 | 7 | 7 | 23 |
| `atlas/tests/test_source_snapshot_fixture.py` | `atlas/tests/test_source_snapshot_fixture.py` | 27 | 2 | 2 | 2 |
| `atlas/tests/test_structure.py` | `atlas/tests/test_structure.py` | 152 | 12 | 12 | 19 |
| `atlas/tests/test_tsx_coffee.py` | `atlas/tests/test_tsx_coffee.py` | 80 | 5 | 5 | 27 |
| `atlas/tests/test_variant_snapshots.py` | `atlas/tests/test_variant_snapshots.py` | 77 | 8 | 8 | 21 |
| `atlas/tests/update_coffee_snapshots.py` | `atlas/tests/update_coffee_snapshots.py` | 37 | 2 | 2 | 5 |
| `atlas/tests/variant_snapshot_support.py` | `atlas/tests/variant_snapshot_support.py` | 88 | 7 | 7 | 29 |
| `dashboard/bunfig.toml` | `dashboard/bunfig.toml` | 2 | 0 | 0 | 0 |
| `dashboard/components.json` | `dashboard/components.json` | 22 | 0 | 0 | 0 |
| `dashboard/eslint.config.js` | `dashboard/eslint.config.js` | 16 | 0 | 0 | 0 |
| `dashboard/package.json` | `dashboard/package.json` | 48 | 0 | 0 | 0 |
| `dashboard/prettier.config.js` | `dashboard/prettier.config.js` | 10 | 0 | 0 | 0 |
| `dashboard/public/manifest.json` | `dashboard/public/manifest.json` | 20 | 0 | 0 | 0 |
| `dashboard/public/robots.txt` | `dashboard/public/robots.txt` | 3 | 0 | 0 | 0 |
| `dashboard/src/branding.test.ts` | `dashboard/src/branding.test.ts` | 15 | 1 | 1 | 2 |
| `dashboard/src/components/graph/graph-canvas.tsx` | `dashboard/src/components/graph/graph-canvas.tsx` | 265 | 25 | 25 | 55 |
| `dashboard/src/components/graph/graph-complexity.test.tsx` | `dashboard/src/components/graph/graph-complexity.test.tsx` | 129 | 9 | 9 | 12 |
| `dashboard/src/components/graph/graph-complexity.tsx` | `dashboard/src/components/graph/graph-complexity.tsx` | 41 | 2 | 2 | 4 |
| `dashboard/src/components/graph/graph-cycles.tsx` | `dashboard/src/components/graph/graph-cycles.tsx` | 77 | 6 | 6 | 14 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx` | 109 | 11 | 11 | 16 |
| `dashboard/src/components/graph/graph-dependency-metrics.tsx` | `dashboard/src/components/graph/graph-dependency-metrics.tsx` | 48 | 3 | 3 | 5 |
| `dashboard/src/components/graph/graph-explorer.test.tsx` | `dashboard/src/components/graph/graph-explorer.test.tsx` | 99 | 2 | 2 | 3 |
| `dashboard/src/components/graph/graph-explorer.tsx` | `dashboard/src/components/graph/graph-explorer.tsx` | 210 | 15 | 15 | 30 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx` | `dashboard/src/components/graph/graph-file-complexity.test.tsx` | 206 | 20 | 20 | 26 |
| `dashboard/src/components/graph/graph-file-complexity.tsx` | `dashboard/src/components/graph/graph-file-complexity.tsx` | 39 | 2 | 2 | 10 |
| `dashboard/src/components/graph/graph-layout.test.ts` | `dashboard/src/components/graph/graph-layout.test.ts` | 56 | 5 | 5 | 10 |
| `dashboard/src/components/graph/graph-layout.ts` | `dashboard/src/components/graph/graph-layout.ts` | 41 | 6 | 6 | 10 |
| `dashboard/src/components/graph/graph-navigation.tsx` | `dashboard/src/components/graph/graph-navigation.tsx` | 32 | 3 | 3 | 6 |
| `dashboard/src/components/graph/graph-sidebar.tsx` | `dashboard/src/components/graph/graph-sidebar.tsx` | 264 | 21 | 21 | 52 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx` | `dashboard/src/components/graph/graph-size-metrics.test.tsx` | 67 | 12 | 12 | 15 |
| `dashboard/src/components/graph/graph-size-metrics.tsx` | `dashboard/src/components/graph/graph-size-metrics.tsx` | 39 | 3 | 3 | 8 |
| `dashboard/src/components/repository-form.tsx` | `dashboard/src/components/repository-form.tsx` | 84 | 6 | 6 | 10 |
| `dashboard/src/components/repository-row.tsx` | `dashboard/src/components/repository-row.tsx` | 34 | 1 | 1 | 4 |
| `dashboard/src/components/ui/badge.tsx` | `dashboard/src/components/ui/badge.tsx` | 44 | 1 | 1 | 1 |
| `dashboard/src/components/ui/button.tsx` | `dashboard/src/components/ui/button.tsx` | 58 | 1 | 1 | 1 |
| `dashboard/src/components/ui/input.tsx` | `dashboard/src/components/ui/input.tsx` | 21 | 1 | 1 | 1 |
| `dashboard/src/components/ui/primitives.test.tsx` | `dashboard/src/components/ui/primitives.test.tsx` | 54 | 3 | 3 | 5 |
| `dashboard/src/env.d.ts` | `dashboard/src/env.d.ts` | 10 | 0 | 0 | 0 |
| `dashboard/src/lib/api.ts` | `dashboard/src/lib/api.ts` | 30 | 3 | 3 | 4 |
| `dashboard/src/lib/architecture-artifact.ts` | `dashboard/src/lib/architecture-artifact.ts` | 84 | 0 | 0 | 0 |
| `dashboard/src/lib/database.servers.test.ts` | `dashboard/src/lib/database.servers.test.ts` | 25 | 1 | 1 | 3 |
| `dashboard/src/lib/file-complexity.ts` | `dashboard/src/lib/file-complexity.ts` | 35 | 5 | 5 | 10 |
| `dashboard/src/lib/graph-analysis.test.ts` | `dashboard/src/lib/graph-analysis.test.ts` | 228 | 14 | 14 | 23 |
| `dashboard/src/lib/graph-analysis.ts` | `dashboard/src/lib/graph-analysis.ts` | 215 | 30 | 30 | 57 |
| `dashboard/src/lib/graph-cycles.test.ts` | `dashboard/src/lib/graph-cycles.test.ts` | 192 | 17 | 17 | 19 |
| `dashboard/src/lib/graph-cycles.ts` | `dashboard/src/lib/graph-cycles.ts` | 129 | 22 | 22 | 43 |
| `dashboard/src/lib/graph-data.ts` | `dashboard/src/lib/graph-data.ts` | 55 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-details-test.helpers.ts` | `dashboard/src/lib/graph-details-test.helpers.ts` | 15 | 3 | 3 | 3 |
| `dashboard/src/lib/graph-test-path.ts` | `dashboard/src/lib/graph-test-path.ts` | 24 | 2 | 2 | 9 |
| `dashboard/src/lib/graph-traversal.ts` | `dashboard/src/lib/graph-traversal.ts` | 11 | 1 | 1 | 3 |
| `dashboard/src/lib/graph-visibility.test.ts` | `dashboard/src/lib/graph-visibility.test.ts` | 166 | 12 | 12 | 15 |
| `dashboard/src/lib/graph-visibility.ts` | `dashboard/src/lib/graph-visibility.ts` | 59 | 7 | 7 | 20 |
| `dashboard/src/lib/import-cycles.servers.ts` | `dashboard/src/lib/import-cycles.servers.ts` | 188 | 23 | 23 | 57 |
| `dashboard/src/lib/imported-artifact-fixture.ts` | `dashboard/src/lib/imported-artifact-fixture.ts` | 156 | 8 | 8 | 20 |
| `dashboard/src/lib/normalized-graph.servers.test.ts` | `dashboard/src/lib/normalized-graph.servers.test.ts` | 557 | 44 | 44 | 58 |
| `dashboard/src/lib/persistence/repositories/connection.ts` | `dashboard/src/lib/persistence/repositories/connection.ts` | 28 | 3 | 3 | 5 |
| `dashboard/src/lib/persistence/repositories/factory.ts` | `dashboard/src/lib/persistence/repositories/factory.ts` | 19 | 6 | 6 | 6 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts` | `dashboard/src/lib/persistence/repositories/graph-queries.ts` | 227 | 20 | 20 | 25 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts` | `dashboard/src/lib/persistence/repositories/graph-store.ts` | 217 | 29 | 29 | 45 |
| `dashboard/src/lib/persistence/repositories/repository-store.ts` | `dashboard/src/lib/persistence/repositories/repository-store.ts` | 43 | 4 | 4 | 6 |
| `dashboard/src/lib/persistence/repositories/schema.ts` | `dashboard/src/lib/persistence/repositories/schema.ts` | 115 | 8 | 8 | 8 |
| `dashboard/src/lib/project-graph-boundary.test.ts` | `dashboard/src/lib/project-graph-boundary.test.ts` | 222 | 26 | 26 | 32 |
| `dashboard/src/lib/project-graph-boundary.ts` | `dashboard/src/lib/project-graph-boundary.ts` | 110 | 13 | 13 | 35 |
| `dashboard/src/lib/project-graph-fixture.ts` | `dashboard/src/lib/project-graph-fixture.ts` | 85 | 2 | 2 | 6 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts` | `dashboard/src/lib/project-graph-projection-test-helpers.ts` | 149 | 17 | 17 | 45 |
| `dashboard/src/lib/project-graph-real.test.ts` | `dashboard/src/lib/project-graph-real.test.ts` | 98 | 18 | 18 | 26 |
| `dashboard/src/lib/project-graph-test.helpers.ts` | `dashboard/src/lib/project-graph-test.helpers.ts` | 17 | 6 | 6 | 6 |
| `dashboard/src/lib/project-graph-types.ts` | `dashboard/src/lib/project-graph-types.ts` | 28 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts` | `dashboard/src/lib/project-graph.test.ts` | 562 | 54 | 54 | 78 |
| `dashboard/src/lib/project-graph.ts` | `dashboard/src/lib/project-graph.ts` | 274 | 27 | 27 | 82 |
| `dashboard/src/lib/repositories.servers.test.ts` | `dashboard/src/lib/repositories.servers.test.ts` | 364 | 39 | 39 | 45 |
| `dashboard/src/lib/repositories.servers.ts` | `dashboard/src/lib/repositories.servers.ts` | 93 | 15 | 15 | 28 |
| `dashboard/src/lib/repository-ports.ts` | `dashboard/src/lib/repository-ports.ts` | 11 | 0 | 0 | 0 |
| `dashboard/src/lib/utils.ts` | `dashboard/src/lib/utils.ts` | 7 | 1 | 1 | 1 |
| `dashboard/src/router.tsx` | `dashboard/src/router.tsx` | 13 | 1 | 1 | 1 |
| `dashboard/src/routes/__root.tsx` | `dashboard/src/routes/__root.tsx` | 87 | 5 | 5 | 6 |
| `dashboard/src/routes/api/architecture.ts` | `dashboard/src/routes/api/architecture.ts` | 29 | 1 | 1 | 3 |
| `dashboard/src/routes/api/repositories.ts` | `dashboard/src/routes/api/repositories.ts` | 33 | 2 | 2 | 5 |
| `dashboard/src/routes/graph-project-name.test.ts` | `dashboard/src/routes/graph-project-name.test.ts` | 58 | 4 | 4 | 5 |
| `dashboard/src/routes/graph.$repositoryId.tsx` | `dashboard/src/routes/graph.$repositoryId.tsx` | 128 | 6 | 6 | 15 |
| `dashboard/src/routes/index.tsx` | `dashboard/src/routes/index.tsx` | 88 | 6 | 6 | 15 |
| `dashboard/src/server.ts` | `dashboard/src/server.ts` | 7 | 1 | 1 | 1 |
| `dashboard/src/start.ts` | `dashboard/src/start.ts` | 3 | 1 | 1 | 1 |
| `dashboard/src/styles.css` | `dashboard/src/styles.css` | 4 | 0 | 0 | 0 |
| `dashboard/src/styles/base.css` | `dashboard/src/styles/base.css` | 310 | 0 | 0 | 0 |
| `dashboard/src/styles/graph.css` | `dashboard/src/styles/graph.css` | 456 | 0 | 0 | 0 |
| `dashboard/src/styles/responsive.css` | `dashboard/src/styles/responsive.css` | 90 | 0 | 0 | 0 |
| `dashboard/src/test.setup.ts` | `dashboard/src/test.setup.ts` | 8 | 1 | 1 | 1 |
| `dashboard/tests/database-access-policy.ts` | `dashboard/tests/database-access-policy.ts` | 113 | 10 | 10 | 47 |
| `dashboard/tests/database-architecture.test.ts` | `dashboard/tests/database-architecture.test.ts` | 218 | 15 | 15 | 23 |
| `dashboard/tests/database-architecture.ts` | `dashboard/tests/database-architecture.ts` | 141 | 10 | 10 | 32 |
| `dashboard/tests/database-boundary-regressions.test.ts` | `dashboard/tests/database-boundary-regressions.test.ts` | 220 | 24 | 24 | 34 |
| `dashboard/tests/database-dependency-policy.ts` | `dashboard/tests/database-dependency-policy.ts` | 214 | 26 | 26 | 69 |
| `dashboard/tests/database-factory-boundary.test.ts` | `dashboard/tests/database-factory-boundary.test.ts` | 75 | 4 | 4 | 7 |
| `dashboard/tests/database-module-policy.ts` | `dashboard/tests/database-module-policy.ts` | 117 | 12 | 12 | 49 |
| `dashboard/tests/database-policy.ts` | `dashboard/tests/database-policy.ts` | 60 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts` | `dashboard/tests/database-service-exports.ts` | 126 | 21 | 21 | 38 |
| `dashboard/tests/database-syntax.ts` | `dashboard/tests/database-syntax.ts` | 88 | 10 | 10 | 49 |
| `dashboard/tsconfig.json` | `dashboard/tsconfig.json` | 34 | 0 | 0 | 0 |
| `dashboard/vite.config.ts` | `dashboard/vite.config.ts` | 29 | 0 | 0 | 0 |
| `reports/atlas-navigation/REPORT.md` | `reports/atlas-navigation/REPORT.md` | 104 | 0 | 0 | 0 |
| `reports/atlas-navigation/evaluation-original.md` | `reports/atlas-navigation/evaluation-original.md` | 130 | 0 | 0 | 0 |
| `reports/atlas-navigation/evaluation-revised.md` | `reports/atlas-navigation/evaluation-revised.md` | 122 | 0 | 0 | 0 |
| `reports/atlas-navigation/evidence/EX-ATLAS.md` | `reports/atlas-navigation/evidence/EX-ATLAS.md` | 48 | 0 | 0 | 0 |
| `reports/atlas-navigation/evidence/EX-PLAIN.md` | `reports/atlas-navigation/evidence/EX-PLAIN.md` | 49 | 0 | 0 | 0 |
| `reports/atlas-navigation/evidence/EX-REVISED.md` | `reports/atlas-navigation/evidence/EX-REVISED.md` | 50 | 0 | 0 | 0 |
| `reports/atlas-navigation/evidence/PY-ATLAS.md` | `reports/atlas-navigation/evidence/PY-ATLAS.md` | 46 | 0 | 0 | 0 |
| `reports/atlas-navigation/evidence/PY-PLAIN.md` | `reports/atlas-navigation/evidence/PY-PLAIN.md` | 50 | 0 | 0 | 0 |
| `reports/atlas-navigation/evidence/PY-REVISED.md` | `reports/atlas-navigation/evidence/PY-REVISED.md` | 49 | 0 | 0 | 0 |
| `reports/atlas-navigation/evidence/TS-ATLAS.md` | `reports/atlas-navigation/evidence/TS-ATLAS.md` | 47 | 0 | 0 | 0 |
| `reports/atlas-navigation/evidence/TS-PLAIN.md` | `reports/atlas-navigation/evidence/TS-PLAIN.md` | 46 | 0 | 0 | 0 |
| `reports/atlas-navigation/evidence/TS-REVISED.md` | `reports/atlas-navigation/evidence/TS-REVISED.md` | 56 | 0 | 0 | 0 |
| `reports/atlas-navigation/evidence/skill-measured/SKILL.md` | `reports/atlas-navigation/evidence/skill-measured/SKILL.md` | 74 | 0 | 0 | 0 |
| `reports/atlas-navigation/evidence/skill-measured/references/commands.md` | `reports/atlas-navigation/evidence/skill-measured/references/commands.md` | 67 | 0 | 0 | 0 |
| `reports/atlas-navigation/metrics.json` | `reports/atlas-navigation/metrics.json` | 323 | 0 | 0 | 0 |
| `reports/atlas-navigation/prompts.json` | `reports/atlas-navigation/prompts.json` | 11 | 0 | 0 | 0 |
| `reports/atlas-navigation/provenance.json` | `reports/atlas-navigation/provenance.json` | 54 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/REPORT.md` | `reports/atlas-vs-graphify/REPORT.md` | 78 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/evaluation.json` | `reports/atlas-vs-graphify/evaluation.json` | 126 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/evidence/EX-ATLAS.md` | `reports/atlas-vs-graphify/evidence/EX-ATLAS.md` | 43 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/evidence/EX-GRAPHIFY.md` | `reports/atlas-vs-graphify/evidence/EX-GRAPHIFY.md` | 42 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/evidence/EX-PLAIN.md` | `reports/atlas-vs-graphify/evidence/EX-PLAIN.md` | 42 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/evidence/PY-ATLAS.md` | `reports/atlas-vs-graphify/evidence/PY-ATLAS.md` | 44 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/evidence/PY-GRAPHIFY.md` | `reports/atlas-vs-graphify/evidence/PY-GRAPHIFY.md` | 48 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/evidence/PY-PLAIN.md` | `reports/atlas-vs-graphify/evidence/PY-PLAIN.md` | 43 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/evidence/TS-ATLAS.md` | `reports/atlas-vs-graphify/evidence/TS-ATLAS.md` | 40 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/evidence/TS-GRAPHIFY.md` | `reports/atlas-vs-graphify/evidence/TS-GRAPHIFY.md` | 38 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/evidence/TS-PLAIN.md` | `reports/atlas-vs-graphify/evidence/TS-PLAIN.md` | 38 | 0 | 0 | 0 |
| `reports/atlas-vs-graphify/metrics.json` | `reports/atlas-vs-graphify/metrics.json` | 308 | 0 | 0 | 0 |

## Callables

| Item | Location | Lines | Parameters | Cyclomatic complexity | Weighted complexity | Nested decision penalty | Nested loops | Decision depth |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `atlas/src/atlas/cli/commands.py::main` | `atlas/src/atlas/cli/commands.py:13` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/commands.py::index_command` | `atlas/src/atlas/cli/commands.py:19` | 17 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/cli/commands.py::projects_command` | `atlas/src/atlas/cli/commands.py:39` | 10 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/cli/commands.py::_folder_report` | `atlas/src/atlas/cli/commands.py:51` | 13 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/cli/commands.py::report_command` | `atlas/src/atlas/cli/commands.py:70` | 9 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/cli/commands.py::check_command` | `atlas/src/atlas/cli/commands.py:92` | 14 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/cli/graph.py::graph` | `atlas/src/atlas/cli/graph.py:19` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/graph.py::GraphError.show` | `atlas/src/atlas/cli/graph.py:26` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/graph.py::emit` | `atlas/src/atlas/cli/graph.py:30` | 15 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/cli/graph.py::command_options` | `atlas/src/atlas/cli/graph.py:47` | 7 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/cli/graph.py::overview` | `atlas/src/atlas/cli/graph.py:58` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/graph.py::find` | `atlas/src/atlas/cli/graph.py:66` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/graph.py::show` | `atlas/src/atlas/cli/graph.py:73` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/graph.py::children` | `atlas/src/atlas/cli/graph.py:82` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/graph.py::relation_list` | `atlas/src/atlas/cli/graph.py:86` | 6 | 3 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/cli/graph.py::traversal_options` | `atlas/src/atlas/cli/graph.py:94` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/graph.py::context` | `atlas/src/atlas/cli/graph.py:106` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/graph.py::source` | `atlas/src/atlas/cli/graph.py:116` | 5 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/cli/graph.py::path` | `atlas/src/atlas/cli/graph.py:129` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/cli/graph_output.py::graph_output` | `atlas/src/atlas/cli/graph_output.py:11` | 13 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/cli/graph_output.py::_unresolved_identity` | `atlas/src/atlas/cli/graph_output.py:26` | 7 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/cli/graph_source_output.py::source_text` | `atlas/src/atlas/cli/graph_source_output.py:8` | 8 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/cli/graph_source_output.py::excerpt_text` | `atlas/src/atlas/cli/graph_source_output.py:18` | 5 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/domain/models.py::ParsedRepository.symbols` | `atlas/src/atlas/domain/models.py:207` | 14 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/domain/models.py::ParsedRepository.imports` | `atlas/src/atlas/domain/models.py:223` | 14 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/domain/models.py::ParsedRepository.calls` | `atlas/src/atlas/domain/models.py:239` | 14 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/domain/models.py::ParsedRepository.inheritances` | `atlas/src/atlas/domain/models.py:255` | 14 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/domain/models.py::file_key` | `atlas/src/atlas/domain/models.py:271` | 16 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/navigation.py::GraphSnapshot.metadata` | `atlas/src/atlas/domain/navigation.py:20` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.overview` | `atlas/src/atlas/domain/navigation.py:57` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.find` | `atlas/src/atlas/domain/navigation.py:58` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.node` | `atlas/src/atlas/domain/navigation.py:59` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.children` | `atlas/src/atlas/domain/navigation.py:60` | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.edges` | `atlas/src/atlas/domain/navigation.py:61` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.diagnostics` | `atlas/src/atlas/domain/navigation.py:62` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.file` | `atlas/src/atlas/domain/navigation.py:63` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/repositories.py::RepositoryError.__init__` | `atlas/src/atlas/domain/repositories.py:9` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.register` | `atlas/src/atlas/domain/repositories.py:84` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.list` | `atlas/src/atlas/domain/repositories.py:86` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.exists` | `atlas/src/atlas/domain/repositories.py:88` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.resolve` | `atlas/src/atlas/domain/repositories.py:90` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.graph` | `atlas/src/atlas/domain/repositories.py:92` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.report_facts` | `atlas/src/atlas/domain/repositories.py:94` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.save` | `atlas/src/atlas/domain/repositories.py:96` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.save_new` | `atlas/src/atlas/domain/repositories.py:98` | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/indexer.py::analyze_repository` | `atlas/src/atlas/indexer.py:12` | 22 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/language_syntax.py::_declaration_head` | `atlas/src/atlas/language_syntax.py:19` | 12 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/language_syntax.py::_first_head` | `atlas/src/atlas/language_syntax.py:33` | 6 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/language_syntax.py::_property_callable` | `atlas/src/atlas/language_syntax.py:41` | 10 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/__init__.py::get_metric_adapter` | `atlas/src/atlas/metrics/adapters/__init__.py:40` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/__init__.py::receiver_coverage` | `atlas/src/atlas/metrics/adapters/__init__.py:60` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/__init__.py::get_resolution_adapter` | `atlas/src/atlas/metrics/adapters/__init__.py:66` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/base.py::never` | `atlas/src/atlas/metrics/adapters/base.py:81` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/base.py::alternative` | `atlas/src/atlas/metrics/adapters/base.py:85` | 14 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/base.py::_conditional_parent` | `atlas/src/atlas/metrics/adapters/base.py:101` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/base.py::MetricPolicy.body` | `atlas/src/atlas/metrics/adapters/base.py:118` | 8 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/base.py::MetricPolicy.scope` | `atlas/src/atlas/metrics/adapters/base.py:127` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/base.py::MetricPolicy.decision` | `atlas/src/atlas/metrics/adapters/base.py:130` | 9 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/base.py::MetricPolicy.logical` | `atlas/src/atlas/metrics/adapters/base.py:140` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/base.py::MetricPolicy.alternative` | `atlas/src/atlas/metrics/adapters/base.py:145` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/base.py::MetricAdapter.<anonymous>` | `atlas/src/atlas/metrics/adapters/base.py:156` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::Assignment.index` | `atlas/src/atlas/metrics/adapters/callable_selection.py:51` | 10 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::Assignment.assign` | `atlas/src/atlas/metrics/adapters/callable_selection.py:62` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::Assignment.complete` | `atlas/src/atlas/metrics/adapters/callable_selection.py:68` | 2 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_sole` | `atlas/src/atlas/metrics/adapters/callable_selection.py:72` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_type_names` | `atlas/src/atlas/metrics/adapters/callable_selection.py:76` | 5 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::select_callable` | `atlas/src/atlas/metrics/adapters/callable_selection.py:83` | 9 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_viable` | `atlas/src/atlas/metrics/adapters/callable_selection.py:94` | 7 | 3 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::call_arguments` | `atlas/src/atlas/metrics/adapters/callable_selection.py:103` | 9 | 1 | 7 | 8 | 1 | 0 | 3 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_kotlin_arguments` | `atlas/src/atlas/metrics/adapters/callable_selection.py:114` | 14 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_argument` | `atlas/src/atlas/metrics/adapters/callable_selection.py:130` | 7 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_parameter_container` | `atlas/src/atlas/metrics/adapters/callable_selection.py:139` | 7 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::callable_parameters` | `atlas/src/atlas/metrics/adapters/callable_selection.py:148` | 13 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_parameter` | `atlas/src/atlas/metrics/adapters/callable_selection.py:163` | 13 | 3 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::accepts` | `atlas/src/atlas/metrics/adapters/callable_selection.py:178` | 9 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_accept_argument` | `atlas/src/atlas/metrics/adapters/callable_selection.py:189` | 10 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::expression_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:201` | 13 | 2 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_integer_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:216` | 5 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_visible_binding` | `atlas/src/atlas/metrics/adapters/callable_selection.py:223` | 3 | 3 | 4 | 4 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_scope_width` | `atlas/src/atlas/metrics/adapters/callable_selection.py:228` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_identifier_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:232` | 9 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_nearest_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:243` | 4 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_mentions_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:255` | 3 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_annotation_node` | `atlas/src/atlas/metrics/adapters/callable_selection.py:260` | 3 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_lossy_annotation` | `atlas/src/atlas/metrics/adapters/callable_selection.py:265` | 3 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_uncertain_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:270` | 8 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::proven_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:280` | 8 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_kotlin_incompatible` | `atlas/src/atlas/metrics/adapters/callable_selection.py:290` | 5 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_java_incompatible` | `atlas/src/atlas/metrics/adapters/callable_selection.py:297` | 8 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::incompatible` | `atlas/src/atlas/metrics/adapters/callable_selection.py:307` | 7 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::target` | `atlas/src/atlas/metrics/adapters/elixir.py:38` | 3 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::scope` | `atlas/src/atlas/metrics/adapters/elixir.py:43` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/elixir.py::call_decision` | `atlas/src/atlas/metrics/adapters/elixir.py:47` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/elixir.py::guard_decision` | `atlas/src/atlas/metrics/adapters/elixir.py:51` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::clause_decision` | `atlas/src/atlas/metrics/adapters/elixir.py:55` | 14 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_cond_fallback` | `atlas/src/atlas/metrics/adapters/elixir.py:71` | 2 | 2 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/elixir.py::arguments` | `atlas/src/atlas/metrics/adapters/elixir.py:75` | 11 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::parameter_count` | `atlas/src/atlas/metrics/adapters/elixir.py:88` | 9 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_elixir_head_count` | `atlas/src/atlas/metrics/adapters/elixir.py:99` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_elixir_anonymous_count` | `atlas/src/atlas/metrics/adapters/elixir.py:105` | 4 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_elixir_clause_count` | `atlas/src/atlas/metrics/adapters/elixir.py:111` | 11 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::arity` | `atlas/src/atlas/metrics/adapters/elixir.py:135` | 7 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_clause_signature` | `atlas/src/atlas/metrics/adapters/elixir.py:144` | 10 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_parameter_counts` | `atlas/src/atlas/metrics/adapters/elixir.py:156` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_resolution_pipeline` | `atlas/src/atlas/metrics/adapters/elixir.py:164` | 9 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_pipeline_identifier` | `atlas/src/atlas/metrics/adapters/elixir.py:175` | 2 | 2 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_call_arity` | `atlas/src/atlas/metrics/adapters/elixir.py:179` | 8 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_clause_matches` | `atlas/src/atlas/metrics/adapters/elixir.py:195` | 10 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.import_path` | `atlas/src/atlas/metrics/adapters/elixir.py:208` | 3 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.is_import_node` | `atlas/src/atlas/metrics/adapters/elixir.py:216` | 5 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.module_identity` | `atlas/src/atlas/metrics/adapters/elixir.py:222` | 6 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.import_key` | `atlas/src/atlas/metrics/adapters/elixir.py:229` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.import_item` | `atlas/src/atlas/metrics/adapters/elixir.py:233` | 10 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.qualified` | `atlas/src/atlas/metrics/adapters/elixir.py:244` | 4 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.clauses` | `atlas/src/atlas/metrics/adapters/elixir.py:249` | 11 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.select` | `atlas/src/atlas/metrics/adapters/elixir.py:261` | 11 | 3 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/generic.py::receiver_coverage` | `atlas/src/atlas/metrics/adapters/generic.py:9` | 11 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/generic.py::unwrapped` | `atlas/src/atlas/metrics/adapters/generic.py:22` | 4 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/generic.py::GenericResolution.__init__` | `atlas/src/atlas/metrics/adapters/generic.py:31` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/generic.py::GenericResolution.call_target` | `atlas/src/atlas/metrics/adapters/generic.py:34` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/generic.py::GenericResolution.receiver_class_allowed` | `atlas/src/atlas/metrics/adapters/generic.py:38` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/go.py::parameter_count` | `atlas/src/atlas/metrics/adapters/go.py:23` | 11 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.instance_members` | `atlas/src/atlas/metrics/adapters/go.py:39` | 3 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution._package_symbols` | `atlas/src/atlas/metrics/adapters/go.py:43` | 2 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution._receiver_method` | `atlas/src/atlas/metrics/adapters/go.py:46` | 7 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution._package_files` | `atlas/src/atlas/metrics/adapters/go.py:54` | 4 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution._package` | `atlas/src/atlas/metrics/adapters/go.py:59` | 3 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.same_package` | `atlas/src/atlas/metrics/adapters/go.py:63` | 3 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.import_path` | `atlas/src/atlas/metrics/adapters/go.py:66` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.import_item` | `atlas/src/atlas/metrics/adapters/go.py:69` | 13 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.binding` | `atlas/src/atlas/metrics/adapters/go.py:92` | 6 | 3 | 5 | 6 | 1 | 0 | 3 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.call_target` | `atlas/src/atlas/metrics/adapters/go.py:99` | 9 | 1 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/java.py::parameter_count` | `atlas/src/atlas/metrics/adapters/java.py:23` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/java.py::package` | `atlas/src/atlas/metrics/adapters/java.py:30` | 11 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.import_path` | `atlas/src/atlas/metrics/adapters/java.py:45` | 3 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.select` | `atlas/src/atlas/metrics/adapters/java.py:65` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.call_target` | `atlas/src/atlas/metrics/adapters/java.py:68` | 6 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.binding` | `atlas/src/atlas/metrics/adapters/java.py:75` | 6 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.module_identity` | `atlas/src/atlas/metrics/adapters/java.py:82` | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.same_package` | `atlas/src/atlas/metrics/adapters/java.py:87` | 5 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.import_name` | `atlas/src/atlas/metrics/adapters/java.py:93` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.import_key` | `atlas/src/atlas/metrics/adapters/java.py:97` | 5 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.import_item` | `atlas/src/atlas/metrics/adapters/java.py:103` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.qualify_class` | `atlas/src/atlas/metrics/adapters/java.py:107` | 2 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.inheritance` | `atlas/src/atlas/metrics/adapters/java.py:110` | 6 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::parameter_count` | `atlas/src/atlas/metrics/adapters/javascript.py:29` | 10 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_local_export` | `atlas/src/atlas/metrics/adapters/javascript.py:41` | 6 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_export_declaration` | `atlas/src/atlas/metrics/adapters/javascript.py:49` | 7 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_declaration_symbols` | `atlas/src/atlas/metrics/adapters/javascript.py:58` | 7 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_export_specifiers` | `atlas/src/atlas/metrics/adapters/javascript.py:67` | 3 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_export_specifier` | `atlas/src/atlas/metrics/adapters/javascript.py:72` | 6 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_export_entries` | `atlas/src/atlas/metrics/adapters/javascript.py:80` | 8 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_extend_exports` | `atlas/src/atlas/metrics/adapters/javascript.py:90` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_unique_symbols` | `atlas/src/atlas/metrics/adapters/javascript.py:95` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::export_bindings` | `atlas/src/atlas/metrics/adapters/javascript.py:99` | 7 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_import_clause` | `atlas/src/atlas/metrics/adapters/javascript.py:108` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_named_import` | `atlas/src/atlas/metrics/adapters/javascript.py:113` | 7 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_named_imports` | `atlas/src/atlas/metrics/adapters/javascript.py:122` | 9 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_has_type_modifier` | `atlas/src/atlas/metrics/adapters/javascript.py:133` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_named_import_specifiers` | `atlas/src/atlas/metrics/adapters/javascript.py:137` | 7 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_type_only_named_clause` | `atlas/src/atlas/metrics/adapters/javascript.py:146` | 4 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_field_masks_method` | `atlas/src/atlas/metrics/adapters/javascript.py:152` | 7 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_non_callable_member` | `atlas/src/atlas/metrics/adapters/javascript.py:161` | 4 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_script_own_field` | `atlas/src/atlas/metrics/adapters/javascript.py:167` | 8 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_receiver_alias` | `atlas/src/atlas/metrics/adapters/javascript.py:177` | 7 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_receiver_mutation` | `atlas/src/atlas/metrics/adapters/javascript.py:186` | 5 | 3 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_receiver_aliases` | `atlas/src/atlas/metrics/adapters/javascript.py:193` | 2 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_method_group` | `atlas/src/atlas/metrics/adapters/javascript.py:197` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_plain_method` | `atlas/src/atlas/metrics/adapters/javascript.py:201` | 4 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_script_mutation` | `atlas/src/atlas/metrics/adapters/javascript.py:207` | 9 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.import_path` | `atlas/src/atlas/metrics/adapters/javascript.py:220` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.instance_members` | `atlas/src/atlas/metrics/adapters/javascript.py:240` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.select` | `atlas/src/atlas/metrics/adapters/javascript.py:243` | 11 | 3 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.select.<anonymous>` | `atlas/src/atlas/metrics/adapters/javascript.py:253` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.call_target` | `atlas/src/atlas/metrics/adapters/javascript.py:255` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.normalized_call` | `atlas/src/atlas/metrics/adapters/javascript.py:260` | 4 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.receiver_type_allowed` | `atlas/src/atlas/metrics/adapters/javascript.py:265` | 2 | 3 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.receiver_class_allowed` | `atlas/src/atlas/metrics/adapters/javascript.py:268` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.member_overwritten` | `atlas/src/atlas/metrics/adapters/javascript.py:271` | 4 | 3 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.binding` | `atlas/src/atlas/metrics/adapters/javascript.py:276` | 14 | 3 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.paths` | `atlas/src/atlas/metrics/adapters/javascript.py:291` | 6 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.members` | `atlas/src/atlas/metrics/adapters/javascript.py:298` | 7 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.namespace_exports` | `atlas/src/atlas/metrics/adapters/javascript.py:306` | 7 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.import_type_only` | `atlas/src/atlas/metrics/adapters/javascript.py:314` | 6 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.import_item` | `atlas/src/atlas/metrics/adapters/javascript.py:321` | 19 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution._namespace_import` | `atlas/src/atlas/metrics/adapters/javascript.py:341` | 9 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.namespace_members` | `atlas/src/atlas/metrics/adapters/javascript.py:351` | 2 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.implicit_receiver` | `atlas/src/atlas/metrics/adapters/javascript.py:354` | 12 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::alternative` | `atlas/src/atlas/metrics/adapters/kotlin.py:22` | 11 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::parameter_count` | `atlas/src/atlas/metrics/adapters/kotlin.py:35` | 18 | 1 | 7 | 8 | 1 | 0 | 3 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.import_path` | `atlas/src/atlas/metrics/adapters/kotlin.py:62` | 3 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.write_target` | `atlas/src/atlas/metrics/adapters/kotlin.py:82` | 4 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.call_target` | `atlas/src/atlas/metrics/adapters/kotlin.py:88` | 7 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.binding` | `atlas/src/atlas/metrics/adapters/kotlin.py:96` | 17 | 3 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.import_name` | `atlas/src/atlas/metrics/adapters/kotlin.py:114` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.import_item` | `atlas/src/atlas/metrics/adapters/kotlin.py:117` | 10 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.static_member` | `atlas/src/atlas/metrics/adapters/kotlin.py:128` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.__init__` | `atlas/src/atlas/metrics/adapters/module_index.py:22` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.add_scopes` | `atlas/src/atlas/metrics/adapters/module_index.py:26` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.walk_scopes` | `atlas/src/atlas/metrics/adapters/module_index.py:32` | 8 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.scopes_at` | `atlas/src/atlas/metrics/adapters/module_index.py:41` | 10 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.unique_scope` | `atlas/src/atlas/metrics/adapters/module_index.py:52` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.scope_key` | `atlas/src/atlas/metrics/adapters/module_index.py:59` | 15 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.scope_symbols` | `atlas/src/atlas/metrics/adapters/module_index.py:76` | 7 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.scope_files` | `atlas/src/atlas/metrics/adapters/module_index.py:84` | 3 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/module_index.py::_pending_scopes` | `atlas/src/atlas/metrics/adapters/module_index.py:89` | 6 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/module_index.py::_narrowest_scopes` | `atlas/src/atlas/metrics/adapters/module_index.py:97` | 3 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/parameters.py::parameter_children` | `atlas/src/atlas/metrics/adapters/parameters.py:10` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/parameters.py::parameter_node` | `atlas/src/atlas/metrics/adapters/parameters.py:14` | 4 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/parameters.py::count_parameters` | `atlas/src/atlas/metrics/adapters/parameters.py:20` | 6 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::irrefutable_pattern` | `atlas/src/atlas/metrics/adapters/python.py:36` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_single_pattern` | `atlas/src/atlas/metrics/adapters/python.py:41` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/python.py::_case_pattern` | `atlas/src/atlas/metrics/adapters/python.py:46` | 4 | 1 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::_capture_pattern` | `atlas/src/atlas/metrics/adapters/python.py:52` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/python.py::_as_pattern` | `atlas/src/atlas/metrics/adapters/python.py:57` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/python.py::_union_pattern` | `atlas/src/atlas/metrics/adapters/python.py:62` | 4 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_tuple_pattern` | `atlas/src/atlas/metrics/adapters/python.py:68` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::case_decision` | `atlas/src/atlas/metrics/adapters/python.py:83` | 5 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::parameter_count` | `atlas/src/atlas/metrics/adapters/python.py:90` | 11 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::_python_owner` | `atlas/src/atlas/metrics/adapters/python.py:103` | 9 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::_python_method` | `atlas/src/atlas/metrics/adapters/python.py:114` | 10 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::_python_static` | `atlas/src/atlas/metrics/adapters/python.py:126` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/python.py::_python_receiver` | `atlas/src/atlas/metrics/adapters/python.py:131` | 8 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_in_comprehension_iterable` | `atlas/src/atlas/metrics/adapters/python.py:152` | 4 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_hides_class_scope` | `atlas/src/atlas/metrics/adapters/python.py:158` | 6 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::_self_parameter` | `atlas/src/atlas/metrics/adapters/python.py:166` | 6 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/python.py::_bare_relative_import` | `atlas/src/atlas/metrics/adapters/python.py:174` | 2 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/python.py::_package_root` | `atlas/src/atlas/metrics/adapters/python.py:178` | 6 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_source_roots` | `atlas/src/atlas/metrics/adapters/python.py:186` | 12 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_src_roots` | `atlas/src/atlas/metrics/adapters/python.py:200` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_module_name` | `atlas/src/atlas/metrics/adapters/python.py:204` | 7 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_index_modules` | `atlas/src/atlas/metrics/adapters/python.py:213` | 5 | 3 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::_import_attributes` | `atlas/src/atlas/metrics/adapters/python.py:220` | 6 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_runtime_assignment` | `atlas/src/atlas/metrics/adapters/python.py:228` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/python.py::_assigned_attribute` | `atlas/src/atlas/metrics/adapters/python.py:232` | 5 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_package_parent` | `atlas/src/atlas/metrics/adapters/python.py:239` | 6 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/python.py::_absolute_module_files` | `atlas/src/atlas/metrics/adapters/python.py:247` | 9 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::_module_attribute` | `atlas/src/atlas/metrics/adapters/python.py:258` | 10 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_child_module_files` | `atlas/src/atlas/metrics/adapters/python.py:270` | 6 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_child_path` | `atlas/src/atlas/metrics/adapters/python.py:278` | 2 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::_import_node` | `atlas/src/atlas/metrics/adapters/python.py:282` | 10 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.import_path` | `atlas/src/atlas/metrics/adapters/python.py:296` | 8 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.instance_members` | `atlas/src/atlas/metrics/adapters/python.py:319` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.select` | `atlas/src/atlas/metrics/adapters/python.py:322` | 13 | 3 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.select.<anonymous>` | `atlas/src/atlas/metrics/adapters/python.py:332` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.module_index` | `atlas/src/atlas/metrics/adapters/python.py:336` | 11 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.import_files` | `atlas/src/atlas/metrics/adapters/python.py:348` | 8 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.paths` | `atlas/src/atlas/metrics/adapters/python.py:357` | 14 | 3 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.lexical_imports` | `atlas/src/atlas/metrics/adapters/python.py:372` | 7 | 1 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution._lexical_import_names` | `atlas/src/atlas/metrics/adapters/python.py:380` | 10 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.binding` | `atlas/src/atlas/metrics/adapters/python.py:391` | 10 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.visible` | `atlas/src/atlas/metrics/adapters/python.py:402` | 7 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution._class_visible` | `atlas/src/atlas/metrics/adapters/python.py:410` | 10 | 3 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.declaration_allowed` | `atlas/src/atlas/metrics/adapters/python.py:421` | 5 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.import_shadowed` | `atlas/src/atlas/metrics/adapters/python.py:427` | 9 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.static` | `atlas/src/atlas/metrics/adapters/python.py:437` | 9 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.import_targets` | `atlas/src/atlas/metrics/adapters/python.py:447` | 15 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution._from_import_target` | `atlas/src/atlas/metrics/adapters/python.py:463` | 12 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.import_item` | `atlas/src/atlas/metrics/adapters/python.py:476` | 14 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution._from_import_item` | `atlas/src/atlas/metrics/adapters/python.py:491` | 11 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution._module_symbols` | `atlas/src/atlas/metrics/adapters/python.py:503` | 5 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.implicit_receiver` | `atlas/src/atlas/metrics/adapters/python.py:509` | 15 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::Binding.member` | `atlas/src/atlas/metrics/adapters/resolution.py:36` | 4 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::Modules.__init__` | `atlas/src/atlas/metrics/adapters/resolution.py:45` | 12 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::Modules.declared` | `atlas/src/atlas/metrics/adapters/resolution.py:58` | 10 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::Modules._declared` | `atlas/src/atlas/metrics/adapters/resolution.py:69` | 7 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::Modules.same_package` | `atlas/src/atlas/metrics/adapters/resolution.py:77` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution.py::CallableIdentity.__init__` | `atlas/src/atlas/metrics/adapters/resolution.py:82` | 9 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::CallableIdentity.select` | `atlas/src/atlas/metrics/adapters/resolution.py:92` | 5 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings.__init__` | `atlas/src/atlas/metrics/adapters/resolution.py:102` | 10 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings.path_files` | `atlas/src/atlas/metrics/adapters/resolution.py:113` | 17 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings.files` | `atlas/src/atlas/metrics/adapters/resolution.py:131` | 6 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._members` | `atlas/src/atlas/metrics/adapters/resolution.py:138` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._file_bindings` | `atlas/src/atlas/metrics/adapters/resolution.py:141` | 13 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._directive_bindings` | `atlas/src/atlas/metrics/adapters/resolution.py:155` | 16 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._binding` | `atlas/src/atlas/metrics/adapters/resolution.py:172` | 6 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._visible_binding` | `atlas/src/atlas/metrics/adapters/resolution.py:179` | 5 | 3 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._named_bindings` | `atlas/src/atlas/metrics/adapters/resolution.py:185` | 2 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings.get` | `atlas/src/atlas/metrics/adapters/resolution.py:188` | 11 | 3 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::top_symbols` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:10` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::quoted_path` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:14` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::import_path` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:19` | 14 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_relative_match` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:35` | 3 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::relative_targets` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:40` | 8 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_relative_directory` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:50` | 11 | 3 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_package_match` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:63` | 5 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_package_directory` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:70` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_package_directories` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:74` | 5 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_package_path` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:81` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::package_targets` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:86` | 9 | 2 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::path_target_key` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:97` | 5 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::namespace_binding` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:104` | 14 | 2 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.receiver_owner` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:45` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.receiver_bindings` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:49` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.instance_members` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:52` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.module_index` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:55` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.lexical_imports` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:58` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.binding` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:61` | 10 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.write_target` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:72` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.visible` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:75` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.declaration_allowed` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:78` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_shadowed` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:81` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.is_import_node` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:84` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.static` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:87` | 10 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.paths` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:98` | 6 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_files` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:105` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_path` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:108` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_key` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:111` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_targets` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:114` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_type_only` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:118` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_item` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:121` | 4 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.namespace_members` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:126` | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.module_bindings` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:131` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.members` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:134` | 7 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.module_identity` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:142` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.same_package` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:145` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.qualify_class` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:148` | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.qualified` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:153` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.local_namespace` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:156` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.static_member` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:159` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.member_overwritten` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:162` | 4 | 3 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.call_target` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:167` | 12 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.normalized_call` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:180` | 5 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.receiver_type_allowed` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:186` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.receiver_class_allowed` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:189` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.receiver_rejected` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:192` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.implicit_receiver` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:195` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.clauses` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:198` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.select` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:201` | 4 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.inheritance` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:206` | 10 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::_namespace_inheritance` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:218` | 6 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::_inheritance_namespace` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:226` | 5 | 3 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::_import_symbols` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:233` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::match_decision` | `atlas/src/atlas/metrics/adapters/rust.py:36` | 3 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/rust.py::_path_value` | `atlas/src/atlas/metrics/adapters/rust.py:41` | 10 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/rust.py::_path_attribute` | `atlas/src/atlas/metrics/adapters/rust.py:53` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::path_attributes` | `atlas/src/atlas/metrics/adapters/rust.py:61` | 15 | 1 | 5 | 6 | 1 | 0 | 3 |
| `atlas/src/atlas/metrics/adapters/rust.py::_relative_identity` | `atlas/src/atlas/metrics/adapters/rust.py:78` | 9 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::_entry_files` | `atlas/src/atlas/metrics/adapters/rust.py:89` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::_inline_scopes` | `atlas/src/atlas/metrics/adapters/rust.py:97` | 4 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules.__init__` | `atlas/src/atlas/metrics/adapters/rust.py:106` | 11 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._rust_roots` | `atlas/src/atlas/metrics/adapters/rust.py:118` | 11 | 0 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._rust_files` | `atlas/src/atlas/metrics/adapters/rust.py:130` | 4 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._module_owner` | `atlas/src/atlas/metrics/adapters/rust.py:135` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._referenced_files` | `atlas/src/atlas/metrics/adapters/rust.py:141` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._module_directory` | `atlas/src/atlas/metrics/adapters/rust.py:149` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._child_scopes` | `atlas/src/atlas/metrics/adapters/rust.py:153` | 20 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._external_scopes` | `atlas/src/atlas/metrics/adapters/rust.py:174` | 9 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._walk_rust` | `atlas/src/atlas/metrics/adapters/rust.py:184` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._module_children` | `atlas/src/atlas/metrics/adapters/rust.py:191` | 3 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._rust_identities` | `atlas/src/atlas/metrics/adapters/rust.py:195` | 10 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._rust_target` | `atlas/src/atlas/metrics/adapters/rust.py:206` | 5 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules.rust_key` | `atlas/src/atlas/metrics/adapters/rust.py:212` | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules.rust_import` | `atlas/src/atlas/metrics/adapters/rust.py:217` | 10 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules.rust_symbols` | `atlas/src/atlas/metrics/adapters/rust.py:228` | 5 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules.rust_files` | `atlas/src/atlas/metrics/adapters/rust.py:234` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.instance_members` | `atlas/src/atlas/metrics/adapters/rust.py:241` | 6 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.import_path` | `atlas/src/atlas/metrics/adapters/rust.py:248` | 3 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution._inherent_impl` | `atlas/src/atlas/metrics/adapters/rust.py:252` | 9 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution._impl_types` | `atlas/src/atlas/metrics/adapters/rust.py:262` | 9 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.qualify_class` | `atlas/src/atlas/metrics/adapters/rust.py:272` | 7 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.receiver_owner` | `atlas/src/atlas/metrics/adapters/rust.py:280` | 11 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution._ancestor` | `atlas/src/atlas/metrics/adapters/rust.py:292` | 2 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution._has_self` | `atlas/src/atlas/metrics/adapters/rust.py:295` | 4 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.static` | `atlas/src/atlas/metrics/adapters/rust.py:300` | 7 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution._has_self_node` | `atlas/src/atlas/metrics/adapters/rust.py:308` | 6 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.call_target` | `atlas/src/atlas/metrics/adapters/rust.py:315` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.module_index` | `atlas/src/atlas/metrics/adapters/rust.py:333` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.index` | `atlas/src/atlas/metrics/adapters/rust.py:336` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.import_files` | `atlas/src/atlas/metrics/adapters/rust.py:339` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.import_key` | `atlas/src/atlas/metrics/adapters/rust.py:342` | 8 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.members` | `atlas/src/atlas/metrics/adapters/rust.py:351` | 6 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.import_item` | `atlas/src/atlas/metrics/adapters/rust.py:358` | 16 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.module_bindings` | `atlas/src/atlas/metrics/adapters/rust.py:375` | 17 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.local_namespace` | `atlas/src/atlas/metrics/adapters/rust.py:393` | 7 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.qualified` | `atlas/src/atlas/metrics/adapters/rust.py:401` | 8 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.receiver_rejected` | `atlas/src/atlas/metrics/adapters/rust.py:410` | 6 | 2 | 4 | 4 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/rust.py::parameter_count` | `atlas/src/atlas/metrics/adapters/rust.py:418` | 9 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::import_names` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:9` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_decorators` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:16` | 3 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_prior_import` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:21` | 4 | 3 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_overload_target` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:27` | 7 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_add_providers` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:36` | 4 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_OverloadProviders.__init__` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:43` | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_OverloadProviders.matches` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:48` | 4 | 2 | 4 | 4 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::typing_overload` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:54` | 11 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::overload_implementation` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:67` | 4 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_descriptor_aliases` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:73` | 6 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_descriptor_method` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:81` | 5 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_first_self` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:88` | 4 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_self_assignment` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:94` | 4 | 3 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_instance_owner` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:100` | 8 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::bound_self` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:110` | 8 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::inherited_members` | `atlas/src/atlas/metrics/adapters/script_resolution.py:10` | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_InheritedMember.__init__` | `atlas/src/atlas/metrics/adapters/script_resolution.py:16` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_InheritedMember.members` | `atlas/src/atlas/metrics/adapters/script_resolution.py:20` | 11 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_InheritedMember._masked` | `atlas/src/atlas/metrics/adapters/script_resolution.py:32` | 4 | 2 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_InheritedMember._inherited` | `atlas/src/atlas/metrics/adapters/script_resolution.py:37` | 6 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_InheritedMember.base_instance_write` | `atlas/src/atlas/metrics/adapters/script_resolution.py:44` | 8 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_base_class` | `atlas/src/atlas/metrics/adapters/script_resolution.py:54` | 12 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_instance_member_write` | `atlas/src/atlas/metrics/adapters/script_resolution.py:68` | 3 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_scope_member_write` | `atlas/src/atlas/metrics/adapters/script_resolution.py:73` | 3 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_instance_node_write` | `atlas/src/atlas/metrics/adapters/script_resolution.py:78` | 6 | 3 | 4 | 4 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_receiver_scopes` | `atlas/src/atlas/metrics/adapters/script_resolution.py:86` | 19 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_instance_scope` | `atlas/src/atlas/metrics/adapters/script_resolution.py:107` | 10 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_lexical_aliases` | `atlas/src/atlas/metrics/adapters/script_resolution.py:119` | 8 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_lexical_alias_targets` | `atlas/src/atlas/metrics/adapters/script_resolution.py:129` | 7 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_instance_field` | `atlas/src/atlas/metrics/adapters/script_resolution.py:138` | 8 | 3 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_plain_class` | `atlas/src/atlas/metrics/adapters/script_resolution.py:148` | 4 | 2 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_method_receiver` | `atlas/src/atlas/metrics/adapters/script_resolution.py:154` | 9 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_first_receiver` | `atlas/src/atlas/metrics/adapters/script_resolution.py:165` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::member_mutation` | `atlas/src/atlas/metrics/adapters/script_resolution.py:172` | 10 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::member_write` | `atlas/src/atlas/metrics/adapters/script_resolution.py:184` | 4 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_plain_base` | `atlas/src/atlas/metrics/adapters/script_resolution.py:190` | 6 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_single_base` | `atlas/src/atlas/metrics/adapters/script_resolution.py:198` | 8 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::same_declaration_group` | `atlas/src/atlas/metrics/adapters/script_resolution.py:208` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::executable_implementation` | `atlas/src/atlas/metrics/adapters/script_resolution.py:212` | 8 | 3 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_signature_implementation` | `atlas/src/atlas/metrics/adapters/script_resolution.py:222` | 6 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_signatures_precede` | `atlas/src/atlas/metrics/adapters/script_resolution.py:230` | 3 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/typescript.py::parameter_count` | `atlas/src/atlas/metrics/adapters/typescript.py:12` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/adapters/typescript.py::TypeScriptResolution.select` | `atlas/src/atlas/metrics/adapters/typescript.py:20` | 7 | 3 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/artifact.py::GraphArtifact.validate_references` | `atlas/src/atlas/metrics/artifact.py:45` | 32 | 0 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/artifact.py::_validate_dependency_metrics` | `atlas/src/atlas/metrics/artifact.py:79` | 8 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/artifact.py::_validate_instability` | `atlas/src/atlas/metrics/artifact.py:89` | 5 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::_validate_edge_endpoints` | `atlas/src/atlas/metrics/artifact.py:96` | 7 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/artifact.py::_module_key` | `atlas/src/atlas/metrics/artifact.py:105` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/artifact.py::_symbol_level` | `atlas/src/atlas/metrics/artifact.py:109` | 8 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::_directory_ancestors` | `atlas/src/atlas/metrics/artifact.py:119` | 7 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::_module_paths` | `atlas/src/atlas/metrics/artifact.py:128` | 5 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::_module_paths.<anonymous>` | `atlas/src/atlas/metrics/artifact.py:132` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/artifact.py::_containment_edge` | `atlas/src/atlas/metrics/artifact.py:149` | 12 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/artifact.py::_ancestor_keys` | `atlas/src/atlas/metrics/artifact.py:163` | 10 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/artifact.py::_add_hierarchy` | `atlas/src/atlas/metrics/artifact.py:175` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::_enrich_edges` | `atlas/src/atlas/metrics/artifact.py:183` | 13 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::_projected_key` | `atlas/src/atlas/metrics/artifact.py:198` | 10 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/artifact.py::_projected_relationships` | `atlas/src/atlas/metrics/artifact.py:210` | 15 | 3 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/artifact.py::_relationship_counts` | `atlas/src/atlas/metrics/artifact.py:227` | 2 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::_view_edges` | `atlas/src/atlas/metrics/artifact.py:231` | 17 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::_level_view` | `atlas/src/atlas/metrics/artifact.py:250` | 10 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::build_dependency_views` | `atlas/src/atlas/metrics/artifact.py:262` | 9 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::_add_view_metrics` | `atlas/src/atlas/metrics/artifact.py:273` | 5 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::_add_dependency_metrics` | `atlas/src/atlas/metrics/artifact.py:280` | 6 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::_add_directory_nodes` | `atlas/src/atlas/metrics/artifact.py:288` | 23 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/artifact.py::_add_file_nodes` | `atlas/src/atlas/metrics/artifact.py:313` | 36 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/artifact.py::_add_symbol_nodes` | `atlas/src/atlas/metrics/artifact.py:351` | 49 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/artifact.py::_add_external_nodes` | `atlas/src/atlas/metrics/artifact.py:402` | 16 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::build_artifact` | `atlas/src/atlas/metrics/artifact.py:420` | 87 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/artifact.py::validate_artifact` | `atlas/src/atlas/metrics/artifact.py:509` | 18 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/callables.py::callable_metrics` | `atlas/src/atlas/metrics/callables.py:10` | 21 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/callables.py::add_callable_metrics` | `atlas/src/atlas/metrics/callables.py:33` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/check.py::_finding` | `atlas/src/atlas/metrics/check.py:30` | 11 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/check.py::_metric_finding` | `atlas/src/atlas/metrics/check.py:43` | 5 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/check.py::_enabled_limits` | `atlas/src/atlas/metrics/check.py:50` | 8 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/check.py::_isolated` | `atlas/src/atlas/metrics/check.py:60` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/check.py::_node_findings` | `atlas/src/atlas/metrics/check.py:64` | 10 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/check.py::_cycle_files` | `atlas/src/atlas/metrics/check.py:76` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/check.py::_cycle_finding` | `atlas/src/atlas/metrics/check.py:83` | 13 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/check.py::build_check` | `atlas/src/atlas/metrics/check.py:98` | 10 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/check.py::_finding_section` | `atlas/src/atlas/metrics/check.py:110` | 7 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/check.py::render_check` | `atlas/src/atlas/metrics/check.py:119` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/complexity.py::_decision_metrics` | `atlas/src/atlas/metrics/complexity.py:22` | 14 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/complexity.py::_child_frames` | `atlas/src/atlas/metrics/complexity.py:38` | 5 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/complexity.py::calculate_complexity` | `atlas/src/atlas/metrics/complexity.py:45` | 27 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/config.py::load_config` | `atlas/src/atlas/metrics/config.py:22` | 11 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/cycles.py::_owner_boundary` | `atlas/src/atlas/metrics/cycles.py:31` | 10 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/cycles.py::_find_file_owner` | `atlas/src/atlas/metrics/cycles.py:43` | 14 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/cycles.py::_file_owners` | `atlas/src/atlas/metrics/cycles.py:59` | 8 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/cycles.py::_import_edges` | `atlas/src/atlas/metrics/cycles.py:69` | 10 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/cycles.py::_import_edges.<anonymous>` | `atlas/src/atlas/metrics/cycles.py:78` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/cycles.py::_import_metadata` | `atlas/src/atlas/metrics/cycles.py:81` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/cycles.py::_project_import` | `atlas/src/atlas/metrics/cycles.py:89` | 18 | 2 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/cycles.py::_reverse_group` | `atlas/src/atlas/metrics/cycles.py:109` | 10 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/cycles.py::_enqueue_unvisited` | `atlas/src/atlas/metrics/cycles.py:121` | 7 | 3 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/cycles.py::_finish_from` | `atlas/src/atlas/metrics/cycles.py:130` | 15 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/cycles.py::_add_reverse_edges` | `atlas/src/atlas/metrics/cycles.py:147` | 5 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/cycles.py::_reverse_adjacency` | `atlas/src/atlas/metrics/cycles.py:154` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/cycles.py::_finish_order` | `atlas/src/atlas/metrics/cycles.py:161` | 9 | 1 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/cycles.py::strongly_connected_components` | `atlas/src/atlas/metrics/cycles.py:172` | 16 | 1 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/cycles.py::_components` | `atlas/src/atlas/metrics/cycles.py:190` | 6 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/cycles.py::_path_to_start` | `atlas/src/atlas/metrics/cycles.py:198` | 7 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/cycles.py::_CycleSearch.visit_neighbors` | `atlas/src/atlas/metrics/cycles.py:215` | 9 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/cycles.py::_example_cycle` | `atlas/src/atlas/metrics/cycles.py:226` | 14 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/cycles.py::_cycle_group` | `atlas/src/atlas/metrics/cycles.py:242` | 8 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/cycles.py::_register_members` | `atlas/src/atlas/metrics/cycles.py:252` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/cycles.py::circular_dependencies` | `atlas/src/atlas/metrics/cycles.py:257` | 48 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/dependency_metrics.py::_adjacency` | `atlas/src/atlas/metrics/dependency_metrics.py:12` | 7 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/dependency_metrics.py::_component_targets` | `atlas/src/atlas/metrics/dependency_metrics.py:21` | 13 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/dependency_metrics.py::_propagate` | `atlas/src/atlas/metrics/dependency_metrics.py:36` | 3 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/dependency_metrics.py::_change_impact` | `atlas/src/atlas/metrics/dependency_metrics.py:41` | 14 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/dependency_metrics.py::dependency_metrics` | `atlas/src/atlas/metrics/dependency_metrics.py:57` | 24 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes.__init__` | `atlas/src/atlas/metrics/receiver_resolution.py:13` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes.bindings` | `atlas/src/atlas/metrics/receiver_resolution.py:17` | 3 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes.resolve` | `atlas/src/atlas/metrics/receiver_resolution.py:21` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._receiver_types` | `atlas/src/atlas/metrics/receiver_resolution.py:25` | 12 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._implicit_types` | `atlas/src/atlas/metrics/receiver_resolution.py:38` | 8 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._lexical_types` | `atlas/src/atlas/metrics/receiver_resolution.py:47` | 11 | 3 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._binding_types` | `atlas/src/atlas/metrics/receiver_resolution.py:59` | 9 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._nearest` | `atlas/src/atlas/metrics/receiver_resolution.py:69` | 5 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._member_receiver` | `atlas/src/atlas/metrics/receiver_resolution.py:75` | 3 | 2 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._candidates` | `atlas/src/atlas/metrics/receiver_resolution.py:79` | 3 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._visible` | `atlas/src/atlas/metrics/receiver_resolution.py:83` | 7 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._unsafe` | `atlas/src/atlas/metrics/receiver_resolution.py:91` | 6 | 3 | 8 | 8 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._conditional` | `atlas/src/atlas/metrics/receiver_resolution.py:98` | 10 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._declared_types` | `atlas/src/atlas/metrics/receiver_resolution.py:109` | 16 | 3 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._type_symbols` | `atlas/src/atlas/metrics/receiver_resolution.py:126` | 5 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._conflicting_types` | `atlas/src/atlas/metrics/receiver_resolution.py:132` | 2 | 2 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._initializer_types` | `atlas/src/atlas/metrics/receiver_resolution.py:135` | 4 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._value_types` | `atlas/src/atlas/metrics/receiver_resolution.py:140` | 14 | 3 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._qualified_type` | `atlas/src/atlas/metrics/receiver_resolution.py:155` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._field_types` | `atlas/src/atlas/metrics/receiver_resolution.py:160` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._fields` | `atlas/src/atlas/metrics/receiver_resolution.py:165` | 15 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._field_bindings` | `atlas/src/atlas/metrics/receiver_resolution.py:181` | 3 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._static` | `atlas/src/atlas/metrics/receiver_resolution.py:185` | 3 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._shadowed` | `atlas/src/atlas/metrics/receiver_resolution.py:189` | 6 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._reassigned` | `atlas/src/atlas/metrics/receiver_resolution.py:196` | 9 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._field_initialization` | `atlas/src/atlas/metrics/receiver_resolution.py:206` | 9 | 3 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._constructor_initialization` | `atlas/src/atlas/metrics/receiver_resolution.py:216` | 7 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._path_written` | `atlas/src/atlas/metrics/receiver_resolution.py:224` | 10 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._call_scope` | `atlas/src/atlas/metrics/receiver_resolution.py:235` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._targets_written` | `atlas/src/atlas/metrics/receiver_resolution.py:241` | 3 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._expand_paths` | `atlas/src/atlas/metrics/receiver_resolution.py:245` | 8 | 3 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._expand_aliases` | `atlas/src/atlas/metrics/receiver_resolution.py:254` | 6 | 3 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._node_aliases` | `atlas/src/atlas/metrics/receiver_resolution.py:261` | 6 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._alias_paths` | `atlas/src/atlas/metrics/receiver_resolution.py:268` | 3 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._identity_overwritten` | `atlas/src/atlas/metrics/receiver_resolution.py:272` | 5 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._identity_write` | `atlas/src/atlas/metrics/receiver_resolution.py:278` | 9 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._write_identities` | `atlas/src/atlas/metrics/receiver_resolution.py:288` | 5 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._single_expression` | `atlas/src/atlas/metrics/receiver_resolution.py:294` | 4 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._write_names` | `atlas/src/atlas/metrics/receiver_resolution.py:299` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/receiver_syntax.py::type_name` | `atlas/src/atlas/metrics/receiver_syntax.py:22` | 9 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_wrapped_type_name` | `atlas/src/atlas/metrics/receiver_syntax.py:33` | 3 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::child` | `atlas/src/atlas/metrics/receiver_syntax.py:38` | 2 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::enclosing` | `atlas/src/atlas/metrics/receiver_syntax.py:42` | 5 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::declaration` | `atlas/src/atlas/metrics/receiver_syntax.py:60` | 9 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_inferred_annotation` | `atlas/src/atlas/metrics/receiver_syntax.py:71` | 8 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_constructed_annotation` | `atlas/src/atlas/metrics/receiver_syntax.py:81` | 6 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/receiver_syntax.py::member_assignment` | `atlas/src/atlas/metrics/receiver_syntax.py:89` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/receiver_syntax.py::static_field` | `atlas/src/atlas/metrics/receiver_syntax.py:94` | 4 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::constructor` | `atlas/src/atlas/metrics/receiver_syntax.py:100` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/receiver_syntax.py::injected_parameter` | `atlas/src/atlas/metrics/receiver_syntax.py:105` | 11 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_parameter_written` | `atlas/src/atlas/metrics/receiver_syntax.py:118` | 4 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_parameter_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:124` | 3 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::java_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:129` | 7 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::kotlin_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:138` | 10 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_kotlin_member` | `atlas/src/atlas/metrics/receiver_syntax.py:150` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_kotlin_property` | `atlas/src/atlas/metrics/receiver_syntax.py:154` | 6 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/receiver_syntax.py::python_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:162` | 16 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::script_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:180` | 10 | 2 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/receiver_syntax.py::go_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:192` | 8 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_go_short_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:202` | 9 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/receiver_syntax.py::rust_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:213` | 8 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report.py::_node_order` | `atlas/src/atlas/metrics/report.py:26` | 2 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/report.py::_dependency_values` | `atlas/src/atlas/metrics/report.py:30` | 7 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report.py::_file_owner` | `atlas/src/atlas/metrics/report.py:39` | 8 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/report.py::_file_summaries` | `atlas/src/atlas/metrics/report.py:49` | 19 | 1 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/report.py::_measurement` | `atlas/src/atlas/metrics/report.py:70` | 20 | 3 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/report.py::_cycle_measurements` | `atlas/src/atlas/metrics/report.py:92` | 15 | 2 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report.py::build_artifact_report` | `atlas/src/atlas/metrics/report.py:109` | 23 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report.py::_record_node` | `atlas/src/atlas/metrics/report.py:134` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report.py::build_report` | `atlas/src/atlas/metrics/report.py:140` | 7 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report_markdown.py::code` | `atlas/src/atlas/metrics/report_markdown.py:16` | 8 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report_markdown.py::location` | `atlas/src/atlas/metrics/report_markdown.py:26` | 3 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report_markdown.py::value_text` | `atlas/src/atlas/metrics/report_markdown.py:31` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report_markdown.py::_table_row` | `atlas/src/atlas/metrics/report_markdown.py:37` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report_markdown.py::_table` | `atlas/src/atlas/metrics/report_markdown.py:42` | 5 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report_markdown.py::_cycle_section` | `atlas/src/atlas/metrics/report_markdown.py:49` | 7 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report_markdown.py::_cycles` | `atlas/src/atlas/metrics/report_markdown.py:58` | 5 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report_markdown.py::_size_tables` | `atlas/src/atlas/metrics/report_markdown.py:65` | 12 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report_markdown.py::_dependencies` | `atlas/src/atlas/metrics/report_markdown.py:79` | 9 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/report_markdown.py::render_markdown` | `atlas/src/atlas/metrics/report_markdown.py:90` | 13 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolution_syntax.py::names` | `atlas/src/atlas/metrics/resolution_syntax.py:33` | 11 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolution_syntax.py::_structured_names` | `atlas/src/atlas/metrics/resolution_syntax.py:46` | 8 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolution_syntax.py::_child_names` | `atlas/src/atlas/metrics/resolution_syntax.py:56` | 24 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolution_syntax.py::_same_import` | `atlas/src/atlas/metrics/resolution_syntax.py:86` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolution_syntax.py::_class_or_function` | `atlas/src/atlas/metrics/resolution_syntax.py:90` | 8 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolution_syntax.py::_binding_entries` | `atlas/src/atlas/metrics/resolution_syntax.py:100` | 2 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.__init__` | `atlas/src/atlas/metrics/resolution_syntax.py:107` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.root` | `atlas/src/atlas/metrics/resolution_syntax.py:114` | 11 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.nodes` | `atlas/src/atlas/metrics/resolution_syntax.py:127` | 2 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.spans` | `atlas/src/atlas/metrics/resolution_syntax.py:131` | 2 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.imports` | `atlas/src/atlas/metrics/resolution_syntax.py:135` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.bindings` | `atlas/src/atlas/metrics/resolution_syntax.py:139` | 5 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.node` | `atlas/src/atlas/metrics/resolution_syntax.py:145` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.scope` | `atlas/src/atlas/metrics/resolution_syntax.py:148` | 5 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax._bindings` | `atlas/src/atlas/metrics/resolution_syntax.py:154` | 13 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax._visible` | `atlas/src/atlas/metrics/resolution_syntax.py:168` | 4 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax._declaration_allowed` | `atlas/src/atlas/metrics/resolution_syntax.py:173` | 7 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.shadowed` | `atlas/src/atlas/metrics/resolution_syntax.py:181` | 12 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.import_nodes_by_line` | `atlas/src/atlas/metrics/resolution_syntax.py:195` | 6 | 0 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.import_node` | `atlas/src/atlas/metrics/resolution_syntax.py:202` | 7 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.import_scope` | `atlas/src/atlas/metrics/resolution_syntax.py:210` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.class_rebound` | `atlas/src/atlas/metrics/resolution_syntax.py:214` | 12 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.member_rebound` | `atlas/src/atlas/metrics/resolution_syntax.py:227` | 7 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.static` | `atlas/src/atlas/metrics/resolution_syntax.py:235` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolver.py::_external_key` | `atlas/src/atlas/metrics/resolver.py:70` | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolver.py::_resolve_calls` | `atlas/src/atlas/metrics/resolver.py:75` | 10 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::_call_connections` | `atlas/src/atlas/metrics/resolver.py:87` | 22 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::resolve_connections` | `atlas/src/atlas/metrics/resolver.py:111` | 30 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolver.py::resolve_connections._external` | `atlas/src/atlas/metrics/resolver.py:131` | 5 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolver.py::_resolve_imports` | `atlas/src/atlas/metrics/resolver.py:143` | 9 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::_import_connections` | `atlas/src/atlas/metrics/resolver.py:154` | 26 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::_resolve_inheritances` | `atlas/src/atlas/metrics/resolver.py:182` | 25 | 3 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolver.py::_inheritance_targets` | `atlas/src/atlas/metrics/resolver.py:209` | 27 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::_language_family` | `atlas/src/atlas/metrics/resolver.py:242` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolver.py::_import_masks_local` | `atlas/src/atlas/metrics/resolver.py:246` | 9 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::_enclosing_method` | `atlas/src/atlas/metrics/resolver.py:257` | 6 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::_is_bare_target` | `atlas/src/atlas/metrics/resolver.py:265` | 4 | 2 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.__init__` | `atlas/src/atlas/metrics/resolver.py:274` | 12 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.owner` | `atlas/src/atlas/metrics/resolver.py:287` | 11 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.owner.<anonymous>` | `atlas/src/atlas/metrics/resolver.py:294` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.ancestors` | `atlas/src/atlas/metrics/resolver.py:299` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.lexical` | `atlas/src/atlas/metrics/resolver.py:306` | 11 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._scope_declarations` | `atlas/src/atlas/metrics/resolver.py:318` | 11 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.named` | `atlas/src/atlas/metrics/resolver.py:330` | 17 | 2 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._fallback_named` | `atlas/src/atlas/metrics/resolver.py:348` | 9 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.class_named` | `atlas/src/atlas/metrics/resolver.py:358` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._receiver_class` | `atlas/src/atlas/metrics/resolver.py:365` | 14 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._self_class` | `atlas/src/atlas/metrics/resolver.py:380` | 13 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.members` | `atlas/src/atlas/metrics/resolver.py:394` | 13 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._member_declarations` | `atlas/src/atlas/metrics/resolver.py:408` | 6 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._static_members` | `atlas/src/atlas/metrics/resolver.py:415` | 9 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._namespace_member` | `atlas/src/atlas/metrics/resolver.py:425` | 11 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.qualified` | `atlas/src/atlas/metrics/resolver.py:437` | 14 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._qualified_binding` | `atlas/src/atlas/metrics/resolver.py:452` | 13 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._bare` | `atlas/src/atlas/metrics/resolver.py:466` | 6 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._matches` | `atlas/src/atlas/metrics/resolver.py:473` | 22 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._typed_matches` | `atlas/src/atlas/metrics/resolver.py:496` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._receiver_matches` | `atlas/src/atlas/metrics/resolver.py:501` | 6 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.resolve` | `atlas/src/atlas/metrics/resolver.py:508` | 19 | 2 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/__init__.py::get_adapter` | `atlas/src/atlas/parsing/adapters/__init__.py:22` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/base.py::LanguageAdapter.imports` | `atlas/src/atlas/parsing/adapters/base.py:43` | 6 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/base.py::LanguageAdapter.inheritance` | `atlas/src/atlas/parsing/adapters/base.py:50` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/elixir.py::declaration` | `atlas/src/atlas/parsing/adapters/elixir.py:36` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/elixir.py::_target` | `atlas/src/atlas/parsing/adapters/elixir.py:61` | 3 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/elixir.py::_noncall` | `atlas/src/atlas/parsing/adapters/elixir.py:66` | 14 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/adapters/elixir.py::_pipeline_target` | `atlas/src/atlas/parsing/adapters/elixir.py:82` | 8 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/elixir.py::elixir_call_target` | `atlas/src/atlas/parsing/adapters/elixir.py:92` | 5 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/elixir.py::elixir_call_sites` | `atlas/src/atlas/parsing/adapters/elixir.py:99` | 8 | 1 | 6 | 7 | 1 | 0 | 3 |
| `atlas/src/atlas/parsing/adapters/go.py::_binding` | `atlas/src/atlas/parsing/adapters/go.py:31` | 12 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/go.py::_assigned_name` | `atlas/src/atlas/parsing/adapters/go.py:45` | 9 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/go.py::declaration` | `atlas/src/atlas/parsing/adapters/go.py:56` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/go.py::call_sites` | `atlas/src/atlas/parsing/adapters/go.py:62` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/java.py::declaration` | `atlas/src/atlas/parsing/adapters/java.py:39` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/java.py::call_sites` | `atlas/src/atlas/parsing/adapters/java.py:47` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/java.py::metadata` | `atlas/src/atlas/parsing/adapters/java.py:51` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/javascript.py::_component` | `atlas/src/atlas/parsing/adapters/javascript.py:52` | 9 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/javascript.py::is_jsx_site` | `atlas/src/atlas/parsing/adapters/javascript.py:63` | 7 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/javascript.py::call_sites` | `atlas/src/atlas/parsing/adapters/javascript.py:72` | 4 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/adapters/javascript.py::normalize_call` | `atlas/src/atlas/parsing/adapters/javascript.py:78` | 7 | 1 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/adapters/javascript.py::call_relationship` | `atlas/src/atlas/parsing/adapters/javascript.py:87` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/javascript.py::metadata` | `atlas/src/atlas/parsing/adapters/javascript.py:91` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/javascript.py::unparenthesized` | `atlas/src/atlas/parsing/adapters/javascript.py:95` | 8 | 1 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/adapters/javascript.py::_expressions` | `atlas/src/atlas/parsing/adapters/javascript.py:105` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/javascript.py::script_declaration` | `atlas/src/atlas/parsing/adapters/javascript.py:109` | 13 | 1 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::_base_name` | `atlas/src/atlas/parsing/adapters/kotlin.py:41` | 11 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::declaration` | `atlas/src/atlas/parsing/adapters/kotlin.py:59` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::_identifier_name` | `atlas/src/atlas/parsing/adapters/kotlin.py:67` | 3 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::_type_declaration` | `atlas/src/atlas/parsing/adapters/kotlin.py:72` | 10 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::_member` | `atlas/src/atlas/parsing/adapters/kotlin.py:84` | 13 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::normalize_call` | `atlas/src/atlas/parsing/adapters/kotlin.py:99` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::call_sites` | `atlas/src/atlas/parsing/adapters/kotlin.py:103` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::metadata` | `atlas/src/atlas/parsing/adapters/kotlin.py:107` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/python.py::declaration` | `atlas/src/atlas/parsing/adapters/python.py:32` | 14 | 1 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/adapters/python.py::call_sites` | `atlas/src/atlas/parsing/adapters/python.py:48` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/rust.py::declaration` | `atlas/src/atlas/parsing/adapters/rust.py:53` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/rust.py::metadata` | `atlas/src/atlas/parsing/adapters/rust.py:59` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/rust.py::rust_module_import` | `atlas/src/atlas/parsing/adapters/rust.py:63` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/rust.py::rust_call_target` | `atlas/src/atlas/parsing/adapters/rust.py:68` | 11 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/rust.py::rust_call_sites` | `atlas/src/atlas/parsing/adapters/rust.py:92` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/rust.py::_rust_call_sites` | `atlas/src/atlas/parsing/adapters/rust.py:96` | 8 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/adapters/rust.py::_macro_sites` | `atlas/src/atlas/parsing/adapters/rust.py:106` | 10 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/adapters/rust.py::_root` | `atlas/src/atlas/parsing/adapters/rust.py:139` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/rust.py::_qualified_macro_shadowed` | `atlas/src/atlas/parsing/adapters/rust.py:145` | 10 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/rust.py::_macro_shadowed` | `atlas/src/atlas/parsing/adapters/rust.py:157` | 10 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/rust.py::_walk_roots` | `atlas/src/atlas/parsing/adapters/rust.py:169` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/rust.py::_evaluating` | `atlas/src/atlas/parsing/adapters/rust.py:173` | 16 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/rust.py::_macro_tokens` | `atlas/src/atlas/parsing/adapters/rust.py:191` | 5 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/rust.py::macro_payloads` | `atlas/src/atlas/parsing/adapters/rust.py:198` | 21 | 3 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/adapters/rust.py::_pattern_names` | `atlas/src/atlas/parsing/adapters/rust.py:221` | 11 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/rust.py::_named_binding` | `atlas/src/atlas/parsing/adapters/rust.py:234` | 13 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/adapters/rust.py::_payload_binding` | `atlas/src/atlas/parsing/adapters/rust.py:249` | 14 | 2 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/rust.py::_payload_target` | `atlas/src/atlas/parsing/adapters/rust.py:265` | 5 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/rust.py::payload_unshadowed` | `atlas/src/atlas/parsing/adapters/rust.py:272` | 9 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/adapters/typescript.py::declaration` | `atlas/src/atlas/parsing/adapters/typescript.py:24` | 7 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/discovery.py::is_supported_language` | `atlas/src/atlas/parsing/discovery.py:32` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/discovery.py::require_supported_language` | `atlas/src/atlas/parsing/discovery.py:36` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/discovery.py::validate_repository` | `atlas/src/atlas/parsing/discovery.py:57` | 20 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/discovery.py::_is_ignored` | `atlas/src/atlas/parsing/discovery.py:79` | 10 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/discovery.py::_directory_rules` | `atlas/src/atlas/parsing/discovery.py:91` | 6 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/discovery.py::_include_directory` | `atlas/src/atlas/parsing/discovery.py:107` | 7 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/discovery.py::_directory_files` | `atlas/src/atlas/parsing/discovery.py:116` | 8 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/discovery.py::_child_rules` | `atlas/src/atlas/parsing/discovery.py:126` | 2 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/discovery.py::_visible_directories` | `atlas/src/atlas/parsing/discovery.py:130` | 2 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/discovery.py::_repository_paths` | `atlas/src/atlas/parsing/discovery.py:134` | 19 | 1 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/discovery.py::_contained_files` | `atlas/src/atlas/parsing/discovery.py:155` | 2 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/discovery.py::detect_language` | `atlas/src/atlas/parsing/discovery.py:159` | 15 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/discovery.py::discover_files` | `atlas/src/atlas/parsing/discovery.py:176` | 26 | 1 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/parser.py::_has_call_nodes` | `atlas/src/atlas/parsing/parser.py:34` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/parser.py::_parse_syntax` | `atlas/src/atlas/parsing/parser.py:42` | 9 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/parser.py::_syntax_error` | `atlas/src/atlas/parsing/parser.py:53` | 11 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/parser.py::_extract_calls` | `atlas/src/atlas/parsing/parser.py:66` | 31 | 3 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/parser.py::_add_structure` | `atlas/src/atlas/parsing/parser.py:105` | 44 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/parser.py::parse_file` | `atlas/src/atlas/parsing/parser.py:151` | 50 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/parser.py::parse_files` | `atlas/src/atlas/parsing/parser.py:203` | 20 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/structure.py::_declaration_query` | `atlas/src/atlas/parsing/structure.py:36` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/structure.py::_structure_item` | `atlas/src/atlas/parsing/structure.py:42` | 20 | 3 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/structure.py::_captured_declarations` | `atlas/src/atlas/parsing/structure.py:64` | 7 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/structure.py::_definition_capture` | `atlas/src/atlas/parsing/structure.py:73` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/structure.py::_capture_name` | `atlas/src/atlas/parsing/structure.py:77` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/structure.py::_add_captured_match` | `atlas/src/atlas/parsing/structure.py:81` | 19 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/structure.py::_native_declarations` | `atlas/src/atlas/parsing/structure.py:102` | 11 | 2 | 4 | 5 | 1 | 0 | 3 |
| `atlas/src/atlas/parsing/structure.py::_canonical_declaration` | `atlas/src/atlas/parsing/structure.py:115` | 7 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/structure.py::_carrier_metadata` | `atlas/src/atlas/parsing/structure.py:124` | 8 | 3 | 4 | 4 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/structure.py::_span_changed` | `atlas/src/atlas/parsing/structure.py:134` | 4 | 2 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/structure.py::_canonical_item` | `atlas/src/atlas/parsing/structure.py:140` | 15 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/structure.py::_declaration_key` | `atlas/src/atlas/parsing/structure.py:157` | 6 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/structure.py::_merge_item` | `atlas/src/atlas/parsing/structure.py:165` | 11 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/structure.py::extract_structure` | `atlas/src/atlas/parsing/structure.py:178` | 16 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/structure.py::_merge_declarations` | `atlas/src/atlas/parsing/structure.py:196` | 19 | 3 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/structure.py::_declared_parent` | `atlas/src/atlas/parsing/structure.py:217` | 5 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/structure.py::_structure_hierarchy` | `atlas/src/atlas/parsing/structure.py:224` | 12 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/structure.py::_structure_hierarchy.<anonymous>` | `atlas/src/atlas/parsing/structure.py:230` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/syntax.py::modifier_metadata` | `atlas/src/atlas/parsing/syntax.py:15` | 16 | 2 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/syntax.py::relationship` | `atlas/src/atlas/parsing/syntax.py:49` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::call_member` | `atlas/src/atlas/parsing/syntax.py:70` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/syntax.py::_reference_target` | `atlas/src/atlas/parsing/syntax.py:75` | 7 | 1 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::call_target` | `atlas/src/atlas/parsing/syntax.py:84` | 15 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/syntax.py::_callee_node` | `atlas/src/atlas/parsing/syntax.py:101` | 13 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::_bare_call` | `atlas/src/atlas/parsing/syntax.py:116` | 7 | 2 | 3 | 3 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/syntax.py::normalize_call` | `atlas/src/atlas/parsing/syntax.py:125` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/syntax.py::call_sites` | `atlas/src/atlas/parsing/syntax.py:129` | 6 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/syntax.py::metadata` | `atlas/src/atlas/parsing/syntax.py:137` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/syntax.py::named_carrier` | `atlas/src/atlas/parsing/syntax.py:151` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::callback_carrier` | `atlas/src/atlas/parsing/syntax.py:156` | 5 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::_expression_children` | `atlas/src/atlas/parsing/syntax.py:163` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::_callback_value` | `atlas/src/atlas/parsing/syntax.py:167` | 7 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/syntax.py::_callback_parent` | `atlas/src/atlas/parsing/syntax.py:176` | 13 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::callback_binding` | `atlas/src/atlas/parsing/syntax.py:191` | 15 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::ParsedSyntax.tree` | `atlas/src/atlas/parsing/syntax.py:215` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::supplement_imports` | `atlas/src/atlas/parsing/syntax.py:227` | 6 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::_merge_imports` | `atlas/src/atlas/parsing/syntax.py:235` | 16 | 3 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/syntax.py::_merge_imports.<anonymous>` | `atlas/src/atlas/parsing/syntax.py:250` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/parsing/syntax.py::_base_target` | `atlas/src/atlas/parsing/syntax.py:316` | 4 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::_base_components` | `atlas/src/atlas/parsing/syntax.py:322` | 6 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/syntax.py::_base_name` | `atlas/src/atlas/parsing/syntax.py:330` | 18 | 2 | 8 | 8 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/syntax.py::_clause_names` | `atlas/src/atlas/parsing/syntax.py:350` | 16 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::inheritance_names` | `atlas/src/atlas/parsing/syntax.py:375` | 16 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/parsing/syntax.py::_superclass_names` | `atlas/src/atlas/parsing/syntax.py:393` | 5 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::_has_inheritance_clause` | `atlas/src/atlas/parsing/syntax.py:400` | 2 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::_is_inheritance_clause` | `atlas/src/atlas/parsing/syntax.py:404` | 6 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/parsing/syntax.py::_header_names` | `atlas/src/atlas/parsing/syntax.py:412` | 13 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/persistence/database.py::default_database_path` | `atlas/src/atlas/persistence/database.py:18` | 6 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/database.py::create_engine` | `atlas/src/atlas/persistence/database.py:26` | 20 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/database.py::create_engine.configure` | `atlas/src/atlas/persistence/database.py:32` | 8 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/database.py::create_engine.begin` | `atlas/src/atlas/persistence/database.py:42` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/database.py::migrate_database` | `atlas/src/atlas/persistence/database.py:48` | 18 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/database.py::repository_session` | `atlas/src/atlas/persistence/database.py:69` | 10 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/database.py::main` | `atlas/src/atlas/persistence/database.py:81` | 4 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository.__init__` | `atlas/src/atlas/persistence/graph_queries.py:17` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository.graph` | `atlas/src/atlas/persistence/graph_queries.py:20` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository.report_facts` | `atlas/src/atlas/persistence/graph_queries.py:26` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository._graph_summary` | `atlas/src/atlas/persistence/graph_queries.py:32` | 22 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository._count` | `atlas/src/atlas/persistence/graph_queries.py:55` | 4 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository._report_facts` | `atlas/src/atlas/persistence/graph_queries.py:60` | 27 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/graph_records.py::_properties` | `atlas/src/atlas/persistence/graph_records.py:13` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/graph_records.py::_decorators` | `atlas/src/atlas/persistence/graph_records.py:17` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/graph_records.py::validate_collections` | `atlas/src/atlas/persistence/graph_records.py:21` | 8 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/persistence/graph_records.py::validate_parentage` | `atlas/src/atlas/persistence/graph_records.py:31` | 7 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/graph_records.py::_validate_ancestry` | `atlas/src/atlas/persistence/graph_records.py:40` | 9 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/persistence/graph_records.py::graph_metadata` | `atlas/src/atlas/persistence/graph_records.py:51` | 8 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/graph_records.py::node_records` | `atlas/src/atlas/persistence/graph_records.py:61` | 17 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/graph_records.py::file_records` | `atlas/src/atlas/persistence/graph_records.py:80` | 10 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/graph_records.py::is_symbol` | `atlas/src/atlas/persistence/graph_records.py:92` | 8 | 1 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/graph_records.py::symbol_records` | `atlas/src/atlas/persistence/graph_records.py:102` | 14 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/graph_records.py::decorator_records` | `atlas/src/atlas/persistence/graph_records.py:118` | 6 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/graph_records.py::_metric_record` | `atlas/src/atlas/persistence/graph_records.py:126` | 13 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/graph_records.py::metric_records` | `atlas/src/atlas/persistence/graph_records.py:141` | 6 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/persistence/graph_records.py::edge_records` | `atlas/src/atlas/persistence/graph_records.py:149` | 16 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/graph_records.py::diagnostic_records` | `atlas/src/atlas/persistence/graph_records.py:167` | 12 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/migrations/env.py::run_migrations_offline` | `atlas/src/atlas/persistence/migrations/env.py:12` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/migrations/env.py::migrate_connection` | `atlas/src/atlas/persistence/migrations/env.py:22` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/migrations/env.py::run_migrations_online` | `atlas/src/atlas/persistence/migrations/env.py:28` | 11 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/migrations/versions/0001_initial.py::upgrade` | `atlas/src/atlas/persistence/migrations/versions/0001_initial.py:16` | 16 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/migrations/versions/0001_initial.py::downgrade` | `atlas/src/atlas/persistence/migrations/versions/0001_initial.py:34` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py::upgrade` | `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py:16` | 46 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py::downgrade` | `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py:64` | 9 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py::upgrade` | `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py:16` | 49 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py::downgrade` | `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py:67` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py::upgrade` | `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py:12` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py::downgrade` | `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py:16` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/navigation.py::navigation_reader` | `atlas/src/atlas/persistence/navigation.py:21` | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.__init__` | `atlas/src/atlas/persistence/navigation.py:28` | 9 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader._project` | `atlas/src/atlas/persistence/navigation.py:38` | 13 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader._containing_projects` | `atlas/src/atlas/persistence/navigation.py:52` | 11 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader._rows` | `atlas/src/atlas/persistence/navigation.py:64` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.overview` | `atlas/src/atlas/persistence/navigation.py:67` | 11 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.find` | `atlas/src/atlas/persistence/navigation.py:79` | 20 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.node` | `atlas/src/atlas/persistence/navigation.py:100` | 21 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.children` | `atlas/src/atlas/persistence/navigation.py:122` | 5 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.edges` | `atlas/src/atlas/persistence/navigation.py:128` | 7 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.diagnostics` | `atlas/src/atlas/persistence/navigation.py:136` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.file` | `atlas/src/atlas/persistence/navigation.py:142` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/navigation_database.py::IndexedSQLiteCompiler.get_from_hint_text` | `atlas/src/atlas/persistence/navigation_database.py:25` | 4 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/navigation_database.py::_check_schema` | `atlas/src/atlas/persistence/navigation_database.py:31` | 8 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/navigation_database.py::readonly_session` | `atlas/src/atlas/persistence/navigation_database.py:42` | 26 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/navigation_database.py::readonly_session.configure` | `atlas/src/atlas/persistence/navigation_database.py:50` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/navigation_database.py::readonly_session.configure.<anonymous>` | `atlas/src/atlas/persistence/navigation_database.py:53` | 1 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/navigation_database.py::readonly_session.begin` | `atlas/src/atlas/persistence/navigation_database.py:57` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/navigation_queries.py::nodes` | `atlas/src/atlas/persistence/navigation_queries.py:27` | 10 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/navigation_queries.py::metrics` | `atlas/src/atlas/persistence/navigation_queries.py:39` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/navigation_queries.py::adjacency` | `atlas/src/atlas/persistence/navigation_queries.py:53` | 9 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/repositories.py::_repository_dto` | `atlas/src/atlas/persistence/repositories.py:43` | 8 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/repositories.py::repository_store` | `atlas/src/atlas/persistence/repositories.py:54` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.register` | `atlas/src/atlas/persistence/repositories.py:61` | 21 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.list` | `atlas/src/atlas/persistence/repositories.py:83` | 12 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.exists` | `atlas/src/atlas/persistence/repositories.py:96` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.resolve` | `atlas/src/atlas/persistence/repositories.py:99` | 7 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.save_new` | `atlas/src/atlas/persistence/repositories.py:107` | 12 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.save` | `atlas/src/atlas/persistence/repositories.py:120` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore._save` | `atlas/src/atlas/persistence/repositories.py:125` | 24 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore._replace_graph` | `atlas/src/atlas/persistence/repositories.py:150` | 11 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore._insert_records` | `atlas/src/atlas/persistence/repositories.py:162` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/services/factories.py::navigation_service` | `atlas/src/atlas/services/factories.py:15` | 4 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/services/factories.py::migrate_database` | `atlas/src/atlas/services/factories.py:21` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/factories.py::repository_service` | `atlas/src/atlas/services/factories.py:27` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/navigation.py::NavigationService.__init__` | `atlas/src/atlas/services/navigation.py:9` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/navigation.py::NavigationService.response` | `atlas/src/atlas/services/navigation.py:12` | 5 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/services/navigation.py::NavigationService.overview` | `atlas/src/atlas/services/navigation.py:18` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/navigation.py::NavigationService.find` | `atlas/src/atlas/services/navigation.py:22` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/navigation.py::NavigationService.show` | `atlas/src/atlas/services/navigation.py:26` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/navigation.py::NavigationService.ancestors` | `atlas/src/atlas/services/navigation.py:31` | 10 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/services/navigation.py::NavigationService.children` | `atlas/src/atlas/services/navigation.py:42` | 6 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/services/navigation.py::NavigationService.context` | `atlas/src/atlas/services/navigation.py:49` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/navigation.py::NavigationService.path` | `atlas/src/atlas/services/navigation.py:55` | 8 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/navigation.py::NavigationService.sources` | `atlas/src/atlas/services/navigation.py:64` | 5 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/services/navigation.py::NavigationService.source` | `atlas/src/atlas/services/navigation.py:70` | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/navigation_source.py::source_excerpt` | `atlas/src/atlas/services/navigation_source.py:15` | 13 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/services/navigation_source.py::verified_excerpt` | `atlas/src/atlas/services/navigation_source.py:30` | 12 | 3 | 7 | 7 | 0 | 0 | 2 |
| `atlas/src/atlas/services/navigation_source.py::source_lines` | `atlas/src/atlas/services/navigation_source.py:44` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/services/navigation_source.py::source_status` | `atlas/src/atlas/services/navigation_source.py:52` | 5 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/services/navigation_source.py::local_bytes` | `atlas/src/atlas/services/navigation_source.py:59` | 16 | 2 | 8 | 8 | 0 | 0 | 1 |
| `atlas/src/atlas/services/navigation_source.py::contained_bytes` | `atlas/src/atlas/services/navigation_source.py:77` | 18 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/services/navigation_source.py::excerpt_lines` | `atlas/src/atlas/services/navigation_source.py:97` | 10 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/src/atlas/services/navigation_walk.py::Walk.output` | `atlas/src/atlas/services/navigation_walk.py:16` | 8 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/src/atlas/services/navigation_walk.py::Traversal.__init__` | `atlas/src/atlas/services/navigation_walk.py:27` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/navigation_walk.py::Traversal.run` | `atlas/src/atlas/services/navigation_walk.py:33` | 10 | 0 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/services/navigation_walk.py::Traversal.expand` | `atlas/src/atlas/services/navigation_walk.py:44` | 12 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/src/atlas/services/navigation_walk.py::Traversal.add_edge` | `atlas/src/atlas/services/navigation_walk.py:57` | 11 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/services/navigation_walk.py::traverse` | `atlas/src/atlas/services/navigation_walk.py:70` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/navigation_walk.py::route` | `atlas/src/atlas/services/navigation_walk.py:74` | 10 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/src/atlas/services/repositories.py::_required_text` | `atlas/src/atlas/services/repositories.py:18` | 7 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/src/atlas/services/repositories.py::analyze_folder` | `atlas/src/atlas/services/repositories.py:27` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.__init__` | `atlas/src/atlas/services/repositories.py:35` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.register` | `atlas/src/atlas/services/repositories.py:38` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.list` | `atlas/src/atlas/services/repositories.py:45` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.get_architecture` | `atlas/src/atlas/services/repositories.py:48` | 5 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.get_report_facts` | `atlas/src/atlas/services/repositories.py:54` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.report` | `atlas/src/atlas/services/repositories.py:61` | 9 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.save_folder` | `atlas/src/atlas/services/repositories.py:71` | 15 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.index` | `atlas/src/atlas/services/repositories.py:87` | 8 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/syntax.py::walk` | `atlas/src/atlas/syntax.py:8` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/src/atlas/syntax.py::text` | `atlas/src/atlas/syntax.py:16` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/src/atlas/syntax.py::field` | `atlas/src/atlas/syntax.py:22` | 9 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_consolidation.py::coffee_source` | `atlas/tests/coffee_consolidation.py:16` | 3 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_consolidation.py::coffee_parsed` | `atlas/tests/coffee_consolidation.py:21` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_consolidation.py::coffee_symbols` | `atlas/tests/coffee_consolidation.py:28` | 5 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_consolidation.py::coffee_node` | `atlas/tests/coffee_consolidation.py:35` | 8 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_fixture.py::coffee_sources` | `atlas/tests/coffee_fixture.py:26` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_fixture.py::coffee_graph` | `atlas/tests/coffee_fixture.py:32` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_fixture.py::coffee_snapshot` | `atlas/tests/coffee_fixture.py:36` | 8 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_integrity.py::assert_node_ancestry` | `atlas/tests/coffee_integrity.py:14` | 11 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_integrity.py::assert_view_edge` | `atlas/tests/coffee_integrity.py:27` | 5 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_integrity.py::assert_view` | `atlas/tests/coffee_integrity.py:34` | 4 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_integrity.py::assert_cycle_edge` | `atlas/tests/coffee_integrity.py:40` | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_integrity.py::assert_cycle_group` | `atlas/tests/coffee_integrity.py:46` | 8 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_integrity.py::assert_level_stats` | `atlas/tests/coffee_integrity.py:56` | 6 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_integrity.py::level_node_keys` | `atlas/tests/coffee_integrity.py:64` | 2 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_integrity.py::assert_coffee_integrity` | `atlas/tests/coffee_integrity.py:68` | 16 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::Declaration.matches` | `atlas/tests/coffee_navigation.py:47` | 4 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/coffee_navigation.py::command` | `atlas/tests/coffee_navigation.py:53` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_navigation.py::declaration` | `atlas/tests/coffee_navigation.py:60` | 6 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::file_node` | `atlas/tests/coffee_navigation.py:68` | 6 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::navigation_responses` | `atlas/tests/coffee_navigation.py:76` | 8 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.query` | `atlas/tests/coffee_navigation.py:94` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.collect` | `atlas/tests/coffee_navigation.py:99` | 15 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.find_core` | `atlas/tests/coffee_navigation.py:115` | 5 | 0 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.select_core` | `atlas/tests/coffee_navigation.py:121` | 12 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.show_render` | `atlas/tests/coffee_navigation.py:134` | 9 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.calls` | `atlas/tests/coffee_navigation.py:144` | 16 | 0 | 8 | 8 | 0 | 0 | 2 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.assert_go_render_boundary` | `atlas/tests/coffee_navigation.py:161` | 12 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.source` | `atlas/tests/coffee_navigation.py:174` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.imports` | `atlas/tests/coffee_navigation.py:179` | 9 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.assert_imports` | `atlas/tests/coffee_navigation.py:189` | 11 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.inheritance` | `atlas/tests/coffee_navigation.py:201` | 15 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.absent_inheritance` | `atlas/tests/coffee_navigation.py:217` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.assert_inheritance` | `atlas/tests/coffee_navigation.py:222` | 13 | 3 | 8 | 8 | 0 | 0 | 2 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.callback` | `atlas/tests/coffee_navigation.py:236` | 34 | 0 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.recursion` | `atlas/tests/coffee_navigation.py:271` | 8 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.unicode_search` | `atlas/tests/coffee_navigation.py:280` | 26 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.retry_clauses` | `atlas/tests/coffee_navigation.py:307` | 10 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::edges_targeting` | `atlas/tests/coffee_navigation.py:319` | 2 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::assert_unresolved_node` | `atlas/tests/coffee_navigation.py:323` | 3 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::assert_no_path` | `atlas/tests/coffee_navigation.py:328` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_navigation.py::expected_import_paths` | `atlas/tests/coffee_navigation.py:332` | 6 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::assert_file_import_cycle` | `atlas/tests/coffee_navigation.py:340` | 7 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::internal_import_targets` | `atlas/tests/coffee_navigation.py:349` | 4 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::assert_recursion` | `atlas/tests/coffee_navigation.py:355` | 9 | 3 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::assert_verified_source` | `atlas/tests/coffee_navigation.py:366` | 9 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::assert_same_metadata` | `atlas/tests/coffee_navigation.py:377` | 3 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::normalize_responses` | `atlas/tests/coffee_navigation.py:382` | 8 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_navigation.py::normalize_root` | `atlas/tests/coffee_navigation.py:392` | 8 | 3 | 8 | 8 | 0 | 0 | 2 |
| `atlas/tests/coffee_pipeline.py::project_analysis` | `atlas/tests/coffee_pipeline.py:31` | 16 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_pipeline.py::shared_grammar_variants` | `atlas/tests/coffee_pipeline.py:49` | 5 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_pipeline.py::grammar_variant` | `atlas/tests/coffee_pipeline.py:56` | 12 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_pipeline.py::grammar_resolution` | `atlas/tests/coffee_pipeline.py:70` | 5 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/coffee_pipeline.py::source_structures` | `atlas/tests/coffee_pipeline.py:77` | 13 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_pipeline.py::project_cli` | `atlas/tests/coffee_pipeline.py:92` | 14 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/coffee_pipeline.py::coffee_pipeline` | `atlas/tests/coffee_pipeline.py:109` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_pipeline.py::write_pipeline` | `atlas/tests/coffee_pipeline.py:113` | 8 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_scenarios.py::core_calls` | `atlas/tests/coffee_scenarios.py:34` | 15 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_scenarios.py::core_calls.role` | `atlas/tests/coffee_scenarios.py:38` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::named_node` | `atlas/tests/coffee_semantic_assertions.py:9` | 2 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_oo_contract` | `atlas/tests/coffee_semantic_assertions.py:13` | 13 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_brewer_construction` | `atlas/tests/coffee_semantic_assertions.py:28` | 14 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_go_closure` | `atlas/tests/coffee_semantic_assertions.py:44` | 23 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_elixir_recursion` | `atlas/tests/coffee_semantic_assertions.py:69` | 14 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::calls_from_owner` | `atlas/tests/coffee_semantic_assertions.py:85` | 2 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_recursive_dispatch` | `atlas/tests/coffee_semantic_assertions.py:89` | 5 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_elixir_inner_metrics` | `atlas/tests/coffee_semantic_assertions.py:96` | 12 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::workflow_cases` | `atlas/tests/coffee_semantic_assertions.py:110` | 17 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::workflow_owner` | `atlas/tests/coffee_semantic_assertions.py:129` | 5 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::matches_workflow` | `atlas/tests/coffee_semantic_assertions.py:143` | 9 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_workflow_case` | `atlas/tests/coffee_semantic_assertions.py:154` | 9 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_workflow` | `atlas/tests/coffee_semantic_assertions.py:165` | 11 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_java_workflow_references` | `atlas/tests/coffee_semantic_assertions.py:178` | 12 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::module_imports` | `atlas/tests/coffee_semantic_assertions.py:192` | 2 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::external_calls_named` | `atlas/tests/coffee_semantic_assertions.py:196` | 3 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::source_edges` | `atlas/tests/coffee_semantic_assertions.py:201` | 2 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_go_module_limitations` | `atlas/tests/coffee_semantic_assertions.py:205` | 32 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_elixir_grouped_alias_limitation` | `atlas/tests/coffee_semantic_assertions.py:239` | 10 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/coffee_semantic_assertions.py::assert_library_output` | `atlas/tests/coffee_semantic_assertions.py:251` | 8 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::nodes_by_key` | `atlas/tests/coffee_snapshot_assertions.py:23` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::call_edges` | `atlas/tests/coffee_snapshot_assertions.py:27` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_snapshot` | `atlas/tests/coffee_snapshot_assertions.py:31` | 19 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_layout` | `atlas/tests/coffee_snapshot_assertions.py:52` | 7 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_file_hashes` | `atlas/tests/coffee_snapshot_assertions.py:61` | 7 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_coordinates` | `atlas/tests/coffee_snapshot_assertions.py:70` | 8 | 3 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_recursion_scenarios` | `atlas/tests/coffee_snapshot_assertions.py:80` | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_callback_owners` | `atlas/tests/coffee_snapshot_assertions.py:86` | 20 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::required_core_calls` | `atlas/tests/coffee_snapshot_assertions.py:108` | 13 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_call_sites` | `atlas/tests/coffee_snapshot_assertions.py:123` | 5 | 3 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_source_evidence` | `atlas/tests/coffee_snapshot_assertions.py:130` | 7 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_render_paths` | `atlas/tests/coffee_snapshot_assertions.py:139` | 9 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::calls_named` | `atlas/tests/coffee_snapshot_assertions.py:150` | 2 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_empty_and_nonempty_render` | `atlas/tests/coffee_snapshot_assertions.py:154` | 4 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_preview_render` | `atlas/tests/coffee_snapshot_assertions.py:160` | 9 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_score` | `atlas/tests/coffee_snapshot_assertions.py:171` | 7 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_project_calls` | `atlas/tests/coffee_snapshot_assertions.py:180` | 40 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_snapshot_assertions.py::is_external_project_call` | `atlas/tests/coffee_snapshot_assertions.py:222` | 10 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/coffee_tsx_assertions.py::reference_edges` | `atlas/tests/coffee_tsx_assertions.py:6` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/coffee_tsx_assertions.py::owned_references` | `atlas/tests/coffee_tsx_assertions.py:10` | 6 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/coffee_tsx_assertions.py::assert_component_references` | `atlas/tests/coffee_tsx_assertions.py:18` | 22 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/coffee_tsx_assertions.py::assert_normal_calls` | `atlas/tests/coffee_tsx_assertions.py:42` | 10 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/coffee_tsx_assertions.py::assert_file_call_coordinates` | `atlas/tests/coffee_tsx_assertions.py:54` | 8 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/coffee_tsx_assertions.py::assert_intrinsics_and_shadowing` | `atlas/tests/coffee_tsx_assertions.py:64` | 8 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::boundary_sensitive` | `atlas/tests/database_boundary_policy.py:68` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_policy.py::node_dynamic_violations` | `atlas/tests/database_boundary_policy.py:73` | 8 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::syntax_dynamic_violations` | `atlas/tests/database_boundary_policy.py:83` | 6 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::private_reflection_path` | `atlas/tests/database_boundary_policy.py:91` | 4 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::reflective_port_extraction` | `atlas/tests/database_boundary_policy.py:97` | 7 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::dynamic_import_violations` | `atlas/tests/database_boundary_policy.py:106` | 4 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::forbidden_prefixes` | `atlas/tests/database_boundary_policy.py:112` | 7 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::layer_prefixes` | `atlas/tests/database_boundary_policy.py:121` | 6 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::matches_forbidden_prefix` | `atlas/tests/database_boundary_policy.py:129` | 2 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::forbidden_imports` | `atlas/tests/database_boundary_policy.py:133` | 5 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::factory_targets_forbidden` | `atlas/tests/database_boundary_policy.py:140` | 6 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::unapproved_targets` | `atlas/tests/database_boundary_policy.py:148` | 2 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::bootstrap_violations` | `atlas/tests/database_boundary_policy.py:152` | 3 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::bootstrap_statement_allowed` | `atlas/tests/database_boundary_policy.py:157` | 8 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::bootstrap_assignment_allowed` | `atlas/tests/database_boundary_policy.py:167` | 2 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::bootstrap_export_allowed` | `atlas/tests/database_boundary_policy.py:171` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_policy.py::bootstrap_all_allowed` | `atlas/tests/database_boundary_policy.py:175` | 2 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::factory_import_violations` | `atlas/tests/database_boundary_policy.py:179` | 2 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::factory_node_import_violations` | `atlas/tests/database_boundary_policy.py:183` | 9 | 2 | 8 | 8 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::private_import_alias` | `atlas/tests/database_boundary_policy.py:194` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_policy.py::in_memory_repository_attributes` | `atlas/tests/database_boundary_policy.py:198` | 7 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::in_memory_function_attributes` | `atlas/tests/database_boundary_policy.py:207` | 6 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::in_memory_assignment` | `atlas/tests/database_boundary_policy.py:215` | 2 | 3 | 4 | 4 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_policy.py::raw_sql_violations` | `atlas/tests/database_boundary_policy.py:219` | 6 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::raw_expression` | `atlas/tests/database_boundary_policy.py:227` | 3 | 2 | 7 | 7 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_policy.py::raw_literal_violations` | `atlas/tests/database_boundary_policy.py:232` | 8 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::raw_string_execution` | `atlas/tests/database_boundary_policy.py:242` | 2 | 2 | 4 | 4 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_policy.py::string_expression` | `atlas/tests/database_boundary_policy.py:246` | 2 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_policy.py::setup_statement` | `atlas/tests/database_boundary_policy.py:250` | 4 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::infrastructure_sql_violations` | `atlas/tests/database_boundary_policy.py:256` | 15 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::literal_setup` | `atlas/tests/database_boundary_policy.py:273` | 2 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_policy.py::infrastructure_domain_violations` | `atlas/tests/database_boundary_policy.py:277` | 8 | 2 | 8 | 8 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::infrastructure_execution_violations` | `atlas/tests/database_boundary_policy.py:287` | 4 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::migration_schema_text` | `atlas/tests/database_boundary_policy.py:293` | 5 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::migration_index_text` | `atlas/tests/database_boundary_policy.py:300` | 10 | 2 | 6 | 7 | 1 | 0 | 3 |
| `atlas/tests/database_boundary_policy.py::migration_sql_violations` | `atlas/tests/database_boundary_policy.py:312` | 8 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::factory_escape_violations` | `atlas/tests/database_boundary_policy.py:322` | 6 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::context_port_aliases` | `atlas/tests/database_boundary_policy.py:330` | 4 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::return_port_violations` | `atlas/tests/database_boundary_policy.py:336` | 4 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::database_behavior_violations` | `atlas/tests/database_boundary_policy.py:342` | 9 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::database_operation` | `atlas/tests/database_boundary_policy.py:353` | 3 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::service_port_violations` | `atlas/tests/database_boundary_policy.py:358` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::service_node_port_violations` | `atlas/tests/database_boundary_policy.py:363` | 10 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::port_aliases` | `atlas/tests/database_boundary_policy.py:375` | 7 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::annotation_expression` | `atlas/tests/database_boundary_policy.py:384` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::port_annotation` | `atlas/tests/database_boundary_policy.py:388` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::port_assignment_aliases` | `atlas/tests/database_boundary_policy.py:393` | 6 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::port_argument_violations` | `atlas/tests/database_boundary_policy.py:401` | 6 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::port_escape_violations` | `atlas/tests/database_boundary_policy.py:409` | 7 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::service_constructor_violations` | `atlas/tests/database_boundary_policy.py:418` | 13 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::parameter_assignment_aliases` | `atlas/tests/database_boundary_policy.py:433` | 4 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::constructor_protocol_matches` | `atlas/tests/database_boundary_policy.py:439` | 2 | 3 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_policy.py::port_access_violations` | `atlas/tests/database_boundary_policy.py:453` | 12 | 2 | 8 | 8 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::port_attribute_allowed` | `atlas/tests/database_boundary_policy.py:467` | 4 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::boundary_violations` | `atlas/tests/database_boundary_policy.py:473` | 17 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::docstring_ids` | `atlas/tests/database_boundary_policy.py:492` | 3 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::has_docstring` | `atlas/tests/database_boundary_policy.py:497` | 2 | 1 | 4 | 4 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_policy.py::boundary_node_violations` | `atlas/tests/database_boundary_policy.py:501` | 7 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_policy.py::boundary_sql_violations` | `atlas/tests/database_boundary_policy.py:510` | 8 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_policy.py::guarded_dynamic_violations` | `atlas/tests/database_boundary_policy.py:520` | 5 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_syntax.py::belongs_to` | `atlas/tests/database_boundary_syntax.py:9` | 2 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_syntax.py::resolved_import_module` | `atlas/tests/database_boundary_syntax.py:13` | 3 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_syntax.py::node_import_targets` | `atlas/tests/database_boundary_syntax.py:18` | 7 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_syntax.py::node_import_aliases` | `atlas/tests/database_boundary_syntax.py:27` | 7 | 2 | 8 | 8 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_syntax.py::qualified_name` | `atlas/tests/database_boundary_syntax.py:36` | 10 | 2 | 8 | 8 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_syntax.py::assignment_pairs` | `atlas/tests/database_boundary_syntax.py:48` | 6 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_syntax.py::import_aliases` | `atlas/tests/database_boundary_syntax.py:56` | 9 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_syntax.py::import_assignment_aliases` | `atlas/tests/database_boundary_syntax.py:67` | 5 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_syntax.py::apply_alias_pairs` | `atlas/tests/database_boundary_syntax.py:74` | 3 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_syntax.py::propagate_aliases` | `atlas/tests/database_boundary_syntax.py:79` | 7 | 3 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_syntax.py::import_targets` | `atlas/tests/database_boundary_syntax.py:88` | 12 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/tests/database_boundary_syntax.py::main_config_reflection_ids` | `atlas/tests/database_boundary_syntax.py:107` | 8 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_syntax.py::exact_lookup_definitions` | `atlas/tests/database_boundary_syntax.py:117` | 3 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_syntax.py::public_config_aliases` | `atlas/tests/database_boundary_syntax.py:122` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/database_boundary_syntax.py::check_lookup_definition` | `atlas/tests/database_boundary_syntax.py:126` | 4 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/database_boundary_syntax.py::check_lookup_getattr` | `atlas/tests/database_boundary_syntax.py:132` | 2 | 1 | 5 | 5 | 0 | 0 | 0 |
| `atlas/tests/graph_storage_fixture.py::_node` | `atlas/tests/graph_storage_fixture.py:24` | 7 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/graph_storage_fixture.py::graph_artifact` | `atlas/tests/graph_storage_fixture.py:33` | 28 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/graph_storage_fixture.py::migration_config` | `atlas/tests/graph_storage_fixture.py:63` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/graph_storage_fixture.py::normalized_rows` | `atlas/tests/graph_storage_fixture.py:67` | 6 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/import_project_support.py::project_sources` | `atlas/tests/import_project_support.py:15` | 8 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/tests/import_project_support.py::repository` | `atlas/tests/import_project_support.py:25` | 6 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/import_project_support.py::project_repository` | `atlas/tests/import_project_support.py:33` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/import_project_support.py::analyze` | `atlas/tests/import_project_support.py:37` | 6 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/import_project_support.py::symbols` | `atlas/tests/import_project_support.py:45` | 5 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/import_project_support.py::connections_at` | `atlas/tests/import_project_support.py:52` | 8 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/import_project_support.py::edges_at` | `atlas/tests/import_project_support.py:62` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/import_project_support.py::imports_at` | `atlas/tests/import_project_support.py:66` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/import_project_support.py::assert_call` | `atlas/tests/import_project_support.py:70` | 6 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/import_project_support.py::assert_external` | `atlas/tests/import_project_support.py:78` | 4 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/metric_test_support.py::assert_symbol_identity` | `atlas/tests/metric_test_support.py:4` | 2 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/metric_test_support.py::restore_symbol_metrics` | `atlas/tests/metric_test_support.py:8` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/metric_test_support.py::restore_file_metrics` | `atlas/tests/metric_test_support.py:13` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/metric_test_support.py::restore_repository_metrics` | `atlas/tests/metric_test_support.py:18` | 3 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/project_snapshot_support.py::parsed_value` | `atlas/tests/project_snapshot_support.py:8` | 11 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/project_snapshot_support.py::structure_value` | `atlas/tests/project_snapshot_support.py:21` | 11 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/tests/source_snapshot_fixture.py::snapshot_value` | `atlas/tests/source_snapshot_fixture.py:13` | 10 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/tests/source_snapshot_fixture.py::snapshot_collection` | `atlas/tests/source_snapshot_fixture.py:25` | 11 | 1 | 7 | 7 | 0 | 0 | 2 |
| `atlas/tests/source_snapshot_fixture.py::snapshot_collection.<anonymous>` | `atlas/tests/source_snapshot_fixture.py:33` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/source_snapshot_fixture.py::snapshot_scalar` | `atlas/tests/source_snapshot_fixture.py:38` | 10 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_boundaries.py::language_literals` | `atlas/tests/test_adapter_boundaries.py:24` | 5 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_boundaries.py::forbidden_adapter_modules` | `atlas/tests/test_adapter_boundaries.py:31` | 5 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_boundaries.py::AdapterBoundaryTest.assert_shared_engine_node` | `atlas/tests/test_adapter_boundaries.py:39` | 7 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_boundaries.py::AdapterBoundaryTest.assert_shared_engine_file` | `atlas/tests/test_adapter_boundaries.py:47` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_boundaries.py::AdapterBoundaryTest.test_shared_engines_do_not_dispatch_on_language_names` | `atlas/tests/test_adapter_boundaries.py:51` | 15 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_boundaries.py::AdapterBoundaryTest.test_nested_adapter_modules_obey_size_limits` | `atlas/tests/test_adapter_boundaries.py:67` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_complexity_cleanup.py::nodes` | `atlas/tests/test_adapter_complexity_cleanup.py:13` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_complexity_cleanup.py::node_text` | `atlas/tests/test_adapter_complexity_cleanup.py:21` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_adapter_complexity_cleanup.py::test_adapter_callable_complexity_budget` | `atlas/tests/test_adapter_complexity_cleanup.py:29` | 22 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_adapter_complexity_cleanup.py::test_python_irrefutable_patterns` | `atlas/tests/test_adapter_complexity_cleanup.py:58` | 9 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_complexity_cleanup.py::elixir_scheduling_calls` | `atlas/tests/test_adapter_complexity_cleanup.py:69` | 6 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_complexity_cleanup.py::test_elixir_default_guard_and_pipeline_arities` | `atlas/tests/test_adapter_complexity_cleanup.py:77` | 10 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_indexes.py::indexes` | `atlas/tests/test_adapter_indexes.py:17` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_indexes.py::test_unrelated_scans_do_not_construct_language_specific_indexes` | `atlas/tests/test_adapter_indexes.py:26` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_indexes.py::assert_index_file_ownership` | `atlas/tests/test_adapter_indexes.py:34` | 5 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_indexes.py::assert_distinct_index_files` | `atlas/tests/test_adapter_indexes.py:41` | 6 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_adapter_indexes.py::test_indexes_are_owned_by_each_repository` | `atlas/tests/test_adapter_indexes.py:49` | 25 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_ownership.py::test_language_module_owns_adapter_and_parameter_policy` | `atlas/tests/test_adapter_ownership.py:28` | 8 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_adapter_ownership.py::test_language_module_owns_metric_policy` | `atlas/tests/test_adapter_ownership.py:39` | 7 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_ownership.py::test_shared_adapter_helpers_do_not_import_language_modules` | `atlas/tests/test_adapter_ownership.py:51` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapter_ownership.py::_language_import` | `atlas/tests/test_adapter_ownership.py:56` | 9 | 1 | 6 | 7 | 1 | 0 | 3 |
| `atlas/tests/test_adapter_ownership.py::test_rust_module_owns_macro_evaluation` | `atlas/tests/test_adapter_ownership.py:67` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_adapters.py::AdapterContractTest.test_registry_is_overrides_not_the_language_support_list` | `atlas/tests/test_adapters.py:24` | 12 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapters.py::AdapterContractTest.test_hooks_return_common_carriers_and_call_site_contracts` | `atlas/tests/test_adapters.py:37` | 14 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapters.py::AdapterContractTest.assert_source_contract` | `atlas/tests/test_adapters.py:52` | 17 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_adapters.py::AdapterContractTest.assert_call_site_contract` | `atlas/tests/test_adapters.py:70` | 10 | 2 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/test_adapters.py::AdapterContractTest.test_kotlin_recovery_and_hierarchy_remain_shared` | `atlas/tests/test_adapters.py:81` | 7 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_adapters.py::AdapterContractTest.test_adapter_import_supplements_keep_original_evidence_and_line` | `atlas/tests/test_adapters.py:89` | 13 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapters.py::AdapterContractTest.assert_import_supplements` | `atlas/tests/test_adapters.py:103` | 9 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapters.py::AdapterContractTest.test_shared_import_merging_defers_inline_module_policy_to_adapter` | `atlas/tests/test_adapters.py:113` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_unrecognized_filenames_return_none` | `atlas/tests/test_adapters.py:124` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_discovery_propagates_language_detection_errors` | `atlas/tests/test_adapters.py:129` | 9 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_discovery_excludes_retired_languages_without_narrowing_other_grammars` | `atlas/tests/test_adapters.py:139` | 23 | 0 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_call_parser_failure_propagates` | `atlas/tests/test_adapters.py:163` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_native_processing_failure_propagates` | `atlas/tests/test_adapters.py:169` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_direct_extraction_rejects_excluded_languages_before_parsing_or_queries` | `atlas/tests/test_adapters.py:175` | 5 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.assert_unsupported_extraction` | `atlas/tests/test_adapters.py:181` | 21 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_architecture.py::control_depth` | `atlas/tests/test_architecture.py:23` | 15 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::module_dependencies` | `atlas/tests/test_architecture.py:40` | 16 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_architecture.py::module_dependencies.visit` | `atlas/tests/test_architecture.py:44` | 9 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/tests/test_architecture.py::is_type_checking_guard` | `atlas/tests/test_architecture.py:58` | 6 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/test_architecture.py::relative_import_dependencies` | `atlas/tests/test_architecture.py:66` | 4 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::import_dependency` | `atlas/tests/test_architecture.py:72` | 3 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::branch_complexity` | `atlas/tests/test_architecture.py:77` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::is_complexity_branch` | `atlas/tests/test_architecture.py:83` | 6 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/test_architecture.py::assert_function_limits` | `atlas/tests/test_architecture.py:91` | 4 | 3 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_architecture.py::assert_tree_function_limits` | `atlas/tests/test_architecture.py:97` | 4 | 3 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_architecture.py::module_name` | `atlas/tests/test_architecture.py:103` | 5 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::module_package` | `atlas/tests/test_architecture.py:110` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_package_boundaries_exist` | `atlas/tests/test_architecture.py:116` | 21 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_one_implementation_file_per_primary_language` | `atlas/tests/test_architecture.py:138` | 15 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_adapters_do_not_depend_on_shared_graph_orchestration` | `atlas/tests/test_architecture.py:154` | 15 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_phase_adapters_and_shared_models_are_independent` | `atlas/tests/test_architecture.py:170` | 9 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::ArchitectureTest.assert_package_independent` | `atlas/tests/test_architecture.py:180` | 8 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_module_size_function_size_and_relative_import_dag` | `atlas/tests/test_architecture.py:189` | 24 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_module_size_function_size_and_relative_import_dag.visit` | `atlas/tests/test_architecture.py:203` | 7 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_atlasignore.py::write_files` | `atlas/tests/test_atlasignore.py:15` | 6 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_atlasignore.py::source_paths` | `atlas/tests/test_atlasignore.py:23` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_atlasignore.py::test_atlasignore_patterns_and_negation` | `atlas/tests/test_atlasignore.py:28` | 21 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_atlasignore.py::test_atlasignore_preserves_fallback_and_git_metadata` | `atlas/tests/test_atlasignore.py:52` | 6 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_atlasignore.py::test_atlasignore_cannot_restore_gitignored_paths_or_be_undone_by_gitignore` | `atlas/tests/test_atlasignore.py:60` | 8 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_atlasignore.py::test_nested_atlasignore_is_relative_and_can_override_inherited_patterns` | `atlas/tests/test_atlasignore.py:71` | 17 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_atlasignore.py::test_negation_requires_visible_parent_directories` | `atlas/tests/test_atlasignore.py:90` | 7 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_atlasignore.py::test_repository_atlasignore_excludes_fixtures_only_when_scanning_repository` | `atlas/tests/test_atlasignore.py:99` | 10 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_atlasignore.py::test_repository_atlasignore_excludes_data_not_snapshot_test_implementation` | `atlas/tests/test_atlasignore.py:111` | 11 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_atlasignore.py::test_cli_reanalysis_removes_atlasignored_files_and_findings` | `atlas/tests/test_atlasignore.py:125` | 54 | 2 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_autogenerate.py::test_autogenerate_detects_changed_foreign_key_actions` | `atlas/tests/test_autogenerate.py:17` | 19 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_bootstrap.py::test_service_does_not_migrate_and_disposes_on_storage_error` | `atlas/tests/test_bootstrap.py:15` | 15 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_bootstrap.py::test_service_does_not_migrate_and_disposes_on_storage_error.<anonymous>` | `atlas/tests/test_bootstrap.py:20` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_bootstrap.py::test_service_does_not_migrate_and_disposes_on_storage_error.<anonymous>` | `atlas/tests/test_bootstrap.py:21` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_bootstrap.py::test_service_preserves_domain_errors` | `atlas/tests/test_bootstrap.py:32` | 8 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_bootstrap.py::test_service_factories_do_not_expose_storage_handles` | `atlas/tests/test_bootstrap.py:42` | 11 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_bootstrap.py::test_migration_translates_storage_error_and_disposes` | `atlas/tests/test_bootstrap.py:55` | 19 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_bootstrap.py::test_migration_translates_storage_error_and_disposes.<anonymous>` | `atlas/tests/test_bootstrap.py:60` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_bootstrap.py::test_migration_translates_storage_error_and_disposes.<anonymous>` | `atlas/tests/test_bootstrap.py:61` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_bootstrap.py::test_migration_translates_storage_error_and_disposes.fail_upgrade` | `atlas/tests/test_bootstrap.py:64` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_call_resolution.py::calls_at` | `atlas/tests/test_call_resolution.py:25` | 5 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_call_resolution.py::test_member_collisions_never_use_local_or_global_name_fallback` | `atlas/tests/test_call_resolution.py:34` | 11 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_call_resolution.py::assert_call_evidence` | `atlas/tests/test_call_resolution.py:47` | 2 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_call_resolution.py::test_computed_and_qualified_targets_are_not_bare` | `atlas/tests/test_call_resolution.py:51` | 11 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_call_resolution.py::test_ambiguous_bare_call_stays_external` | `atlas/tests/test_call_resolution.py:64` | 7 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_call_resolution.py::test_query_from_does_not_resolve_to_receipt_factory` | `atlas/tests/test_call_resolution.py:73` | 7 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_callable_metric_boundaries.py::test_malformed_header_and_mixed_clause_arity_are_unknown` | `atlas/tests/test_callable_metric_boundaries.py:25` | 15 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_callable_metric_boundaries.py::test_named_layout_variants_count_physical_lines` | `atlas/tests/test_callable_metric_boundaries.py:50` | 7 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_callable_metric_boundaries.py::test_python_receiver_discriminators_on_whole_tracking_source` | `atlas/tests/test_callable_metric_boundaries.py:75` | 12 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_callable_metric_boundaries.py::test_native_end_exclusive_column_zero_on_real_nested_tracking_spans` | `atlas/tests/test_callable_metric_boundaries.py:90` | 16 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_callable_metrics.py::test_tracking_workflow_parameter_counts_and_spans` | `atlas/tests/test_callable_metrics.py:38` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_callable_metrics.py::test_coffee_parameter_counts_and_physical_spans` | `atlas/tests/test_callable_metrics.py:91` | 7 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_callable_metrics.py::test_python_receivers_only_in_methods` | `atlas/tests/test_callable_metrics.py:100` | 14 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_callable_metrics.py::test_comments_separators_and_annotations_are_not_inputs` | `atlas/tests/test_callable_metrics.py:120` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_callable_metrics.py::test_elixir_clauses_keep_identity_and_counts` | `atlas/tests/test_callable_metrics.py:125` | 7 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_callable_metrics.py::test_unknown_parameter_property_is_omitted` | `atlas/tests/test_callable_metrics.py:134` | 6 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_callable_metrics.py::test_metrics_survive_snapshot_persistence` | `atlas/tests/test_callable_metrics.py:142` | 21 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::tracking_source` | `atlas/tests/test_callback_carrier_regression.py:38` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::flatten` | `atlas/tests/test_callback_carrier_regression.py:43` | 8 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::span` | `atlas/tests/test_callback_carrier_regression.py:53` | 6 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_callback_carrier_regression.py::binding_context` | `atlas/tests/test_callback_carrier_regression.py:61` | 7 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::assert_carrier` | `atlas/tests/test_callback_carrier_regression.py:70` | 10 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::assert_local_owner` | `atlas/tests/test_callback_carrier_regression.py:82` | 14 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::assert_local_calls` | `atlas/tests/test_callback_carrier_regression.py:98` | 11 | 3 | 7 | 7 | 0 | 0 | 2 |
| `atlas/tests/test_callback_carrier_regression.py::test_parenthesized_bindings_have_exact_carrier_and_local_owner` | `atlas/tests/test_callback_carrier_regression.py:114` | 5 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::binding_wrapper` | `atlas/tests/test_callback_carrier_regression.py:121` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::test_all_binding_contexts_cover_all_four_carrier_styles` | `atlas/tests/test_callback_carrier_regression.py:135` | 8 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::test_generator_ancestor_keeps_callback_and_local_call_owner` | `atlas/tests/test_callback_carrier_regression.py:146` | 14 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::test_inline_dispatch_callbacks_keep_nearest_owner` | `atlas/tests/test_callback_carrier_regression.py:164` | 15 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::assert_native_endpoint` | `atlas/tests/test_callback_carrier_regression.py:181` | 30 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::test_native_wrappers_correct_both_endpoints_without_mutation` | `atlas/tests/test_callback_carrier_regression.py:216` | 15 | 3 | 5 | 5 | 0 | 0 | 2 |
| `atlas/tests/test_callback_carrier_regression.py::test_unresolved_binding_preserves_native_name_and_metadata_once` | `atlas/tests/test_callback_carrier_regression.py:234` | 13 | 1 | 8 | 8 | 0 | 0 | 2 |
| `atlas/tests/test_callback_carrier_regression.py::receipt_callbacks` | `atlas/tests/test_callback_carrier_regression.py:249` | 6 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_callback_carrier_regression.py::test_only_parentheses_are_transparent_and_inline_names_stay_explicit` | `atlas/tests/test_callback_carrier_regression.py:259` | 16 | 2 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_check.py::disabled_config` | `atlas/tests/test_check.py:16` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check.py::report_node` | `atlas/tests/test_check.py:20` | 3 | 3 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_check.py::report` | `atlas/tests/test_check.py:25` | 3 | 3 | 5 | 5 | 0 | 0 | 0 |
| `atlas/tests/test_check.py::<anonymous>` | `atlas/tests/test_check.py:47` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check.py::test_equality_passes_and_only_exceeded_limits_are_returned` | `atlas/tests/test_check.py:48` | 10 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_check.py::test_null_disables_every_metric_check` | `atlas/tests/test_check.py:60` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check.py::test_missing_measurements_cannot_silently_pass_enabled_rules` | `atlas/tests/test_check.py:70` | 6 | 0 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_check.py::test_isolated_instability_is_not_a_violation_and_zero_is_valid` | `atlas/tests/test_check.py:78` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check.py::test_dependency_limits_apply_to_files_and_modules_not_callables` | `atlas/tests/test_check.py:84` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check.py::test_cycle_count_maximum_and_explicit_configuration` | `atlas/tests/test_check.py:89` | 8 | 0 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_check.py::test_analysis_errors_cannot_produce_a_successful_check` | `atlas/tests/test_check.py:99` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check.py::test_real_dependency_graph_has_trackable_impact_and_instability` | `atlas/tests/test_check.py:105` | 15 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_check_cli.py::invoke` | `atlas/tests/test_check_cli.py:17` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check_cli.py::configure` | `atlas/tests/test_check_cli.py:21` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check_cli.py::test_check_help_describes_model_defaults_and_check_semantics` | `atlas/tests/test_check_cli.py:25` | 10 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_check_cli.py::test_default_parameter_limit_checks_current_code_and_exit_status` | `atlas/tests/test_check_cli.py:37` | 15 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_check_cli.py::test_cycles_fail_check_but_report_stays_quantitative` | `atlas/tests/test_check_cli.py:54` | 21 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_check_cli.py::test_partial_config_merges_defaults_and_disabled_checks` | `atlas/tests/test_check_cli.py:77` | 12 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_check_cli.py::test_dependency_limits_are_read_from_project_configuration` | `atlas/tests/test_check_cli.py:91` | 14 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_check_cli.py::test_check_defaults_aliases_and_analyzed_root_config` | `atlas/tests/test_check_cli.py:108` | 9 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_check_cli.py::test_check_default_never_opens_database` | `atlas/tests/test_check_cli.py:119` | 13 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check_cli.py::test_check_default_never_opens_database.fail` | `atlas/tests/test_check_cli.py:122` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check_cli.py::test_invalid_configuration_fails_before_analysis` | `atlas/tests/test_check_cli.py:135` | 11 | 3 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_check_cli.py::test_invalid_configuration_fails_before_analysis.fail` | `atlas/tests/test_check_cli.py:138` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check_cli.py::test_report_does_not_apply_project_limits` | `atlas/tests/test_check_cli.py:148` | 11 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/test_check_cli.py::test_missing_analysis_folder_is_an_error` | `atlas/tests/test_check_cli.py:161` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check_cli.py::test_real_syntax_errors_fail_check_even_with_all_limits_disabled` | `atlas/tests/test_check_cli.py:171` | 15 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_check_config.py::test_missing_config_and_empty_object_use_defaults` | `atlas/tests/test_check_config.py:17` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check_config.py::test_partial_overrides_and_null_disabled_limits` | `atlas/tests/test_check_config.py:23` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check_config.py::test_every_rule_can_be_disabled` | `atlas/tests/test_check_config.py:30` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check_config.py::test_invalid_configuration_is_an_error_with_its_path` | `atlas/tests/test_check_config.py:40` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_check_config.py::test_root_configuration_does_not_search_parent_folders` | `atlas/tests/test_check_config.py:47` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_cli.py::CliTest.test_help_lists_commands_without_project_selector` | `atlas/tests/test_cli.py:8` | 10 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_cli.py::CliTest.test_migrate_is_not_a_cli_command` | `atlas/tests/test_cli.py:19` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.setUpClass` | `atlas/tests/test_coffee.py:28` | 6 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_every_supported_sample_has_a_python_baseline` | `atlas/tests/test_coffee.py:35` | 10 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_all_supported_complete_graph_snapshots` | `atlas/tests/test_coffee.py:46` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_real_layout_hashes_and_coordinates` | `atlas/tests/test_coffee.py:51` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_hierarchy_views_cycles_and_stats_have_no_dangling_references` | `atlas/tests/test_coffee.py:56` | 5 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_recursion_inheritance_callbacks_imports_and_file_cycles` | `atlas/tests/test_coffee.py:62` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_every_reviewed_call_site_is_grounded_in_sample_source` | `atlas/tests/test_coffee.py:67` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_empty_filter_preview_and_nonempty_render_paths` | `atlas/tests/test_coffee.py:72` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_nested_score_complexity` | `atlas/tests/test_coffee.py:77` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_project_call_resolution_and_exact_known_limitations` | `atlas/tests/test_coffee.py:82` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_repeated_indexing_is_deterministic_except_timestamp` | `atlas/tests/test_coffee.py:87` | 6 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_check_snapshots.py::test_coffee_check_matches_snapshot` | `atlas/tests/test_coffee_check_snapshots.py:13` | 11 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_coffee_go_rust_receiver_snapshots.py::test_literal_receiver_targets_snapshot` | `atlas/tests/test_coffee_go_rust_receiver_snapshots.py:50` | 9 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_navigation_snapshots.py::test_coffee_navigation_matches_snapshot` | `atlas/tests/test_coffee_navigation_snapshots.py:18` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_coffee_navigation_snapshots.py::test_inheritance_assertions_reject_incomplete_outgoing_chain` | `atlas/tests/test_coffee_navigation_snapshots.py:25` | 12 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_navigation_snapshots.py::test_normalization_rejects_inconsistent_metadata` | `atlas/tests/test_coffee_navigation_snapshots.py:40` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_coffee_navigation_snapshots.py::test_normalization_preserves_nonvolatile_content_and_order` | `atlas/tests/test_coffee_navigation_snapshots.py:47` | 17 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_coffee_pipeline.py::test_complete_project_seam_snapshot` | `atlas/tests/test_coffee_pipeline.py:20` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_coffee_pipeline.py::test_every_physical_source_reaches_every_analysis_seam` | `atlas/tests/test_coffee_pipeline.py:26` | 12 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::physical_source_paths` | `atlas/tests/test_coffee_pipeline.py:40` | 4 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::assert_extraction_bytes` | `atlas/tests/test_coffee_pipeline.py:46` | 4 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::assert_analysis_symbols` | `atlas/tests/test_coffee_pipeline.py:52` | 4 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::test_staged_pipeline_matches_production_entry_point` | `atlas/tests/test_coffee_pipeline.py:59` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_coffee_pipeline.py::test_tags_only_extraction_is_deterministic` | `atlas/tests/test_coffee_pipeline.py:64` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::test_projects_are_not_artificial_threshold_padding` | `atlas/tests/test_coffee_pipeline.py:71` | 5 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::test_project_cli_does_not_create_storage_or_modify_source` | `atlas/tests/test_coffee_pipeline.py:79` | 7 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::test_same_source_grammar_variants_are_identified_and_enriched` | `atlas/tests/test_coffee_pipeline.py:92` | 12 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::test_each_physical_project_has_analysis_seams` | `atlas/tests/test_coffee_pipeline.py:106` | 8 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::assert_standalone_group` | `atlas/tests/test_coffee_pipeline.py:116` | 5 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::assert_standalone_project_seams` | `atlas/tests/test_coffee_pipeline.py:123` | 11 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::test_java_stocked_selects_one_argument_constructor` | `atlas/tests/test_coffee_pipeline.py:136` | 9 | 0 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_pipeline.py::test_shared_order_contract_has_real_tsx_parser_and_native_metadata` | `atlas/tests/test_coffee_pipeline.py:147` | 11 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_report_snapshots.py::test_coffee_report_matches_snapshot` | `atlas/tests/test_coffee_report_snapshots.py:14` | 12 | 1 | 5 | 5 | 0 | 0 | 0 |
| `atlas/tests/test_coffee_report_snapshots.py::test_coffee_size_measurements_include_every_source_and_callable` | `atlas/tests/test_coffee_report_snapshots.py:29` | 12 | 1 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_report_snapshots.py::assert_calibration_size` | `atlas/tests/test_coffee_report_snapshots.py:43` | 12 | 3 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/test_coffee_safety_review_snapshots.py::safety_snapshot` | `atlas/tests/test_coffee_safety_review_snapshots.py:14` | 13 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_safety_review_snapshots.py::test_safety_review_snapshot` | `atlas/tests/test_coffee_safety_review_snapshots.py:30` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_coffee_safety_review_snapshots.py::test_script_safety_review_targets` | `atlas/tests/test_coffee_safety_review_snapshots.py:36` | 18 | 1 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.setUpClass` | `atlas/tests/test_coffee_semantics.py:19` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_all_oo_contracts_and_explicit_brewer_constructions` | `atlas/tests/test_coffee_semantics.py:24` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_java_method_reference_is_a_dependency_not_an_immediate_call` | `atlas/tests/test_coffee_semantics.py:29` | 10 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_go_closure_has_its_own_call_edges_and_metrics` | `atlas/tests/test_coffee_semantics.py:40` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_elixir_recursion_is_one_real_call_site_with_clause_dispatch` | `atlas/tests/test_coffee_semantics.py:43` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_python_decorators_base_abc_and_match_complexity` | `atlas/tests/test_coffee_semantics.py:46` | 20 | 0 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_python_import_styles_link_to_local_files` | `atlas/tests/test_coffee_semantics.py:67` | 33 | 0 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_python_import_styles_link_to_namespace_callables` | `atlas/tests/test_coffee_semantics.py:101` | 21 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_workflow_edges_reach_the_actual_sample_files` | `atlas/tests/test_coffee_semantics.py:123` | 5 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_library_output_dependencies_include_rust_macros` | `atlas/tests/test_coffee_semantics.py:129` | 14 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_complexity.py::ComplexityTests.assert_fulfillment` | `atlas/tests/test_complexity.py:12` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_entry_and_sequential_decisions` | `atlas/tests/test_complexity.py:17` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_requested_example_across_grammars` | `atlas/tests/test_complexity.py:26` | 15 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_depths_three_and_five` | `atlas/tests/test_complexity.py:42` | 6 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_penalty_per_deep_decision_not_only_maximum` | `atlas/tests/test_complexity.py:49` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_loop_ancestor_need_not_be_immediate_parent` | `atlas/tests/test_complexity.py:52` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_boolean_ternary_and_catch` | `atlas/tests/test_complexity.py:56` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_else_if_is_not_nesting` | `atlas/tests/test_complexity.py:60` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_nested_scopes_are_not_counted` | `atlas/tests/test_complexity.py:66` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_python_method_and_inner_function_are_independent` | `atlas/tests/test_complexity.py:70` | 8 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_artifact_only_function_and_method_properties` | `atlas/tests/test_complexity.py:79` | 16 | 0 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.assert_metrics` | `atlas/tests/test_complexity_regression.py:13` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.assert_python` | `atlas/tests/test_complexity_regression.py:18` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.assert_elixir` | `atlas/tests/test_complexity_regression.py:23` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_kotlin_each_short_circuit_operator_without_boolean_depth` | `atlas/tests/test_complexity_regression.py:28` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_python_refutable_match_patterns_and_fallbacks` | `atlas/tests/test_complexity_regression.py:35` | 5 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_python_fallback_guards_are_decisions` | `atlas/tests/test_complexity_regression.py:41` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_python_case_guard_depth_does_not_leak_into_body` | `atlas/tests/test_complexity_regression.py:46` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_python_match_nesting_and_nested_functions` | `atlas/tests/test_complexity_regression.py:50` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_if_unless_and_qualified_non_controls` | `atlas/tests/test_complexity_regression.py:54` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_case_and_cond_default_arm_exclusion` | `atlas/tests/test_complexity_regression.py:57` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_guarded_case_alternatives_and_deep_penalties` | `atlas/tests/test_complexity_regression.py:61` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_declaration_and_lambda_guards` | `atlas/tests/test_complexity_regression.py:66` | 10 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_reducer_calls_are_not_loops_and_fn_scopes_are_independent` | `atlas/tests/test_complexity_regression.py:77` | 13 | 0 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_nested_declaration_scopes` | `atlas/tests/test_complexity_regression.py:91` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_quoted_declarations_have_independent_bodies` | `atlas/tests/test_complexity_regression.py:96` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_else_if_chains_share_depth_across_grammars` | `atlas/tests/test_complexity_regression.py:103` | 13 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_default_arms_remain_excluded_across_grammars` | `atlas/tests/test_complexity_regression.py:117` | 14 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_braced_else_is_real_nesting_not_else_if` | `atlas/tests/test_complexity_regression.py:132` | 6 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.assert_callable_body` | `atlas/tests/test_complexity_regression.py:139` | 5 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_callable_roots_use_bodies_not_parameter_defaults` | `atlas/tests/test_complexity_regression.py:145` | 11 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_cycles.py::file` | `atlas/tests/test_cycles.py:8` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_cycles.py::edge` | `atlas/tests/test_cycles.py:12` | 10 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_cycles.py::CyclesTest.test_acyclic_and_empty` | `atlas/tests/test_cycles.py:25` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_cycles.py::CyclesTest.test_sccs_witness_and_internal_edges` | `atlas/tests/test_cycles.py:30` | 10 | 0 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_cycles.py::CyclesTest.assert_cycle_witness` | `atlas/tests/test_cycles.py:41` | 8 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_cycles.py::CyclesTest.test_projection_preserves_evidence_without_mutation` | `atlas/tests/test_cycles.py:50` | 13 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_cycles.py::CyclesTest.test_only_genuine_file_self_import` | `atlas/tests/test_cycles.py:64` | 11 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_cycles.py::CyclesTest.test_external_missing_and_non_import_edges_ignored` | `atlas/tests/test_cycles.py:76` | 20 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_cycles.py::CyclesTest.test_determinism_and_optional_metadata` | `atlas/tests/test_cycles.py:97` | 18 | 0 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_cycles.py::CyclesTest.test_large_chain_and_cycle_are_iterative` | `atlas/tests/test_cycles.py:116` | 9 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_database_boundaries.py::violations` | `atlas/tests/test_database_boundaries.py:30` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_database_boundaries.py::test_database_boundary_policy` | `atlas/tests/test_database_boundaries.py:99` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_database_boundaries.py::test_every_production_package_is_boundary_sensitive` | `atlas/tests/test_database_boundaries.py:103` | 10 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_database_boundaries.py::test_repository_ownership_is_frozen_and_pure_records_are_not_orm` | `atlas/tests/test_database_boundaries.py:115` | 13 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_database_boundaries.py::test_production_modules_respect_database_boundaries` | `atlas/tests/test_database_boundaries.py:130` | 9 | 0 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_database_boundaries.py::test_policy_helpers_fit_architecture_limits` | `atlas/tests/test_database_boundaries.py:141` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_database_boundaries.py::assert_policy_function_limits` | `atlas/tests/test_database_boundaries.py:150` | 8 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/test_database_cli.py::test_database_option_is_rejected` | `atlas/tests/test_database_cli.py:12` | 10 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_database_cli.py::test_help_has_no_database_option` | `atlas/tests/test_database_cli.py:25` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::flatten` | `atlas/tests/test_declaration_callbacks.py:16` | 8 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::child_entries` | `atlas/tests/test_declaration_callbacks.py:26` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_callback_carriers` | `atlas/tests/test_declaration_callbacks.py:45` | 15 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_declaration_nodes` | `atlas/tests/test_declaration_callbacks.py:61` | 10 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_declaration_node` | `atlas/tests/test_declaration_callbacks.py:72` | 9 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_callback_spans` | `atlas/tests/test_declaration_callbacks.py:82` | 7 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_callback_parentage` | `atlas/tests/test_declaration_callbacks.py:90` | 7 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.nearest_declaration` | `atlas/tests/test_declaration_callbacks.py:99` | 9 | 2 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_nested_callbacks_match_real_ast_and_parentage_with_or_without_native` | `atlas/tests/test_declaration_callbacks.py:109` | 3 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_application_callbacks` | `atlas/tests/test_declaration_callbacks.py:113` | 7 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_native_callbacks` | `atlas/tests/test_declaration_callbacks.py:121` | 13 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_native_duplicate_callback_metadata_merges_once_without_mutation` | `atlas/tests/test_declaration_callbacks.py:135` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_duplicate_callback_metadata` | `atlas/tests/test_declaration_callbacks.py:140` | 20 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_unbound_callback_identity_ignores_conflicting_native_names` | `atlas/tests/test_declaration_callbacks.py:161` | 17 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_go_assigned_literal_accepts_safe_binding_not_receiver_assignment` | `atlas/tests/test_declaration_callbacks.py:179` | 10 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_kotlin_anonymous_fun_and_labeled_lambda_not_wrappers` | `atlas/tests/test_declaration_callbacks.py:190` | 10 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_elixir_multiclause_fn_and_identical_expressions_stay_distinct` | `atlas/tests/test_declaration_callbacks.py:201` | 11 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_script_bindings_and_inline_functions_keep_single_identity` | `atlas/tests/test_declaration_callbacks.py:213` | 5 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_script_bindings` | `atlas/tests/test_declaration_callbacks.py:219` | 15 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_declarations_inside_callbacks_keep_expression_parent` | `atlas/tests/test_declaration_callbacks.py:235` | 12 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_canonical.py::merged` | `atlas/tests/test_declaration_canonical.py:16` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_declaration_canonical.py::names` | `atlas/tests/test_declaration_canonical.py:23` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_kotlin_unnamed_native_declarations_preserve_metadata` | `atlas/tests/test_declaration_canonical.py:28` | 12 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_kotlin_overloads_preserve_metadata_and_utf8_spans` | `atlas/tests/test_declaration_canonical.py:41` | 15 | 0 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_ts_interface_callable_properties_not_types_or_fields` | `atlas/tests/test_declaration_canonical.py:57` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.assert_interface_properties` | `atlas/tests/test_declaration_canonical.py:65` | 19 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_java_constructor_kind_and_visibility` | `atlas/tests/test_declaration_canonical.py:85` | 11 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_python_decorator_metadata_and_nested_definition` | `atlas/tests/test_declaration_canonical.py:97` | 11 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_python_stacked_utf8_decorator_discriminator` | `atlas/tests/test_declaration_canonical.py:109` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.assert_stacked_decorators` | `atlas/tests/test_declaration_canonical.py:114` | 12 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_python_native_decorated_wrapper_canonicalizes_to_definition` | `atlas/tests/test_declaration_canonical.py:127` | 17 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_missing_tags_preserves_native_metadata` | `atlas/tests/test_declaration_canonical.py:145` | 13 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_declaration_coffee.py::qualified_items` | `atlas/tests/test_declaration_coffee.py:14` | 9 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.test_whole_project_spans_ownership_and_native_nonmutation` | `atlas/tests/test_declaration_coffee.py:26` | 3 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_project_spans` | `atlas/tests/test_declaration_coffee.py:30` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_source_variants` | `atlas/tests/test_declaration_coffee.py:34` | 8 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_ast_spans` | `atlas/tests/test_declaration_coffee.py:43` | 25 | 3 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_ast_ancestor` | `atlas/tests/test_declaration_coffee.py:69` | 5 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.test_source_reviewed_kind_and_decorator_corrections` | `atlas/tests/test_declaration_coffee.py:75` | 3 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_source_corrections` | `atlas/tests/test_declaration_coffee.py:79` | 9 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_corrections` | `atlas/tests/test_declaration_coffee.py:89` | 12 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metric_persistence.py::fact_views` | `atlas/tests/test_dependency_metric_persistence.py:24` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metric_persistence.py::test_dependency_metrics_from_normalized_facts` | `atlas/tests/test_dependency_metric_persistence.py:31` | 28 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metric_persistence.py::test_normalized_instability_excludes_duplicates_self_and_external_edges` | `atlas/tests/test_dependency_metric_persistence.py:61` | 21 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metric_persistence.py::rich_artifact` | `atlas/tests/test_dependency_metric_persistence.py:84` | 13 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_dependency_metric_persistence.py::test_normalized_facts_keep_all_dependency_occurrences_and_legacy_complexities` | `atlas/tests/test_dependency_metric_persistence.py:99` | 30 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metric_persistence.py::test_enriched_facts_share_a_revision_and_are_repository_scoped` | `atlas/tests/test_dependency_metric_persistence.py:131` | 42 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/test_dependency_metric_persistence.py::test_enriched_facts_share_a_revision_and_are_repository_scoped.replace_after_header` | `atlas/tests/test_dependency_metric_persistence.py:148` | 8 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metric_persistence.py::test_report_facts_default_collections_are_independent` | `atlas/tests/test_dependency_metric_persistence.py:175` | 9 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_dependency_metrics.py::view` | `atlas/tests/test_dependency_metrics.py:27` | 16 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::counts` | `atlas/tests/test_dependency_metrics.py:45` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_dependency_metrics.py::expected_metrics` | `atlas/tests/test_dependency_metrics.py:49` | 5 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::test_chain_diamond_and_cycles` | `atlas/tests/test_dependency_metrics.py:74` | 7 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::test_duplicate_self_and_outside_view_edges_do_not_count` | `atlas/tests/test_dependency_metrics.py:83` | 16 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_dependency_metrics.py::test_instability_uses_distinct_incoming_and_outgoing_peers` | `atlas/tests/test_dependency_metrics.py:101` | 9 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::reverse_reachable` | `atlas/tests/test_dependency_metrics.py:112` | 11 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::test_bitsets_match_independent_traversal_on_mixed_graphs` | `atlas/tests/test_dependency_metrics.py:126` | 8 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::test_deep_graph_is_iterative_and_exact` | `atlas/tests/test_dependency_metrics.py:136` | 7 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::test_large_cycle_is_iterative_and_excludes_selected_node` | `atlas/tests/test_dependency_metrics.py:145` | 4 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::declaration` | `atlas/tests/test_dependency_metrics.py:151` | 6 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::projected_artifact` | `atlas/tests/test_dependency_metrics.py:159` | 36 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::metric_values` | `atlas/tests/test_dependency_metrics.py:197` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::assert_projected_peer_metrics` | `atlas/tests/test_dependency_metrics.py:201` | 7 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::test_all_levels_use_aggregated_internal_dependencies` | `atlas/tests/test_dependency_metrics.py:210` | 21 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::logistics_nodes` | `atlas/tests/test_dependency_metrics.py:233` | 3 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::assert_source_evidence` | `atlas/tests/test_dependency_metrics.py:238` | 2 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::assert_no_runtime_import_cycle` | `atlas/tests/test_dependency_metrics.py:242` | 4 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::test_indexer_populates_metrics_and_excludes_unresolved_targets` | `atlas/tests/test_dependency_metrics.py:248` | 17 | 1 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::assert_stock_compile_time_metrics` | `atlas/tests/test_dependency_metrics.py:267` | 5 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::test_type_only_imports_contribute_compile_time_impact` | `atlas/tests/test_dependency_metrics.py:274` | 10 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::strip_metrics` | `atlas/tests/test_dependency_metrics.py:286` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::test_legacy_metrics_are_optional_and_round_trip` | `atlas/tests/test_dependency_metrics.py:291` | 5 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_dependency_metrics.py::test_metric_properties_require_nonnegative_integer_counts` | `atlas/tests/test_dependency_metrics.py:300` | 7 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_dependency_metrics.py::test_instability_accepts_none_and_finite_unit_interval_floats` | `atlas/tests/test_dependency_metrics.py:310` | 8 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_dependency_metrics.py::test_instability_requires_none_or_a_finite_unit_interval_float` | `atlas/tests/test_dependency_metrics.py:321` | 9 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_discovery.py::discovered` | `atlas/tests/test_discovery.py:15` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_discovery.py::write_source` | `atlas/tests/test_discovery.py:19` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_discovery.py::test_gitignore_replaces_fallback_with_or_without_git` | `atlas/tests/test_discovery.py:27` | 15 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_discovery.py::test_nested_gitignore_and_negation` | `atlas/tests/test_discovery.py:44` | 11 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_discovery.py::test_empty_gitignore_disables_fallback_but_not_git_metadata` | `atlas/tests/test_discovery.py:57` | 5 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_discovery.py::test_fallback_excludes_generated_folders_not_files` | `atlas/tests/test_discovery.py:64` | 5 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.test_per_language_inheritance_and_generic_fallback` | `atlas/tests/test_extraction_adapters.py:16` | 18 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.assert_inheritance` | `atlas/tests/test_extraction_adapters.py:35` | 6 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.test_jsx_tag_name_sites_are_references_without_swallowing_attribute_calls` | `atlas/tests/test_extraction_adapters.py:42` | 5 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.assert_jsx_calls` | `atlas/tests/test_extraction_adapters.py:48` | 16 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.test_decorators_visibility_and_import_supplement_owned_by_adapters` | `atlas/tests/test_extraction_adapters.py:65` | 22 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.assert_declaration_metadata` | `atlas/tests/test_extraction_adapters.py:88` | 4 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.test_rust_macro_payload_remains_rust_only` | `atlas/tests/test_extraction_adapters.py:93` | 20 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_integration.py::test_elixir_heads_controls_nested_arguments_and_pipelines` | `atlas/tests/test_extraction_integration.py:9` | 11 | 0 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_integration.py::test_rust_macro_nested_arguments_offsets_and_invalid_dsl` | `atlas/tests/test_extraction_integration.py:22` | 13 | 0 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_integration.py::assert_invalid_receipt_macros` | `atlas/tests/test_extraction_integration.py:37` | 4 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_extraction_integration.py::test_rust_relative_module_paths_keep_declared_identity` | `atlas/tests/test_extraction_integration.py:43` | 11 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_integration.py::test_inheritance_headers_and_import_aliases_are_precise` | `atlas/tests/test_extraction_integration.py:56` | 9 | 0 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_extraction_integration.py::test_multiple_bases_exclude_metaclass_arguments` | `atlas/tests/test_extraction_integration.py:67` | 5 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_folder_cli.py::source_contents` | `atlas/tests/test_folder_cli.py:23` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_folder_cli.py::folder_arguments` | `atlas/tests/test_folder_cli.py:27` | 7 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_folder_cli.py::assert_saved_output` | `atlas/tests/test_folder_cli.py:36` | 18 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_folder_cli.py::test_folder_default_and_aliases` | `atlas/tests/test_folder_cli.py:60` | 15 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_folder_cli.py::test_report_default_cwd_without_saving` | `atlas/tests/test_folder_cli.py:77` | 9 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_folder_cli.py::test_skip_save_option_is_removed` | `atlas/tests/test_folder_cli.py:89` | 11 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_folder_report_cli.py::source` | `atlas/tests/test_folder_report_cli.py:21` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_folder_report_cli.py::test_folder_report_creates_and_updates_saved_project` | `atlas/tests/test_folder_report_cli.py:29` | 27 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_folder_report_cli.py::test_folder_names_are_trimmed_for_registration` | `atlas/tests/test_folder_report_cli.py:58` | 10 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_folder_report_cli.py::test_relative_folder_uses_user_database_not_source` | `atlas/tests/test_folder_report_cli.py:70` | 11 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_folder_report_cli.py::test_folder_updates_registered_location_not_same_name` | `atlas/tests/test_folder_report_cli.py:83` | 14 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_folder_report_cli.py::test_same_basename_folders_get_distinct_projects` | `atlas/tests/test_folder_report_cli.py:99` | 12 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_folder_report_cli.py::test_default_never_accesses_database` | `atlas/tests/test_folder_report_cli.py:114` | 19 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_folder_report_cli.py::test_default_never_accesses_database.fail` | `atlas/tests/test_folder_report_cli.py:117` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_folder_report_cli.py::test_default_preserves_existing_graph` | `atlas/tests/test_folder_report_cli.py:136` | 19 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_folder_report_cli.py::test_save_analyzes_once_and_keeps_output` | `atlas/tests/test_folder_report_cli.py:158` | 33 | 3 | 6 | 6 | 0 | 0 | 2 |
| `atlas/tests/test_folder_report_cli.py::test_save_analyzes_once_and_keeps_output.analyze` | `atlas/tests/test_folder_report_cli.py:168` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_folder_report_cli.py::test_invalid_report_arguments_do_not_create_database` | `atlas/tests/test_folder_report_cli.py:193` | 7 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_folder_report_cli.py::test_file_is_not_a_report_folder` | `atlas/tests/test_folder_report_cli.py:202` | 8 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_folder_report_cli.py::test_global_project_selector_is_rejected` | `atlas/tests/test_folder_report_cli.py:212` | 9 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_folder_report_cli.py::test_failed_update_preserves_saved_graph` | `atlas/tests/test_folder_report_cli.py:223` | 20 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_folder_report_cli.py::test_failed_save_rolls_back_registration` | `atlas/tests/test_folder_report_cli.py:245` | 11 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_contracts.py::null_container_artifact` | `atlas/tests/test_graph_contracts.py:13` | 10 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/test_graph_contracts.py::test_null_containers_round_trip` | `atlas/tests/test_graph_contracts.py:26` | 13 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_graph_contracts.py::test_missing_or_empty_collections_have_no_normalized_rows` | `atlas/tests/test_graph_contracts.py:42` | 6 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_contracts.py::malformed_artifact` | `atlas/tests/test_graph_contracts.py:50` | 7 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_contracts.py::test_malformed_occurrence_containers_reject_without_changing_storage` | `atlas/tests/test_graph_contracts.py:71` | 18 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_migrations.py::test_schema_upgrade_leaves_existing_artifacts_unparsed` | `atlas/tests/test_graph_migrations.py:14` | 21 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_migrations.py::test_fresh_migration_late_failure_rolls_back_all_schema` | `atlas/tests/test_graph_migrations.py:37` | 15 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_migrations.py::test_fresh_migration_late_failure_rolls_back_all_schema.fail_schema` | `atlas/tests/test_graph_migrations.py:42` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_migrations.py::test_fresh_migration_late_failure_rolls_back_all_schema.<anonymous>` | `atlas/tests/test_graph_migrations.py:47` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::graph` | `atlas/tests/test_graph_navigation.py:32` | 15 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::command` | `atlas/tests/test_graph_navigation.py:49` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_cli_metadata_and_optional_project` | `atlas/tests/test_graph_navigation.py:55` | 10 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_search_rank_ambiguity_and_literal_query` | `atlas/tests/test_graph_navigation.py:67` | 12 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_search_prefers_internal_declarations_and_exact_files` | `atlas/tests/test_graph_navigation.py:81` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_unicode_search_rank_and_tie_breakers_on_existing_database` | `atlas/tests/test_graph_navigation.py:88` | 40 | 1 | 10 | 13 | 0 | 3 | 2 |
| `atlas/tests/test_graph_navigation.py::test_unicode_search_keeps_punctuation_literal` | `atlas/tests/test_graph_navigation.py:131` | 5 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_hierarchy_pagination_and_diagnostic_scope` | `atlas/tests/test_graph_navigation.py:138` | 10 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_directions_cycles_and_evidence` | `atlas/tests/test_graph_navigation.py:151` | 9 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::<anonymous>` | `atlas/tests/test_graph_navigation.py:162` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_context_cutoffs` | `atlas/tests/test_graph_navigation.py:163` | 7 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_unresolved_and_type_only` | `atlas/tests/test_graph_navigation.py:172` | 7 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_cli_unresolved_labels_leave_storage_and_service_unchanged` | `atlas/tests/test_graph_navigation.py:181` | 13 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::driver` | `atlas/tests/test_graph_navigation.py:196` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_frontier_edge_queries_are_scoped_and_bounded` | `atlas/tests/test_graph_navigation.py:201` | 11 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_adjacency_plan_streams_endpoint_relation_index` | `atlas/tests/test_graph_navigation.py:215` | 8 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_adjacency_work_ignores_unrelated_edges` | `atlas/tests/test_graph_navigation.py:226` | 13 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_adjacency_work_ignores_unrelated_edges.count_steps` | `atlas/tests/test_graph_navigation.py:232` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_unknown_relation_is_a_usage_error` | `atlas/tests/test_graph_navigation.py:241` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_path_found_unknown_and_not_found` | `atlas/tests/test_graph_navigation.py:246` | 6 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_repository_isolation` | `atlas/tests/test_graph_navigation.py:255` | 13 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_read_snapshot_and_revision` | `atlas/tests/test_graph_navigation.py:270` | 14 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_missing_database_is_not_created` | `atlas/tests/test_graph_navigation.py:286` | 6 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_missing_schema_and_index` | `atlas/tests/test_graph_navigation.py:294` | 12 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_source_spans_use_parser_lf_coordinates` | `atlas/tests/test_graph_navigation.py:310` | 23 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_batch_source_preserves_order_status_and_metadata` | `atlas/tests/test_graph_navigation.py:335` | 9 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::assert_source_matches_single` | `atlas/tests/test_graph_navigation.py:346` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_batch_source_pagination_and_duplicate_keys` | `atlas/tests/test_graph_navigation.py:352` | 7 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_batch_source_keeps_verification_failures_per_excerpt` | `atlas/tests/test_graph_navigation.py:362` | 9 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_source_numbered_text_preserves_excerpt_and_snapshot_details` | `atlas/tests/test_graph_navigation.py:374` | 10 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::assert_text_excerpt` | `atlas/tests/test_graph_navigation.py:386` | 6 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_graph_navigation.py::test_batch_source_rejects_stale_revision_and_unknown_key` | `atlas/tests/test_graph_navigation.py:394` | 6 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_source_verified_paged_changed_missing` | `atlas/tests/test_graph_navigation.py:402` | 14 | 1 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_source_unsafe_paths_and_symlink` | `atlas/tests/test_graph_navigation.py:419` | 8 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_source_fifo_never_blocks` | `atlas/tests/test_graph_navigation.py:429` | 7 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_source_symlink_loop_is_structured` | `atlas/tests/test_graph_navigation.py:438` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_source_file_size_is_bounded` | `atlas/tests/test_graph_navigation.py:445` | 8 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_graph_navigation.py::test_source_long_line_output_is_bounded` | `atlas/tests/test_graph_navigation.py:455` | 9 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_graph_output.py::test_unresolved_projection_preserves_keys_and_evidence` | `atlas/tests/test_graph_output.py:6` | 18 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_persistence.py::database` | `atlas/tests/test_graph_persistence.py:25` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_persistence.py::header` | `atlas/tests/test_graph_persistence.py:31` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_persistence.py::fail_edges` | `atlas/tests/test_graph_persistence.py:36` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_persistence.py::assert_saved` | `atlas/tests/test_graph_persistence.py:41` | 8 | 3 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/test_graph_persistence.py::test_full_normalized_facts` | `atlas/tests/test_graph_persistence.py:51` | 52 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_graph_persistence.py::test_explicit_null_measurement_is_present_not_zero` | `atlas/tests/test_graph_persistence.py:105` | 12 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_persistence.py::test_scoped_cascade_and_same_keys` | `atlas/tests/test_graph_persistence.py:120` | 14 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_graph_persistence.py::test_composite_references_cannot_cross_repositories` | `atlas/tests/test_graph_persistence.py:137` | 20 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_graph_persistence.py::replacement` | `atlas/tests/test_graph_persistence.py:159` | 7 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_persistence.py::test_replacement_removes_stale_facts_and_always_changes_revision` | `atlas/tests/test_graph_persistence.py:168` | 15 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_persistence.py::test_late_replacement_failure_restores_entire_snapshot_and_session` | `atlas/tests/test_graph_persistence.py:185` | 15 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_persistence.py::test_save_new_failure_leaves_no_pending_or_ghost_registration` | `atlas/tests/test_graph_persistence.py:203` | 17 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_persistence.py::test_invalid_graph_rolls_back_existing_snapshot` | `atlas/tests/test_graph_persistence.py:223` | 16 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_graph_persistence.py::connection_rows` | `atlas/tests/test_graph_persistence.py:241` | 2 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_persistence.py::test_wal_reader_keeps_header_and_rows_in_one_snapshot` | `atlas/tests/test_graph_persistence.py:245` | 20 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_persistence.py::test_coffee_graphs_write_all_nodes_and_edge_occurrences` | `atlas/tests/test_graph_persistence.py:268` | 10 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_graph_persistence.py::test_type_only_records_literal_true` | `atlas/tests/test_graph_persistence.py:281` | 6 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_project_discovery.py::indexed_folder` | `atlas/tests/test_graph_project_discovery.py:17` | 9 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_project_discovery.py::test_commands_infer_project` | `atlas/tests/test_graph_project_discovery.py:32` | 7 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_project_discovery.py::test_nearest_indexed_folder_wins` | `atlas/tests/test_graph_project_discovery.py:41` | 9 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_project_discovery.py::test_outside_folder_needs_explicit_project` | `atlas/tests/test_graph_project_discovery.py:53` | 11 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_project_discovery.py::test_duplicate_locations_need_explicit_project` | `atlas/tests/test_graph_project_discovery.py:66` | 10 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_project_discovery.py::test_location_symlink_is_canonicalized` | `atlas/tests/test_graph_project_discovery.py:78` | 15 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_project_discovery.py::test_inference_does_not_create_missing_database` | `atlas/tests/test_graph_project_discovery.py:95` | 8 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_schema.py::database` | `atlas/tests/test_graph_schema.py:103` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_schema.py::test_exact_table_inventory_and_deferred_parentage` | `atlas/tests/test_graph_schema.py:109` | 7 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_schema.py::test_exact_normalized_columns_and_foreign_keys` | `atlas/tests/test_graph_schema.py:119` | 8 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_graph_schema.py::index_columns` | `atlas/tests/test_graph_schema.py:129` | 2 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_graph_schema.py::test_exact_scoped_indexes` | `atlas/tests/test_graph_schema.py:134` | 5 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_graph_schema.py::test_name_index_collation_and_registration_uniqueness` | `atlas/tests/test_graph_schema.py:141` | 6 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_graph_transactions.py::database` | `atlas/tests/test_graph_transactions.py:19` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_transactions.py::header` | `atlas/tests/test_graph_transactions.py:25` | 7 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_transactions.py::replacement` | `atlas/tests/test_graph_transactions.py:34` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_transactions.py::assert_integrity` | `atlas/tests/test_graph_transactions.py:44` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_transactions.py::assert_replaced` | `atlas/tests/test_graph_transactions.py:51` | 8 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_graph_transactions.py::assert_new_graph` | `atlas/tests/test_graph_transactions.py:61` | 10 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_graph_transactions.py::test_public_write_ends_stale_orchestration_read` | `atlas/tests/test_graph_transactions.py:74` | 31 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/tests/test_graph_transactions.py::test_write_failure_is_atomic_and_same_session_reusable` | `atlas/tests/test_graph_transactions.py:109` | 35 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_import_binding_guard.py::test_selective_imports_never_bind_module_namespace` | `atlas/tests/test_import_binding_guard.py:21` | 12 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_import_binding_guard.py::test_member_calls_do_not_borrow_local_or_project_declarations` | `atlas/tests/test_import_binding_guard.py:70` | 18 | 1 | 8 | 8 | 0 | 0 | 2 |
| `atlas/tests/test_import_binding_guard.py::test_member_collision_keeps_real_inventory_binding` | `atlas/tests/test_import_binding_guard.py:104` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_binding_guard.py::test_project_repository_uses_each_files_grammar_and_skips_manifests` | `atlas/tests/test_import_binding_guard.py:109` | 12 | 0 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_import_cycle_semantics.py::test_typescript_stock_back_references` | `atlas/tests/test_import_cycle_semantics.py:27` | 16 | 3 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_import_cycle_semantics.py::cycle_keys_touching` | `atlas/tests/test_import_cycle_semantics.py:45` | 4 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_import_cycle_semantics.py::package_project` | `atlas/tests/test_import_cycle_semantics.py:51` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_cycle_semantics.py::imports_at` | `atlas/tests/test_import_cycle_semantics.py:57` | 2 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_import_cycle_semantics.py::groups_at` | `atlas/tests/test_import_cycle_semantics.py:61` | 3 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_import_cycle_semantics.py::test_python_package_child_imports` | `atlas/tests/test_import_cycle_semantics.py:66` | 13 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_import_cycle_semantics.py::test_python_actual_self_imports` | `atlas/tests/test_import_cycle_semantics.py:82` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_cycle_semantics.py::test_python_runtime_child_cycle` | `atlas/tests/test_import_cycle_semantics.py:87` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_cycle_semantics.py::test_python_unresolved_child_stays_external` | `atlas/tests/test_import_cycle_semantics.py:94` | 7 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_cycle_semantics.py::test_python_package_attribute_does_not_become_self_import` | `atlas/tests/test_import_cycle_semantics.py:103` | 9 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_import_cycle_semantics.py::test_type_only_external_import_remains_visible` | `atlas/tests/test_import_cycle_semantics.py:114` | 10 | 1 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_import_performance.py::test_analyzes_this_repository_within_fast_cold_process_budget` | `atlas/tests/test_import_performance.py:26` | 20 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_performance.py::menu_source` | `atlas/tests/test_import_performance.py:48` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_performance.py::test_data_grammars_do_not_parse_or_walk_for_impossible_calls` | `atlas/tests/test_import_performance.py:54` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_performance.py::test_default_adapter_still_extracts_calls_when_grammar_supports_them` | `atlas/tests/test_import_performance.py:60` | 5 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_import_performance.py::test_file_extraction_reuses_one_syntax_tree_per_coffee_file` | `atlas/tests/test_import_performance.py:68` | 15 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_import_performance.py::file_callables` | `atlas/tests/test_import_performance.py:85` | 2 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_import_performance.py::assert_unmeasured_coffee_calls` | `atlas/tests/test_import_performance.py:89` | 7 | 1 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_import_performance.py::assert_metric_parsing_once` | `atlas/tests/test_import_performance.py:98` | 12 | 2 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_import_performance.py::test_data_files_do_not_create_an_extra_syntax_tree` | `atlas/tests/test_import_performance.py:112` | 10 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_performance.py::test_syntax_tree_reuse_is_local_to_each_file` | `atlas/tests/test_import_performance.py:124` | 8 | 0 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_import_performance.py::test_import_node_lookup_indexes_each_coffee_tree_once` | `atlas/tests/test_import_performance.py:134` | 18 | 0 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_import_performance.py::test_syntax_tree_and_binding_scan_are_lazy_and_cached` | `atlas/tests/test_import_performance.py:154` | 14 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_import_performance.py::test_path_resolution_is_cached_only_within_one_repository` | `atlas/tests/test_import_performance.py:170` | 17 | 0 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_import_resolution.py::coffee_repository` | `atlas/tests/test_import_resolution.py:12` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_resolution.py::coffee_target_keys` | `atlas/tests/test_import_resolution.py:16` | 3 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_import_resolution.py::assert_coffee_call` | `atlas/tests/test_import_resolution.py:21` | 9 | 2 | 7 | 7 | 0 | 0 | 2 |
| `atlas/tests/test_import_resolution.py::coffee_import_edges` | `atlas/tests/test_import_resolution.py:56` | 6 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_import_resolution.py::assert_import_targets` | `atlas/tests/test_import_resolution.py:64` | 7 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_import_resolution.py::test_coffee_imports_reach_exact_declarations` | `atlas/tests/test_import_resolution.py:74` | 5 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_import_resolution.py::test_coffee_python_namespace_and_aliased_calls` | `atlas/tests/test_import_resolution.py:86` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_resolution.py::test_coffee_python_combined_module_aliases` | `atlas/tests/test_import_resolution.py:90` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_resolution.py::test_coffee_go_module_namespace_limit_is_explicit` | `atlas/tests/test_import_resolution.py:100` | 8 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_import_resolution.py::test_namespace_import_forms` | `atlas/tests/test_import_resolution.py:115` | 7 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_import_resolution.py::test_unsafe_namespace_bindings_stay_unresolved` | `atlas/tests/test_import_resolution.py:133` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_resolution.py::test_namespace_shadowing_does_not_poison_other_workflows` | `atlas/tests/test_import_resolution.py:139` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_import_resolution.py::test_go_package_identity_and_explicit_alias` | `atlas/tests/test_import_resolution.py:146` | 12 | 2 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_import_source_order.py::facts` | `atlas/tests/test_import_source_order.py:16` | 8 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_import_source_order.py::test_whole_project_resolution_is_independent_of_source_order` | `atlas/tests/test_import_source_order.py:28` | 13 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_import_source_order.py::test_ambiguous_roast_call_remains_external_in_every_source_order` | `atlas/tests/test_import_source_order.py:44` | 9 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::copy_application` | `atlas/tests/test_indexer.py:28` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_indexer.py::go_brewer_symbols` | `atlas/tests/test_indexer.py:33` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::rust_brewer_symbols` | `atlas/tests/test_indexer.py:42` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::elixir_brewer_symbols` | `atlas/tests/test_indexer.py:51` | 9 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::class_brewer_symbols` | `atlas/tests/test_indexer.py:71` | 19 | 1 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::brewer_symbols` | `atlas/tests/test_indexer.py:92` | 5 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::reporting_calls` | `atlas/tests/test_indexer.py:116` | 12 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::tree_contents` | `atlas/tests/test_indexer.py:130` | 3 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::qualified_edges` | `atlas/tests/test_indexer.py:135` | 5 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.setUpClass` | `atlas/tests/test_indexer.py:144` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.test_indexes_polyglot_symbols_and_connections` | `atlas/tests/test_indexer.py:152` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.test_rust_dispatch_wiring_preserves_namespace_and_encoder_ownership` | `atlas/tests/test_indexer.py:157` | 15 | 0 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_application_symbols` | `atlas/tests/test_indexer.py:173` | 16 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_brewer_imports` | `atlas/tests/test_indexer.py:190` | 5 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_calls` | `atlas/tests/test_indexer.py:196` | 10 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_graph_structure` | `atlas/tests/test_indexer.py:207` | 15 | 1 | 6 | 6 | 0 | 0 | 2 |
| `atlas/tests/test_indexer.py::IndexerTest.test_builds_polyglot_module_file_type_and_callable_views` | `atlas/tests/test_indexer.py:223` | 6 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_view_inventory` | `atlas/tests/test_indexer.py:230` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_level_inventory` | `atlas/tests/test_indexer.py:234` | 6 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_views` | `atlas/tests/test_indexer.py:241` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_file_view` | `atlas/tests/test_indexer.py:247` | 9 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_callable_view` | `atlas/tests/test_indexer.py:257` | 14 | 2 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_type_view` | `atlas/tests/test_indexer.py:272` | 10 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_module_view` | `atlas/tests/test_indexer.py:283` | 9 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.test_kotlin_class_methods_and_nested_declarations` | `atlas/tests/test_indexer.py:293` | 16 | 0 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_kotlin_nested_declarations` | `atlas/tests/test_indexer.py:310` | 10 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.test_java_tags_add_constructors_without_losing_imports` | `atlas/tests/test_indexer.py:321` | 10 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_java_constructors` | `atlas/tests/test_indexer.py:332` | 13 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_java_service_imports` | `atlas/tests/test_indexer.py:346` | 10 | 2 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_service_dependencies` | `atlas/tests/test_indexer.py:357` | 14 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.test_reanalysis_reflects_source_changes_without_writing_a_file` | `atlas/tests/test_indexer.py:372` | 18 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.test_discovers_git_files_with_special_characters` | `atlas/tests/test_indexer.py:391` | 15 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_indexer.py::IndexerTest.test_discovers_large_and_non_programming_language_files` | `atlas/tests/test_indexer.py:407` | 18 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_invalid_utf8.py::test_original_file_digest_and_replacement_decoded_declarations` | `atlas/tests/test_invalid_utf8.py:70` | 27 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_jvm_callable_selection_snapshots.py::selection_snapshot` | `atlas/tests/test_jvm_callable_selection_snapshots.py:15` | 15 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_jvm_callable_selection_snapshots.py::test_jvm_callable_selection_snapshot` | `atlas/tests/test_jvm_callable_selection_snapshots.py:33` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_metric_adapters.py::assert_source_policy` | `atlas/tests/test_metric_adapters.py:17` | 8 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_metric_adapters.py::test_primary_policies_preserve_node_only_api` | `atlas/tests/test_metric_adapters.py:28` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_metric_adapters.py::test_policy_controls_decisions_without_changing_traversal` | `atlas/tests/test_metric_adapters.py:32` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_metric_phases.py::assert_decoded_span` | `atlas/tests/test_metric_phases.py:16` | 11 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_metric_phases.py::enrich_once` | `atlas/tests/test_metric_phases.py:29` | 9 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_metric_phases.py::test_callable_metrics_are_explicit_and_use_decoded_byte_spans` | `atlas/tests/test_metric_phases.py:43` | 20 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_metric_phases.py::test_metric_enrichment_does_not_parse_files_without_callables` | `atlas/tests/test_metric_phases.py:65` | 9 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_metric_snapshots.py::metric_subject` | `atlas/tests/test_metric_snapshots.py:34` | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_metric_snapshots.py::assert_thresholds` | `atlas/tests/test_metric_snapshots.py:39` | 16 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_metric_snapshots.py::assert_metric_threshold` | `atlas/tests/test_metric_snapshots.py:57` | 6 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_metric_snapshots.py::expected_finding` | `atlas/tests/test_metric_snapshots.py:65` | 7 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_metric_snapshots.py::test_callable_records` | `atlas/tests/test_metric_snapshots.py:75` | 19 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_metric_snapshots.py::assert_file_callables` | `atlas/tests/test_metric_snapshots.py:96` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_metric_snapshots.py::assert_callable_record` | `atlas/tests/test_metric_snapshots.py:101` | 13 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_metric_snapshots.py::assert_file_record` | `atlas/tests/test_metric_snapshots.py:116` | 21 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_metric_snapshots.py::test_grammar_complexity` | `atlas/tests/test_metric_snapshots.py:150` | 11 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_metric_snapshots.py::test_explicit_empty_policy_keeps_whole_source_scopes_excluded` | `atlas/tests/test_metric_snapshots.py:163` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_metric_snapshots.py::test_native_overload_records_keep_signatures_spans_and_order` | `atlas/tests/test_metric_snapshots.py:171` | 21 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_metric_snapshots.py::test_native_elixir_clauses_remain_separate_records` | `atlas/tests/test_metric_snapshots.py:194` | 20 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_metric_snapshots.py::test_implicit_kotlin_lambda_parameter_is_unavailable_not_zero` | `atlas/tests/test_metric_snapshots.py:216` | 7 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_models.py::ModelsTest.artifact` | `atlas/tests/test_models.py:17` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_models.py::ModelsTest.test_language_graphs_round_trip_without_field_changes` | `atlas/tests/test_models.py:20` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_models.py::ModelsTest.test_positional_constructors_and_default_lists` | `atlas/tests/test_models.py:28` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_models.py::ModelsTest.test_strict_constructor_and_assignment_validation` | `atlas/tests/test_models.py:37` | 12 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_models.py::ModelsTest.test_invalid_artifact_fields_are_rejected` | `atlas/tests/test_models.py:50` | 18 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_models.py::ModelsTest.test_reference_validation_runs_at_construction` | `atlas/tests/test_models.py:69` | 19 | 0 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_models.py::ModelsTest.test_mutation_is_revalidated_in_memory` | `atlas/tests/test_models.py:89` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_normalized_runtime.py::test_repository_multi_query_response_uses_one_revision` | `atlas/tests/test_normalized_runtime.py:17` | 40 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_normalized_runtime.py::test_repository_multi_query_response_uses_one_revision.replace_after_header` | `atlas/tests/test_normalized_runtime.py:31` | 8 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_normalized_runtime.py::test_report_facts_isolate_repositories_with_identical_node_keys` | `atlas/tests/test_normalized_runtime.py:59` | 22 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_normalized_runtime.py::test_index_summary_counts_match_source_analysis` | `atlas/tests/test_normalized_runtime.py:83` | 8 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_parsing_snapshots.py::items_tree` | `atlas/tests/test_parsing_snapshots.py:36` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::assert_symbol_record` | `atlas/tests/test_parsing_snapshots.py:42` | 12 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::assert_call_record` | `atlas/tests/test_parsing_snapshots.py:56` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_parsing_snapshots.py::assert_import_record` | `atlas/tests/test_parsing_snapshots.py:62` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_parsing_snapshots.py::assert_file_record` | `atlas/tests/test_parsing_snapshots.py:69` | 11 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::assert_repository_records` | `atlas/tests/test_parsing_snapshots.py:82` | 6 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::test_parser_records` | `atlas/tests/test_parsing_snapshots.py:91` | 9 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::assert_hierarchy` | `atlas/tests/test_parsing_snapshots.py:102` | 11 | 3 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_parsing_snapshots.py::structure_spans` | `atlas/tests/test_parsing_snapshots.py:115` | 3 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::assert_native_structure` | `atlas/tests/test_parsing_snapshots.py:120` | 13 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::test_structure_native_variants` | `atlas/tests/test_parsing_snapshots.py:136` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::node_span` | `atlas/tests/test_parsing_snapshots.py:141` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_parsing_snapshots.py::scheduling_syntax` | `atlas/tests/test_parsing_snapshots.py:147` | 4 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::test_native_wrappers_canonicalize_both_endpoints_without_mutation` | `atlas/tests/test_parsing_snapshots.py:160` | 14 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::assert_native_wrapper` | `atlas/tests/test_parsing_snapshots.py:176` | 19 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::test_malformed_and_invalid_utf8_records_preserve_original_bytes` | `atlas/tests/test_parsing_snapshots.py:200` | 21 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_parsing_snapshots.py::test_missing_tags_preserve_native_list_and_metadata` | `atlas/tests/test_parsing_snapshots.py:223` | 14 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_persistence.py::database` | `atlas/tests/test_persistence.py:22` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_persistence.py::test_current_schema_and_constraints` | `atlas/tests/test_persistence.py:28` | 36 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_persistence.py::test_service_requires_explicit_migration` | `atlas/tests/test_persistence.py:66` | 8 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_persistence.py::test_service_reindex_resolves_name_and_rolls_back_failed_write` | `atlas/tests/test_persistence.py:76` | 30 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_persistence.py::test_non_ascii_name_resolution_matches_sqlite_lower` | `atlas/tests/test_persistence.py:108` | 7 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_persistence.py::test_service_validation_and_shared_graph` | `atlas/tests/test_persistence.py:117` | 23 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_persistence.py::test_default_path_is_independent_of_working_directory` | `atlas/tests/test_persistence.py:142` | 9 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_persistence_entity_boundaries.py::entity_violations` | `atlas/tests/test_persistence_entity_boundaries.py:72` | 20 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_persistence_entity_boundaries.py::entity_target_forbidden` | `atlas/tests/test_persistence_entity_boundaries.py:94` | 8 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/tests/test_persistence_entity_boundaries.py::entity_behavior_violations` | `atlas/tests/test_persistence_entity_boundaries.py:104` | 17 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_persistence_entity_boundaries.py::graph_record_violations` | `atlas/tests/test_persistence_entity_boundaries.py:123` | 7 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/test_persistence_entity_boundaries.py::test_production_entities_declare_schema_without_io` | `atlas/tests/test_persistence_entity_boundaries.py:132` | 9 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_persistence_entity_boundaries.py::test_optional_production_graph_records_are_pure` | `atlas/tests/test_persistence_entity_boundaries.py:143` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::source` | `atlas/tests/test_policy_snapshots.py:25` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::selected_source` | `atlas/tests/test_policy_snapshots.py:29` | 9 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::keep_definition` | `atlas/tests/test_policy_snapshots.py:40` | 2 | 2 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::project_definition` | `atlas/tests/test_policy_snapshots.py:44` | 5 | 2 | 5 | 5 | 0 | 0 | 2 |
| `atlas/tests/test_policy_snapshots.py::boundary` | `atlas/tests/test_policy_snapshots.py:51` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_service_returns_domain_results_not_private_ports` | `atlas/tests/test_policy_snapshots.py:56` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_service_ports_cannot_escape_through_values_or_aliases` | `atlas/tests/test_policy_snapshots.py:67` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_service_ports_are_private_and_have_no_database_handles` | `atlas/tests/test_policy_snapshots.py:73` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::test_service_constructor_requires_the_domain_protocol` | `atlas/tests/test_policy_snapshots.py:79` | 7 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::test_nonservice_modules_cannot_accept_private_ports` | `atlas/tests/test_policy_snapshots.py:89` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_factory_wraps_context_ports_in_services` | `atlas/tests/test_policy_snapshots.py:95` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_factory_context_ports_cannot_escape` | `atlas/tests/test_policy_snapshots.py:101` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_factory_cannot_access_repository_session` | `atlas/tests/test_policy_snapshots.py:106` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_factory_operation_imports_are_exact_and_private` | `atlas/tests/test_policy_snapshots.py:114` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::test_infrastructure_allows_only_literal_connection_setup` | `atlas/tests/test_policy_snapshots.py:121` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_infrastructure_cannot_query_domain_data_or_loosen_setup` | `atlas/tests/test_policy_snapshots.py:131` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::test_in_memory_graph_repository_is_not_a_storage_port` | `atlas/tests/test_policy_snapshots.py:136` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_exact_repository_owner_allows_mapped_queries` | `atlas/tests/test_policy_snapshots.py:141` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_even_exact_orm_owners_cannot_use_raw_sql` | `atlas/tests/test_policy_snapshots.py:151` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::test_frozen_revision_allows_schema_and_exact_existing_collation` | `atlas/tests/test_policy_snapshots.py:157` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_revision_ownership_never_allows_data_queries` | `atlas/tests/test_policy_snapshots.py:163` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_collation_exception_is_confined_to_one_exact_revision_and_expression` | `atlas/tests/test_policy_snapshots.py:168` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_dynamic_and_reflective_access_cannot_hide_in_aliases` | `atlas/tests/test_policy_snapshots.py:186` | 9 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::test_public_domain_introspection_is_not_private_port_extraction` | `atlas/tests/test_policy_snapshots.py:198` | 5 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::test_exact_public_check_config_lookup_has_one_owner` | `atlas/tests/test_policy_snapshots.py:205` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_public_config_exception_is_exact_not_general_reflection` | `atlas/tests/test_policy_snapshots.py:217` | 4 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::test_entities_allow_declarative_schema_without_io` | `atlas/tests/test_policy_snapshots.py:223` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_entities_cannot_gain_database_or_filesystem_behavior` | `atlas/tests/test_policy_snapshots.py:229` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_import_scan_tracks_relative_local_type_and_chained_aliases` | `atlas/tests/test_policy_snapshots.py:234` | 11 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_architecture_dependencies_include_local_and_package_imports_not_types` | `atlas/tests/test_policy_snapshots.py:247` | 8 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::test_bootstrap_only_reexports_public_service_factories` | `atlas/tests/test_policy_snapshots.py:257` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_bootstrap_cannot_gain_composition_or_other_behavior` | `atlas/tests/test_policy_snapshots.py:263` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::test_entity_and_record_import_ownership_is_exact` | `atlas/tests/test_policy_snapshots.py:272` | 7 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_policy_snapshots.py::test_graph_records_only_transform_in_memory_values` | `atlas/tests/test_policy_snapshots.py:281` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_policy_snapshots.py::test_graph_records_cannot_gain_io` | `atlas/tests/test_policy_snapshots.py:287` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_primary_import_parsing.py::application` | `atlas/tests/test_primary_import_parsing.py:21` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_primary_import_parsing.py::test_primary_import_paths_do_not_use_polyglot_fallback` | `atlas/tests/test_primary_import_parsing.py:26` | 13 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_primary_import_parsing.py::test_application_import_paths_are_exact` | `atlas/tests/test_primary_import_parsing.py:58` | 7 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_primary_import_parsing.py::test_go_namespace_rules_do_not_use_polyglot_fallback` | `atlas/tests/test_primary_import_parsing.py:71` | 11 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_primary_import_parsing.py::assert_legacy_import_fallbacks` | `atlas/tests/test_primary_import_parsing.py:84` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_primary_import_parsing.py::test_legacy_import_path_fallback_and_reexport` | `atlas/tests/test_primary_import_parsing.py:93` | 3 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_primary_import_parsing.py::test_legacy_namespace_fallback_and_reexport` | `atlas/tests/test_primary_import_parsing.py:105` | 6 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_primary_import_parsing.py::test_jsx_alias_import_policy_uses_owned_hook` | `atlas/tests/test_primary_import_parsing.py:113` | 6 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_primary_import_parsing.py::test_legacy_include_paths` | `atlas/tests/test_primary_import_parsing.py:124` | 6 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_primary_import_parsing.py::test_legacy_unknown_import_path_is_preserved` | `atlas/tests/test_primary_import_parsing.py:132` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_primary_import_parsing.py::directive` | `atlas/tests/test_primary_import_parsing.py:137` | 5 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_primary_import_parsing.py::test_default_import_methods_dispatch_to_adapter_path_hook` | `atlas/tests/test_primary_import_parsing.py:144` | 10 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_primary_import_parsing.py::test_directive_bindings_dispatch_to_adapter_path_hook` | `atlas/tests/test_primary_import_parsing.py:156` | 12 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_primary_import_parsing.py::test_missing_required_import_node_dispatches_to_adapter_path_hook` | `atlas/tests/test_primary_import_parsing.py:170` | 18 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_project_names_cli.py::test_root_project_selector_is_rejected` | `atlas/tests/test_project_names_cli.py:12` | 9 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_project_names_cli.py::test_command_project_selectors_are_rejected` | `atlas/tests/test_project_names_cli.py:29` | 7 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_project_names_cli.py::test_positional_folder_is_rejected` | `atlas/tests/test_project_names_cli.py:39` | 6 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_project_names_cli.py::test_help_has_no_project_selector` | `atlas/tests/test_project_names_cli.py:48` | 7 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_projects_cli.py::database` | `atlas/tests/test_projects_cli.py:16` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_projects_cli.py::test_projects_lists_indexed_and_unindexed_projects` | `atlas/tests/test_projects_cli.py:23` | 20 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_projects_cli.py::test_projects_empty_database_is_empty_json_array` | `atlas/tests/test_projects_cli.py:45` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_projects_cli.py::test_projects_unmigrated_database_has_cli_error` | `atlas/tests/test_projects_cli.py:51` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_python_project_imports.py::package_sources` | `atlas/tests/test_python_project_imports.py:16` | 5 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::child_probe` | `atlas/tests/test_python_project_imports.py:23` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::test_package_imports_resolve_independently_of_analysis_root` | `atlas/tests/test_python_project_imports.py:32` | 18 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::assert_relationship_targets` | `atlas/tests/test_python_project_imports.py:52` | 2 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::test_child_module_imports_link_and_bind_namespace` | `atlas/tests/test_python_project_imports.py:58` | 10 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::test_comma_separated_module_imports` | `atlas/tests/test_python_project_imports.py:70` | 11 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::test_duplicate_source_roots_and_ambiguous_parent_cannot_choose_child` | `atlas/tests/test_python_project_imports.py:84` | 11 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::test_duplicate_complete_source_roots_are_ambiguous` | `atlas/tests/test_python_project_imports.py:97` | 7 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::test_unrelated_suffix_is_not_an_import_root` | `atlas/tests/test_python_project_imports.py:106` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::test_runtime_modules_take_precedence_over_type_stubs` | `atlas/tests/test_python_project_imports.py:116` | 11 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::test_package_attributes_prevent_child_module_guesses` | `atlas/tests/test_python_project_imports.py:131` | 8 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::test_annotation_only_attribute_does_not_hide_child_module` | `atlas/tests/test_python_project_imports.py:142` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_python_project_imports.py::test_ordinary_module_cannot_have_child_modules` | `atlas/tests/test_python_project_imports.py:151` | 7 | 1 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/test_python_project_imports.py::test_absolute_src_import_cycle_is_reported` | `atlas/tests/test_python_project_imports.py:160` | 8 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_alias_field_mutation` | `atlas/tests/test_receiver_remaining_blockers.py:24` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_script_member_write_forms` | `atlas/tests/test_receiver_remaining_blockers.py:32` | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_annotated_initializer_identity` | `atlas/tests/test_receiver_remaining_blockers.py:40` | 10 | 3 | 7 | 7 | 0 | 0 | 2 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_import_alias_identity_and_static_parameter_types` | `atlas/tests/test_receiver_remaining_blockers.py:60` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_rust_self_impl_identity` | `atlas/tests/test_receiver_remaining_blockers.py:72` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_compound_receiver_assignment` | `atlas/tests/test_receiver_remaining_blockers.py:84` | 4 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_go_block_shadow_is_not_a_declared_receiver` | `atlas/tests/test_receiver_remaining_blockers.py:90` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_go_range_binding_does_not_leak` | `atlas/tests/test_receiver_remaining_blockers.py:94` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_resolution.py::test_coffee_declared_receivers` | `atlas/tests/test_receiver_resolution.py:50` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_resolution.py::test_coffee_receiver_limits_are_explicit` | `atlas/tests/test_receiver_resolution.py:65` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_resolution.py::test_declared_receiver_forms_absent_from_coffee` | `atlas/tests/test_receiver_resolution.py:72` | 7 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_receiver_resolution.py::test_unknown_receiver_never_uses_member_name` | `atlas/tests/test_receiver_resolution.py:94` | 3 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_receiver_resolution.py::test_reassigned_inferred_receiver_stays_external` | `atlas/tests/test_receiver_resolution.py:105` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_resolution.py::test_elixir_has_module_calls_not_instance_members` | `atlas/tests/test_receiver_resolution.py:109` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_review_fixes.py::test_reassigned_declared_receiver_is_not_trusted` | `atlas/tests/test_receiver_review_fixes.py:22` | 3 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_receiver_review_fixes.py::test_python_caller_field_writes_invalidate_receiver` | `atlas/tests/test_receiver_review_fixes.py:34` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_review_fixes.py::test_script_caller_field_writes_invalidate_receiver` | `atlas/tests/test_receiver_review_fixes.py:40` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_review_fixes.py::test_python_member_mutation_follows_imported_class_identity` | `atlas/tests/test_receiver_review_fixes.py:45` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_review_fixes.py::test_script_member_mutation_follows_imported_class_identity` | `atlas/tests/test_receiver_review_fixes.py:50` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_review_fixes.py::test_unchanged_receivers_remain_internal` | `atlas/tests/test_receiver_review_fixes.py:60` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_review_fixes.py::test_rust_impl_in_another_module_resolves_identity` | `atlas/tests/test_receiver_review_fixes.py:70` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_review_fixes.py::test_rust_unrelated_duplicate_and_trait_impl_members_stay_external` | `atlas/tests/test_receiver_review_fixes.py:75` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_review_fixes.py::test_java_constructor_subtype_field_write_is_not_trusted` | `atlas/tests/test_receiver_review_fixes.py:79` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_review_fixes.py::test_rust_impl_target_is_the_actual_method` | `atlas/tests/test_receiver_review_fixes.py:83` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_review_fixes.py::test_callback_bindings_do_not_inherit_or_poison_outer_receiver` | `atlas/tests/test_receiver_review_fixes.py:98` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_review_fixes.py::test_typed_java_callback_receiver_has_its_own_identity` | `atlas/tests/test_receiver_review_fixes.py:105` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_receiver_safety.py::assert_target` | `atlas/tests/test_receiver_safety.py:16` | 7 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_receiver_safety.py::assert_lifetime_call` | `atlas/tests/test_receiver_safety.py:25` | 8 | 3 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_safety.py::test_constructor_and_field_receivers` | `atlas/tests/test_receiver_safety.py:58` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_safety.py::test_unsafe_receivers_stay_external` | `atlas/tests/test_receiver_safety.py:87` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_safety.py::test_type_visibility_follows_import_and_namespace_context` | `atlas/tests/test_receiver_safety.py:104` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_safety.py::test_imported_receiver_member_rebinding_is_not_ignored` | `atlas/tests/test_receiver_safety.py:110` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_safety.py::test_imported_python_receiver_member_rebinding_is_not_ignored` | `atlas/tests/test_receiver_safety.py:114` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_safety.py::test_constructor_injected_order_created_client` | `atlas/tests/test_receiver_safety.py:118` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_safety.py::test_audit_receiver_selects_one_argument_overload` | `atlas/tests/test_receiver_safety.py:125` | 12 | 0 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_receiver_safety.py::test_unrelated_constructor_assignments_are_separate_scopes` | `atlas/tests/test_receiver_safety.py:139` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_receiver_safety.py::test_unimported_type_is_not_guessed_globally` | `atlas/tests/test_receiver_safety.py:144` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_report.py::callable_node` | `atlas/tests/test_report.py:19` | 13 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_report.py::file_node` | `atlas/tests/test_report.py:34` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_report.py::test_report_contains_below_and_above_thresholds_and_keeps_input` | `atlas/tests/test_report.py:41` | 18 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_report.py::test_cycles_have_quantitative_counts_and_readable_paths` | `atlas/tests/test_report.py:62` | 18 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_report.py::test_empty_graph_still_has_quantitative_summary` | `atlas/tests/test_report.py:82` | 7 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_report.py::test_unavailable_metrics_and_partial_file_totals_are_explicit` | `atlas/tests/test_report.py:91` | 9 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_report.py::test_measurements_sort_by_path_line_then_symbol` | `atlas/tests/test_report.py:102` | 8 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_report.py::test_markdown_preserves_literal_names_and_shows_analysis_diagnostics` | `atlas/tests/test_report.py:112` | 8 | 0 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_report.py::test_imports_only_normalized_facts_preserve_cycle_metrics` | `atlas/tests/test_report.py:122` | 10 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_report_cli.py::database` | `atlas/tests/test_report_cli.py:18` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_report_cli.py::test_index_then_report_analyzes_fresh_folder` | `atlas/tests/test_report_cli.py:25` | 39 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_report_cli.py::test_service_report_requires_project_name` | `atlas/tests/test_report_cli.py:66` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_report_cli.py::test_report_empty_measurements_formats` | `atlas/tests/test_report_cli.py:72` | 10 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_report_cli.py::test_saving_does_not_migrate_database` | `atlas/tests/test_report_cli.py:85` | 12 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_adapter_dispatch.py::ResolutionAdapterDispatchTest.test_all_supported_languages_have_concrete_policies` | `atlas/tests/test_resolution_adapter_dispatch.py:11` | 18 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_adapter_dispatch.py::ResolutionAdapterDispatchTest.test_catalog_inventory_preserves_conservative_generic_fallback` | `atlas/tests/test_resolution_adapter_dispatch.py:30` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_adapter_dispatch.py::ResolutionAdapterDispatchTest.test_python_comprehension_and_javascript_hoisting_are_separate_policies` | `atlas/tests/test_resolution_adapter_dispatch.py:38` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_adapter_dispatch.py::ResolutionAdapterDispatchTest.test_tsx_namespace_reference_uses_qualified_import_and_shadowing` | `atlas/tests/test_resolution_adapter_dispatch.py:47` | 12 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_adapter_dispatch.py::component_keys` | `atlas/tests/test_resolution_adapter_dispatch.py:61` | 5 | 1 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_adapter_dispatch.py::app_references` | `atlas/tests/test_resolution_adapter_dispatch.py:68` | 3 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_resolution_callable_budgets` | `atlas/tests/test_resolution_complexity_cleanup.py:36` | 8 | 1 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_resolution_complexity_cleanup.py::_assert_budget` | `atlas/tests/test_resolution_complexity_cleanup.py:46` | 7 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_policy_and_scope_reexports_keep_the_same_objects` | `atlas/tests/test_resolution_complexity_cleanup.py:55` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_registry_relative_imports_target_children_not_itself` | `atlas/tests/test_resolution_complexity_cleanup.py:60` | 9 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_syntax_type_dependency_targets_independent_policy_contract` | `atlas/tests/test_resolution_complexity_cleanup.py:71` | 10 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_complexity_cleanup.py::_assert_no_syntax_dependency` | `atlas/tests/test_resolution_complexity_cleanup.py:83` | 8 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_complexity_cleanup.py::lexical_repository` | `atlas/tests/test_resolution_complexity_cleanup.py:93` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_js_export_deduplication_preserves_alias_keys_and_order` | `atlas/tests/test_resolution_complexity_cleanup.py:97` | 11 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_parentheses_only_unwrap_single_expressions` | `atlas/tests/test_resolution_complexity_cleanup.py:111` | 7 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_complexity_cleanup.py::parenthesized_types` | `atlas/tests/test_resolution_complexity_cleanup.py:120` | 5 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_complexity_cleanup.py::assert_transparent_expression` | `atlas/tests/test_resolution_complexity_cleanup.py:127` | 9 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_import_directives_keep_exact_source_selection` | `atlas/tests/test_resolution_complexity_cleanup.py:138` | 10 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_recursive_binding_names_still_ignore_types_and_member_targets` | `atlas/tests/test_resolution_complexity_cleanup.py:157` | 8 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_complexity_cleanup.py::syntax_node` | `atlas/tests/test_resolution_complexity_cleanup.py:167` | 3 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_complexity_cleanup.py::assert_member_targets_have_no_bindings` | `atlas/tests/test_resolution_complexity_cleanup.py:172` | 4 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_lexical_safety.py::lexical_sources` | `atlas/tests/test_resolution_lexical_safety.py:11` | 5 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_lexical_safety.py::lexical_repository` | `atlas/tests/test_resolution_lexical_safety.py:18` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_lexical_safety.py::order_symbol_keys` | `atlas/tests/test_resolution_lexical_safety.py:22` | 5 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_lexical_safety.py::assert_order_spans` | `atlas/tests/test_resolution_lexical_safety.py:29` | 6 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_lexical_safety.py::assert_order_target` | `atlas/tests/test_resolution_lexical_safety.py:37` | 5 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/test_resolution_lexical_safety.py::assert_order_call` | `atlas/tests/test_resolution_lexical_safety.py:44` | 9 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_blocks_bind_in_enclosing_function` | `atlas/tests/test_resolution_lexical_safety.py:59` | 6 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_module_and_class_blocks_are_not_scopes` | `atlas/tests/test_resolution_lexical_safety.py:67` | 14 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_conditional_import_order_and_scope` | `atlas/tests/test_resolution_lexical_safety.py:83` | 10 | 0 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_class_import_cannot_be_captured_by_method` | `atlas/tests/test_resolution_lexical_safety.py:95` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_callback_and_comprehension_bindings` | `atlas/tests/test_resolution_lexical_safety.py:102` | 13 | 0 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_parameter_shadows_callable_without_hiding_module_call` | `atlas/tests/test_resolution_lexical_safety.py:117` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_lexical_safety.py::test_javascript_and_typescript_callback_bindings` | `atlas/tests/test_resolution_lexical_safety.py:124` | 13 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_lexical_safety.py::test_java_blocks_loops_catches_and_lambda_parameters` | `atlas/tests/test_resolution_lexical_safety.py:139` | 10 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_lexical_safety.py::test_go_range_and_callback_bindings` | `atlas/tests/test_resolution_lexical_safety.py:151` | 10 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_lexical_safety.py::test_kotlin_lambda_and_range_bindings` | `atlas/tests/test_resolution_lexical_safety.py:163` | 8 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_lexical_safety.py::test_resolution_does_not_mutate_parsed_projects` | `atlas/tests/test_resolution_lexical_safety.py:173` | 11 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::receipt_sources` | `atlas/tests/test_resolution_modules.py:14` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::receipt_repository` | `atlas/tests/test_resolution_modules.py:20` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::modules` | `atlas/tests/test_resolution_modules.py:24` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::assert_receipt` | `atlas/tests/test_resolution_modules.py:28` | 4 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::rust_paths` | `atlas/tests/test_resolution_modules.py:34` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::assert_printer_imports` | `atlas/tests/test_resolution_modules.py:38` | 5 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::assert_module_visibility` | `atlas/tests/test_resolution_modules.py:45` | 8 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::test_external_module_owner_is_not_a_second_crate_root` | `atlas/tests/test_resolution_modules.py:55` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_modules.py::test_inline_ancestry_selects_nested_file_not_root_decoy` | `atlas/tests/test_resolution_modules.py:63` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_modules.py::test_deep_inline_modules_mod_rs_and_file_stem_layout` | `atlas/tests/test_resolution_modules.py:71` | 18 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::test_external_path_attribute_is_relative_to_containing_file` | `atlas/tests/test_resolution_modules.py:91` | 7 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::test_inline_path_attributes_use_inline_directory` | `atlas/tests/test_resolution_modules.py:100` | 9 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_modules.py::test_nonstandard_coffee_root_excludes_referenced_module_owners` | `atlas/tests/test_resolution_modules.py:111` | 13 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_modules.py::test_multiple_roots_remain_ambiguous` | `atlas/tests/test_resolution_modules.py:127` | 8 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::test_relative_module_aliases_require_inline_lexical_position` | `atlas/tests/test_resolution_modules.py:137` | 14 | 0 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::test_inline_namespaces_expose_only_direct_symbols_and_import_scopes` | `atlas/tests/test_resolution_modules.py:153` | 12 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::test_module_visibility_syntax_is_preserved` | `atlas/tests/test_resolution_modules.py:167` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_modules.py::test_recursive_path_module_graph_terminates_without_false_root` | `atlas/tests/test_resolution_modules.py:176` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_review_regressions.py::owner_calls` | `atlas/tests/test_resolution_review_regressions.py:14` | 4 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_review_regressions.py::assert_inherits` | `atlas/tests/test_resolution_review_regressions.py:20` | 6 | 3 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_review_regressions.py::owner_call_names` | `atlas/tests/test_resolution_review_regressions.py:28` | 2 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_review_regressions.py::assert_no_nested_macro_targets` | `atlas/tests/test_resolution_review_regressions.py:32` | 5 | 1 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_review_regressions.py::test_java_base_is_looked_up_outside_derived_class_body` | `atlas/tests/test_resolution_review_regressions.py:39` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_review_regressions.py::test_python_future_class_body_bindings_do_not_shadow_base_header` | `atlas/tests/test_resolution_review_regressions.py:44` | 4 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_review_regressions.py::test_namespace_default_and_named_exports_keep_real_keys_without_private_names` | `atlas/tests/test_resolution_review_regressions.py:51` | 7 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_review_regressions.py::test_stringification_unknown_and_overridden_macros_are_not_runtime_calls` | `atlas/tests/test_resolution_review_regressions.py:60` | 10 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_review_regressions.py::test_macro_local_and_nested_bindings_do_not_become_repository_functions` | `atlas/tests/test_resolution_review_regressions.py:72` | 6 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_resolution_review_regressions.py::test_rust_closure_parameter_shadows_bare_function_only_in_callback` | `atlas/tests/test_resolution_review_regressions.py:80` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_resolution_review_regressions.py::test_macro_method_receivers_do_not_become_module_namespaces` | `atlas/tests/test_resolution_review_regressions.py:86` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_rust_root_streaming.py::fallback_entry_sources` | `atlas/tests/test_rust_root_streaming.py:13` | 4 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_rust_root_streaming.py::test_fallback_root_references_are_merged_incrementally` | `atlas/tests/test_rust_root_streaming.py:19` | 31 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_rust_root_streaming.py::test_fallback_root_references_are_merged_incrementally.referenced_files` | `atlas/tests/test_rust_root_streaming.py:28` | 7 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_script_member_coffee_snapshots.py::script_member_snapshot` | `atlas/tests/test_script_member_coffee_snapshots.py:13` | 14 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_script_member_coffee_snapshots.py::test_script_members_match_standalone_snapshot` | `atlas/tests/test_script_member_coffee_snapshots.py:30` | 15 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_script_member_coffee_snapshots.py::assert_script_implementations` | `atlas/tests/test_script_member_coffee_snapshots.py:47` | 12 | 3 | 6 | 6 | 0 | 0 | 2 |
| `atlas/tests/test_script_member_coffee_snapshots.py::assert_dynamic_bases` | `atlas/tests/test_script_member_coffee_snapshots.py:61` | 9 | 3 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/test_semantic_contracts.py::test_macro_inner_calls_have_original_utf8_source_spans_and_hints` | `atlas/tests/test_semantic_contracts.py:10` | 14 | 0 | 8 | 8 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_contracts.py::test_constructor_identity_never_uses_global_type_guessing` | `atlas/tests/test_semantic_contracts.py:30` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_contracts.py::test_java_static_member_import_retains_recipe_identity` | `atlas/tests/test_semantic_contracts.py:38` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_semantic_contracts.py::is_retry_clause` | `atlas/tests/test_semantic_contracts.py:44` | 3 | 2 | 3 | 3 | 0 | 0 | 0 |
| `atlas/tests/test_semantic_contracts.py::retry_candidates` | `atlas/tests/test_semantic_contracts.py:49` | 2 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_contracts.py::assert_other_retry_targets_excluded` | `atlas/tests/test_semantic_contracts.py:53` | 4 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_contracts.py::test_elixir_clause_arity_and_unrelated_modules_remain_ambiguous` | `atlas/tests/test_semantic_contracts.py:59` | 8 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_contracts.py::test_rust_object_dot_is_not_a_module_reference` | `atlas/tests/test_semantic_contracts.py:69` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_semantic_contracts.py::test_receiver_rebinding_and_prototype_replacement` | `atlas/tests/test_semantic_contracts.py:74` | 6 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::repository` | `atlas/tests/test_semantic_resolution.py:13` | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_semantic_resolution.py::call_edges` | `atlas/tests/test_semantic_resolution.py:18` | 3 | 2 | 6 | 6 | 0 | 0 | 2 |
| `atlas/tests/test_semantic_resolution.py::coffee_repository` | `atlas/tests/test_semantic_resolution.py:23` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_semantic_resolution.py::coffee_symbols` | `atlas/tests/test_semantic_resolution.py:27` | 7 | 3 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::coffee_target_keys` | `atlas/tests/test_semantic_resolution.py:36` | 5 | 2 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_semantic_resolution.py::coffee_owner_keys` | `atlas/tests/test_semantic_resolution.py:43` | 5 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::assert_call_source` | `atlas/tests/test_semantic_resolution.py:50` | 6 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::assert_coffee_call` | `atlas/tests/test_semantic_resolution.py:58` | 10 | 2 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::test_coffee_static_imported_and_constructed_calls` | `atlas/tests/test_semantic_resolution.py:99` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_semantic_resolution.py::test_coffee_recursion_preserves_declaration_identity` | `atlas/tests/test_semantic_resolution.py:117` | 6 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::test_coffee_go_named_closure_ownership_and_target` | `atlas/tests/test_semantic_resolution.py:125` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_semantic_resolution.py::ResolutionAssertions.internal` | `atlas/tests/test_semantic_resolution.py:134` | 13 | 3 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::ResolutionAssertions.external` | `atlas/tests/test_semantic_resolution.py:148` | 6 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.project` | `atlas/tests/test_semantic_resolution.py:157` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.unresolved` | `atlas/tests/test_semantic_resolution.py:162` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_python_nonstatic_access_and_unknown_factory_results` | `atlas/tests/test_semantic_resolution.py:168` | 10 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_python_import_shadowing_and_rebinding` | `atlas/tests/test_semantic_resolution.py:179` | 11 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_python_conditional_bindings_do_not_select_house_recipe` | `atlas/tests/test_semantic_resolution.py:191` | 13 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_receiver_rebinding_and_destructuring_preserve_ambiguity` | `atlas/tests/test_semantic_resolution.py:205` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.assert_receiver_ambiguity` | `atlas/tests/test_semantic_resolution.py:213` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_javascript_aliases_defaults_strings_and_unknown_factories` | `atlas/tests/test_semantic_resolution.py:220` | 3 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.assert_javascript_aliases` | `atlas/tests/test_semantic_resolution.py:224` | 20 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_typescript_type_only_and_conflicting_imports` | `atlas/tests/test_semantic_resolution.py:245` | 5 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_javascript_callback_destructuring_shadows_only_callback` | `atlas/tests/test_semantic_resolution.py:251` | 3 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.assert_callback_shadowing` | `atlas/tests/test_semantic_resolution.py:255` | 17 | 2 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_java_declared_packages_same_package_and_static_imports` | `atlas/tests/test_semantic_resolution.py:273` | 16 | 0 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_java_wrong_namespace_and_duplicate_types_are_not_guessed` | `atlas/tests/test_semantic_resolution.py:290` | 14 | 0 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_rust_declared_modules_and_path_relocations` | `atlas/tests/test_semantic_resolution.py:305` | 14 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_rust_duplicate_module_roots_are_ambiguous` | `atlas/tests/test_semantic_resolution.py:320` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_go_rebound_closure_keeps_owner_but_not_target` | `atlas/tests/test_semantic_resolution.py:324` | 7 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_size_report.py::size_config` | `atlas/tests/test_size_report.py:22` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_size_report.py::node` | `atlas/tests/test_size_report.py:27` | 6 | 3 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_size_report.py::test_size_limits_are_strict_and_kind_specific` | `atlas/tests/test_size_report.py:35` | 13 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_size_report.py::assert_receiver_findings` | `atlas/tests/test_size_report.py:50` | 5 | 3 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_size_report.py::test_receivers_decorator_comments_and_attributes_at_parameter_threshold` | `atlas/tests/test_size_report.py:57` | 13 | 1 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_size_report.py::daily_export_source` | `atlas/tests/test_size_report.py:72` | 10 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_size_report.py::test_cli_fresh_and_saved_measurements_match_without_sources` | `atlas/tests/test_size_report.py:84` | 22 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_source_snapshot_fixture.py::test_bytes_paths_and_native_record_order_are_lossless` | `atlas/tests/test_source_snapshot_fixture.py:17` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_source_snapshot_fixture.py::test_only_unordered_collections_are_sorted` | `atlas/tests/test_source_snapshot_fixture.py:25` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_structure.py::names` | `atlas/tests/test_structure.py:13` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_structure.py::StructureTagsTest.setUp` | `atlas/tests/test_structure.py:18` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_structure.py::StructureTagsTest.tearDown` | `atlas/tests/test_structure.py:21` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_uses_bundled_tags_with_graph_metadata_and_nesting` | `atlas/tests/test_structure.py:24` | 28 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_kotlin_private_visibility_discriminator` | `atlas/tests/test_structure.py:53` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_unnamed_companion_is_a_container_without_duplicate_declarations` | `atlas/tests/test_structure.py:60` | 10 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_java_methods_constructors_overloads_and_nested_types` | `atlas/tests/test_structure.py:71` | 21 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_java_private_method_visibility_discriminator` | `atlas/tests/test_structure.py:93` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_java_private_constructor_visibility` | `atlas/tests/test_structure.py:100` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_other_languages_use_the_same_nesting_and_keep_native_metadata` | `atlas/tests/test_structure.py:106` | 30 | 0 | 3 | 3 | 0 | 0 | 2 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_missing_bundled_tags_preserves_native_extraction` | `atlas/tests/test_structure.py:137` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_queries_are_cached_per_language` | `atlas/tests/test_structure.py:144` | 5 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_tsx_coffee.py::assert_workflow_call` | `atlas/tests/test_tsx_coffee.py:24` | 12 | 2 | 7 | 7 | 0 | 0 | 1 |
| `atlas/tests/test_tsx_coffee.py::TsxCoffeeTest.test_component_reference_ownership_and_normal_calls` | `atlas/tests/test_tsx_coffee.py:39` | 9 | 0 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_tsx_coffee.py::TsxCoffeeTest.test_shared_workflow_calls_retain_source_and_owner` | `atlas/tests/test_tsx_coffee.py:49` | 7 | 0 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/test_tsx_coffee.py::test_xml_receipt_intrinsics_fragments_closing_tags_and_shadowing` | `atlas/tests/test_tsx_coffee.py:59` | 8 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_tsx_coffee.py::assert_xml_receipt_references` | `atlas/tests/test_tsx_coffee.py:69` | 12 | 2 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/test_variant_snapshots.py::test_named_project_variants` | `atlas/tests/test_variant_snapshots.py:16` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/test_variant_snapshots.py::assert_scenario_inputs` | `atlas/tests/test_variant_snapshots.py:24` | 5 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_variant_snapshots.py::assert_source_bytes` | `atlas/tests/test_variant_snapshots.py:31` | 7 | 2 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_variant_snapshots.py::test_legacy_c_include_has_actual_grammar_and_native_spans` | `atlas/tests/test_variant_snapshots.py:40` | 12 | 0 | 2 | 2 | 0 | 0 | 0 |
| `atlas/tests/test_variant_snapshots.py::test_excluded_language_files_are_not_detected` | `atlas/tests/test_variant_snapshots.py:55` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/test_variant_snapshots.py::test_excluded_languages_never_reach_pipeline_or_production_graph` | `atlas/tests/test_variant_snapshots.py:61` | 8 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/test_variant_snapshots.py::assert_only_supported_nodes` | `atlas/tests/test_variant_snapshots.py:71` | 3 | 1 | 5 | 5 | 0 | 0 | 1 |
| `atlas/tests/test_variant_snapshots.py::test_each_variant_group_has_a_snapshot` | `atlas/tests/test_variant_snapshots.py:76` | 2 | 0 | 2 | 2 | 0 | 0 | 1 |
| `atlas/tests/update_coffee_snapshots.py::main` | `atlas/tests/update_coffee_snapshots.py:14` | 10 | 0 | 4 | 4 | 0 | 0 | 2 |
| `atlas/tests/update_coffee_snapshots.py::write_navigation` | `atlas/tests/update_coffee_snapshots.py:26` | 8 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/variant_snapshot_support.py::variant_groups` | `atlas/tests/variant_snapshot_support.py:23` | 2 | 0 | 3 | 3 | 0 | 0 | 1 |
| `atlas/tests/variant_snapshot_support.py::variant_snapshot` | `atlas/tests/variant_snapshot_support.py:27` | 8 | 1 | 8 | 8 | 0 | 0 | 2 |
| `atlas/tests/variant_snapshot_support.py::scenario_snapshot` | `atlas/tests/variant_snapshot_support.py:37` | 7 | 1 | 5 | 5 | 0 | 0 | 2 |
| `atlas/tests/variant_snapshot_support.py::legacy_c_snapshot` | `atlas/tests/variant_snapshot_support.py:46` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `atlas/tests/variant_snapshot_support.py::snapshot_records` | `atlas/tests/variant_snapshot_support.py:53` | 19 | 3 | 6 | 6 | 0 | 0 | 1 |
| `atlas/tests/variant_snapshot_support.py::scenario_sources` | `atlas/tests/variant_snapshot_support.py:74` | 6 | 1 | 4 | 4 | 0 | 0 | 1 |
| `atlas/tests/variant_snapshot_support.py::write_variants` | `atlas/tests/variant_snapshot_support.py:82` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/branding.test.ts::<anonymous>` | `dashboard/src/branding.test.ts:4` | 12 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-canvas.tsx::CodeNodeAction` | `dashboard/src/components/graph/graph-canvas.tsx:27` | 23 | 1 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-canvas.tsx::CodeNodeAction.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:39` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::CodeGraphNode` | `dashboard/src/components/graph/graph-canvas.tsx:51` | 16 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasEdges` | `dashboard/src/components/graph/graph-canvas.tsx:78` | 23 | 3 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasEdges.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:83` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasEdges.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:86` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasEdges.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:89` | 11 | 1 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-canvas.tsx::edgeLabel` | `dashboard/src/components/graph/graph-canvas.tsx:102` | 4 | 2 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasEdge` | `dashboard/src/components/graph/graph-canvas.tsx:114` | 24 | 1 | 6 | 6 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasNode` | `dashboard/src/components/graph/graph-canvas.tsx:148` | 27 | 1 | 7 | 7 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas` | `dashboard/src/components/graph/graph-canvas.tsx:176` | 82 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:184` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:186` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:190` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:192` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:197` | 15 | 0 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:200` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:213` | 11 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:214` | 9 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:227` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:242` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:243` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:244` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:245` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-canvas.tsx::GraphCanvas` | `dashboard/src/components/graph/graph-canvas.tsx:259` | 7 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::fixture` | `dashboard/src/components/graph/graph-complexity.test.tsx:16` | 47 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::sidebar` | `dashboard/src/components/graph/graph-complexity.test.tsx:64` | 19 | 3 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:74` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:75` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:78` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:79` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:84` | 18 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:103` | 18 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:122` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-complexity.tsx::GraphComplexity` | `dashboard/src/components/graph/graph-complexity.tsx:3` | 39 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-complexity.tsx::GraphComplexity.<anonymous>` | `dashboard/src/components/graph/graph-complexity.tsx:29` | 7 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles` | `dashboard/src/components/graph/graph-cycles.tsx:12` | 66 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles.<anonymous>` | `dashboard/src/components/graph/graph-cycles.tsx:20` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles.<anonymous>` | `dashboard/src/components/graph/graph-cycles.tsx:39` | 36 | 1 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-cycles.tsx:44` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-cycles.tsx:53` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-cycles.tsx:70` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::fixture` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:12` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:21` | 29 | 3 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:27` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:41` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:42` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:45` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:46` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:58` | 14 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:73` | 15 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:89` | 15 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:105` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-dependency-metrics.tsx::GraphDependencyMetrics` | `dashboard/src/components/graph/graph-dependency-metrics.tsx:3` | 46 | 1 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-dependency-metrics.tsx::GraphDependencyMetrics.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.tsx:19` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-dependency-metrics.tsx::GraphDependencyMetrics.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.tsx:26` | 6 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-explorer.test.tsx::explorerStates` | `dashboard/src/components/graph/graph-explorer.test.tsx:4` | 69 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-explorer.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-explorer.test.tsx:74` | 26 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-explorer.tsx::<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:13` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-explorer.tsx::EmptyGraph` | `dashboard/src/components/graph/graph-explorer.tsx:15` | 22 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphViewport` | `dashboard/src/components/graph/graph-explorer.tsx:38` | 22 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphWorkspace` | `dashboard/src/components/graph/graph-explorer.tsx:61` | 58 | 1 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphWorkspace.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:103` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer` | `dashboard/src/components/graph/graph-explorer.tsx:120` | 91 | 1 | 8 | 8 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.queryFn` | `dashboard/src/components/graph/graph-explorer.tsx:131` | 8 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:152` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:160` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:174` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.select` | `dashboard/src/components/graph/graph-explorer.tsx:175` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.open` | `dashboard/src/components/graph/graph-explorer.tsx:179` | 8 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.navigate` | `dashboard/src/components/graph/graph-explorer.tsx:187` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:200` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:203` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::fixture` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:18` | 47 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::fixture.add` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:20` | 21 | 1 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::fixture.add.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:21` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::summary` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:66` | 8 | 3 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::selectedFile` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:82` | 21 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::selectedFile.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:94` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::selectedFile.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:95` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::selectedFile.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:98` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::selectedFile.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:99` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:104` | 18 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:119` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:123` | 22 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:146` | 10 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:157` | 18 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:163` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:164` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:176` | 11 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:179` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:188` | 19 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:190` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-file-complexity.tsx::complexityHint` | `dashboard/src/components/graph/graph-file-complexity.tsx:3` | 11 | 3 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-file-complexity.tsx::GraphFileComplexity` | `dashboard/src/components/graph/graph-file-complexity.tsx:15` | 25 | 1 | 6 | 6 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-layout.test.ts::<anonymous>` | `dashboard/src/components/graph/graph-layout.test.ts:6` | 8 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-layout.test.ts::<anonymous>` | `dashboard/src/components/graph/graph-layout.test.ts:18` | 7 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-layout.test.ts::expectSeparated` | `dashboard/src/components/graph/graph-layout.test.ts:27` | 13 | 3 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/components/graph/graph-layout.test.ts::<anonymous>` | `dashboard/src/components/graph/graph-layout.test.ts:41` | 11 | 0 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-layout.test.ts::<anonymous>` | `dashboard/src/components/graph/graph-layout.test.ts:53` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph` | `dashboard/src/components/graph/graph-layout.ts:4` | 38 | 1 | 5 | 5 | 0 | 0 | 2 |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph.<anonymous>` | `dashboard/src/components/graph/graph-layout.ts:6` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph.<anonymous>` | `dashboard/src/components/graph/graph-layout.ts:16` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph.<anonymous>` | `dashboard/src/components/graph/graph-layout.ts:30` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph.<anonymous>` | `dashboard/src/components/graph/graph-layout.ts:32` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph.<anonymous>` | `dashboard/src/components/graph/graph-layout.ts:34` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-navigation.tsx::GraphNavigation` | `dashboard/src/components/graph/graph-navigation.tsx:11` | 22 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-navigation.tsx::GraphNavigation.<anonymous>` | `dashboard/src/components/graph/graph-navigation.tsx:17` | 13 | 2 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-navigation.tsx::GraphNavigation.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-navigation.tsx:23` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar` | `dashboard/src/components/graph/graph-sidebar.tsx:32` | 77 | 1 | 8 | 8 | 0 | 0 | 2 |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:42` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:54` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:61` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:62` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:85` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:89` | 8 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::ScopeItem` | `dashboard/src/components/graph/graph-sidebar.tsx:110` | 40 | 1 | 8 | 8 | 0 | 0 | 2 |
| `dashboard/src/components/graph/graph-sidebar.tsx::ScopeItem.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:125` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::ScopeItem.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:141` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::nodeTitle` | `dashboard/src/components/graph/graph-sidebar.tsx:151` | 4 | 2 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeSummary` | `dashboard/src/components/graph/graph-sidebar.tsx:156` | 31 | 1 | 6 | 6 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeSummary.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:175` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeMetrics` | `dashboard/src/components/graph/graph-sidebar.tsx:188` | 14 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails` | `dashboard/src/components/graph/graph-sidebar.tsx:203` | 62 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:211` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:213` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:215` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:222` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:238` | 17 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:245` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::fixture` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:10` | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::fixture.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:12` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::sidebar` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:16` | 21 | 3 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:28` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:29` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:32` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:33` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:38` | 7 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:46` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:54` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:63` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:65` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.tsx::GraphSizeMetrics` | `dashboard/src/components/graph/graph-size-metrics.tsx:3` | 37 | 1 | 6 | 6 | 0 | 0 | 2 |
| `dashboard/src/components/graph/graph-size-metrics.tsx::GraphSizeMetrics.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.tsx:12` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/graph/graph-size-metrics.tsx::GraphSizeMetrics.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.tsx:19` | 6 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/repository-form.tsx::RepositoryForm` | `dashboard/src/components/repository-form.tsx:8` | 77 | 1 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/src/components/repository-form.tsx::RepositoryForm.mutationFn` | `dashboard/src/components/repository-form.tsx:13` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/repository-form.tsx::RepositoryForm.onSuccess` | `dashboard/src/components/repository-form.tsx:19` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/repository-form.tsx::RepositoryForm.<anonymous>` | `dashboard/src/components/repository-form.tsx:27` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/repository-form.tsx::RepositoryForm.<anonymous>` | `dashboard/src/components/repository-form.tsx:49` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/repository-form.tsx::RepositoryForm.<anonymous>` | `dashboard/src/components/repository-form.tsx:62` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/repository-row.tsx::RepositoryRow` | `dashboard/src/components/repository-row.tsx:7` | 28 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/components/ui/badge.tsx::Badge` | `dashboard/src/components/ui/badge.tsx:29` | 14 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/ui/button.tsx::Button` | `dashboard/src/components/ui/button.tsx:41` | 16 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/ui/input.tsx::Input` | `dashboard/src/components/ui/input.tsx:5` | 15 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/ui/primitives.test.tsx::<anonymous>` | `dashboard/src/components/ui/primitives.test.tsx:6` | 29 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/components/ui/primitives.test.tsx::<anonymous>.onClick` | `dashboard/src/components/ui/primitives.test.tsx:7` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/components/ui/primitives.test.tsx::<anonymous>` | `dashboard/src/components/ui/primitives.test.tsx:36` | 19 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/api.ts::api` | `dashboard/src/lib/api.ts:13` | 7 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/api.ts::queryFn` | `dashboard/src/lib/api.ts:23` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/api.ts::formatDate` | `dashboard/src/lib/api.ts:26` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/database.servers.test.ts::<anonymous>` | `dashboard/src/lib/database.servers.test.ts:6` | 20 | 0 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/lib/file-complexity.ts::sumFileComplexity` | `dashboard/src/lib/file-complexity.ts:10` | 26 | 2 | 6 | 6 | 0 | 0 | 2 |
| `dashboard/src/lib/file-complexity.ts::sumFileComplexity.<anonymous>` | `dashboard/src/lib/file-complexity.ts:15` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/file-complexity.ts::sumFileComplexity.<anonymous>` | `dashboard/src/lib/file-complexity.ts:19` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/file-complexity.ts::sumFileComplexity.<anonymous>` | `dashboard/src/lib/file-complexity.ts:20` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/file-complexity.ts::sumFileComplexity.<anonymous>` | `dashboard/src/lib/file-complexity.ts:25` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.test.ts::node` | `dashboard/src/lib/graph-analysis.test.ts:6` | 12 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.test.ts::edge` | `dashboard/src/lib/graph-analysis.test.ts:18` | 9 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:28` | 38 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.test.ts::hierarchyFixture` | `dashboard/src/lib/graph-analysis.test.ts:67` | 38 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-analysis.test.ts::hierarchyFixture.add` | `dashboard/src/lib/graph-analysis.test.ts:69` | 14 | 3 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-analysis.test.ts::hierarchyFixture.add.<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:70` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:106` | 59 | 0 | 6 | 6 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:166` | 27 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:185` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:188` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:189` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:194` | 9 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:196` | 4 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:204` | 25 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::compareKeys` | `dashboard/src/lib/graph-analysis.ts:10` | 10 | 2 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-analysis.ts::finishFrom` | `dashboard/src/lib/graph-analysis.ts:28` | 16 | 1 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-analysis.ts::finishOrder` | `dashboard/src/lib/graph-analysis.ts:45` | 10 | 1 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-analysis.ts::addReverseEdges` | `dashboard/src/lib/graph-analysis.ts:56` | 7 | 3 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-analysis.ts::enqueueUnvisited` | `dashboard/src/lib/graph-analysis.ts:64` | 11 | 3 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-analysis.ts::reverseGroup` | `dashboard/src/lib/graph-analysis.ts:76` | 11 | 3 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-analysis.ts::components` | `dashboard/src/lib/graph-analysis.ts:89` | 14 | 1 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-analysis.ts::components.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:91` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::levelOwners` | `dashboard/src/lib/graph-analysis.ts:104` | 11 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::levelOwners.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:105` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::levelOwners.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:107` | 6 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::levelOwners.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:110` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::impactCounts` | `dashboard/src/lib/graph-analysis.ts:116` | 27 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::impactCounts.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:119` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::impactCounts.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:119` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::impactCounts.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:124` | 17 | 2 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-analysis.ts::impactCounts.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:133` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::impactCounts.<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:134` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::levelAdjacency` | `dashboard/src/lib/graph-analysis.ts:144` | 21 | 3 | 5 | 5 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-analysis.ts::levelAdjacency.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:152` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::levelAdjacency.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:153` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::levelAdjacency.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:162` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::countIncoming` | `dashboard/src/lib/graph-analysis.ts:166` | 4 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-analysis.ts::addLevelMetrics` | `dashboard/src/lib/graph-analysis.ts:171` | 18 | 2 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-analysis.ts::internalNodes` | `dashboard/src/lib/graph-analysis.ts:191` | 13 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::internalNodes.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:194` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::internalNodes.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:195` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::internalNodes.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:198` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::internalNodes.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:199` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-analysis.ts::dependencyMetrics` | `dashboard/src/lib/graph-analysis.ts:206` | 10 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-cycles.test.ts::node` | `dashboard/src/lib/graph-cycles.test.ts:14` | 19 | 3 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-cycles.test.ts::fixture` | `dashboard/src/lib/graph-cycles.test.ts:33` | 34 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::fixture.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:37` | 6 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::group` | `dashboard/src/lib/graph-cycles.test.ts:67` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:70` | 12 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:75` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:83` | 14 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:98` | 13 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:112` | 12 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:125` | 12 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:127` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:138` | 28 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:140` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:162` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:167` | 17 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:182` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:185` | 8 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::owningFile` | `dashboard/src/lib/graph-cycles.ts:15` | 10 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::owningFile.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:19` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::owningFile.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:22` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::cycleContainsNode` | `dashboard/src/lib/graph-cycles.ts:26` | 13 | 3 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-cycles.ts::cycleContainsNode.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:34` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope` | `dashboard/src/lib/graph-cycles.ts:40` | 22 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:44` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:45` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:50` | 9 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:51` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:53` | 5 | 1 | 4 | 4 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles` | `dashboard/src/lib/graph-cycles.ts:64` | 66 | 3 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:71` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:73` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:75` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:75` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:76` | 43 | 1 | 8 | 8 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:81` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:83` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:106` | 4 | 1 | 3 | 3 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:120` | 8 | 1 | 3 | 3 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:124` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-details-test.helpers.ts::fixtureDetails` | `dashboard/src/lib/graph-details-test.helpers.ts:5` | 11 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-details-test.helpers.ts::fixtureDetails.<anonymous>` | `dashboard/src/lib/graph-details-test.helpers.ts:9` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-details-test.helpers.ts::fixtureDetails.<anonymous>` | `dashboard/src/lib/graph-details-test.helpers.ts:10` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-test-path.ts::isTestPath` | `dashboard/src/lib/graph-test-path.ts:2` | 23 | 2 | 8 | 8 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-test-path.ts::isTestPath.<anonymous>` | `dashboard/src/lib/graph-test-path.ts:6` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-traversal.ts::pushChildren` | `dashboard/src/lib/graph-traversal.ts:4` | 8 | 3 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:23` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:33` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:35` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.test.ts::node` | `dashboard/src/lib/graph-visibility.test.ts:48` | 19 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-visibility.test.ts::fixture` | `dashboard/src/lib/graph-visibility.test.ts:68` | 43 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:112` | 26 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:116` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:128` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:134` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:139` | 28 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:153` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:157` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.ts::isFolder` | `dashboard/src/lib/graph-visibility.ts:8` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.ts::isTestNode` | `dashboard/src/lib/graph-visibility.ts:11` | 4 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-visibility.ts::hideEmptyFolder` | `dashboard/src/lib/graph-visibility.ts:16` | 12 | 3 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/graph-visibility.ts::hideEmptyFolder.<anonymous>` | `dashboard/src/lib/graph-visibility.ts:24` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.ts::hideTestFiles` | `dashboard/src/lib/graph-visibility.ts:30` | 30 | 1 | 6 | 6 | 0 | 0 | 2 |
| `dashboard/src/lib/graph-visibility.ts::hideTestFiles.<anonymous>` | `dashboard/src/lib/graph-visibility.ts:53` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/graph-visibility.ts::hideTestFiles.<anonymous>` | `dashboard/src/lib/graph-visibility.ts:55` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::pythonJson` | `dashboard/src/lib/import-cycles.servers.ts:11` | 14 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/import-cycles.servers.ts::pythonJson.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:15` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::pythonJson.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:16` | 1 | 2 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/import-cycles.servers.ts::pythonJson.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:17` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::pythonJson.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:21` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::fileOwners` | `dashboard/src/lib/import-cycles.servers.ts:26` | 22 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::fileOwners.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:27` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::fileOwners.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:29` | 17 | 1 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/lib/import-cycles.servers.ts::fileOwners.<anonymous>.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:31` | 8 | 1 | 3 | 3 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::projectImport` | `dashboard/src/lib/import-cycles.servers.ts:49` | 24 | 2 | 8 | 8 | 0 | 0 | 1 |
| `dashboard/src/lib/import-cycles.servers.ts::projectImports` | `dashboard/src/lib/import-cycles.servers.ts:74` | 12 | 2 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/import-cycles.servers.ts::projectImports.sortKey` | `dashboard/src/lib/import-cycles.servers.ts:81` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::projectImports.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:82` | 2 | 2 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/import-cycles.servers.ts::cyclePath` | `dashboard/src/lib/import-cycles.servers.ts:87` | 9 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/import-cycles.servers.ts::cycleNeighbors` | `dashboard/src/lib/import-cycles.servers.ts:106` | 16 | 1 | 5 | 5 | 0 | 0 | 2 |
| `dashboard/src/lib/import-cycles.servers.ts::exampleCycle` | `dashboard/src/lib/import-cycles.servers.ts:123` | 26 | 2 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/lib/import-cycles.servers.ts::exampleCycle.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:132` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles` | `dashboard/src/lib/import-cycles.servers.ts:151` | 38 | 2 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:167` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:171` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:174` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:175` | 13 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:182` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/imported-artifact-fixture.ts::importedArtifact` | `dashboard/src/lib/imported-artifact-fixture.ts:45` | 30 | 0 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/imported-artifact-fixture.ts::largeArtifact` | `dashboard/src/lib/imported-artifact-fixture.ts:77` | 59 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/imported-artifact-fixture.ts::largeArtifact.add` | `dashboard/src/lib/imported-artifact-fixture.ts:88` | 30 | 3 | 7 | 7 | 0 | 0 | 2 |
| `dashboard/src/lib/imported-artifact-fixture.ts::largeArtifact.<anonymous>` | `dashboard/src/lib/imported-artifact-fixture.ts:122` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/imported-artifact-fixture.ts::largeArtifact.<anonymous>` | `dashboard/src/lib/imported-artifact-fixture.ts:124` | 8 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/imported-artifact-fixture.ts::largeArtifact.<anonymous>.<anonymous>` | `dashboard/src/lib/imported-artifact-fixture.ts:125` | 7 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/imported-artifact-fixture.ts::addFiles` | `dashboard/src/lib/imported-artifact-fixture.ts:143` | 4 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/imported-artifact-fixture.ts::addFunctions` | `dashboard/src/lib/imported-artifact-fixture.ts:148` | 4 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::python` | `dashboard/src/lib/normalized-graph.servers.test.ts:30` | 7 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:37` | 11 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:48` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::ready` | `dashboard/src/lib/normalized-graph.servers.test.ts:53` | 5 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::save` | `dashboard/src/lib/normalized-graph.servers.test.ts:58` | 19 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::fixture` | `dashboard/src/lib/normalized-graph.servers.test.ts:84` | 92 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::fixture.add` | `dashboard/src/lib/normalized-graph.servers.test.ts:86` | 19 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::fixture.add.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:87` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails` | `dashboard/src/lib/normalized-graph.servers.test.ts:177` | 53 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:178` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:186` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:204` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:207` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:209` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectMetrics` | `dashboard/src/lib/normalized-graph.servers.test.ts:231` | 13 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectAnalyzedDetails` | `dashboard/src/lib/normalized-graph.servers.test.ts:245` | 12 | 2 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectAnalyzedDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:248` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::enqueueScopes` | `dashboard/src/lib/normalized-graph.servers.test.ts:258` | 10 | 2 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::enqueueScopes.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:263` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:269` | 79 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:316` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:321` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:335` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:338` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:345` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:349` | 53 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:388` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:389` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:392` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:393` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:403` | 21 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.edge` | `dashboard/src/lib/normalized-graph.servers.test.ts:405` | 11 | 3 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:425` | 53 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:474` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:479` | 52 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:481` | 16 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:501` | 6 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:511` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:514` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:520` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:523` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:532` | 26 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:551` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:554` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/connection.ts::defaultDatabasePath` | `dashboard/src/lib/persistence/repositories/connection.ts:11` | 6 | 0 | 3 | 3 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/connection.ts::openConnection` | `dashboard/src/lib/persistence/repositories/connection.ts:19` | 10 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/connection.ts::openConnection.close` | `dashboard/src/lib/persistence/repositories/connection.ts:27` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/factory.ts::createRepositoryContext` | `dashboard/src/lib/persistence/repositories/factory.ts:7` | 11 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/factory.ts::createRepositoryContext.register` | `dashboard/src/lib/persistence/repositories/factory.ts:12` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/factory.ts::createRepositoryContext.list` | `dashboard/src/lib/persistence/repositories/factory.ts:13` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/factory.ts::createRepositoryContext.view` | `dashboard/src/lib/persistence/repositories/factory.ts:14` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/factory.ts::createRepositoryContext.close` | `dashboard/src/lib/persistence/repositories/factory.ts:15` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/factory.ts::repositoryDatabasePath` | `dashboard/src/lib/persistence/repositories/factory.ts:19` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::identity` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:17` | 7 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::selectedRows` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:26` | 9 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.constructor` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:37` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.metadata` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:39` | 18 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.topology` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:58` | 21 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:80` | 33 | 3 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing.read` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:81` | 13 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:100` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:104` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:108` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:110` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.relations` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:114` | 13 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.imports` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:128` | 14 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.metrics` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:143` | 33 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.metrics.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:144` | 30 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.decorators` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:177` | 18 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.decorators.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:178` | 15 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.complexities` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:196` | 17 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.complexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:197` | 14 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.diagnostics` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:214` | 13 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::compactProperties` | `dashboard/src/lib/persistence/repositories/graph-store.ts:22` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::compactProperties.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:23` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::hierarchy` | `dashboard/src/lib/persistence/repositories/graph-store.ts:25` | 16 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::hierarchy.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:26` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::hierarchy.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:27` | 13 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.constructor` | `dashboard/src/lib/persistence/repositories/graph-store.ts:45` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.view` | `dashboard/src/lib/persistence/repositories/graph-store.ts:49` | 6 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.view.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:51` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.details` | `dashboard/src/lib/persistence/repositories/graph-store.ts:56` | 46 | 3 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.details.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:92` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.details.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:93` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities` | `dashboard/src/lib/persistence/repositories/graph-store.ts:103` | 40 | 3 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:111` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:112` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:118` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:119` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:123` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:128` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:130` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView` | `dashboard/src/lib/persistence/repositories/graph-store.ts:144` | 73 | 2 | 7 | 7 | 0 | 0 | 2 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:161` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:163` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:178` | 11 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:182` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:183` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:186` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:187` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:191` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:198` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/repository-store.ts::RepositoryStore.constructor` | `dashboard/src/lib/persistence/repositories/repository-store.ts:8` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/repository-store.ts::RepositoryStore.register` | `dashboard/src/lib/persistence/repositories/repository-store.ts:10` | 10 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/persistence/repositories/repository-store.ts::RepositoryStore.list` | `dashboard/src/lib/persistence/repositories/repository-store.ts:21` | 22 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/repository-store.ts::RepositoryStore.list.<anonymous>` | `dashboard/src/lib/persistence/repositories/repository-store.ts:38` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/persistence/repositories/schema.ts::nodeIdentity` | `dashboard/src/lib/persistence/repositories/schema.ts:19` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:37` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:46` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:59` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:73` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:82` | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:102` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:114` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::fixture` | `dashboard/src/lib/project-graph-boundary.test.ts:5` | 41 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::fixture.add` | `dashboard/src/lib/project-graph-boundary.test.ts:7` | 17 | 3 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph-boundary.test.ts::fixture.add.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:8` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::link` | `dashboard/src/lib/project-graph-boundary.test.ts:54` | 8 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::ids` | `dashboard/src/lib/project-graph-boundary.test.ts:63` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::ids.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:64` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:66` | 44 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:94` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:100` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:105` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:107` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:111` | 36 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:128` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:137` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:142` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::addExternalChild` | `dashboard/src/lib/project-graph-boundary.test.ts:148` | 13 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::addExternalChild.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:149` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:162` | 31 | 0 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:164` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:181` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:182` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:187` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:194` | 29 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:196` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:199` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:217` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.ts::isFolder` | `dashboard/src/lib/project-graph-boundary.ts:6` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.ts::boundaryTarget` | `dashboard/src/lib/project-graph-boundary.ts:9` | 32 | 3 | 8 | 8 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph-boundary.ts::boundaryTarget.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:15` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.ts::boundaryTarget.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:18` | 6 | 1 | 6 | 6 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.ts::boundaryTarget.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:31` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.ts::boundaryTarget.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:32` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.ts::renderBoundary` | `dashboard/src/lib/project-graph-boundary.ts:42` | 20 | 3 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph-boundary.ts::renderBoundary.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:51` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.ts::renderBoundary.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:53` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.ts::isBoundaryEdge` | `dashboard/src/lib/project-graph-boundary.ts:63` | 7 | 2 | 3 | 3 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.ts::addBoundaryDependencies` | `dashboard/src/lib/project-graph-boundary.ts:80` | 31 | 1 | 7 | 7 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph-boundary.ts::addBoundaryDependencies.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:88` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-boundary.ts::addBoundaryDependencies.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:89` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-fixture.ts::fixtureNodes` | `dashboard/src/lib/project-graph-fixture.ts:10` | 76 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-fixture.ts::fixtureNodes.add` | `dashboard/src/lib/project-graph-fixture.ts:13` | 30 | 1 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::canAlias` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:5` | 16 | 2 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::canAlias.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:12` | 4 | 1 | 3 | 3 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::registerFolderAliases` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:30` | 13 | 1 | 5 | 5 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::projectAncestors` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:44` | 21 | 3 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::projectAncestors.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:54` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::projectAncestors.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:60` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectedEdges` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:66` | 18 | 2 | 6 | 6 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:86` | 27 | 3 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:91` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:92` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:93` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:94` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:101` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::recordReachableNodes` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:121` | 12 | 1 | 5 | 5 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectNavigableTrail` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:134` | 8 | 3 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectNavigableTrail.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:140` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::enqueueFolders` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:143` | 7 | 2 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:7` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:11` | 26 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:14` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:17` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:23` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:32` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:38` | 61 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:51` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:55` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:59` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:65` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:69` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:76` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:78` | 2 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:86` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:90` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:94` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:97` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-test.helpers.ts::buildProjectGraph` | `dashboard/src/lib/project-graph-test.helpers.ts:6` | 9 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-test.helpers.ts::buildProjectGraph.<anonymous>` | `dashboard/src/lib/project-graph-test.helpers.ts:11` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-test.helpers.ts::buildProjectGraph.<anonymous>` | `dashboard/src/lib/project-graph-test.helpers.ts:12` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-test.helpers.ts::buildProjectGraph.<anonymous>` | `dashboard/src/lib/project-graph-test.helpers.ts:13` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-test.helpers.ts::ids` | `dashboard/src/lib/project-graph-test.helpers.ts:16` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph-test.helpers.ts::ids.<anonymous>` | `dashboard/src/lib/project-graph-test.helpers.ts:17` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:15` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::fixture` | `dashboard/src/lib/project-graph.test.ts:19` | 49 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::fixture.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:22` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::fixture.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:23` | 6 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::fixture.link` | `dashboard/src/lib/project-graph.test.ts:29` | 7 | 3 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::tree` | `dashboard/src/lib/project-graph.test.ts:69` | 23 | 1 | 5 | 5 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.test.ts::tree.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:74` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::relation` | `dashboard/src/lib/project-graph.test.ts:93` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::relation.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:94` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::expectRelations` | `dashboard/src/lib/project-graph.test.ts:103` | 17 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::expectRelations.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:114` | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:121` | 73 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:122` | 37 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:125` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:129` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:159` | 34 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:165` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:169` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:195` | 74 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:196` | 27 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:200` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:223` | 45 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:231` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:234` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:270` | 22 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:282` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:283` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:293` | 16 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:295` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:310` | 30 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:313` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:314` | 12 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:320` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:323` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:327` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:329` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:341` | 27 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:344` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:370` | 35 | 0 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:394` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:395` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:400` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:401` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:407` | 63 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:444` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:452` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:471` | 14 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:486` | 15 | 0 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:502` | 24 | 0 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:515` | 7 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:527` | 20 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:543` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:544` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:548` | 15 | 0 | 5 | 5 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.ts::isExternal` | `dashboard/src/lib/project-graph.ts:22` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::isFolder` | `dashboard/src/lib/project-graph.ts:24` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::isFile` | `dashboard/src/lib/project-graph.ts:26` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::indexChildren` | `dashboard/src/lib/project-graph.ts:28` | 9 | 1 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.ts::descendants` | `dashboard/src/lib/project-graph.ts:38` | 13 | 2 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.ts::isTransparent` | `dashboard/src/lib/project-graph.ts:52` | 3 | 1 | 4 | 4 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::rootNodes` | `dashboard/src/lib/project-graph.ts:56` | 14 | 1 | 6 | 6 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.ts::scopeNode` | `dashboard/src/lib/project-graph.ts:71` | 20 | 2 | 8 | 8 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.ts::scopeNode.<anonymous>` | `dashboard/src/lib/project-graph.ts:75` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::scopeNode.<anonymous>` | `dashboard/src/lib/project-graph.ts:76` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::scopeNode.<anonymous>` | `dashboard/src/lib/project-graph.ts:79` | 4 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::visibleNodes` | `dashboard/src/lib/project-graph.ts:92` | 15 | 3 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph.ts::visibleNodes.<anonymous>` | `dashboard/src/lib/project-graph.ts:101` | 1 | 1 | 3 | 3 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::visibleNodes.<anonymous>` | `dashboard/src/lib/project-graph.ts:104` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::compactChain` | `dashboard/src/lib/project-graph.ts:108` | 15 | 2 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.ts::compactChain.<anonymous>` | `dashboard/src/lib/project-graph.ts:115` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::nodeLabel` | `dashboard/src/lib/project-graph.ts:124` | 2 | 1 | 3 | 3 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::sourceLines` | `dashboard/src/lib/project-graph.ts:127` | 8 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/project-graph.ts::graphNode` | `dashboard/src/lib/project-graph.ts:136` | 36 | 2 | 5 | 5 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.ts::projectNodes` | `dashboard/src/lib/project-graph.ts:173` | 10 | 2 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.ts::aggregateEdges` | `dashboard/src/lib/project-graph.ts:184` | 26 | 3 | 6 | 6 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.ts::buildProjectGraph` | `dashboard/src/lib/project-graph.ts:218` | 34 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::buildProjectGraph.render` | `dashboard/src/lib/project-graph.ts:224` | 15 | 2 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.ts::buildProjectGraph.render.<anonymous>` | `dashboard/src/lib/project-graph.ts:234` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::buildProjectGraph.<anonymous>` | `dashboard/src/lib/project-graph.ts:239` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/project-graph.ts::getGraphTrail` | `dashboard/src/lib/project-graph.ts:254` | 21 | 2 | 7 | 7 | 0 | 0 | 2 |
| `dashboard/src/lib/project-graph.ts::getGraphTrail.<anonymous>` | `dashboard/src/lib/project-graph.ts:263` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::openDatabase` | `dashboard/src/lib/repositories.servers.test.ts:27` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::registerRepository` | `dashboard/src/lib/repositories.servers.test.ts:29` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::listRepositories` | `dashboard/src/lib/repositories.servers.test.ts:31` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::getArchitecture` | `dashboard/src/lib/repositories.servers.test.ts:32` | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::ready` | `dashboard/src/lib/repositories.servers.test.ts:35` | 10 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/repositories.servers.test.ts::fileView` | `dashboard/src/lib/repositories.servers.test.ts:45` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::python` | `dashboard/src/lib/repositories.servers.test.ts:48` | 14 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:63` | 7 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:71` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:77` | 34 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:112` | 16 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:114` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:121` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:129` | 23 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:131` | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:143` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:145` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:148` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:153` | 59 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:165` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:170` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:172` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:181` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:197` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:209` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:213` | 21 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:223` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:230` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:235` | 23 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:259` | 30 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:274` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:281` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:286` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:290` | 24 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:311` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:315` | 38 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:327` | 15 | 1 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:350` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:354` | 11 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/repositories.servers.ts::RepositoryError.constructor` | `dashboard/src/lib/repositories.servers.ts:10` | 7 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.ts::requiredText` | `dashboard/src/lib/repositories.servers.ts:19` | 11 | 3 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/repositories.servers.ts::register` | `dashboard/src/lib/repositories.servers.ts:31` | 16 | 2 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/src/lib/repositories.servers.ts::createRepositoryService` | `dashboard/src/lib/repositories.servers.ts:49` | 18 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.ts::createRepositoryService.registerRepository` | `dashboard/src/lib/repositories.servers.ts:52` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.ts::createRepositoryService.listRepositories` | `dashboard/src/lib/repositories.servers.ts:53` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.ts::createRepositoryService.getArchitecture` | `dashboard/src/lib/repositories.servers.ts:54` | 10 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/lib/repositories.servers.ts::createRepositoryService.close` | `dashboard/src/lib/repositories.servers.ts:64` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.ts::defaultDatabasePath` | `dashboard/src/lib/repositories.servers.ts:69` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.ts::getService` | `dashboard/src/lib/repositories.servers.ts:71` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.ts::registerRepository` | `dashboard/src/lib/repositories.servers.ts:72` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.ts::listRepositories` | `dashboard/src/lib/repositories.servers.ts:74` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.ts::getArchitecture` | `dashboard/src/lib/repositories.servers.ts:75` | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/lib/repositories.servers.ts::architectureScope` | `dashboard/src/lib/repositories.servers.ts:78` | 7 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/lib/repositories.servers.ts::repositoryErrorResponse` | `dashboard/src/lib/repositories.servers.ts:86` | 8 | 1 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/lib/utils.ts::cn` | `dashboard/src/lib/utils.ts:5` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/router.tsx::getRouter` | `dashboard/src/router.tsx:7` | 7 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/__root.tsx::head` | `dashboard/src/routes/__root.tsx:15` | 17 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/__root.tsx::notFoundComponent` | `dashboard/src/routes/__root.tsx:34` | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/__root.tsx::errorComponent` | `dashboard/src/routes/__root.tsx:40` | 9 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/routes/__root.tsx::RootDocument` | `dashboard/src/routes/__root.tsx:52` | 13 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/__root.tsx::RootComponent` | `dashboard/src/routes/__root.tsx:66` | 22 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/api/architecture.ts::GET` | `dashboard/src/routes/api/architecture.ts:11` | 16 | 1 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/routes/api/repositories.ts::GET` | `dashboard/src/routes/api/repositories.ts:11` | 7 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/routes/api/repositories.ts::POST` | `dashboard/src/routes/api/repositories.ts:18` | 13 | 1 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/routes/graph-project-name.test.ts::renderRoute` | `dashboard/src/routes/graph-project-name.test.ts:4` | 25 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/src/routes/graph-project-name.test.ts::<anonymous>` | `dashboard/src/routes/graph-project-name.test.ts:30` | 11 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/graph-project-name.test.ts::<anonymous>` | `dashboard/src/routes/graph-project-name.test.ts:42` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/graph-project-name.test.ts::<anonymous>` | `dashboard/src/routes/graph-project-name.test.ts:47` | 12 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/graph.$repositoryId.tsx::GraphPage` | `dashboard/src/routes/graph.$repositoryId.tsx:14` | 49 | 0 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/src/routes/graph.$repositoryId.tsx::GraphPage.queryFn` | `dashboard/src/routes/graph.$repositoryId.tsx:19` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/graph.$repositoryId.tsx::GraphPage.<anonymous>` | `dashboard/src/routes/graph.$repositoryId.tsx:26` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/graph.$repositoryId.tsx::GraphPage.refresh` | `dashboard/src/routes/graph.$repositoryId.tsx:28` | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/graph.$repositoryId.tsx::GraphContent` | `dashboard/src/routes/graph.$repositoryId.tsx:64` | 51 | 1 | 8 | 8 | 0 | 0 | 0 |
| `dashboard/src/routes/graph.$repositoryId.tsx::WaitingForImport` | `dashboard/src/routes/graph.$repositoryId.tsx:116` | 13 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/index.tsx::AddRepositoryButton` | `dashboard/src/routes/index.tsx:12` | 14 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/src/routes/index.tsx::RepositoriesPage` | `dashboard/src/routes/index.tsx:27` | 62 | 0 | 7 | 7 | 0 | 0 | 0 |
| `dashboard/src/routes/index.tsx::RepositoriesPage.<anonymous>` | `dashboard/src/routes/index.tsx:34` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/index.tsx::RepositoriesPage.<anonymous>` | `dashboard/src/routes/index.tsx:47` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/index.tsx::RepositoriesPage.<anonymous>` | `dashboard/src/routes/index.tsx:61` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/routes/index.tsx::RepositoriesPage.<anonymous>` | `dashboard/src/routes/index.tsx:81` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/server.ts::fetch` | `dashboard/src/server.ts:4` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/start.ts::<anonymous>` | `dashboard/src/start.ts:3` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/src/test.setup.ts::<anonymous>` | `dashboard/src/test.setup.ts:8` | 1 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-access-policy.ts::pragmaCall` | `dashboard/tests/database-access-policy.ts:21` | 8 | 2 | 4 | 4 | 0 | 0 | 0 |
| `dashboard/tests/database-access-policy.ts::sensitiveOwner` | `dashboard/tests/database-access-policy.ts:29` | 4 | 2 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/tests/database-access-policy.ts::checkRawAccess` | `dashboard/tests/database-access-policy.ts:33` | 8 | 2 | 8 | 8 | 0 | 0 | 1 |
| `dashboard/tests/database-access-policy.ts::checkOrmAccess` | `dashboard/tests/database-access-policy.ts:41` | 13 | 2 | 7 | 7 | 0 | 0 | 1 |
| `dashboard/tests/database-access-policy.ts::checkWriteAccess` | `dashboard/tests/database-access-policy.ts:54` | 9 | 2 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/tests/database-access-policy.ts::checkOperationAccess` | `dashboard/tests/database-access-policy.ts:63` | 12 | 2 | 6 | 6 | 0 | 0 | 1 |
| `dashboard/tests/database-access-policy.ts::checkComputedBinding` | `dashboard/tests/database-access-policy.ts:75` | 11 | 2 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/tests/database-access-policy.ts::invokedAccess` | `dashboard/tests/database-access-policy.ts:86` | 6 | 1 | 3 | 3 | 0 | 0 | 0 |
| `dashboard/tests/database-access-policy.ts::checkComputedAccess` | `dashboard/tests/database-access-policy.ts:92` | 13 | 2 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/tests/database-access-policy.ts::checkAccess` | `dashboard/tests/database-access-policy.ts:105` | 9 | 2 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/tests/database-architecture.test.ts::productionFiles` | `dashboard/tests/database-architecture.test.ts:14` | 14 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.test.ts::productionFiles.<anonymous>` | `dashboard/tests/database-architecture.test.ts:15` | 12 | 1 | 6 | 6 | 0 | 0 | 2 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:29` | 10 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-architecture.test.ts:31` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-architecture.test.ts:32` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-architecture.test.ts:34` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:40` | 11 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:118` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:124` | 14 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:139` | 12 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-architecture.test.ts:146` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:152` | 39 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-architecture.test.ts::serviceProgram` | `dashboard/tests/database-architecture.test.ts:192` | 17 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.test.ts::serviceProgram.getSourceFile` | `dashboard/tests/database-architecture.test.ts:202` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:209` | 10 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-architecture.ts::sensitiveValue` | `dashboard/tests/database-architecture.ts:22` | 10 | 2 | 3 | 3 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.ts::trackBinding` | `dashboard/tests/database-architecture.ts:32` | 15 | 2 | 7 | 7 | 0 | 0 | 1 |
| `dashboard/tests/database-architecture.ts::sensitiveBindings` | `dashboard/tests/database-architecture.ts:47` | 26 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.ts::sensitiveBindings.visit` | `dashboard/tests/database-architecture.ts:66` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.ts::checkSql` | `dashboard/tests/database-architecture.ts:73` | 12 | 3 | 7 | 7 | 0 | 0 | 1 |
| `dashboard/tests/database-architecture.ts::checkIdentifier` | `dashboard/tests/database-architecture.ts:85` | 24 | 3 | 7 | 7 | 0 | 0 | 1 |
| `dashboard/tests/database-architecture.ts::checkReferences` | `dashboard/tests/database-architecture.ts:109` | 8 | 3 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/tests/database-architecture.ts::auditSource` | `dashboard/tests/database-architecture.ts:118` | 24 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.ts::auditSource.report` | `dashboard/tests/database-architecture.ts:127` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-architecture.ts::auditSource.visit` | `dashboard/tests/database-architecture.ts:132` | 7 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::fixtureProgram` | `dashboard/tests/database-boundary-regressions.test.ts:23` | 18 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::fixtureProgram.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:25` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::fixtureProgram.getSourceFile` | `dashboard/tests/database-boundary-regressions.test.ts:29` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-boundary-regressions.test.ts::fixtureProgram.fileExists` | `dashboard/tests/database-boundary-regressions.test.ts:37` | 1 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::fixtureProgram.readFile` | `dashboard/tests/database-boundary-regressions.test.ts:38` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::dependencyErrors` | `dashboard/tests/database-boundary-regressions.test.ts:42` | 19 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::dependencyErrors.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:44` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::dependencyErrors.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:49` | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::dependencyErrors.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:53` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::dependencyErrors.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:57` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:80` | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:86` | 10 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:103` | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:107` | 16 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:118` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:131` | 7 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:139` | 28 | 0 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:162` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:168` | 25 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:187` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:194` | 9 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:204` | 17 | 0 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:210` | 5 | 1 | 4 | 4 | 0 | 0 | 0 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:218` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::ownsRepositoryDependencies` | `dashboard/tests/database-dependency-policy.ts:4` | 9 | 1 | 4 | 4 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::applicationDeclaration` | `dashboard/tests/database-dependency-policy.ts:14` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::structuralPort` | `dashboard/tests/database-dependency-policy.ts:18` | 12 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::structuralPort.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:19` | 10 | 1 | 3 | 3 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::referencedTypes` | `dashboard/tests/database-dependency-policy.ts:31` | 8 | 2 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/tests/database-dependency-policy.ts::dependencyBinding` | `dashboard/tests/database-dependency-policy.ts:40` | 9 | 1 | 5 | 5 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector` | `dashboard/tests/database-dependency-policy.ts:50` | 54 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect` | `dashboard/tests/database-dependency-policy.ts:51` | 51 | 2 | 8 | 8 | 0 | 0 | 1 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:63` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:69` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:73` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:78` | 13 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:81` | 9 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:94` | 7 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::argumentValue` | `dashboard/tests/database-dependency-policy.ts:105` | 8 | 1 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInitializer` | `dashboard/tests/database-dependency-policy.ts:114` | 8 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/tests/database-dependency-policy.ts::dependencyAssignments` | `dashboard/tests/database-dependency-policy.ts:123` | 19 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::dependencyAssignments.visit` | `dashboard/tests/database-dependency-policy.ts:125` | 14 | 1 | 4 | 4 | 0 | 0 | 2 |
| `dashboard/tests/database-dependency-policy.ts::valueInspector` | `dashboard/tests/database-dependency-policy.ts:143` | 24 | 3 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::valueInspector.inspect` | `dashboard/tests/database-dependency-policy.ts:149` | 16 | 2 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/tests/database-dependency-policy.ts::valueInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:163` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::externalCall` | `dashboard/tests/database-dependency-policy.ts:168` | 10 | 2 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::auditRepositoryDependencies` | `dashboard/tests/database-dependency-policy.ts:180` | 35 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::auditRepositoryDependencies.report` | `dashboard/tests/database-dependency-policy.ts:189` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-dependency-policy.ts::auditRepositoryDependencies.visit` | `dashboard/tests/database-dependency-policy.ts:193` | 19 | 1 | 8 | 8 | 0 | 0 | 2 |
| `dashboard/tests/database-dependency-policy.ts::auditRepositoryDependencies.visit.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:201` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-factory-boundary.test.ts::<anonymous>` | `dashboard/tests/database-factory-boundary.test.ts:12` | 20 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-factory-boundary.test.ts::<anonymous>` | `dashboard/tests/database-factory-boundary.test.ts:33` | 43 | 0 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-factory-boundary.test.ts::<anonymous>.getSourceFile` | `dashboard/tests/database-factory-boundary.test.ts:57` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-factory-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-factory-boundary.test.ts:74` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-module-policy.ts::modulePath` | `dashboard/tests/database-module-policy.ts:14` | 7 | 2 | 3 | 3 | 0 | 0 | 2 |
| `dashboard/tests/database-module-policy.ts::permittedFactory` | `dashboard/tests/database-module-policy.ts:21` | 14 | 2 | 6 | 6 | 0 | 0 | 1 |
| `dashboard/tests/database-module-policy.ts::permittedFactory.<anonymous>` | `dashboard/tests/database-module-policy.ts:30` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-module-policy.ts::checkRepositoryModule` | `dashboard/tests/database-module-policy.ts:36` | 19 | 2 | 7 | 7 | 0 | 0 | 1 |
| `dashboard/tests/database-module-policy.ts::checkServiceFactory` | `dashboard/tests/database-module-policy.ts:55` | 7 | 2 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/tests/database-module-policy.ts::checkPortModule` | `dashboard/tests/database-module-policy.ts:62` | 8 | 2 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/tests/database-module-policy.ts::checkRepositoryOwner` | `dashboard/tests/database-module-policy.ts:70` | 4 | 2 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/tests/database-module-policy.ts::checkDriverModule` | `dashboard/tests/database-module-policy.ts:74` | 13 | 2 | 6 | 6 | 0 | 0 | 1 |
| `dashboard/tests/database-module-policy.ts::checkModule` | `dashboard/tests/database-module-policy.ts:87` | 10 | 2 | 6 | 6 | 0 | 0 | 1 |
| `dashboard/tests/database-module-policy.ts::checkOrmModule` | `dashboard/tests/database-module-policy.ts:97` | 12 | 2 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/tests/database-module-policy.ts::checkOrmModule.visit` | `dashboard/tests/database-module-policy.ts:102` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/tests/database-module-policy.ts::checkOrmNamespace` | `dashboard/tests/database-module-policy.ts:109` | 9 | 2 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/tests/database-service-exports.ts::typeDeclarations` | `dashboard/tests/database-service-exports.ts:3` | 6 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::persistenceDeclaration` | `dashboard/tests/database-service-exports.ts:9` | 11 | 1 | 5 | 5 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::persistenceType` | `dashboard/tests/database-service-exports.ts:20` | 9 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::persistenceType.<anonymous>` | `dashboard/tests/database-service-exports.ts:24` | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::applicationDeclaration` | `dashboard/tests/database-service-exports.ts:29` | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::applicationMembers` | `dashboard/tests/database-service-exports.ts:32` | 6 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-service-exports.ts::applicationMembers.<anonymous>` | `dashboard/tests/database-service-exports.ts:36` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::typeArguments` | `dashboard/tests/database-service-exports.ts:38` | 12 | 2 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/tests/database-service-exports.ts::typeArguments.<anonymous>` | `dashboard/tests/database-service-exports.ts:45` | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::exportInspector` | `dashboard/tests/database-service-exports.ts:55` | 31 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::exportInspector.inspect` | `dashboard/tests/database-service-exports.ts:57` | 24 | 2 | 5 | 5 | 0 | 0 | 1 |
| `dashboard/tests/database-service-exports.ts::exportInspector.inspect.<anonymous>` | `dashboard/tests/database-service-exports.ts:69` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::exportInspector.inspect.<anonymous>` | `dashboard/tests/database-service-exports.ts:71` | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::exportInspector.inspect.inspect` | `dashboard/tests/database-service-exports.ts:77` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::exportInspector.inspect.<anonymous>` | `dashboard/tests/database-service-exports.ts:79` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::exportInspector.<anonymous>` | `dashboard/tests/database-service-exports.ts:81` | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::inspectSignatures` | `dashboard/tests/database-service-exports.ts:86` | 21 | 2 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::inspectSignatures.<anonymous>` | `dashboard/tests/database-service-exports.ts:99` | 7 | 1 | 1 | 1 | 0 | 0 | 0 |
| `dashboard/tests/database-service-exports.ts::inspectSignatures.<anonymous>.<anonymous>` | `dashboard/tests/database-service-exports.ts:101` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-service-exports.ts::auditServiceExports` | `dashboard/tests/database-service-exports.ts:108` | 19 | 2 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-service-exports.ts::auditServiceExports.<anonymous>` | `dashboard/tests/database-service-exports.ts:117` | 8 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-syntax.ts::loaderCall` | `dashboard/tests/database-syntax.ts:6` | 8 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/tests/database-syntax.ts::moduleReferences` | `dashboard/tests/database-syntax.ts:14` | 10 | 1 | 8 | 8 | 0 | 0 | 2 |
| `dashboard/tests/database-syntax.ts::importEqualsReferences` | `dashboard/tests/database-syntax.ts:24` | 4 | 1 | 2 | 2 | 0 | 0 | 1 |
| `dashboard/tests/database-syntax.ts::literal` | `dashboard/tests/database-syntax.ts:28` | 4 | 1 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/tests/database-syntax.ts::namedProperty` | `dashboard/tests/database-syntax.ts:32` | 12 | 1 | 6 | 6 | 0 | 0 | 0 |
| `dashboard/tests/database-syntax.ts::bindingProperty` | `dashboard/tests/database-syntax.ts:44` | 5 | 1 | 3 | 3 | 0 | 0 | 1 |
| `dashboard/tests/database-syntax.ts::property` | `dashboard/tests/database-syntax.ts:49` | 11 | 1 | 6 | 6 | 0 | 0 | 2 |
| `dashboard/tests/database-syntax.ts::allowedPragma` | `dashboard/tests/database-syntax.ts:60` | 16 | 2 | 8 | 8 | 0 | 0 | 1 |
| `dashboard/tests/database-syntax.ts::rootName` | `dashboard/tests/database-syntax.ts:76` | 6 | 1 | 4 | 4 | 0 | 0 | 1 |
| `dashboard/tests/database-syntax.ts::accessOwner` | `dashboard/tests/database-syntax.ts:82` | 7 | 1 | 5 | 5 | 0 | 0 | 1 |

## Dependencies

| Item | Location | Fan-in | Fan-out | Change impact | Internal instability |
| --- | --- | --- | --- | --- | --- |
| `pythonUnicodeGraphFind` | `.` | 0 | 0 | 0 | N/A |
| `.agents` | `.agents` | 0 | 0 | 0 | N/A |
| `.agents.skills` | `.agents/skills` | 0 | 0 | 0 | N/A |
| `.agents.skills.atlas-navigate` | `.agents/skills/atlas-navigate` | 0 | 0 | 0 | N/A |
| `.agents/skills/atlas-navigate/SKILL.md` | `.agents/skills/atlas-navigate/SKILL.md` | 0 | 0 | 0 | N/A |
| `.agents.skills.atlas-navigate.references` | `.agents/skills/atlas-navigate/references` | 0 | 0 | 0 | N/A |
| `.agents/skills/atlas-navigate/references/commands.md` | `.agents/skills/atlas-navigate/references/commands.md` | 0 | 0 | 0 | N/A |
| `.github` | `.github` | 0 | 0 | 0 | N/A |
| `.github/dependabot.yml` | `.github/dependabot.yml` | 0 | 0 | 0 | N/A |
| `.github.workflows` | `.github/workflows` | 0 | 0 | 0 | N/A |
| `.github/workflows/atlas-ci.yml` | `.github/workflows/atlas-ci.yml` | 0 | 0 | 0 | N/A |
| `.github/workflows/ci.yml` | `.github/workflows/ci.yml` | 0 | 0 | 0 | N/A |
| `.github/workflows/dashboard-ci.yml` | `.github/workflows/dashboard-ci.yml` | 0 | 0 | 0 | N/A |
| `AGENTS.md` | `AGENTS.md` | 0 | 0 | 0 | N/A |
| `DESIGN.md` | `DESIGN.md` | 0 | 0 | 0 | N/A |
| `PRODUCT.md` | `PRODUCT.md` | 0 | 0 | 0 | N/A |
| `README.md` | `README.md` | 0 | 0 | 0 | N/A |
| `SECURITY.md` | `SECURITY.md` | 0 | 0 | 0 | N/A |
| `atlas` | `atlas` | 0 | 0 | 0 | N/A |
| `atlas/alembic.ini` | `atlas/alembic.ini` | 0 | 0 | 0 | N/A |
| `atlas/mise.toml` | `atlas/mise.toml` | 0 | 0 | 0 | N/A |
| `atlas/pyproject.toml` | `atlas/pyproject.toml` | 0 | 0 | 0 | N/A |
| `atlas.src` | `atlas/src` | 0 | 0 | 0 | N/A |
| `atlas.src.atlas` | `atlas/src/atlas` | 7 | 4 | 7 | 0.36 |
| `atlas/src/atlas/__init__.py` | `atlas/src/atlas/__init__.py` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/__main__.py` | `atlas/src/atlas/__main__.py` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/bootstrap.py` | `atlas/src/atlas/bootstrap.py` | 15 | 1 | 41 | 0.06 |
| `atlas.src.atlas.cli` | `atlas/src/atlas/cli` | 2 | 4 | 7 | 0.67 |
| `atlas/src/atlas/cli/__init__.py` | `atlas/src/atlas/cli/__init__.py` | 15 | 1 | 33 | 0.06 |
| `atlas/src/atlas/cli/commands.py` | `atlas/src/atlas/cli/commands.py` | 3 | 7 | 36 | 0.70 |
| `atlas/src/atlas/cli/commands.py::main` | `atlas/src/atlas/cli/commands.py:13` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/cli/commands.py::index_command` | `atlas/src/atlas/cli/commands.py:19` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/cli/commands.py::projects_command` | `atlas/src/atlas/cli/commands.py:39` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/cli/commands.py::_folder_report` | `atlas/src/atlas/cli/commands.py:51` | 2 | 2 | 2 | 0.50 |
| `atlas/src/atlas/cli/commands.py::report_command` | `atlas/src/atlas/cli/commands.py:70` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/cli/commands.py::check_command` | `atlas/src/atlas/cli/commands.py:92` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/cli/graph.py` | `atlas/src/atlas/cli/graph.py` | 1 | 5 | 37 | 0.83 |
| `atlas/src/atlas/cli/graph.py::graph` | `atlas/src/atlas/cli/graph.py:19` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/cli/graph.py::GraphError` | `atlas/src/atlas/cli/graph.py:23` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/cli/graph.py::GraphError.show` | `atlas/src/atlas/cli/graph.py:26` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/cli/graph.py::emit` | `atlas/src/atlas/cli/graph.py:30` | 7 | 3 | 7 | 0.30 |
| `atlas/src/atlas/cli/graph.py::command_options` | `atlas/src/atlas/cli/graph.py:47` | 1 | 0 | 8 | 0.00 |
| `atlas/src/atlas/cli/graph.py::overview` | `atlas/src/atlas/cli/graph.py:58` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/cli/graph.py::find` | `atlas/src/atlas/cli/graph.py:66` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/cli/graph.py::show` | `atlas/src/atlas/cli/graph.py:73` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/cli/graph.py::children` | `atlas/src/atlas/cli/graph.py:82` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/cli/graph.py::relation_list` | `atlas/src/atlas/cli/graph.py:86` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/cli/graph.py::traversal_options` | `atlas/src/atlas/cli/graph.py:94` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/cli/graph.py::context` | `atlas/src/atlas/cli/graph.py:106` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/cli/graph.py::source` | `atlas/src/atlas/cli/graph.py:116` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/cli/graph.py::path` | `atlas/src/atlas/cli/graph.py:129` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/cli/graph_output.py` | `atlas/src/atlas/cli/graph_output.py` | 2 | 0 | 39 | 0.00 |
| `atlas/src/atlas/cli/graph_output.py::graph_output` | `atlas/src/atlas/cli/graph_output.py:11` | 2 | 1 | 9 | 0.33 |
| `atlas/src/atlas/cli/graph_output.py::_unresolved_identity` | `atlas/src/atlas/cli/graph_output.py:26` | 1 | 0 | 10 | 0.00 |
| `atlas/src/atlas/cli/graph_source_output.py` | `atlas/src/atlas/cli/graph_source_output.py` | 1 | 1 | 38 | 0.50 |
| `atlas/src/atlas/cli/graph_source_output.py::source_text` | `atlas/src/atlas/cli/graph_source_output.py:8` | 1 | 1 | 8 | 0.50 |
| `atlas/src/atlas/cli/graph_source_output.py::excerpt_text` | `atlas/src/atlas/cli/graph_source_output.py:18` | 1 | 0 | 9 | 0.00 |
| `atlas.src.atlas.domain` | `atlas/src/atlas/domain` | 7 | 0 | 10 | 0.00 |
| `atlas/src/atlas/domain/__init__.py` | `atlas/src/atlas/domain/__init__.py` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py` | `atlas/src/atlas/domain/models.py` | 36 | 0 | 134 | 0.00 |
| `atlas/src/atlas/domain/models.py::RepositoryMetadata` | `atlas/src/atlas/domain/models.py:27` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::GraphNode` | `atlas/src/atlas/domain/models.py:36` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::GraphEdge` | `atlas/src/atlas/domain/models.py:58` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::ProjectedEdge` | `atlas/src/atlas/domain/models.py:77` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::GraphView` | `atlas/src/atlas/domain/models.py:89` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::Diagnostic` | `atlas/src/atlas/domain/models.py:96` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::SourceFile` | `atlas/src/atlas/domain/models.py:106` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::Complexity` | `atlas/src/atlas/domain/models.py:116` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/domain/models.py::Symbol` | `atlas/src/atlas/domain/models.py:127` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::Import` | `atlas/src/atlas/domain/models.py:152` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::Call` | `atlas/src/atlas/domain/models.py:161` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/models.py::Inheritance` | `atlas/src/atlas/domain/models.py:176` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::ParsedFile` | `atlas/src/atlas/domain/models.py:188` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/models.py::ParsedRepository` | `atlas/src/atlas/domain/models.py:201` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::ParsedRepository.symbols` | `atlas/src/atlas/domain/models.py:207` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::ParsedRepository.imports` | `atlas/src/atlas/domain/models.py:223` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::ParsedRepository.calls` | `atlas/src/atlas/domain/models.py:239` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::ParsedRepository.inheritances` | `atlas/src/atlas/domain/models.py:255` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/models.py::file_key` | `atlas/src/atlas/domain/models.py:271` | 11 | 0 | 363 | 0.00 |
| `atlas/src/atlas/domain/navigation.py` | `atlas/src/atlas/domain/navigation.py` | 8 | 0 | 49 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::NavigationError` | `atlas/src/atlas/domain/navigation.py:9` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::GraphSnapshot` | `atlas/src/atlas/domain/navigation.py:14` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::GraphSnapshot.metadata` | `atlas/src/atlas/domain/navigation.py:20` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/navigation.py::EdgeRequest` | `atlas/src/atlas/domain/navigation.py:25` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::TraversalRequest` | `atlas/src/atlas/domain/navigation.py:33` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/navigation.py::PathRequest` | `atlas/src/atlas/domain/navigation.py:43` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/navigation.py::SourceOptions` | `atlas/src/atlas/domain/navigation.py:49` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader` | `atlas/src/atlas/domain/navigation.py:54` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.overview` | `atlas/src/atlas/domain/navigation.py:57` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.find` | `atlas/src/atlas/domain/navigation.py:58` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.node` | `atlas/src/atlas/domain/navigation.py:59` | 8 | 0 | 13 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.children` | `atlas/src/atlas/domain/navigation.py:60` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.edges` | `atlas/src/atlas/domain/navigation.py:61` | 1 | 0 | 6 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.diagnostics` | `atlas/src/atlas/domain/navigation.py:62` | 1 | 0 | 10 | 0.00 |
| `atlas/src/atlas/domain/navigation.py::NavigationReader.file` | `atlas/src/atlas/domain/navigation.py:63` | 1 | 0 | 3 | 0.00 |
| `atlas/src/atlas/domain/repositories.py` | `atlas/src/atlas/domain/repositories.py` | 11 | 0 | 61 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::RepositoryError` | `atlas/src/atlas/domain/repositories.py:8` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::RepositoryError.__init__` | `atlas/src/atlas/domain/repositories.py:9` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/repositories.py::RepositoryDTO` | `atlas/src/atlas/domain/repositories.py:14` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/repositories.py::GraphStatsDTO` | `atlas/src/atlas/domain/repositories.py:22` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::GraphDTO` | `atlas/src/atlas/domain/repositories.py:34` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::ReportNodeDTO` | `atlas/src/atlas/domain/repositories.py:45` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/repositories.py::ReportImportDTO` | `atlas/src/atlas/domain/repositories.py:64` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/domain/repositories.py::ReportFactsDTO` | `atlas/src/atlas/domain/repositories.py:75` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol` | `atlas/src/atlas/domain/repositories.py:83` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.register` | `atlas/src/atlas/domain/repositories.py:84` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.list` | `atlas/src/atlas/domain/repositories.py:86` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.exists` | `atlas/src/atlas/domain/repositories.py:88` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.resolve` | `atlas/src/atlas/domain/repositories.py:90` | 3 | 0 | 3 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.graph` | `atlas/src/atlas/domain/repositories.py:92` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.report_facts` | `atlas/src/atlas/domain/repositories.py:94` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.save` | `atlas/src/atlas/domain/repositories.py:96` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/domain/repositories.py::RepositoryProtocol.save_new` | `atlas/src/atlas/domain/repositories.py:98` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/indexer.py` | `atlas/src/atlas/indexer.py` | 14 | 5 | 85 | 0.26 |
| `atlas/src/atlas/indexer.py::analyze_repository` | `atlas/src/atlas/indexer.py:12` | 17 | 6 | 59 | 0.26 |
| `atlas/src/atlas/language_syntax.py` | `atlas/src/atlas/language_syntax.py` | 4 | 1 | 108 | 0.20 |
| `atlas/src/atlas/language_syntax.py::_declaration_head` | `atlas/src/atlas/language_syntax.py:19` | 2 | 2 | 3 | 0.50 |
| `atlas/src/atlas/language_syntax.py::_first_head` | `atlas/src/atlas/language_syntax.py:33` | 1 | 0 | 4 | 0.00 |
| `atlas/src/atlas/language_syntax.py::_property_callable` | `atlas/src/atlas/language_syntax.py:41` | 2 | 1 | 2 | 0.33 |
| `atlas.src.atlas.metrics` | `atlas/src/atlas/metrics` | 5 | 3 | 7 | 0.38 |
| `atlas/src/atlas/metrics/__init__.py` | `atlas/src/atlas/metrics/__init__.py` | 0 | 0 | 0 | N/A |
| `atlas.src.atlas.metrics.adapters` | `atlas/src/atlas/metrics/adapters` | 2 | 4 | 7 | 0.67 |
| `atlas/src/atlas/metrics/adapters/__init__.py` | `atlas/src/atlas/metrics/adapters/__init__.py` | 15 | 12 | 100 | 0.44 |
| `atlas/src/atlas/metrics/adapters/__init__.py::get_metric_adapter` | `atlas/src/atlas/metrics/adapters/__init__.py:40` | 5 | 1 | 138 | 0.17 |
| `atlas/src/atlas/metrics/adapters/__init__.py::receiver_coverage` | `atlas/src/atlas/metrics/adapters/__init__.py:60` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/__init__.py::get_resolution_adapter` | `atlas/src/atlas/metrics/adapters/__init__.py:66` | 35 | 0 | 274 | 0.00 |
| `atlas/src/atlas/metrics/adapters/base.py` | `atlas/src/atlas/metrics/adapters/base.py` | 12 | 0 | 109 | 0.00 |
| `atlas/src/atlas/metrics/adapters/base.py::never` | `atlas/src/atlas/metrics/adapters/base.py:81` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/base.py::alternative` | `atlas/src/atlas/metrics/adapters/base.py:85` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/base.py::_conditional_parent` | `atlas/src/atlas/metrics/adapters/base.py:101` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/base.py::MetricPolicy` | `atlas/src/atlas/metrics/adapters/base.py:106` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/base.py::MetricPolicy.body` | `atlas/src/atlas/metrics/adapters/base.py:118` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/base.py::MetricPolicy.scope` | `atlas/src/atlas/metrics/adapters/base.py:127` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/base.py::MetricPolicy.decision` | `atlas/src/atlas/metrics/adapters/base.py:130` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/base.py::MetricPolicy.logical` | `atlas/src/atlas/metrics/adapters/base.py:140` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/base.py::MetricPolicy.alternative` | `atlas/src/atlas/metrics/adapters/base.py:145` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/base.py::MetricAdapter` | `atlas/src/atlas/metrics/adapters/base.py:154` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/base.py::MetricAdapter.<anonymous>` | `atlas/src/atlas/metrics/adapters/base.py:156` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/callable_selection.py` | `atlas/src/atlas/metrics/adapters/callable_selection.py` | 1 | 2 | 103 | 0.67 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::Parameter` | `atlas/src/atlas/metrics/adapters/callable_selection.py:18` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::Argument` | `atlas/src/atlas/metrics/adapters/callable_selection.py:26` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::TypeContext` | `atlas/src/atlas/metrics/adapters/callable_selection.py:33` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::CallContext` | `atlas/src/atlas/metrics/adapters/callable_selection.py:39` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::Assignment` | `atlas/src/atlas/metrics/adapters/callable_selection.py:46` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::Assignment.index` | `atlas/src/atlas/metrics/adapters/callable_selection.py:51` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::Assignment.assign` | `atlas/src/atlas/metrics/adapters/callable_selection.py:62` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::Assignment.complete` | `atlas/src/atlas/metrics/adapters/callable_selection.py:68` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_sole` | `atlas/src/atlas/metrics/adapters/callable_selection.py:72` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_type_names` | `atlas/src/atlas/metrics/adapters/callable_selection.py:76` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::select_callable` | `atlas/src/atlas/metrics/adapters/callable_selection.py:83` | 1 | 4 | 1 | 0.80 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_viable` | `atlas/src/atlas/metrics/adapters/callable_selection.py:94` | 1 | 2 | 2 | 0.67 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::call_arguments` | `atlas/src/atlas/metrics/adapters/callable_selection.py:103` | 1 | 2 | 2 | 0.67 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_kotlin_arguments` | `atlas/src/atlas/metrics/adapters/callable_selection.py:114` | 1 | 2 | 3 | 0.67 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_argument` | `atlas/src/atlas/metrics/adapters/callable_selection.py:130` | 1 | 1 | 4 | 0.50 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_parameter_container` | `atlas/src/atlas/metrics/adapters/callable_selection.py:139` | 1 | 2 | 4 | 0.67 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::callable_parameters` | `atlas/src/atlas/metrics/adapters/callable_selection.py:148` | 1 | 2 | 3 | 0.67 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_parameter` | `atlas/src/atlas/metrics/adapters/callable_selection.py:163` | 1 | 4 | 4 | 0.80 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::accepts` | `atlas/src/atlas/metrics/adapters/callable_selection.py:178` | 1 | 1 | 3 | 0.50 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_accept_argument` | `atlas/src/atlas/metrics/adapters/callable_selection.py:189` | 1 | 3 | 4 | 0.75 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::expression_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:201` | 1 | 3 | 5 | 0.75 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_integer_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:216` | 1 | 0 | 6 | 0.00 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_visible_binding` | `atlas/src/atlas/metrics/adapters/callable_selection.py:223` | 1 | 1 | 7 | 0.50 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_scope_width` | `atlas/src/atlas/metrics/adapters/callable_selection.py:228` | 1 | 0 | 8 | 0.00 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_identifier_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:232` | 1 | 2 | 6 | 0.67 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_nearest_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:243` | 1 | 2 | 7 | 0.67 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_mentions_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:255` | 1 | 1 | 10 | 0.50 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_annotation_node` | `atlas/src/atlas/metrics/adapters/callable_selection.py:260` | 1 | 0 | 11 | 0.00 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_lossy_annotation` | `atlas/src/atlas/metrics/adapters/callable_selection.py:265` | 1 | 2 | 10 | 0.67 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_uncertain_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:270` | 1 | 2 | 9 | 0.67 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::proven_type` | `atlas/src/atlas/metrics/adapters/callable_selection.py:280` | 2 | 1 | 8 | 0.33 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_kotlin_incompatible` | `atlas/src/atlas/metrics/adapters/callable_selection.py:290` | 1 | 0 | 6 | 0.00 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::_java_incompatible` | `atlas/src/atlas/metrics/adapters/callable_selection.py:297` | 1 | 0 | 6 | 0.00 |
| `atlas/src/atlas/metrics/adapters/callable_selection.py::incompatible` | `atlas/src/atlas/metrics/adapters/callable_selection.py:307` | 1 | 2 | 5 | 0.67 |
| `atlas/src/atlas/metrics/adapters/elixir.py` | `atlas/src/atlas/metrics/adapters/elixir.py` | 2 | 7 | 101 | 0.78 |
| `atlas/src/atlas/metrics/adapters/elixir.py::target` | `atlas/src/atlas/metrics/adapters/elixir.py:38` | 4 | 2 | 5 | 0.33 |
| `atlas/src/atlas/metrics/adapters/elixir.py::scope` | `atlas/src/atlas/metrics/adapters/elixir.py:43` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/elixir.py::call_decision` | `atlas/src/atlas/metrics/adapters/elixir.py:47` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/elixir.py::guard_decision` | `atlas/src/atlas/metrics/adapters/elixir.py:51` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/elixir.py::clause_decision` | `atlas/src/atlas/metrics/adapters/elixir.py:55` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_cond_fallback` | `atlas/src/atlas/metrics/adapters/elixir.py:71` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/elixir.py::arguments` | `atlas/src/atlas/metrics/adapters/elixir.py:75` | 3 | 1 | 8 | 0.25 |
| `atlas/src/atlas/metrics/adapters/elixir.py::parameter_count` | `atlas/src/atlas/metrics/adapters/elixir.py:88` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_elixir_head_count` | `atlas/src/atlas/metrics/adapters/elixir.py:99` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_elixir_anonymous_count` | `atlas/src/atlas/metrics/adapters/elixir.py:105` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_elixir_clause_count` | `atlas/src/atlas/metrics/adapters/elixir.py:111` | 1 | 2 | 2 | 0.67 |
| `atlas/src/atlas/metrics/adapters/elixir.py::arity` | `atlas/src/atlas/metrics/adapters/elixir.py:135` | 1 | 1 | 3 | 0.50 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_clause_signature` | `atlas/src/atlas/metrics/adapters/elixir.py:144` | 2 | 4 | 2 | 0.67 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_parameter_counts` | `atlas/src/atlas/metrics/adapters/elixir.py:156` | 1 | 1 | 3 | 0.50 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_resolution_pipeline` | `atlas/src/atlas/metrics/adapters/elixir.py:164` | 1 | 2 | 3 | 0.67 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_pipeline_identifier` | `atlas/src/atlas/metrics/adapters/elixir.py:175` | 1 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_call_arity` | `atlas/src/atlas/metrics/adapters/elixir.py:179` | 2 | 3 | 2 | 0.60 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ClauseInvocation` | `atlas/src/atlas/metrics/adapters/elixir.py:190` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/elixir.py::_clause_matches` | `atlas/src/atlas/metrics/adapters/elixir.py:195` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution` | `atlas/src/atlas/metrics/adapters/elixir.py:207` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.import_path` | `atlas/src/atlas/metrics/adapters/elixir.py:208` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.is_import_node` | `atlas/src/atlas/metrics/adapters/elixir.py:216` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.module_identity` | `atlas/src/atlas/metrics/adapters/elixir.py:222` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.import_key` | `atlas/src/atlas/metrics/adapters/elixir.py:229` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.import_item` | `atlas/src/atlas/metrics/adapters/elixir.py:233` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.qualified` | `atlas/src/atlas/metrics/adapters/elixir.py:244` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.clauses` | `atlas/src/atlas/metrics/adapters/elixir.py:249` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/elixir.py::ElixirResolution.select` | `atlas/src/atlas/metrics/adapters/elixir.py:261` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/generic.py` | `atlas/src/atlas/metrics/adapters/generic.py` | 1 | 2 | 101 | 0.67 |
| `atlas/src/atlas/metrics/adapters/generic.py::receiver_coverage` | `atlas/src/atlas/metrics/adapters/generic.py:9` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/generic.py::unwrapped` | `atlas/src/atlas/metrics/adapters/generic.py:22` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/generic.py::GenericResolution` | `atlas/src/atlas/metrics/adapters/generic.py:28` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/generic.py::GenericResolution.__init__` | `atlas/src/atlas/metrics/adapters/generic.py:31` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/generic.py::GenericResolution.call_target` | `atlas/src/atlas/metrics/adapters/generic.py:34` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/generic.py::GenericResolution.receiver_class_allowed` | `atlas/src/atlas/metrics/adapters/generic.py:38` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/go.py` | `atlas/src/atlas/metrics/adapters/go.py` | 1 | 7 | 101 | 0.88 |
| `atlas/src/atlas/metrics/adapters/go.py::parameter_count` | `atlas/src/atlas/metrics/adapters/go.py:23` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution` | `atlas/src/atlas/metrics/adapters/go.py:36` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.instance_members` | `atlas/src/atlas/metrics/adapters/go.py:39` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution._package_symbols` | `atlas/src/atlas/metrics/adapters/go.py:43` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution._receiver_method` | `atlas/src/atlas/metrics/adapters/go.py:46` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution._package_files` | `atlas/src/atlas/metrics/adapters/go.py:54` | 2 | 1 | 3 | 0.33 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution._package` | `atlas/src/atlas/metrics/adapters/go.py:59` | 1 | 1 | 4 | 0.50 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.same_package` | `atlas/src/atlas/metrics/adapters/go.py:63` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.import_path` | `atlas/src/atlas/metrics/adapters/go.py:66` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.import_item` | `atlas/src/atlas/metrics/adapters/go.py:69` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.binding` | `atlas/src/atlas/metrics/adapters/go.py:92` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/go.py::GoResolution.call_target` | `atlas/src/atlas/metrics/adapters/go.py:99` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/java.py` | `atlas/src/atlas/metrics/adapters/java.py` | 2 | 8 | 102 | 0.80 |
| `atlas/src/atlas/metrics/adapters/java.py::parameter_count` | `atlas/src/atlas/metrics/adapters/java.py:23` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/java.py::package` | `atlas/src/atlas/metrics/adapters/java.py:30` | 2 | 1 | 2 | 0.33 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution` | `atlas/src/atlas/metrics/adapters/java.py:43` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.import_path` | `atlas/src/atlas/metrics/adapters/java.py:45` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.select` | `atlas/src/atlas/metrics/adapters/java.py:65` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.call_target` | `atlas/src/atlas/metrics/adapters/java.py:68` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.binding` | `atlas/src/atlas/metrics/adapters/java.py:75` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.module_identity` | `atlas/src/atlas/metrics/adapters/java.py:82` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.same_package` | `atlas/src/atlas/metrics/adapters/java.py:87` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.import_name` | `atlas/src/atlas/metrics/adapters/java.py:93` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.import_key` | `atlas/src/atlas/metrics/adapters/java.py:97` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.import_item` | `atlas/src/atlas/metrics/adapters/java.py:103` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.qualify_class` | `atlas/src/atlas/metrics/adapters/java.py:107` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/java.py::JavaResolution.inheritance` | `atlas/src/atlas/metrics/adapters/java.py:110` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/javascript.py` | `atlas/src/atlas/metrics/adapters/javascript.py` | 2 | 9 | 101 | 0.82 |
| `atlas/src/atlas/metrics/adapters/javascript.py::parameter_count` | `atlas/src/atlas/metrics/adapters/javascript.py:29` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_local_export` | `atlas/src/atlas/metrics/adapters/javascript.py:41` | 1 | 2 | 7 | 0.67 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_export_declaration` | `atlas/src/atlas/metrics/adapters/javascript.py:49` | 1 | 3 | 8 | 0.75 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_declaration_symbols` | `atlas/src/atlas/metrics/adapters/javascript.py:58` | 1 | 1 | 9 | 0.50 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_export_specifiers` | `atlas/src/atlas/metrics/adapters/javascript.py:67` | 1 | 0 | 8 | 0.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_export_specifier` | `atlas/src/atlas/metrics/adapters/javascript.py:72` | 1 | 2 | 8 | 0.67 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_export_entries` | `atlas/src/atlas/metrics/adapters/javascript.py:80` | 1 | 3 | 7 | 0.75 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_extend_exports` | `atlas/src/atlas/metrics/adapters/javascript.py:90` | 2 | 0 | 7 | 0.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_unique_symbols` | `atlas/src/atlas/metrics/adapters/javascript.py:95` | 1 | 0 | 7 | 0.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::export_bindings` | `atlas/src/atlas/metrics/adapters/javascript.py:99` | 3 | 4 | 6 | 0.57 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_import_clause` | `atlas/src/atlas/metrics/adapters/javascript.py:108` | 3 | 0 | 4 | 0.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_named_import` | `atlas/src/atlas/metrics/adapters/javascript.py:113` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_named_imports` | `atlas/src/atlas/metrics/adapters/javascript.py:122` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_has_type_modifier` | `atlas/src/atlas/metrics/adapters/javascript.py:133` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_named_import_specifiers` | `atlas/src/atlas/metrics/adapters/javascript.py:137` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_type_only_named_clause` | `atlas/src/atlas/metrics/adapters/javascript.py:146` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_field_masks_method` | `atlas/src/atlas/metrics/adapters/javascript.py:152` | 1 | 3 | 2 | 0.75 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_non_callable_member` | `atlas/src/atlas/metrics/adapters/javascript.py:161` | 1 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_script_own_field` | `atlas/src/atlas/metrics/adapters/javascript.py:167` | 1 | 3 | 1 | 0.75 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_receiver_alias` | `atlas/src/atlas/metrics/adapters/javascript.py:177` | 1 | 2 | 3 | 0.67 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_receiver_mutation` | `atlas/src/atlas/metrics/adapters/javascript.py:186` | 1 | 3 | 2 | 0.75 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_receiver_aliases` | `atlas/src/atlas/metrics/adapters/javascript.py:193` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_method_group` | `atlas/src/atlas/metrics/adapters/javascript.py:197` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_plain_method` | `atlas/src/atlas/metrics/adapters/javascript.py:201` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/javascript.py::_script_mutation` | `atlas/src/atlas/metrics/adapters/javascript.py:207` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution` | `atlas/src/atlas/metrics/adapters/javascript.py:218` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.import_path` | `atlas/src/atlas/metrics/adapters/javascript.py:220` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.instance_members` | `atlas/src/atlas/metrics/adapters/javascript.py:240` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.select` | `atlas/src/atlas/metrics/adapters/javascript.py:243` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.select.<anonymous>` | `atlas/src/atlas/metrics/adapters/javascript.py:253` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.call_target` | `atlas/src/atlas/metrics/adapters/javascript.py:255` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.normalized_call` | `atlas/src/atlas/metrics/adapters/javascript.py:260` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.receiver_type_allowed` | `atlas/src/atlas/metrics/adapters/javascript.py:265` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.receiver_class_allowed` | `atlas/src/atlas/metrics/adapters/javascript.py:268` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.member_overwritten` | `atlas/src/atlas/metrics/adapters/javascript.py:271` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.binding` | `atlas/src/atlas/metrics/adapters/javascript.py:276` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.paths` | `atlas/src/atlas/metrics/adapters/javascript.py:291` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.members` | `atlas/src/atlas/metrics/adapters/javascript.py:298` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.namespace_exports` | `atlas/src/atlas/metrics/adapters/javascript.py:306` | 2 | 2 | 3 | 0.50 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.import_type_only` | `atlas/src/atlas/metrics/adapters/javascript.py:314` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.import_item` | `atlas/src/atlas/metrics/adapters/javascript.py:321` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution._namespace_import` | `atlas/src/atlas/metrics/adapters/javascript.py:341` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.namespace_members` | `atlas/src/atlas/metrics/adapters/javascript.py:351` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/javascript.py::JavaScriptResolution.implicit_receiver` | `atlas/src/atlas/metrics/adapters/javascript.py:354` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/kotlin.py` | `atlas/src/atlas/metrics/adapters/kotlin.py` | 1 | 6 | 101 | 0.86 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::alternative` | `atlas/src/atlas/metrics/adapters/kotlin.py:22` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/kotlin.py::parameter_count` | `atlas/src/atlas/metrics/adapters/kotlin.py:35` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution` | `atlas/src/atlas/metrics/adapters/kotlin.py:60` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.import_path` | `atlas/src/atlas/metrics/adapters/kotlin.py:62` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.write_target` | `atlas/src/atlas/metrics/adapters/kotlin.py:82` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.call_target` | `atlas/src/atlas/metrics/adapters/kotlin.py:88` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.binding` | `atlas/src/atlas/metrics/adapters/kotlin.py:96` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.import_name` | `atlas/src/atlas/metrics/adapters/kotlin.py:114` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.import_item` | `atlas/src/atlas/metrics/adapters/kotlin.py:117` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/kotlin.py::KotlinResolution.static_member` | `atlas/src/atlas/metrics/adapters/kotlin.py:128` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/module_index.py` | `atlas/src/atlas/metrics/adapters/module_index.py` | 1 | 2 | 102 | 0.67 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleScope` | `atlas/src/atlas/metrics/adapters/module_index.py:14` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex` | `atlas/src/atlas/metrics/adapters/module_index.py:21` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.__init__` | `atlas/src/atlas/metrics/adapters/module_index.py:22` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.add_scopes` | `atlas/src/atlas/metrics/adapters/module_index.py:26` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.walk_scopes` | `atlas/src/atlas/metrics/adapters/module_index.py:32` | 1 | 1 | 4 | 0.50 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.scopes_at` | `atlas/src/atlas/metrics/adapters/module_index.py:41` | 1 | 1 | 5 | 0.50 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.unique_scope` | `atlas/src/atlas/metrics/adapters/module_index.py:52` | 2 | 0 | 6 | 0.00 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.scope_key` | `atlas/src/atlas/metrics/adapters/module_index.py:59` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.scope_symbols` | `atlas/src/atlas/metrics/adapters/module_index.py:76` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/module_index.py::ModuleIndex.scope_files` | `atlas/src/atlas/metrics/adapters/module_index.py:84` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/module_index.py::_pending_scopes` | `atlas/src/atlas/metrics/adapters/module_index.py:89` | 1 | 0 | 5 | 0.00 |
| `atlas/src/atlas/metrics/adapters/module_index.py::_narrowest_scopes` | `atlas/src/atlas/metrics/adapters/module_index.py:97` | 1 | 0 | 6 | 0.00 |
| `atlas/src/atlas/metrics/adapters/parameters.py` | `atlas/src/atlas/metrics/adapters/parameters.py` | 7 | 1 | 108 | 0.12 |
| `atlas/src/atlas/metrics/adapters/parameters.py::parameter_children` | `atlas/src/atlas/metrics/adapters/parameters.py:10` | 7 | 0 | 13 | 0.00 |
| `atlas/src/atlas/metrics/adapters/parameters.py::parameter_node` | `atlas/src/atlas/metrics/adapters/parameters.py:14` | 6 | 1 | 6 | 0.14 |
| `atlas/src/atlas/metrics/adapters/parameters.py::count_parameters` | `atlas/src/atlas/metrics/adapters/parameters.py:20` | 4 | 1 | 6 | 0.20 |
| `atlas/src/atlas/metrics/adapters/python.py` | `atlas/src/atlas/metrics/adapters/python.py` | 2 | 10 | 101 | 0.83 |
| `atlas/src/atlas/metrics/adapters/python.py::irrefutable_pattern` | `atlas/src/atlas/metrics/adapters/python.py:36` | 5 | 0 | 7 | 0.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_single_pattern` | `atlas/src/atlas/metrics/adapters/python.py:41` | 2 | 1 | 2 | 0.33 |
| `atlas/src/atlas/metrics/adapters/python.py::_case_pattern` | `atlas/src/atlas/metrics/adapters/python.py:46` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_capture_pattern` | `atlas/src/atlas/metrics/adapters/python.py:52` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/python.py::_as_pattern` | `atlas/src/atlas/metrics/adapters/python.py:57` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_union_pattern` | `atlas/src/atlas/metrics/adapters/python.py:62` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_tuple_pattern` | `atlas/src/atlas/metrics/adapters/python.py:68` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::case_decision` | `atlas/src/atlas/metrics/adapters/python.py:83` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::parameter_count` | `atlas/src/atlas/metrics/adapters/python.py:90` | 0 | 5 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_python_owner` | `atlas/src/atlas/metrics/adapters/python.py:103` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_python_method` | `atlas/src/atlas/metrics/adapters/python.py:114` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/python.py::_python_static` | `atlas/src/atlas/metrics/adapters/python.py:126` | 1 | 2 | 2 | 0.67 |
| `atlas/src/atlas/metrics/adapters/python.py::_python_receiver` | `atlas/src/atlas/metrics/adapters/python.py:131` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_in_comprehension_iterable` | `atlas/src/atlas/metrics/adapters/python.py:152` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/python.py::_hides_class_scope` | `atlas/src/atlas/metrics/adapters/python.py:158` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/metrics/adapters/python.py::_self_parameter` | `atlas/src/atlas/metrics/adapters/python.py:166` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/python.py::_bare_relative_import` | `atlas/src/atlas/metrics/adapters/python.py:174` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_package_root` | `atlas/src/atlas/metrics/adapters/python.py:178` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_source_roots` | `atlas/src/atlas/metrics/adapters/python.py:186` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/python.py::_src_roots` | `atlas/src/atlas/metrics/adapters/python.py:200` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_module_name` | `atlas/src/atlas/metrics/adapters/python.py:204` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_index_modules` | `atlas/src/atlas/metrics/adapters/python.py:213` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/python.py::_import_attributes` | `atlas/src/atlas/metrics/adapters/python.py:220` | 1 | 1 | 6 | 0.50 |
| `atlas/src/atlas/metrics/adapters/python.py::_runtime_assignment` | `atlas/src/atlas/metrics/adapters/python.py:228` | 1 | 1 | 7 | 0.50 |
| `atlas/src/atlas/metrics/adapters/python.py::_assigned_attribute` | `atlas/src/atlas/metrics/adapters/python.py:232` | 1 | 1 | 6 | 0.50 |
| `atlas/src/atlas/metrics/adapters/python.py::_package_parent` | `atlas/src/atlas/metrics/adapters/python.py:239` | 2 | 0 | 7 | 0.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_absolute_module_files` | `atlas/src/atlas/metrics/adapters/python.py:247` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/python.py::_module_attribute` | `atlas/src/atlas/metrics/adapters/python.py:258` | 1 | 2 | 5 | 0.67 |
| `atlas/src/atlas/metrics/adapters/python.py::_child_module_files` | `atlas/src/atlas/metrics/adapters/python.py:270` | 2 | 3 | 4 | 0.60 |
| `atlas/src/atlas/metrics/adapters/python.py::_child_path` | `atlas/src/atlas/metrics/adapters/python.py:278` | 3 | 0 | 5 | 0.00 |
| `atlas/src/atlas/metrics/adapters/python.py::_import_node` | `atlas/src/atlas/metrics/adapters/python.py:282` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution` | `atlas/src/atlas/metrics/adapters/python.py:294` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.import_path` | `atlas/src/atlas/metrics/adapters/python.py:296` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.instance_members` | `atlas/src/atlas/metrics/adapters/python.py:319` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.select` | `atlas/src/atlas/metrics/adapters/python.py:322` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.select.<anonymous>` | `atlas/src/atlas/metrics/adapters/python.py:332` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.module_index` | `atlas/src/atlas/metrics/adapters/python.py:336` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.import_files` | `atlas/src/atlas/metrics/adapters/python.py:348` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.paths` | `atlas/src/atlas/metrics/adapters/python.py:357` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.lexical_imports` | `atlas/src/atlas/metrics/adapters/python.py:372` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution._lexical_import_names` | `atlas/src/atlas/metrics/adapters/python.py:380` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.binding` | `atlas/src/atlas/metrics/adapters/python.py:391` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.visible` | `atlas/src/atlas/metrics/adapters/python.py:402` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution._class_visible` | `atlas/src/atlas/metrics/adapters/python.py:410` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.declaration_allowed` | `atlas/src/atlas/metrics/adapters/python.py:421` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.import_shadowed` | `atlas/src/atlas/metrics/adapters/python.py:427` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.static` | `atlas/src/atlas/metrics/adapters/python.py:437` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.import_targets` | `atlas/src/atlas/metrics/adapters/python.py:447` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution._from_import_target` | `atlas/src/atlas/metrics/adapters/python.py:463` | 1 | 3 | 1 | 0.75 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.import_item` | `atlas/src/atlas/metrics/adapters/python.py:476` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution._from_import_item` | `atlas/src/atlas/metrics/adapters/python.py:491` | 1 | 3 | 1 | 0.75 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution._module_symbols` | `atlas/src/atlas/metrics/adapters/python.py:503` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/python.py::PythonResolution.implicit_receiver` | `atlas/src/atlas/metrics/adapters/python.py:509` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution.py` | `atlas/src/atlas/metrics/adapters/resolution.py` | 13 | 5 | 108 | 0.28 |
| `atlas/src/atlas/metrics/adapters/resolution.py::Binding` | `atlas/src/atlas/metrics/adapters/resolution.py:27` | 2 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution.py::Binding.member` | `atlas/src/atlas/metrics/adapters/resolution.py:36` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution.py::Modules` | `atlas/src/atlas/metrics/adapters/resolution.py:42` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution.py::Modules.__init__` | `atlas/src/atlas/metrics/adapters/resolution.py:45` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution.py::Modules.declared` | `atlas/src/atlas/metrics/adapters/resolution.py:58` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution.py::Modules._declared` | `atlas/src/atlas/metrics/adapters/resolution.py:69` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution.py::Modules.same_package` | `atlas/src/atlas/metrics/adapters/resolution.py:77` | 1 | 0 | 241 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution.py::CallableIdentity` | `atlas/src/atlas/metrics/adapters/resolution.py:81` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/resolution.py::CallableIdentity.__init__` | `atlas/src/atlas/metrics/adapters/resolution.py:82` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution.py::CallableIdentity.select` | `atlas/src/atlas/metrics/adapters/resolution.py:92` | 1 | 0 | 230 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings` | `atlas/src/atlas/metrics/adapters/resolution.py:99` | 1 | 3 | 1 | 0.75 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings.__init__` | `atlas/src/atlas/metrics/adapters/resolution.py:102` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings.path_files` | `atlas/src/atlas/metrics/adapters/resolution.py:113` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings.files` | `atlas/src/atlas/metrics/adapters/resolution.py:131` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._members` | `atlas/src/atlas/metrics/adapters/resolution.py:138` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._file_bindings` | `atlas/src/atlas/metrics/adapters/resolution.py:141` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._directive_bindings` | `atlas/src/atlas/metrics/adapters/resolution.py:155` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._binding` | `atlas/src/atlas/metrics/adapters/resolution.py:172` | 1 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._visible_binding` | `atlas/src/atlas/metrics/adapters/resolution.py:179` | 1 | 1 | 242 | 0.50 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings._named_bindings` | `atlas/src/atlas/metrics/adapters/resolution.py:185` | 1 | 0 | 242 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution.py::ImportBindings.get` | `atlas/src/atlas/metrics/adapters/resolution.py:188` | 2 | 2 | 241 | 0.50 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py` | `atlas/src/atlas/metrics/adapters/resolution_paths.py` | 11 | 2 | 114 | 0.15 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::top_symbols` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:10` | 3 | 1 | 5 | 0.25 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::quoted_path` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:14` | 7 | 0 | 7 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::import_path` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:19` | 6 | 0 | 8 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_relative_match` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:35` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::relative_targets` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:40` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_relative_directory` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:50` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_package_match` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:63` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_package_directory` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:70` | 3 | 0 | 7 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_package_directories` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:74` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::_package_path` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:81` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::package_targets` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:86` | 1 | 4 | 1 | 0.80 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::path_target_key` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:97` | 1 | 2 | 3 | 0.67 |
| `atlas/src/atlas/metrics/adapters/resolution_paths.py::namespace_binding` | `atlas/src/atlas/metrics/adapters/resolution_paths.py:104` | 4 | 0 | 5 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py` | `atlas/src/atlas/metrics/adapters/resolution_policy.py` | 5 | 4 | 112 | 0.44 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:20` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.receiver_owner` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:45` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.receiver_bindings` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:49` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.instance_members` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:52` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.module_index` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:55` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.lexical_imports` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:58` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.binding` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:61` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.write_target` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:72` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.visible` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:75` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.declaration_allowed` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:78` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_shadowed` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:81` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.is_import_node` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:84` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.static` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:87` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.paths` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:98` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_files` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:105` | 3 | 0 | 5 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_path` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:108` | 3 | 1 | 4 | 0.25 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_key` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:111` | 1 | 2 | 2 | 0.67 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_targets` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:114` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_type_only` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:118` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.import_item` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:121` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.namespace_members` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:126` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.module_bindings` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:131` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.members` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:134` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.module_identity` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:142` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.same_package` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:145` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.qualify_class` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:148` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.qualified` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:153` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.local_namespace` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:156` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.static_member` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:159` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.member_overwritten` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:162` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.call_target` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:167` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.normalized_call` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:180` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.receiver_type_allowed` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:186` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.receiver_class_allowed` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:189` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.receiver_rejected` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:192` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.implicit_receiver` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:195` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.clauses` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:198` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.select` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:201` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::ResolutionAdapter.inheritance` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:206` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::_namespace_inheritance` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:218` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::_inheritance_namespace` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:226` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/resolution_policy.py::_import_symbols` | `atlas/src/atlas/metrics/adapters/resolution_policy.py:233` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/rust.py` | `atlas/src/atlas/metrics/adapters/rust.py` | 4 | 9 | 101 | 0.69 |
| `atlas/src/atlas/metrics/adapters/rust.py::match_decision` | `atlas/src/atlas/metrics/adapters/rust.py:36` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/rust.py::_path_value` | `atlas/src/atlas/metrics/adapters/rust.py:41` | 1 | 1 | 4 | 0.50 |
| `atlas/src/atlas/metrics/adapters/rust.py::_path_attribute` | `atlas/src/atlas/metrics/adapters/rust.py:53` | 1 | 3 | 3 | 0.75 |
| `atlas/src/atlas/metrics/adapters/rust.py::path_attributes` | `atlas/src/atlas/metrics/adapters/rust.py:61` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/metrics/adapters/rust.py::_relative_identity` | `atlas/src/atlas/metrics/adapters/rust.py:78` | 1 | 0 | 5 | 0.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::_entry_files` | `atlas/src/atlas/metrics/adapters/rust.py:89` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::_inline_scopes` | `atlas/src/atlas/metrics/adapters/rust.py:97` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules` | `atlas/src/atlas/metrics/adapters/rust.py:103` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules.__init__` | `atlas/src/atlas/metrics/adapters/rust.py:106` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._rust_roots` | `atlas/src/atlas/metrics/adapters/rust.py:118` | 1 | 4 | 1 | 0.80 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._rust_files` | `atlas/src/atlas/metrics/adapters/rust.py:130` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._module_owner` | `atlas/src/atlas/metrics/adapters/rust.py:135` | 2 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._referenced_files` | `atlas/src/atlas/metrics/adapters/rust.py:141` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._module_directory` | `atlas/src/atlas/metrics/adapters/rust.py:149` | 1 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._child_scopes` | `atlas/src/atlas/metrics/adapters/rust.py:153` | 1 | 5 | 1 | 0.83 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._external_scopes` | `atlas/src/atlas/metrics/adapters/rust.py:174` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._walk_rust` | `atlas/src/atlas/metrics/adapters/rust.py:184` | 1 | 1 | 3 | 0.50 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._module_children` | `atlas/src/atlas/metrics/adapters/rust.py:191` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._rust_identities` | `atlas/src/atlas/metrics/adapters/rust.py:195` | 1 | 2 | 4 | 0.67 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules._rust_target` | `atlas/src/atlas/metrics/adapters/rust.py:206` | 3 | 2 | 3 | 0.40 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules.rust_key` | `atlas/src/atlas/metrics/adapters/rust.py:212` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules.rust_import` | `atlas/src/atlas/metrics/adapters/rust.py:217` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules.rust_symbols` | `atlas/src/atlas/metrics/adapters/rust.py:228` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustModules.rust_files` | `atlas/src/atlas/metrics/adapters/rust.py:234` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution` | `atlas/src/atlas/metrics/adapters/rust.py:238` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.instance_members` | `atlas/src/atlas/metrics/adapters/rust.py:241` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.import_path` | `atlas/src/atlas/metrics/adapters/rust.py:248` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution._inherent_impl` | `atlas/src/atlas/metrics/adapters/rust.py:252` | 1 | 3 | 1 | 0.75 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution._impl_types` | `atlas/src/atlas/metrics/adapters/rust.py:262` | 2 | 2 | 3 | 0.50 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.qualify_class` | `atlas/src/atlas/metrics/adapters/rust.py:272` | 1 | 0 | 4 | 0.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.receiver_owner` | `atlas/src/atlas/metrics/adapters/rust.py:280` | 0 | 5 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution._ancestor` | `atlas/src/atlas/metrics/adapters/rust.py:292` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution._has_self` | `atlas/src/atlas/metrics/adapters/rust.py:295` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.static` | `atlas/src/atlas/metrics/adapters/rust.py:300` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution._has_self_node` | `atlas/src/atlas/metrics/adapters/rust.py:308` | 2 | 1 | 3 | 0.33 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.call_target` | `atlas/src/atlas/metrics/adapters/rust.py:315` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.module_index` | `atlas/src/atlas/metrics/adapters/rust.py:333` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.index` | `atlas/src/atlas/metrics/adapters/rust.py:336` | 6 | 0 | 10 | 0.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.import_files` | `atlas/src/atlas/metrics/adapters/rust.py:339` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.import_key` | `atlas/src/atlas/metrics/adapters/rust.py:342` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.members` | `atlas/src/atlas/metrics/adapters/rust.py:351` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.import_item` | `atlas/src/atlas/metrics/adapters/rust.py:358` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.module_bindings` | `atlas/src/atlas/metrics/adapters/rust.py:375` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.local_namespace` | `atlas/src/atlas/metrics/adapters/rust.py:393` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.qualified` | `atlas/src/atlas/metrics/adapters/rust.py:401` | 1 | 1 | 4 | 0.50 |
| `atlas/src/atlas/metrics/adapters/rust.py::RustResolution.receiver_rejected` | `atlas/src/atlas/metrics/adapters/rust.py:410` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/rust.py::parameter_count` | `atlas/src/atlas/metrics/adapters/rust.py:418` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py` | `atlas/src/atlas/metrics/adapters/script_python_selection.py` | 1 | 2 | 102 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::import_names` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:9` | 5 | 2 | 15 | 0.29 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_decorators` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:16` | 1 | 1 | 3 | 0.50 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_prior_import` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:21` | 1 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_overload_target` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:27` | 1 | 2 | 4 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_add_providers` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:36` | 1 | 2 | 3 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_OverloadProviders` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:42` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_OverloadProviders.__init__` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:43` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_OverloadProviders.matches` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:48` | 1 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::typing_overload` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:54` | 2 | 4 | 2 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::overload_implementation` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:67` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_descriptor_aliases` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:73` | 1 | 3 | 4 | 0.75 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_descriptor_method` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:81` | 1 | 2 | 3 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_first_self` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:88` | 1 | 2 | 2 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_self_assignment` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:94` | 1 | 2 | 2 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::_instance_owner` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:100` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/metrics/adapters/script_python_selection.py::bound_self` | `atlas/src/atlas/metrics/adapters/script_python_selection.py:110` | 1 | 3 | 1 | 0.75 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py` | `atlas/src/atlas/metrics/adapters/script_resolution.py` | 3 | 3 | 104 | 0.50 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::inherited_members` | `atlas/src/atlas/metrics/adapters/script_resolution.py:10` | 2 | 1 | 2 | 0.33 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_InheritedMember` | `atlas/src/atlas/metrics/adapters/script_resolution.py:15` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_InheritedMember.__init__` | `atlas/src/atlas/metrics/adapters/script_resolution.py:16` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_InheritedMember.members` | `atlas/src/atlas/metrics/adapters/script_resolution.py:20` | 2 | 3 | 4 | 0.60 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_InheritedMember._masked` | `atlas/src/atlas/metrics/adapters/script_resolution.py:32` | 1 | 2 | 5 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_InheritedMember._inherited` | `atlas/src/atlas/metrics/adapters/script_resolution.py:37` | 1 | 2 | 4 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_InheritedMember.base_instance_write` | `atlas/src/atlas/metrics/adapters/script_resolution.py:44` | 1 | 4 | 5 | 0.80 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_base_class` | `atlas/src/atlas/metrics/adapters/script_resolution.py:54` | 2 | 1 | 6 | 0.33 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_instance_member_write` | `atlas/src/atlas/metrics/adapters/script_resolution.py:68` | 2 | 2 | 7 | 0.50 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_scope_member_write` | `atlas/src/atlas/metrics/adapters/script_resolution.py:73` | 1 | 1 | 8 | 0.50 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_instance_node_write` | `atlas/src/atlas/metrics/adapters/script_resolution.py:78` | 1 | 3 | 9 | 0.75 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_receiver_scopes` | `atlas/src/atlas/metrics/adapters/script_resolution.py:86` | 1 | 3 | 8 | 0.75 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_instance_scope` | `atlas/src/atlas/metrics/adapters/script_resolution.py:107` | 1 | 0 | 9 | 0.00 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_lexical_aliases` | `atlas/src/atlas/metrics/adapters/script_resolution.py:119` | 1 | 1 | 9 | 0.50 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_lexical_alias_targets` | `atlas/src/atlas/metrics/adapters/script_resolution.py:129` | 1 | 2 | 10 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_instance_field` | `atlas/src/atlas/metrics/adapters/script_resolution.py:138` | 1 | 2 | 6 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_plain_class` | `atlas/src/atlas/metrics/adapters/script_resolution.py:148` | 3 | 0 | 9 | 0.00 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_method_receiver` | `atlas/src/atlas/metrics/adapters/script_resolution.py:154` | 1 | 1 | 9 | 0.50 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_first_receiver` | `atlas/src/atlas/metrics/adapters/script_resolution.py:165` | 1 | 2 | 10 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::member_mutation` | `atlas/src/atlas/metrics/adapters/script_resolution.py:172` | 2 | 2 | 13 | 0.50 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::member_write` | `atlas/src/atlas/metrics/adapters/script_resolution.py:184` | 2 | 0 | 13 | 0.00 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_plain_base` | `atlas/src/atlas/metrics/adapters/script_resolution.py:190` | 1 | 3 | 7 | 0.75 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_single_base` | `atlas/src/atlas/metrics/adapters/script_resolution.py:198` | 1 | 1 | 8 | 0.50 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::same_declaration_group` | `atlas/src/atlas/metrics/adapters/script_resolution.py:208` | 3 | 0 | 5 | 0.00 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::executable_implementation` | `atlas/src/atlas/metrics/adapters/script_resolution.py:212` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_signature_implementation` | `atlas/src/atlas/metrics/adapters/script_resolution.py:222` | 1 | 2 | 2 | 0.67 |
| `atlas/src/atlas/metrics/adapters/script_resolution.py::_signatures_precede` | `atlas/src/atlas/metrics/adapters/script_resolution.py:230` | 1 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/adapters/typescript.py` | `atlas/src/atlas/metrics/adapters/typescript.py` | 1 | 3 | 101 | 0.75 |
| `atlas/src/atlas/metrics/adapters/typescript.py::parameter_count` | `atlas/src/atlas/metrics/adapters/typescript.py:12` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/adapters/typescript.py::TypeScriptResolution` | `atlas/src/atlas/metrics/adapters/typescript.py:19` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/adapters/typescript.py::TypeScriptResolution.select` | `atlas/src/atlas/metrics/adapters/typescript.py:20` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/artifact.py` | `atlas/src/atlas/metrics/artifact.py` | 12 | 4 | 88 | 0.25 |
| `atlas/src/atlas/metrics/artifact.py::GraphArtifact` | `atlas/src/atlas/metrics/artifact.py:28` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::GraphArtifact.validate_references` | `atlas/src/atlas/metrics/artifact.py:45` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/metrics/artifact.py::_validate_dependency_metrics` | `atlas/src/atlas/metrics/artifact.py:79` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/artifact.py::_validate_instability` | `atlas/src/atlas/metrics/artifact.py:89` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::_validate_edge_endpoints` | `atlas/src/atlas/metrics/artifact.py:96` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::_module_key` | `atlas/src/atlas/metrics/artifact.py:105` | 2 | 0 | 89 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::_symbol_level` | `atlas/src/atlas/metrics/artifact.py:109` | 1 | 0 | 86 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::_directory_ancestors` | `atlas/src/atlas/metrics/artifact.py:119` | 1 | 0 | 87 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::_module_paths` | `atlas/src/atlas/metrics/artifact.py:128` | 1 | 1 | 86 | 0.50 |
| `atlas/src/atlas/metrics/artifact.py::_module_paths.<anonymous>` | `atlas/src/atlas/metrics/artifact.py:132` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/artifact.py::_SourceLocation` | `atlas/src/atlas/metrics/artifact.py:136` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/artifact.py::_ArtifactContents` | `atlas/src/atlas/metrics/artifact.py:143` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/artifact.py::_containment_edge` | `atlas/src/atlas/metrics/artifact.py:149` | 3 | 0 | 90 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::_ancestor_keys` | `atlas/src/atlas/metrics/artifact.py:163` | 1 | 0 | 86 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::_add_hierarchy` | `atlas/src/atlas/metrics/artifact.py:175` | 1 | 1 | 85 | 0.50 |
| `atlas/src/atlas/metrics/artifact.py::_enrich_edges` | `atlas/src/atlas/metrics/artifact.py:183` | 1 | 0 | 85 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::_projected_key` | `atlas/src/atlas/metrics/artifact.py:198` | 1 | 0 | 108 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::_projected_relationships` | `atlas/src/atlas/metrics/artifact.py:210` | 1 | 1 | 107 | 0.50 |
| `atlas/src/atlas/metrics/artifact.py::_relationship_counts` | `atlas/src/atlas/metrics/artifact.py:227` | 1 | 0 | 108 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::_view_edges` | `atlas/src/atlas/metrics/artifact.py:231` | 1 | 1 | 107 | 0.50 |
| `atlas/src/atlas/metrics/artifact.py::_level_view` | `atlas/src/atlas/metrics/artifact.py:250` | 1 | 2 | 106 | 0.67 |
| `atlas/src/atlas/metrics/artifact.py::build_dependency_views` | `atlas/src/atlas/metrics/artifact.py:262` | 4 | 1 | 105 | 0.20 |
| `atlas/src/atlas/metrics/artifact.py::_add_view_metrics` | `atlas/src/atlas/metrics/artifact.py:273` | 1 | 1 | 86 | 0.50 |
| `atlas/src/atlas/metrics/artifact.py::_add_dependency_metrics` | `atlas/src/atlas/metrics/artifact.py:280` | 1 | 1 | 85 | 0.50 |
| `atlas/src/atlas/metrics/artifact.py::_add_directory_nodes` | `atlas/src/atlas/metrics/artifact.py:288` | 1 | 3 | 85 | 0.75 |
| `atlas/src/atlas/metrics/artifact.py::_add_file_nodes` | `atlas/src/atlas/metrics/artifact.py:313` | 2 | 3 | 87 | 0.60 |
| `atlas/src/atlas/metrics/artifact.py::_add_symbol_nodes` | `atlas/src/atlas/metrics/artifact.py:351` | 1 | 2 | 85 | 0.67 |
| `atlas/src/atlas/metrics/artifact.py::_add_external_nodes` | `atlas/src/atlas/metrics/artifact.py:402` | 1 | 0 | 85 | 0.00 |
| `atlas/src/atlas/metrics/artifact.py::build_artifact` | `atlas/src/atlas/metrics/artifact.py:420` | 4 | 9 | 84 | 0.69 |
| `atlas/src/atlas/metrics/artifact.py::validate_artifact` | `atlas/src/atlas/metrics/artifact.py:509` | 4 | 0 | 4 | 0.00 |
| `atlas/src/atlas/metrics/callables.py` | `atlas/src/atlas/metrics/callables.py` | 9 | 3 | 92 | 0.25 |
| `atlas/src/atlas/metrics/callables.py::callable_metrics` | `atlas/src/atlas/metrics/callables.py:10` | 6 | 2 | 135 | 0.25 |
| `atlas/src/atlas/metrics/callables.py::add_callable_metrics` | `atlas/src/atlas/metrics/callables.py:33` | 10 | 1 | 89 | 0.09 |
| `atlas/src/atlas/metrics/check.py` | `atlas/src/atlas/metrics/check.py` | 4 | 2 | 39 | 0.33 |
| `atlas/src/atlas/metrics/check.py::_MetricLimit` | `atlas/src/atlas/metrics/check.py:24` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/check.py::_finding` | `atlas/src/atlas/metrics/check.py:30` | 1 | 0 | 23 | 0.00 |
| `atlas/src/atlas/metrics/check.py::_metric_finding` | `atlas/src/atlas/metrics/check.py:43` | 2 | 1 | 22 | 0.33 |
| `atlas/src/atlas/metrics/check.py::_enabled_limits` | `atlas/src/atlas/metrics/check.py:50` | 1 | 0 | 21 | 0.00 |
| `atlas/src/atlas/metrics/check.py::_isolated` | `atlas/src/atlas/metrics/check.py:60` | 1 | 0 | 21 | 0.00 |
| `atlas/src/atlas/metrics/check.py::_node_findings` | `atlas/src/atlas/metrics/check.py:64` | 2 | 3 | 20 | 0.60 |
| `atlas/src/atlas/metrics/check.py::_cycle_files` | `atlas/src/atlas/metrics/check.py:76` | 1 | 0 | 14 | 0.00 |
| `atlas/src/atlas/metrics/check.py::_cycle_finding` | `atlas/src/atlas/metrics/check.py:83` | 1 | 1 | 13 | 0.50 |
| `atlas/src/atlas/metrics/check.py::build_check` | `atlas/src/atlas/metrics/check.py:98` | 12 | 2 | 12 | 0.14 |
| `atlas/src/atlas/metrics/check.py::_finding_section` | `atlas/src/atlas/metrics/check.py:110` | 1 | 3 | 6 | 0.75 |
| `atlas/src/atlas/metrics/check.py::render_check` | `atlas/src/atlas/metrics/check.py:119` | 5 | 1 | 5 | 0.17 |
| `atlas/src/atlas/metrics/complexity.py` | `atlas/src/atlas/metrics/complexity.py` | 7 | 3 | 93 | 0.30 |
| `atlas/src/atlas/metrics/complexity.py::_TraversalFrame` | `atlas/src/atlas/metrics/complexity.py:16` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/complexity.py::_decision_metrics` | `atlas/src/atlas/metrics/complexity.py:22` | 1 | 0 | 144 | 0.00 |
| `atlas/src/atlas/metrics/complexity.py::_child_frames` | `atlas/src/atlas/metrics/complexity.py:38` | 1 | 0 | 144 | 0.00 |
| `atlas/src/atlas/metrics/complexity.py::calculate_complexity` | `atlas/src/atlas/metrics/complexity.py:45` | 12 | 2 | 143 | 0.14 |
| `atlas/src/atlas/metrics/config.py` | `atlas/src/atlas/metrics/config.py` | 8 | 0 | 41 | 0.00 |
| `atlas/src/atlas/metrics/config.py::CheckConfig` | `atlas/src/atlas/metrics/config.py:8` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/config.py::load_config` | `atlas/src/atlas/metrics/config.py:22` | 5 | 0 | 5 | 0.00 |
| `atlas/src/atlas/metrics/cycles.py` | `atlas/src/atlas/metrics/cycles.py` | 5 | 0 | 91 | 0.00 |
| `atlas/src/atlas/metrics/cycles.py::CircularGroup` | `atlas/src/atlas/metrics/cycles.py:15` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/cycles.py::CircularDependencies` | `atlas/src/atlas/metrics/cycles.py:24` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/cycles.py::_owner_boundary` | `atlas/src/atlas/metrics/cycles.py:31` | 1 | 0 | 112 | 0.00 |
| `atlas/src/atlas/metrics/cycles.py::_find_file_owner` | `atlas/src/atlas/metrics/cycles.py:43` | 1 | 1 | 111 | 0.50 |
| `atlas/src/atlas/metrics/cycles.py::_file_owners` | `atlas/src/atlas/metrics/cycles.py:59` | 1 | 1 | 110 | 0.50 |
| `atlas/src/atlas/metrics/cycles.py::_import_edges` | `atlas/src/atlas/metrics/cycles.py:69` | 1 | 2 | 109 | 0.67 |
| `atlas/src/atlas/metrics/cycles.py::_import_edges.<anonymous>` | `atlas/src/atlas/metrics/cycles.py:78` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/cycles.py::_import_metadata` | `atlas/src/atlas/metrics/cycles.py:81` | 1 | 0 | 111 | 0.00 |
| `atlas/src/atlas/metrics/cycles.py::_project_import` | `atlas/src/atlas/metrics/cycles.py:89` | 1 | 1 | 110 | 0.50 |
| `atlas/src/atlas/metrics/cycles.py::_reverse_group` | `atlas/src/atlas/metrics/cycles.py:109` | 1 | 1 | 124 | 0.50 |
| `atlas/src/atlas/metrics/cycles.py::_enqueue_unvisited` | `atlas/src/atlas/metrics/cycles.py:121` | 1 | 0 | 125 | 0.00 |
| `atlas/src/atlas/metrics/cycles.py::_finish_from` | `atlas/src/atlas/metrics/cycles.py:130` | 1 | 0 | 125 | 0.00 |
| `atlas/src/atlas/metrics/cycles.py::_add_reverse_edges` | `atlas/src/atlas/metrics/cycles.py:147` | 1 | 0 | 125 | 0.00 |
| `atlas/src/atlas/metrics/cycles.py::_reverse_adjacency` | `atlas/src/atlas/metrics/cycles.py:154` | 1 | 1 | 124 | 0.50 |
| `atlas/src/atlas/metrics/cycles.py::_finish_order` | `atlas/src/atlas/metrics/cycles.py:161` | 1 | 1 | 124 | 0.50 |
| `atlas/src/atlas/metrics/cycles.py::strongly_connected_components` | `atlas/src/atlas/metrics/cycles.py:172` | 2 | 3 | 123 | 0.60 |
| `atlas/src/atlas/metrics/cycles.py::_components` | `atlas/src/atlas/metrics/cycles.py:190` | 1 | 1 | 109 | 0.50 |
| `atlas/src/atlas/metrics/cycles.py::_path_to_start` | `atlas/src/atlas/metrics/cycles.py:198` | 1 | 0 | 111 | 0.00 |
| `atlas/src/atlas/metrics/cycles.py::_CycleSearch` | `atlas/src/atlas/metrics/cycles.py:208` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/cycles.py::_CycleSearch.visit_neighbors` | `atlas/src/atlas/metrics/cycles.py:215` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/cycles.py::_example_cycle` | `atlas/src/atlas/metrics/cycles.py:226` | 1 | 1 | 110 | 0.50 |
| `atlas/src/atlas/metrics/cycles.py::_cycle_group` | `atlas/src/atlas/metrics/cycles.py:242` | 1 | 1 | 109 | 0.50 |
| `atlas/src/atlas/metrics/cycles.py::_register_members` | `atlas/src/atlas/metrics/cycles.py:252` | 1 | 0 | 109 | 0.00 |
| `atlas/src/atlas/metrics/cycles.py::circular_dependencies` | `atlas/src/atlas/metrics/cycles.py:257` | 10 | 4 | 108 | 0.29 |
| `atlas/src/atlas/metrics/dependency_metrics.py` | `atlas/src/atlas/metrics/dependency_metrics.py` | 4 | 2 | 89 | 0.33 |
| `atlas/src/atlas/metrics/dependency_metrics.py::_adjacency` | `atlas/src/atlas/metrics/dependency_metrics.py:12` | 1 | 0 | 113 | 0.00 |
| `atlas/src/atlas/metrics/dependency_metrics.py::_component_targets` | `atlas/src/atlas/metrics/dependency_metrics.py:21` | 1 | 0 | 114 | 0.00 |
| `atlas/src/atlas/metrics/dependency_metrics.py::_propagate` | `atlas/src/atlas/metrics/dependency_metrics.py:36` | 1 | 0 | 114 | 0.00 |
| `atlas/src/atlas/metrics/dependency_metrics.py::_change_impact` | `atlas/src/atlas/metrics/dependency_metrics.py:41` | 1 | 3 | 113 | 0.75 |
| `atlas/src/atlas/metrics/dependency_metrics.py::dependency_metrics` | `atlas/src/atlas/metrics/dependency_metrics.py:57` | 11 | 2 | 112 | 0.15 |
| `atlas/src/atlas/metrics/receiver_resolution.py` | `atlas/src/atlas/metrics/receiver_resolution.py` | 1 | 4 | 92 | 0.80 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes` | `atlas/src/atlas/metrics/receiver_resolution.py:12` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes.__init__` | `atlas/src/atlas/metrics/receiver_resolution.py:13` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes.bindings` | `atlas/src/atlas/metrics/receiver_resolution.py:17` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes.resolve` | `atlas/src/atlas/metrics/receiver_resolution.py:21` | 1 | 1 | 232 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._receiver_types` | `atlas/src/atlas/metrics/receiver_resolution.py:25` | 3 | 3 | 241 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._implicit_types` | `atlas/src/atlas/metrics/receiver_resolution.py:38` | 1 | 2 | 241 | 0.67 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._lexical_types` | `atlas/src/atlas/metrics/receiver_resolution.py:47` | 1 | 4 | 241 | 0.80 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._binding_types` | `atlas/src/atlas/metrics/receiver_resolution.py:59` | 1 | 5 | 241 | 0.83 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._nearest` | `atlas/src/atlas/metrics/receiver_resolution.py:69` | 1 | 0 | 242 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._member_receiver` | `atlas/src/atlas/metrics/receiver_resolution.py:75` | 3 | 0 | 244 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._candidates` | `atlas/src/atlas/metrics/receiver_resolution.py:79` | 1 | 1 | 242 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._visible` | `atlas/src/atlas/metrics/receiver_resolution.py:83` | 1 | 1 | 243 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._unsafe` | `atlas/src/atlas/metrics/receiver_resolution.py:91` | 1 | 3 | 242 | 0.75 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._conditional` | `atlas/src/atlas/metrics/receiver_resolution.py:98` | 2 | 0 | 243 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._declared_types` | `atlas/src/atlas/metrics/receiver_resolution.py:109` | 3 | 5 | 241 | 0.62 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._type_symbols` | `atlas/src/atlas/metrics/receiver_resolution.py:126` | 1 | 0 | 242 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._conflicting_types` | `atlas/src/atlas/metrics/receiver_resolution.py:132` | 1 | 0 | 242 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._initializer_types` | `atlas/src/atlas/metrics/receiver_resolution.py:135` | 1 | 1 | 241 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._value_types` | `atlas/src/atlas/metrics/receiver_resolution.py:140` | 1 | 4 | 241 | 0.80 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._qualified_type` | `atlas/src/atlas/metrics/receiver_resolution.py:155` | 2 | 0 | 245 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._field_types` | `atlas/src/atlas/metrics/receiver_resolution.py:160` | 1 | 2 | 241 | 0.67 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._fields` | `atlas/src/atlas/metrics/receiver_resolution.py:165` | 2 | 5 | 241 | 0.71 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._field_bindings` | `atlas/src/atlas/metrics/receiver_resolution.py:181` | 1 | 0 | 242 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._static` | `atlas/src/atlas/metrics/receiver_resolution.py:185` | 1 | 0 | 243 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._shadowed` | `atlas/src/atlas/metrics/receiver_resolution.py:189` | 1 | 0 | 242 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._reassigned` | `atlas/src/atlas/metrics/receiver_resolution.py:196` | 3 | 2 | 245 | 0.40 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._field_initialization` | `atlas/src/atlas/metrics/receiver_resolution.py:206` | 1 | 1 | 245 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._constructor_initialization` | `atlas/src/atlas/metrics/receiver_resolution.py:216` | 1 | 3 | 245 | 0.75 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._path_written` | `atlas/src/atlas/metrics/receiver_resolution.py:224` | 3 | 3 | 242 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._call_scope` | `atlas/src/atlas/metrics/receiver_resolution.py:235` | 1 | 0 | 243 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._targets_written` | `atlas/src/atlas/metrics/receiver_resolution.py:241` | 1 | 1 | 243 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._expand_paths` | `atlas/src/atlas/metrics/receiver_resolution.py:245` | 1 | 1 | 243 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._expand_aliases` | `atlas/src/atlas/metrics/receiver_resolution.py:254` | 1 | 1 | 244 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._node_aliases` | `atlas/src/atlas/metrics/receiver_resolution.py:261` | 1 | 4 | 245 | 0.80 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._alias_paths` | `atlas/src/atlas/metrics/receiver_resolution.py:268` | 1 | 0 | 246 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._identity_overwritten` | `atlas/src/atlas/metrics/receiver_resolution.py:272` | 1 | 1 | 242 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._identity_write` | `atlas/src/atlas/metrics/receiver_resolution.py:278` | 1 | 2 | 243 | 0.67 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._write_identities` | `atlas/src/atlas/metrics/receiver_resolution.py:288` | 1 | 1 | 244 | 0.50 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._single_expression` | `atlas/src/atlas/metrics/receiver_resolution.py:294` | 2 | 0 | 252 | 0.00 |
| `atlas/src/atlas/metrics/receiver_resolution.py::ReceiverTypes._write_names` | `atlas/src/atlas/metrics/receiver_resolution.py:299` | 2 | 3 | 248 | 0.60 |
| `atlas/src/atlas/metrics/receiver_syntax.py` | `atlas/src/atlas/metrics/receiver_syntax.py` | 8 | 1 | 109 | 0.11 |
| `atlas/src/atlas/metrics/receiver_syntax.py::ReceiverBinding` | `atlas/src/atlas/metrics/receiver_syntax.py:12` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/receiver_syntax.py::type_name` | `atlas/src/atlas/metrics/receiver_syntax.py:22` | 12 | 4 | 21 | 0.25 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_wrapped_type_name` | `atlas/src/atlas/metrics/receiver_syntax.py:33` | 1 | 1 | 21 | 0.50 |
| `atlas/src/atlas/metrics/receiver_syntax.py::child` | `atlas/src/atlas/metrics/receiver_syntax.py:38` | 6 | 0 | 25 | 0.00 |
| `atlas/src/atlas/metrics/receiver_syntax.py::enclosing` | `atlas/src/atlas/metrics/receiver_syntax.py:42` | 3 | 0 | 11 | 0.00 |
| `atlas/src/atlas/metrics/receiver_syntax.py::Declaration` | `atlas/src/atlas/metrics/receiver_syntax.py:53` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/receiver_syntax.py::declaration` | `atlas/src/atlas/metrics/receiver_syntax.py:60` | 7 | 4 | 7 | 0.36 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_inferred_annotation` | `atlas/src/atlas/metrics/receiver_syntax.py:71` | 1 | 5 | 8 | 0.83 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_constructed_annotation` | `atlas/src/atlas/metrics/receiver_syntax.py:81` | 1 | 1 | 9 | 0.50 |
| `atlas/src/atlas/metrics/receiver_syntax.py::member_assignment` | `atlas/src/atlas/metrics/receiver_syntax.py:89` | 1 | 1 | 9 | 0.50 |
| `atlas/src/atlas/metrics/receiver_syntax.py::static_field` | `atlas/src/atlas/metrics/receiver_syntax.py:94` | 1 | 1 | 8 | 0.50 |
| `atlas/src/atlas/metrics/receiver_syntax.py::constructor` | `atlas/src/atlas/metrics/receiver_syntax.py:100` | 1 | 3 | 9 | 0.75 |
| `atlas/src/atlas/metrics/receiver_syntax.py::injected_parameter` | `atlas/src/atlas/metrics/receiver_syntax.py:105` | 1 | 4 | 9 | 0.80 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_parameter_written` | `atlas/src/atlas/metrics/receiver_syntax.py:118` | 1 | 2 | 10 | 0.67 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_parameter_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:124` | 1 | 0 | 10 | 0.00 |
| `atlas/src/atlas/metrics/receiver_syntax.py::java_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:129` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/metrics/receiver_syntax.py::kotlin_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:138` | 0 | 5 | 0 | 1.00 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_kotlin_member` | `atlas/src/atlas/metrics/receiver_syntax.py:150` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_kotlin_property` | `atlas/src/atlas/metrics/receiver_syntax.py:154` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/receiver_syntax.py::python_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:162` | 0 | 5 | 0 | 1.00 |
| `atlas/src/atlas/metrics/receiver_syntax.py::script_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:180` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/metrics/receiver_syntax.py::go_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:192` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/metrics/receiver_syntax.py::_go_short_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:202` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/receiver_syntax.py::rust_bindings` | `atlas/src/atlas/metrics/receiver_syntax.py:213` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/metrics/report.py` | `atlas/src/atlas/metrics/report.py` | 7 | 6 | 49 | 0.46 |
| `atlas/src/atlas/metrics/report.py::_node_order` | `atlas/src/atlas/metrics/report.py:26` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/report.py::_dependency_values` | `atlas/src/atlas/metrics/report.py:30` | 1 | 2 | 23 | 0.67 |
| `atlas/src/atlas/metrics/report.py::_file_owner` | `atlas/src/atlas/metrics/report.py:39` | 1 | 0 | 24 | 0.00 |
| `atlas/src/atlas/metrics/report.py::_file_summaries` | `atlas/src/atlas/metrics/report.py:49` | 1 | 1 | 23 | 0.50 |
| `atlas/src/atlas/metrics/report.py::_measurement` | `atlas/src/atlas/metrics/report.py:70` | 1 | 0 | 23 | 0.00 |
| `atlas/src/atlas/metrics/report.py::_cycle_measurements` | `atlas/src/atlas/metrics/report.py:92` | 1 | 0 | 23 | 0.00 |
| `atlas/src/atlas/metrics/report.py::build_artifact_report` | `atlas/src/atlas/metrics/report.py:109` | 13 | 5 | 22 | 0.28 |
| `atlas/src/atlas/metrics/report.py::_record_node` | `atlas/src/atlas/metrics/report.py:134` | 1 | 0 | 9 | 0.00 |
| `atlas/src/atlas/metrics/report.py::build_report` | `atlas/src/atlas/metrics/report.py:140` | 3 | 2 | 8 | 0.40 |
| `atlas/src/atlas/metrics/report_markdown.py` | `atlas/src/atlas/metrics/report_markdown.py` | 2 | 0 | 52 | 0.00 |
| `atlas/src/atlas/metrics/report_markdown.py::code` | `atlas/src/atlas/metrics/report_markdown.py:16` | 4 | 0 | 14 | 0.00 |
| `atlas/src/atlas/metrics/report_markdown.py::location` | `atlas/src/atlas/metrics/report_markdown.py:26` | 2 | 0 | 12 | 0.00 |
| `atlas/src/atlas/metrics/report_markdown.py::value_text` | `atlas/src/atlas/metrics/report_markdown.py:31` | 2 | 0 | 12 | 0.00 |
| `atlas/src/atlas/metrics/report_markdown.py::_table_row` | `atlas/src/atlas/metrics/report_markdown.py:37` | 1 | 3 | 4 | 0.75 |
| `atlas/src/atlas/metrics/report_markdown.py::_table` | `atlas/src/atlas/metrics/report_markdown.py:42` | 2 | 1 | 3 | 0.33 |
| `atlas/src/atlas/metrics/report_markdown.py::_cycle_section` | `atlas/src/atlas/metrics/report_markdown.py:49` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/metrics/report_markdown.py::_cycles` | `atlas/src/atlas/metrics/report_markdown.py:58` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/report_markdown.py::_size_tables` | `atlas/src/atlas/metrics/report_markdown.py:65` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/report_markdown.py::_dependencies` | `atlas/src/atlas/metrics/report_markdown.py:79` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/metrics/report_markdown.py::render_markdown` | `atlas/src/atlas/metrics/report_markdown.py:90` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/metrics/resolution_contract.py` | `atlas/src/atlas/metrics/resolution_contract.py` | 15 | 1 | 117 | 0.06 |
| `atlas/src/atlas/metrics/resolution_contract.py::ImportRequest` | `atlas/src/atlas/metrics/resolution_contract.py:11` | 3 | 0 | 5 | 0.00 |
| `atlas/src/atlas/metrics/resolution_contract.py::ResolutionRequest` | `atlas/src/atlas/metrics/resolution_contract.py:21` | 3 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/resolution_contract.py::CallTarget` | `atlas/src/atlas/metrics/resolution_contract.py:32` | 2 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/resolution_contract.py::DeclarationLookup` | `atlas/src/atlas/metrics/resolution_contract.py:42` | 1 | 0 | 3 | 0.00 |
| `atlas/src/atlas/metrics/resolution_syntax.py` | `atlas/src/atlas/metrics/resolution_syntax.py` | 9 | 4 | 110 | 0.31 |
| `atlas/src/atlas/metrics/resolution_syntax.py::names` | `atlas/src/atlas/metrics/resolution_syntax.py:33` | 6 | 3 | 255 | 0.33 |
| `atlas/src/atlas/metrics/resolution_syntax.py::_structured_names` | `atlas/src/atlas/metrics/resolution_syntax.py:46` | 1 | 3 | 255 | 0.75 |
| `atlas/src/atlas/metrics/resolution_syntax.py::_child_names` | `atlas/src/atlas/metrics/resolution_syntax.py:56` | 1 | 1 | 255 | 0.50 |
| `atlas/src/atlas/metrics/resolution_syntax.py::_same_import` | `atlas/src/atlas/metrics/resolution_syntax.py:86` | 1 | 1 | 5 | 0.50 |
| `atlas/src/atlas/metrics/resolution_syntax.py::_class_or_function` | `atlas/src/atlas/metrics/resolution_syntax.py:90` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/resolution_syntax.py::_binding_entries` | `atlas/src/atlas/metrics/resolution_syntax.py:100` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax` | `atlas/src/atlas/metrics/resolution_syntax.py:104` | 2 | 1 | 2 | 0.33 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.__init__` | `atlas/src/atlas/metrics/resolution_syntax.py:107` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.root` | `atlas/src/atlas/metrics/resolution_syntax.py:114` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.nodes` | `atlas/src/atlas/metrics/resolution_syntax.py:127` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.spans` | `atlas/src/atlas/metrics/resolution_syntax.py:131` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.imports` | `atlas/src/atlas/metrics/resolution_syntax.py:135` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.bindings` | `atlas/src/atlas/metrics/resolution_syntax.py:139` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.node` | `atlas/src/atlas/metrics/resolution_syntax.py:145` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.scope` | `atlas/src/atlas/metrics/resolution_syntax.py:148` | 2 | 0 | 4 | 0.00 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax._bindings` | `atlas/src/atlas/metrics/resolution_syntax.py:154` | 1 | 5 | 1 | 0.83 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax._visible` | `atlas/src/atlas/metrics/resolution_syntax.py:168` | 2 | 0 | 245 | 0.00 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax._declaration_allowed` | `atlas/src/atlas/metrics/resolution_syntax.py:173` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.shadowed` | `atlas/src/atlas/metrics/resolution_syntax.py:181` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.import_nodes_by_line` | `atlas/src/atlas/metrics/resolution_syntax.py:195` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.import_node` | `atlas/src/atlas/metrics/resolution_syntax.py:202` | 3 | 1 | 4 | 0.25 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.import_scope` | `atlas/src/atlas/metrics/resolution_syntax.py:210` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.class_rebound` | `atlas/src/atlas/metrics/resolution_syntax.py:214` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.member_rebound` | `atlas/src/atlas/metrics/resolution_syntax.py:227` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/resolution_syntax.py::Syntax.static` | `atlas/src/atlas/metrics/resolution_syntax.py:235` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/resolver.py` | `atlas/src/atlas/metrics/resolver.py` | 19 | 7 | 91 | 0.27 |
| `atlas/src/atlas/metrics/resolver.py::ExternalNode` | `atlas/src/atlas/metrics/resolver.py:39` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/resolver.py::Connection` | `atlas/src/atlas/metrics/resolver.py:49` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/resolver.py::ResolvedGraph` | `atlas/src/atlas/metrics/resolver.py:63` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/resolver.py::_external_key` | `atlas/src/atlas/metrics/resolver.py:70` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/metrics/resolver.py::_resolve_calls` | `atlas/src/atlas/metrics/resolver.py:75` | 1 | 1 | 227 | 0.50 |
| `atlas/src/atlas/metrics/resolver.py::_call_connections` | `atlas/src/atlas/metrics/resolver.py:87` | 1 | 3 | 228 | 0.75 |
| `atlas/src/atlas/metrics/resolver.py::resolve_connections` | `atlas/src/atlas/metrics/resolver.py:111` | 26 | 3 | 226 | 0.10 |
| `atlas/src/atlas/metrics/resolver.py::resolve_connections._external` | `atlas/src/atlas/metrics/resolver.py:131` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/resolver.py::_resolve_imports` | `atlas/src/atlas/metrics/resolver.py:143` | 1 | 1 | 227 | 0.50 |
| `atlas/src/atlas/metrics/resolver.py::_import_connections` | `atlas/src/atlas/metrics/resolver.py:154` | 2 | 2 | 229 | 0.50 |
| `atlas/src/atlas/metrics/resolver.py::_resolve_inheritances` | `atlas/src/atlas/metrics/resolver.py:182` | 1 | 1 | 227 | 0.50 |
| `atlas/src/atlas/metrics/resolver.py::_inheritance_targets` | `atlas/src/atlas/metrics/resolver.py:209` | 1 | 2 | 228 | 0.67 |
| `atlas/src/atlas/metrics/resolver.py::_language_family` | `atlas/src/atlas/metrics/resolver.py:242` | 1 | 1 | 242 | 0.50 |
| `atlas/src/atlas/metrics/resolver.py::_import_masks_local` | `atlas/src/atlas/metrics/resolver.py:246` | 1 | 1 | 241 | 0.50 |
| `atlas/src/atlas/metrics/resolver.py::_enclosing_method` | `atlas/src/atlas/metrics/resolver.py:257` | 1 | 0 | 234 | 0.00 |
| `atlas/src/atlas/metrics/resolver.py::_is_bare_target` | `atlas/src/atlas/metrics/resolver.py:265` | 1 | 0 | 231 | 0.00 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver` | `atlas/src/atlas/metrics/resolver.py:271` | 0 | 6 | 0 | 1.00 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.__init__` | `atlas/src/atlas/metrics/resolver.py:274` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.owner` | `atlas/src/atlas/metrics/resolver.py:287` | 1 | 0 | 229 | 0.00 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.owner.<anonymous>` | `atlas/src/atlas/metrics/resolver.py:294` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.ancestors` | `atlas/src/atlas/metrics/resolver.py:299` | 2 | 0 | 243 | 0.00 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.lexical` | `atlas/src/atlas/metrics/resolver.py:306` | 2 | 3 | 241 | 0.60 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._scope_declarations` | `atlas/src/atlas/metrics/resolver.py:318` | 1 | 1 | 242 | 0.50 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.named` | `atlas/src/atlas/metrics/resolver.py:330` | 3 | 5 | 240 | 0.62 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._fallback_named` | `atlas/src/atlas/metrics/resolver.py:348` | 1 | 1 | 241 | 0.50 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.class_named` | `atlas/src/atlas/metrics/resolver.py:358` | 3 | 2 | 236 | 0.40 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._receiver_class` | `atlas/src/atlas/metrics/resolver.py:365` | 1 | 3 | 232 | 0.75 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._self_class` | `atlas/src/atlas/metrics/resolver.py:380` | 1 | 3 | 233 | 0.75 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.members` | `atlas/src/atlas/metrics/resolver.py:394` | 4 | 2 | 235 | 0.33 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._member_declarations` | `atlas/src/atlas/metrics/resolver.py:408` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._static_members` | `atlas/src/atlas/metrics/resolver.py:415` | 1 | 1 | 236 | 0.50 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._namespace_member` | `atlas/src/atlas/metrics/resolver.py:425` | 1 | 4 | 234 | 0.80 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.qualified` | `atlas/src/atlas/metrics/resolver.py:437` | 2 | 4 | 232 | 0.67 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._qualified_binding` | `atlas/src/atlas/metrics/resolver.py:452` | 1 | 5 | 233 | 0.83 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._bare` | `atlas/src/atlas/metrics/resolver.py:466` | 1 | 2 | 231 | 0.67 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._matches` | `atlas/src/atlas/metrics/resolver.py:473` | 1 | 6 | 230 | 0.86 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._typed_matches` | `atlas/src/atlas/metrics/resolver.py:496` | 1 | 1 | 231 | 0.50 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver._receiver_matches` | `atlas/src/atlas/metrics/resolver.py:501` | 1 | 3 | 231 | 0.75 |
| `atlas/src/atlas/metrics/resolver.py::CallResolver.resolve` | `atlas/src/atlas/metrics/resolver.py:508` | 1 | 3 | 229 | 0.75 |
| `atlas.src.atlas.parsing` | `atlas/src/atlas/parsing` | 4 | 3 | 7 | 0.43 |
| `atlas/src/atlas/parsing/__init__.py` | `atlas/src/atlas/parsing/__init__.py` | 0 | 0 | 0 | N/A |
| `atlas.src.atlas.parsing.adapters` | `atlas/src/atlas/parsing/adapters` | 2 | 2 | 7 | 0.50 |
| `atlas/src/atlas/parsing/adapters/__init__.py` | `atlas/src/atlas/parsing/adapters/__init__.py` | 7 | 10 | 95 | 0.59 |
| `atlas/src/atlas/parsing/adapters/__init__.py::get_adapter` | `atlas/src/atlas/parsing/adapters/__init__.py:22` | 20 | 1 | 371 | 0.05 |
| `atlas/src/atlas/parsing/adapters/base.py` | `atlas/src/atlas/parsing/adapters/base.py` | 8 | 1 | 103 | 0.11 |
| `atlas/src/atlas/parsing/adapters/base.py::LanguageAdapter` | `atlas/src/atlas/parsing/adapters/base.py:29` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/base.py::LanguageAdapter.imports` | `atlas/src/atlas/parsing/adapters/base.py:43` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/base.py::LanguageAdapter.inheritance` | `atlas/src/atlas/parsing/adapters/base.py:50` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/elixir.py` | `atlas/src/atlas/parsing/adapters/elixir.py` | 1 | 4 | 96 | 0.80 |
| `atlas/src/atlas/parsing/adapters/elixir.py::declaration` | `atlas/src/atlas/parsing/adapters/elixir.py:36` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/elixir.py::_target` | `atlas/src/atlas/parsing/adapters/elixir.py:61` | 1 | 2 | 2 | 0.67 |
| `atlas/src/atlas/parsing/adapters/elixir.py::_noncall` | `atlas/src/atlas/parsing/adapters/elixir.py:66` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/parsing/adapters/elixir.py::_pipeline_target` | `atlas/src/atlas/parsing/adapters/elixir.py:82` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/parsing/adapters/elixir.py::elixir_call_target` | `atlas/src/atlas/parsing/adapters/elixir.py:92` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/elixir.py::elixir_call_sites` | `atlas/src/atlas/parsing/adapters/elixir.py:99` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/go.py` | `atlas/src/atlas/parsing/adapters/go.py` | 1 | 3 | 96 | 0.75 |
| `atlas/src/atlas/parsing/adapters/go.py::_binding` | `atlas/src/atlas/parsing/adapters/go.py:31` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/parsing/adapters/go.py::_assigned_name` | `atlas/src/atlas/parsing/adapters/go.py:45` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/parsing/adapters/go.py::declaration` | `atlas/src/atlas/parsing/adapters/go.py:56` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/go.py::call_sites` | `atlas/src/atlas/parsing/adapters/go.py:62` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/java.py` | `atlas/src/atlas/parsing/adapters/java.py` | 1 | 2 | 96 | 0.67 |
| `atlas/src/atlas/parsing/adapters/java.py::declaration` | `atlas/src/atlas/parsing/adapters/java.py:39` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/java.py::call_sites` | `atlas/src/atlas/parsing/adapters/java.py:47` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/java.py::metadata` | `atlas/src/atlas/parsing/adapters/java.py:51` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/javascript.py` | `atlas/src/atlas/parsing/adapters/javascript.py` | 2 | 3 | 96 | 0.60 |
| `atlas/src/atlas/parsing/adapters/javascript.py::_component` | `atlas/src/atlas/parsing/adapters/javascript.py:52` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/parsing/adapters/javascript.py::is_jsx_site` | `atlas/src/atlas/parsing/adapters/javascript.py:63` | 3 | 0 | 3 | 0.00 |
| `atlas/src/atlas/parsing/adapters/javascript.py::call_sites` | `atlas/src/atlas/parsing/adapters/javascript.py:72` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/javascript.py::normalize_call` | `atlas/src/atlas/parsing/adapters/javascript.py:78` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/javascript.py::call_relationship` | `atlas/src/atlas/parsing/adapters/javascript.py:87` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/javascript.py::metadata` | `atlas/src/atlas/parsing/adapters/javascript.py:91` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/javascript.py::unparenthesized` | `atlas/src/atlas/parsing/adapters/javascript.py:95` | 2 | 1 | 4 | 0.33 |
| `atlas/src/atlas/parsing/adapters/javascript.py::_expressions` | `atlas/src/atlas/parsing/adapters/javascript.py:105` | 1 | 0 | 5 | 0.00 |
| `atlas/src/atlas/parsing/adapters/javascript.py::script_declaration` | `atlas/src/atlas/parsing/adapters/javascript.py:109` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/kotlin.py` | `atlas/src/atlas/parsing/adapters/kotlin.py` | 1 | 3 | 96 | 0.75 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::_base_name` | `atlas/src/atlas/parsing/adapters/kotlin.py:41` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::declaration` | `atlas/src/atlas/parsing/adapters/kotlin.py:59` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::_identifier_name` | `atlas/src/atlas/parsing/adapters/kotlin.py:67` | 2 | 1 | 2 | 0.33 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::_type_declaration` | `atlas/src/atlas/parsing/adapters/kotlin.py:72` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::_member` | `atlas/src/atlas/parsing/adapters/kotlin.py:84` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::normalize_call` | `atlas/src/atlas/parsing/adapters/kotlin.py:99` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::call_sites` | `atlas/src/atlas/parsing/adapters/kotlin.py:103` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/kotlin.py::metadata` | `atlas/src/atlas/parsing/adapters/kotlin.py:107` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/python.py` | `atlas/src/atlas/parsing/adapters/python.py` | 1 | 3 | 96 | 0.75 |
| `atlas/src/atlas/parsing/adapters/python.py::declaration` | `atlas/src/atlas/parsing/adapters/python.py:32` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/python.py::call_sites` | `atlas/src/atlas/parsing/adapters/python.py:48` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/rust.py` | `atlas/src/atlas/parsing/adapters/rust.py` | 1 | 3 | 96 | 0.75 |
| `atlas/src/atlas/parsing/adapters/rust.py::declaration` | `atlas/src/atlas/parsing/adapters/rust.py:53` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/rust.py::metadata` | `atlas/src/atlas/parsing/adapters/rust.py:59` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/rust.py::rust_module_import` | `atlas/src/atlas/parsing/adapters/rust.py:63` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/rust.py::rust_call_target` | `atlas/src/atlas/parsing/adapters/rust.py:68` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/rust.py::_RustTraversal` | `atlas/src/atlas/parsing/adapters/rust.py:82` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/parsing/adapters/rust.py::rust_call_sites` | `atlas/src/atlas/parsing/adapters/rust.py:92` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/adapters/rust.py::_rust_call_sites` | `atlas/src/atlas/parsing/adapters/rust.py:96` | 2 | 2 | 2 | 0.50 |
| `atlas/src/atlas/parsing/adapters/rust.py::_macro_sites` | `atlas/src/atlas/parsing/adapters/rust.py:106` | 1 | 2 | 2 | 0.67 |
| `atlas/src/atlas/parsing/adapters/rust.py::_root` | `atlas/src/atlas/parsing/adapters/rust.py:139` | 2 | 0 | 7 | 0.00 |
| `atlas/src/atlas/parsing/adapters/rust.py::_qualified_macro_shadowed` | `atlas/src/atlas/parsing/adapters/rust.py:145` | 1 | 2 | 6 | 0.67 |
| `atlas/src/atlas/parsing/adapters/rust.py::_macro_shadowed` | `atlas/src/atlas/parsing/adapters/rust.py:157` | 1 | 3 | 5 | 0.75 |
| `atlas/src/atlas/parsing/adapters/rust.py::_walk_roots` | `atlas/src/atlas/parsing/adapters/rust.py:169` | 2 | 1 | 7 | 0.33 |
| `atlas/src/atlas/parsing/adapters/rust.py::_evaluating` | `atlas/src/atlas/parsing/adapters/rust.py:173` | 1 | 5 | 4 | 0.83 |
| `atlas/src/atlas/parsing/adapters/rust.py::_macro_tokens` | `atlas/src/atlas/parsing/adapters/rust.py:191` | 1 | 0 | 4 | 0.00 |
| `atlas/src/atlas/parsing/adapters/rust.py::macro_payloads` | `atlas/src/atlas/parsing/adapters/rust.py:198` | 1 | 2 | 3 | 0.67 |
| `atlas/src/atlas/parsing/adapters/rust.py::_pattern_names` | `atlas/src/atlas/parsing/adapters/rust.py:221` | 1 | 1 | 3 | 0.50 |
| `atlas/src/atlas/parsing/adapters/rust.py::_named_binding` | `atlas/src/atlas/parsing/adapters/rust.py:234` | 1 | 2 | 3 | 0.67 |
| `atlas/src/atlas/parsing/adapters/rust.py::_payload_binding` | `atlas/src/atlas/parsing/adapters/rust.py:249` | 1 | 4 | 2 | 0.80 |
| `atlas/src/atlas/parsing/adapters/rust.py::_payload_target` | `atlas/src/atlas/parsing/adapters/rust.py:265` | 1 | 1 | 2 | 0.50 |
| `atlas/src/atlas/parsing/adapters/rust.py::payload_unshadowed` | `atlas/src/atlas/parsing/adapters/rust.py:272` | 1 | 4 | 1 | 0.80 |
| `atlas/src/atlas/parsing/adapters/typescript.py` | `atlas/src/atlas/parsing/adapters/typescript.py` | 1 | 3 | 96 | 0.75 |
| `atlas/src/atlas/parsing/adapters/typescript.py::declaration` | `atlas/src/atlas/parsing/adapters/typescript.py:24` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/parsing/discovery.py` | `atlas/src/atlas/parsing/discovery.py` | 21 | 1 | 104 | 0.05 |
| `atlas/src/atlas/parsing/discovery.py::is_supported_language` | `atlas/src/atlas/parsing/discovery.py:32` | 2 | 0 | 422 | 0.00 |
| `atlas/src/atlas/parsing/discovery.py::require_supported_language` | `atlas/src/atlas/parsing/discovery.py:36` | 2 | 1 | 380 | 0.33 |
| `atlas/src/atlas/parsing/discovery.py::validate_repository` | `atlas/src/atlas/parsing/discovery.py:57` | 1 | 0 | 60 | 0.00 |
| `atlas/src/atlas/parsing/discovery.py::_is_ignored` | `atlas/src/atlas/parsing/discovery.py:79` | 2 | 0 | 373 | 0.00 |
| `atlas/src/atlas/parsing/discovery.py::_directory_rules` | `atlas/src/atlas/parsing/discovery.py:91` | 1 | 0 | 370 | 0.00 |
| `atlas/src/atlas/parsing/discovery.py::_DirectoryContext` | `atlas/src/atlas/parsing/discovery.py:100` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/parsing/discovery.py::_include_directory` | `atlas/src/atlas/parsing/discovery.py:107` | 1 | 1 | 371 | 0.50 |
| `atlas/src/atlas/parsing/discovery.py::_directory_files` | `atlas/src/atlas/parsing/discovery.py:116` | 1 | 1 | 370 | 0.50 |
| `atlas/src/atlas/parsing/discovery.py::_child_rules` | `atlas/src/atlas/parsing/discovery.py:126` | 1 | 0 | 370 | 0.00 |
| `atlas/src/atlas/parsing/discovery.py::_visible_directories` | `atlas/src/atlas/parsing/discovery.py:130` | 1 | 1 | 370 | 0.50 |
| `atlas/src/atlas/parsing/discovery.py::_repository_paths` | `atlas/src/atlas/parsing/discovery.py:134` | 4 | 5 | 369 | 0.56 |
| `atlas/src/atlas/parsing/discovery.py::_contained_files` | `atlas/src/atlas/parsing/discovery.py:155` | 1 | 0 | 370 | 0.00 |
| `atlas/src/atlas/parsing/discovery.py::detect_language` | `atlas/src/atlas/parsing/discovery.py:159` | 6 | 1 | 368 | 0.14 |
| `atlas/src/atlas/parsing/discovery.py::discover_files` | `atlas/src/atlas/parsing/discovery.py:176` | 16 | 2 | 362 | 0.11 |
| `atlas/src/atlas/parsing/parser.py` | `atlas/src/atlas/parsing/parser.py` | 21 | 4 | 92 | 0.16 |
| `atlas/src/atlas/parsing/parser.py::_has_call_nodes` | `atlas/src/atlas/parsing/parser.py:34` | 2 | 0 | 299 | 0.00 |
| `atlas/src/atlas/parsing/parser.py::_parse_syntax` | `atlas/src/atlas/parsing/parser.py:42` | 1 | 2 | 295 | 0.67 |
| `atlas/src/atlas/parsing/parser.py::_syntax_error` | `atlas/src/atlas/parsing/parser.py:53` | 1 | 0 | 295 | 0.00 |
| `atlas/src/atlas/parsing/parser.py::_extract_calls` | `atlas/src/atlas/parsing/parser.py:66` | 4 | 2 | 297 | 0.33 |
| `atlas/src/atlas/parsing/parser.py::_StructureParent` | `atlas/src/atlas/parsing/parser.py:100` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/parsing/parser.py::_add_structure` | `atlas/src/atlas/parsing/parser.py:105` | 1 | 1 | 295 | 0.50 |
| `atlas/src/atlas/parsing/parser.py::parse_file` | `atlas/src/atlas/parsing/parser.py:151` | 13 | 7 | 294 | 0.35 |
| `atlas/src/atlas/parsing/parser.py::parse_files` | `atlas/src/atlas/parsing/parser.py:203` | 28 | 1 | 237 | 0.03 |
| `atlas/src/atlas/parsing/structure.py` | `atlas/src/atlas/parsing/structure.py` | 11 | 2 | 93 | 0.15 |
| `atlas/src/atlas/parsing/structure.py::_declaration_query` | `atlas/src/atlas/parsing/structure.py:36` | 3 | 1 | 350 | 0.25 |
| `atlas/src/atlas/parsing/structure.py::_structure_item` | `atlas/src/atlas/parsing/structure.py:42` | 2 | 1 | 354 | 0.33 |
| `atlas/src/atlas/parsing/structure.py::_captured_declarations` | `atlas/src/atlas/parsing/structure.py:64` | 1 | 1 | 349 | 0.50 |
| `atlas/src/atlas/parsing/structure.py::_definition_capture` | `atlas/src/atlas/parsing/structure.py:73` | 1 | 0 | 351 | 0.00 |
| `atlas/src/atlas/parsing/structure.py::_capture_name` | `atlas/src/atlas/parsing/structure.py:77` | 1 | 0 | 351 | 0.00 |
| `atlas/src/atlas/parsing/structure.py::_add_captured_match` | `atlas/src/atlas/parsing/structure.py:81` | 1 | 3 | 350 | 0.75 |
| `atlas/src/atlas/parsing/structure.py::_native_declarations` | `atlas/src/atlas/parsing/structure.py:102` | 1 | 0 | 349 | 0.00 |
| `atlas/src/atlas/parsing/structure.py::_canonical_declaration` | `atlas/src/atlas/parsing/structure.py:115` | 1 | 2 | 349 | 0.67 |
| `atlas/src/atlas/parsing/structure.py::_carrier_metadata` | `atlas/src/atlas/parsing/structure.py:124` | 1 | 1 | 351 | 0.50 |
| `atlas/src/atlas/parsing/structure.py::_span_changed` | `atlas/src/atlas/parsing/structure.py:134` | 1 | 0 | 351 | 0.00 |
| `atlas/src/atlas/parsing/structure.py::_canonical_item` | `atlas/src/atlas/parsing/structure.py:140` | 1 | 2 | 350 | 0.67 |
| `atlas/src/atlas/parsing/structure.py::_declaration_key` | `atlas/src/atlas/parsing/structure.py:157` | 1 | 1 | 349 | 0.50 |
| `atlas/src/atlas/parsing/structure.py::_merge_item` | `atlas/src/atlas/parsing/structure.py:165` | 1 | 0 | 349 | 0.00 |
| `atlas/src/atlas/parsing/structure.py::extract_structure` | `atlas/src/atlas/parsing/structure.py:178` | 40 | 3 | 347 | 0.07 |
| `atlas/src/atlas/parsing/structure.py::_merge_declarations` | `atlas/src/atlas/parsing/structure.py:196` | 1 | 5 | 348 | 0.83 |
| `atlas/src/atlas/parsing/structure.py::_declared_parent` | `atlas/src/atlas/parsing/structure.py:217` | 1 | 0 | 349 | 0.00 |
| `atlas/src/atlas/parsing/structure.py::_structure_hierarchy` | `atlas/src/atlas/parsing/structure.py:224` | 1 | 1 | 348 | 0.50 |
| `atlas/src/atlas/parsing/structure.py::_structure_hierarchy.<anonymous>` | `atlas/src/atlas/parsing/structure.py:230` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/parsing/syntax.py` | `atlas/src/atlas/parsing/syntax.py` | 23 | 2 | 105 | 0.08 |
| `atlas/src/atlas/parsing/syntax.py::modifier_metadata` | `atlas/src/atlas/parsing/syntax.py:15` | 5 | 1 | 5 | 0.17 |
| `atlas/src/atlas/parsing/syntax.py::relationship` | `atlas/src/atlas/parsing/syntax.py:49` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/parsing/syntax.py::call_member` | `atlas/src/atlas/parsing/syntax.py:70` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/parsing/syntax.py::_reference_target` | `atlas/src/atlas/parsing/syntax.py:75` | 1 | 1 | 6 | 0.50 |
| `atlas/src/atlas/parsing/syntax.py::call_target` | `atlas/src/atlas/parsing/syntax.py:84` | 4 | 5 | 5 | 0.56 |
| `atlas/src/atlas/parsing/syntax.py::_callee_node` | `atlas/src/atlas/parsing/syntax.py:101` | 1 | 1 | 6 | 0.50 |
| `atlas/src/atlas/parsing/syntax.py::_bare_call` | `atlas/src/atlas/parsing/syntax.py:116` | 1 | 1 | 6 | 0.50 |
| `atlas/src/atlas/parsing/syntax.py::normalize_call` | `atlas/src/atlas/parsing/syntax.py:125` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/parsing/syntax.py::call_sites` | `atlas/src/atlas/parsing/syntax.py:129` | 4 | 1 | 4 | 0.20 |
| `atlas/src/atlas/parsing/syntax.py::metadata` | `atlas/src/atlas/parsing/syntax.py:137` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/parsing/syntax.py::DeclarationCarrier` | `atlas/src/atlas/parsing/syntax.py:144` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/parsing/syntax.py::named_carrier` | `atlas/src/atlas/parsing/syntax.py:151` | 7 | 1 | 8 | 0.12 |
| `atlas/src/atlas/parsing/syntax.py::callback_carrier` | `atlas/src/atlas/parsing/syntax.py:156` | 7 | 1 | 7 | 0.12 |
| `atlas/src/atlas/parsing/syntax.py::_expression_children` | `atlas/src/atlas/parsing/syntax.py:163` | 1 | 0 | 8 | 0.00 |
| `atlas/src/atlas/parsing/syntax.py::_callback_value` | `atlas/src/atlas/parsing/syntax.py:167` | 1 | 1 | 7 | 0.50 |
| `atlas/src/atlas/parsing/syntax.py::_callback_parent` | `atlas/src/atlas/parsing/syntax.py:176` | 1 | 0 | 7 | 0.00 |
| `atlas/src/atlas/parsing/syntax.py::callback_binding` | `atlas/src/atlas/parsing/syntax.py:191` | 6 | 3 | 6 | 0.33 |
| `atlas/src/atlas/parsing/syntax.py::ParsedSyntax` | `atlas/src/atlas/parsing/syntax.py:209` | 7 | 0 | 7 | 0.00 |
| `atlas/src/atlas/parsing/syntax.py::ParsedSyntax.tree` | `atlas/src/atlas/parsing/syntax.py:215` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/parsing/syntax.py::ImportPolicy` | `atlas/src/atlas/parsing/syntax.py:222` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/parsing/syntax.py::supplement_imports` | `atlas/src/atlas/parsing/syntax.py:227` | 2 | 1 | 2 | 0.33 |
| `atlas/src/atlas/parsing/syntax.py::_merge_imports` | `atlas/src/atlas/parsing/syntax.py:235` | 1 | 2 | 3 | 0.67 |
| `atlas/src/atlas/parsing/syntax.py::_merge_imports.<anonymous>` | `atlas/src/atlas/parsing/syntax.py:250` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/parsing/syntax.py::InheritancePolicy` | `atlas/src/atlas/parsing/syntax.py:289` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/parsing/syntax.py::_base_target` | `atlas/src/atlas/parsing/syntax.py:316` | 1 | 1 | 7 | 0.50 |
| `atlas/src/atlas/parsing/syntax.py::_base_components` | `atlas/src/atlas/parsing/syntax.py:322` | 1 | 2 | 6 | 0.67 |
| `atlas/src/atlas/parsing/syntax.py::_base_name` | `atlas/src/atlas/parsing/syntax.py:330` | 3 | 3 | 6 | 0.50 |
| `atlas/src/atlas/parsing/syntax.py::_clause_names` | `atlas/src/atlas/parsing/syntax.py:350` | 1 | 1 | 3 | 0.50 |
| `atlas/src/atlas/parsing/syntax.py::DeclarationHeader` | `atlas/src/atlas/parsing/syntax.py:369` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/parsing/syntax.py::inheritance_names` | `atlas/src/atlas/parsing/syntax.py:375` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/parsing/syntax.py::_superclass_names` | `atlas/src/atlas/parsing/syntax.py:393` | 1 | 2 | 3 | 0.67 |
| `atlas/src/atlas/parsing/syntax.py::_has_inheritance_clause` | `atlas/src/atlas/parsing/syntax.py:400` | 1 | 0 | 4 | 0.00 |
| `atlas/src/atlas/parsing/syntax.py::_is_inheritance_clause` | `atlas/src/atlas/parsing/syntax.py:404` | 1 | 1 | 3 | 0.50 |
| `atlas/src/atlas/parsing/syntax.py::_header_names` | `atlas/src/atlas/parsing/syntax.py:412` | 1 | 3 | 2 | 0.75 |
| `atlas.src.atlas.persistence` | `atlas/src/atlas/persistence` | 3 | 1 | 9 | 0.25 |
| `atlas/src/atlas/persistence/__init__.py` | `atlas/src/atlas/persistence/__init__.py` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/database.py` | `atlas/src/atlas/persistence/database.py` | 18 | 1 | 54 | 0.05 |
| `atlas/src/atlas/persistence/database.py::default_database_path` | `atlas/src/atlas/persistence/database.py:18` | 3 | 0 | 63 | 0.00 |
| `atlas/src/atlas/persistence/database.py::create_engine` | `atlas/src/atlas/persistence/database.py:26` | 13 | 1 | 54 | 0.07 |
| `atlas/src/atlas/persistence/database.py::create_engine.configure` | `atlas/src/atlas/persistence/database.py:32` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/database.py::create_engine.begin` | `atlas/src/atlas/persistence/database.py:42` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/database.py::migrate_database` | `atlas/src/atlas/persistence/database.py:48` | 24 | 1 | 27 | 0.04 |
| `atlas/src/atlas/persistence/database.py::repository_session` | `atlas/src/atlas/persistence/database.py:69` | 29 | 1 | 30 | 0.03 |
| `atlas/src/atlas/persistence/database.py::main` | `atlas/src/atlas/persistence/database.py:81` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/graph_queries.py` | `atlas/src/atlas/persistence/graph_queries.py` | 6 | 3 | 48 | 0.33 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository` | `atlas/src/atlas/persistence/graph_queries.py:16` | 1 | 3 | 1 | 0.75 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository.__init__` | `atlas/src/atlas/persistence/graph_queries.py:17` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository.graph` | `atlas/src/atlas/persistence/graph_queries.py:20` | 5 | 1 | 10 | 0.17 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository.report_facts` | `atlas/src/atlas/persistence/graph_queries.py:26` | 4 | 1 | 9 | 0.20 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository._graph_summary` | `atlas/src/atlas/persistence/graph_queries.py:32` | 2 | 1 | 33 | 0.33 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository._count` | `atlas/src/atlas/persistence/graph_queries.py:55` | 1 | 0 | 34 | 0.00 |
| `atlas/src/atlas/persistence/graph_queries.py::GraphReadRepository._report_facts` | `atlas/src/atlas/persistence/graph_queries.py:60` | 1 | 0 | 10 | 0.00 |
| `atlas/src/atlas/persistence/graph_records.py` | `atlas/src/atlas/persistence/graph_records.py` | 1 | 0 | 48 | 0.00 |
| `atlas/src/atlas/persistence/graph_records.py::_properties` | `atlas/src/atlas/persistence/graph_records.py:13` | 7 | 0 | 41 | 0.00 |
| `atlas/src/atlas/persistence/graph_records.py::_decorators` | `atlas/src/atlas/persistence/graph_records.py:17` | 1 | 1 | 33 | 0.50 |
| `atlas/src/atlas/persistence/graph_records.py::validate_collections` | `atlas/src/atlas/persistence/graph_records.py:21` | 1 | 1 | 32 | 0.50 |
| `atlas/src/atlas/persistence/graph_records.py::validate_parentage` | `atlas/src/atlas/persistence/graph_records.py:31` | 1 | 2 | 31 | 0.67 |
| `atlas/src/atlas/persistence/graph_records.py::_validate_ancestry` | `atlas/src/atlas/persistence/graph_records.py:40` | 1 | 0 | 32 | 0.00 |
| `atlas/src/atlas/persistence/graph_records.py::graph_metadata` | `atlas/src/atlas/persistence/graph_records.py:51` | 1 | 0 | 31 | 0.00 |
| `atlas/src/atlas/persistence/graph_records.py::node_records` | `atlas/src/atlas/persistence/graph_records.py:61` | 1 | 0 | 32 | 0.00 |
| `atlas/src/atlas/persistence/graph_records.py::file_records` | `atlas/src/atlas/persistence/graph_records.py:80` | 1 | 1 | 32 | 0.50 |
| `atlas/src/atlas/persistence/graph_records.py::is_symbol` | `atlas/src/atlas/persistence/graph_records.py:92` | 2 | 1 | 34 | 0.33 |
| `atlas/src/atlas/persistence/graph_records.py::symbol_records` | `atlas/src/atlas/persistence/graph_records.py:102` | 1 | 2 | 32 | 0.67 |
| `atlas/src/atlas/persistence/graph_records.py::decorator_records` | `atlas/src/atlas/persistence/graph_records.py:118` | 1 | 2 | 32 | 0.67 |
| `atlas/src/atlas/persistence/graph_records.py::_metric_record` | `atlas/src/atlas/persistence/graph_records.py:126` | 1 | 1 | 33 | 0.50 |
| `atlas/src/atlas/persistence/graph_records.py::metric_records` | `atlas/src/atlas/persistence/graph_records.py:141` | 1 | 2 | 32 | 0.67 |
| `atlas/src/atlas/persistence/graph_records.py::edge_records` | `atlas/src/atlas/persistence/graph_records.py:149` | 1 | 0 | 32 | 0.00 |
| `atlas/src/atlas/persistence/graph_records.py::diagnostic_records` | `atlas/src/atlas/persistence/graph_records.py:167` | 1 | 0 | 32 | 0.00 |
| `atlas.src.atlas.persistence.migrations` | `atlas/src/atlas/persistence/migrations` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/migrations/env.py` | `atlas/src/atlas/persistence/migrations/env.py` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/persistence/migrations/env.py::run_migrations_offline` | `atlas/src/atlas/persistence/migrations/env.py:12` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/migrations/env.py::migrate_connection` | `atlas/src/atlas/persistence/migrations/env.py:22` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/persistence/migrations/env.py::run_migrations_online` | `atlas/src/atlas/persistence/migrations/env.py:28` | 0 | 2 | 0 | 1.00 |
| `atlas.src.atlas.persistence.migrations.versions` | `atlas/src/atlas/persistence/migrations/versions` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0001_initial.py` | `atlas/src/atlas/persistence/migrations/versions/0001_initial.py` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0001_initial.py::upgrade` | `atlas/src/atlas/persistence/migrations/versions/0001_initial.py:16` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0001_initial.py::downgrade` | `atlas/src/atlas/persistence/migrations/versions/0001_initial.py:34` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py` | `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py::upgrade` | `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py:16` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py::downgrade` | `atlas/src/atlas/persistence/migrations/versions/0002_graph_nodes.py:64` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py` | `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py::upgrade` | `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py:16` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py::downgrade` | `atlas/src/atlas/persistence/migrations/versions/0003_graph_relations.py:67` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py` | `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py::upgrade` | `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py:12` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py::downgrade` | `atlas/src/atlas/persistence/migrations/versions/0004_drop_graph_artifact.py:16` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/models.py` | `atlas/src/atlas/persistence/models.py` | 9 | 0 | 54 | 0.00 |
| `atlas/src/atlas/persistence/models.py::Base` | `atlas/src/atlas/persistence/models.py:7` | 9 | 0 | 10 | 0.00 |
| `atlas/src/atlas/persistence/models.py::RepositoryRow` | `atlas/src/atlas/persistence/models.py:11` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/persistence/models.py::RepositoryGraphRow` | `atlas/src/atlas/persistence/models.py:22` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/models.py::GraphNodeRow` | `atlas/src/atlas/persistence/models.py:39` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/models.py::GraphFileRow` | `atlas/src/atlas/persistence/models.py:64` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/models.py::GraphSymbolRow` | `atlas/src/atlas/persistence/models.py:77` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/models.py::GraphNodeMetricRow` | `atlas/src/atlas/persistence/models.py:94` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/models.py::GraphNodeDecoratorRow` | `atlas/src/atlas/persistence/models.py:112` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/models.py::GraphEdgeRow` | `atlas/src/atlas/persistence/models.py:125` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/models.py::GraphDiagnosticRow` | `atlas/src/atlas/persistence/models.py:147` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/navigation.py` | `atlas/src/atlas/persistence/navigation.py` | 2 | 4 | 43 | 0.67 |
| `atlas/src/atlas/persistence/navigation.py::navigation_reader` | `atlas/src/atlas/persistence/navigation.py:21` | 5 | 1 | 5 | 0.17 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader` | `atlas/src/atlas/persistence/navigation.py:27` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.__init__` | `atlas/src/atlas/persistence/navigation.py:28` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader._project` | `atlas/src/atlas/persistence/navigation.py:38` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader._containing_projects` | `atlas/src/atlas/persistence/navigation.py:52` | 1 | 0 | 2 | 0.00 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader._rows` | `atlas/src/atlas/persistence/navigation.py:64` | 7 | 0 | 7 | 0.00 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.overview` | `atlas/src/atlas/persistence/navigation.py:67` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.find` | `atlas/src/atlas/persistence/navigation.py:79` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.node` | `atlas/src/atlas/persistence/navigation.py:100` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.children` | `atlas/src/atlas/persistence/navigation.py:122` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.edges` | `atlas/src/atlas/persistence/navigation.py:128` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.diagnostics` | `atlas/src/atlas/persistence/navigation.py:136` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/navigation.py::GraphReader.file` | `atlas/src/atlas/persistence/navigation.py:142` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/persistence/navigation_database.py` | `atlas/src/atlas/persistence/navigation_database.py` | 1 | 3 | 44 | 0.75 |
| `atlas/src/atlas/persistence/navigation_database.py::IndexedSQLiteCompiler` | `atlas/src/atlas/persistence/navigation_database.py:22` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/navigation_database.py::IndexedSQLiteCompiler.get_from_hint_text` | `atlas/src/atlas/persistence/navigation_database.py:25` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/navigation_database.py::_check_schema` | `atlas/src/atlas/persistence/navigation_database.py:31` | 1 | 0 | 7 | 0.00 |
| `atlas/src/atlas/persistence/navigation_database.py::readonly_session` | `atlas/src/atlas/persistence/navigation_database.py:42` | 1 | 2 | 6 | 0.67 |
| `atlas/src/atlas/persistence/navigation_database.py::readonly_session.configure` | `atlas/src/atlas/persistence/navigation_database.py:50` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/navigation_database.py::readonly_session.configure.<anonymous>` | `atlas/src/atlas/persistence/navigation_database.py:53` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/navigation_database.py::readonly_session.begin` | `atlas/src/atlas/persistence/navigation_database.py:57` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/navigation_queries.py` | `atlas/src/atlas/persistence/navigation_queries.py` | 3 | 1 | 50 | 0.25 |
| `atlas/src/atlas/persistence/navigation_queries.py::nodes` | `atlas/src/atlas/persistence/navigation_queries.py:27` | 4 | 0 | 4 | 0.00 |
| `atlas/src/atlas/persistence/navigation_queries.py::metrics` | `atlas/src/atlas/persistence/navigation_queries.py:39` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/persistence/navigation_queries.py::AdjacencyRequest` | `atlas/src/atlas/persistence/navigation_queries.py:45` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/persistence/navigation_queries.py::adjacency` | `atlas/src/atlas/persistence/navigation_queries.py:53` | 2 | 0 | 2 | 0.00 |
| `atlas/src/atlas/persistence/repositories.py` | `atlas/src/atlas/persistence/repositories.py` | 8 | 5 | 47 | 0.38 |
| `atlas/src/atlas/persistence/repositories.py::_repository_dto` | `atlas/src/atlas/persistence/repositories.py:43` | 2 | 0 | 5 | 0.00 |
| `atlas/src/atlas/persistence/repositories.py::repository_store` | `atlas/src/atlas/persistence/repositories.py:54` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore` | `atlas/src/atlas/persistence/repositories.py:60` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.register` | `atlas/src/atlas/persistence/repositories.py:61` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.list` | `atlas/src/atlas/persistence/repositories.py:83` | 3 | 1 | 3 | 0.25 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.exists` | `atlas/src/atlas/persistence/repositories.py:96` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.resolve` | `atlas/src/atlas/persistence/repositories.py:99` | 4 | 0 | 4 | 0.00 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.save_new` | `atlas/src/atlas/persistence/repositories.py:107` | 25 | 1 | 25 | 0.04 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore.save` | `atlas/src/atlas/persistence/repositories.py:120` | 10 | 1 | 10 | 0.09 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore._save` | `atlas/src/atlas/persistence/repositories.py:125` | 2 | 4 | 30 | 0.67 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore._replace_graph` | `atlas/src/atlas/persistence/repositories.py:150` | 1 | 8 | 31 | 0.89 |
| `atlas/src/atlas/persistence/repositories.py::RepositoryStore._insert_records` | `atlas/src/atlas/persistence/repositories.py:162` | 1 | 0 | 32 | 0.00 |
| `atlas.src.atlas.services` | `atlas/src/atlas/services` | 3 | 4 | 7 | 0.57 |
| `atlas/src/atlas/services/__init__.py` | `atlas/src/atlas/services/__init__.py` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/services/factories.py` | `atlas/src/atlas/services/factories.py` | 1 | 5 | 42 | 0.83 |
| `atlas/src/atlas/services/factories.py::navigation_service` | `atlas/src/atlas/services/factories.py:15` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/services/factories.py::migrate_database` | `atlas/src/atlas/services/factories.py:21` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/services/factories.py::repository_service` | `atlas/src/atlas/services/factories.py:27` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/services/navigation.py` | `atlas/src/atlas/services/navigation.py` | 2 | 3 | 43 | 0.60 |
| `atlas/src/atlas/services/navigation.py::NavigationService` | `atlas/src/atlas/services/navigation.py:8` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/services/navigation.py::NavigationService.__init__` | `atlas/src/atlas/services/navigation.py:9` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/services/navigation.py::NavigationService.response` | `atlas/src/atlas/services/navigation.py:12` | 8 | 1 | 9 | 0.11 |
| `atlas/src/atlas/services/navigation.py::NavigationService.overview` | `atlas/src/atlas/services/navigation.py:18` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/services/navigation.py::NavigationService.find` | `atlas/src/atlas/services/navigation.py:22` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/services/navigation.py::NavigationService.show` | `atlas/src/atlas/services/navigation.py:26` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/services/navigation.py::NavigationService.ancestors` | `atlas/src/atlas/services/navigation.py:31` | 1 | 1 | 1 | 0.50 |
| `atlas/src/atlas/services/navigation.py::NavigationService.children` | `atlas/src/atlas/services/navigation.py:42` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/services/navigation.py::NavigationService.context` | `atlas/src/atlas/services/navigation.py:49` | 1 | 2 | 1 | 0.67 |
| `atlas/src/atlas/services/navigation.py::NavigationService.path` | `atlas/src/atlas/services/navigation.py:55` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/services/navigation.py::NavigationService.sources` | `atlas/src/atlas/services/navigation.py:64` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/services/navigation.py::NavigationService.source` | `atlas/src/atlas/services/navigation.py:70` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/services/navigation_source.py` | `atlas/src/atlas/services/navigation_source.py` | 2 | 1 | 44 | 0.33 |
| `atlas/src/atlas/services/navigation_source.py::source_excerpt` | `atlas/src/atlas/services/navigation_source.py:15` | 2 | 4 | 2 | 0.67 |
| `atlas/src/atlas/services/navigation_source.py::verified_excerpt` | `atlas/src/atlas/services/navigation_source.py:30` | 1 | 3 | 3 | 0.75 |
| `atlas/src/atlas/services/navigation_source.py::source_lines` | `atlas/src/atlas/services/navigation_source.py:44` | 1 | 0 | 4 | 0.00 |
| `atlas/src/atlas/services/navigation_source.py::source_status` | `atlas/src/atlas/services/navigation_source.py:52` | 2 | 0 | 4 | 0.00 |
| `atlas/src/atlas/services/navigation_source.py::local_bytes` | `atlas/src/atlas/services/navigation_source.py:59` | 1 | 1 | 3 | 0.50 |
| `atlas/src/atlas/services/navigation_source.py::contained_bytes` | `atlas/src/atlas/services/navigation_source.py:77` | 1 | 0 | 4 | 0.00 |
| `atlas/src/atlas/services/navigation_source.py::excerpt_lines` | `atlas/src/atlas/services/navigation_source.py:97` | 1 | 0 | 4 | 0.00 |
| `atlas/src/atlas/services/navigation_walk.py` | `atlas/src/atlas/services/navigation_walk.py` | 1 | 1 | 44 | 0.50 |
| `atlas/src/atlas/services/navigation_walk.py::Walk` | `atlas/src/atlas/services/navigation_walk.py:10` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/services/navigation_walk.py::Walk.output` | `atlas/src/atlas/services/navigation_walk.py:16` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/services/navigation_walk.py::Traversal` | `atlas/src/atlas/services/navigation_walk.py:26` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/services/navigation_walk.py::Traversal.__init__` | `atlas/src/atlas/services/navigation_walk.py:27` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/services/navigation_walk.py::Traversal.run` | `atlas/src/atlas/services/navigation_walk.py:33` | 1 | 1 | 4 | 0.50 |
| `atlas/src/atlas/services/navigation_walk.py::Traversal.expand` | `atlas/src/atlas/services/navigation_walk.py:44` | 1 | 2 | 5 | 0.67 |
| `atlas/src/atlas/services/navigation_walk.py::Traversal.add_edge` | `atlas/src/atlas/services/navigation_walk.py:57` | 1 | 1 | 6 | 0.50 |
| `atlas/src/atlas/services/navigation_walk.py::traverse` | `atlas/src/atlas/services/navigation_walk.py:70` | 2 | 1 | 3 | 0.33 |
| `atlas/src/atlas/services/navigation_walk.py::route` | `atlas/src/atlas/services/navigation_walk.py:74` | 1 | 0 | 1 | 0.00 |
| `atlas/src/atlas/services/repositories.py` | `atlas/src/atlas/services/repositories.py` | 6 | 3 | 44 | 0.33 |
| `atlas/src/atlas/services/repositories.py::_required_text` | `atlas/src/atlas/services/repositories.py:18` | 5 | 0 | 5 | 0.00 |
| `atlas/src/atlas/services/repositories.py::analyze_folder` | `atlas/src/atlas/services/repositories.py:27` | 5 | 1 | 7 | 0.17 |
| `atlas/src/atlas/services/repositories.py::RepositoryService` | `atlas/src/atlas/services/repositories.py:32` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.__init__` | `atlas/src/atlas/services/repositories.py:35` | 0 | 0 | 0 | N/A |
| `atlas/src/atlas/services/repositories.py::RepositoryService.register` | `atlas/src/atlas/services/repositories.py:38` | 0 | 2 | 0 | 1.00 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.list` | `atlas/src/atlas/services/repositories.py:45` | 0 | 1 | 0 | 1.00 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.get_architecture` | `atlas/src/atlas/services/repositories.py:48` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.get_report_facts` | `atlas/src/atlas/services/repositories.py:54` | 0 | 3 | 0 | 1.00 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.report` | `atlas/src/atlas/services/repositories.py:61` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.save_folder` | `atlas/src/atlas/services/repositories.py:71` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/services/repositories.py::RepositoryService.index` | `atlas/src/atlas/services/repositories.py:87` | 0 | 4 | 0 | 1.00 |
| `atlas/src/atlas/syntax.py` | `atlas/src/atlas/syntax.py` | 32 | 0 | 133 | 0.00 |
| `atlas/src/atlas/syntax.py::walk` | `atlas/src/atlas/syntax.py:8` | 17 | 0 | 46 | 0.00 |
| `atlas/src/atlas/syntax.py::text` | `atlas/src/atlas/syntax.py:16` | 94 | 0 | 465 | 0.00 |
| `atlas/src/atlas/syntax.py::field` | `atlas/src/atlas/syntax.py:22` | 91 | 0 | 441 | 0.00 |
| `atlas.tests` | `atlas/tests` | 0 | 9 | 0 | 1.00 |
| `atlas/tests/__init__.py` | `atlas/tests/__init__.py` | 0 | 0 | 0 | N/A |
| `atlas/tests/coffee_consolidation.py` | `atlas/tests/coffee_consolidation.py` | 13 | 5 | 14 | 0.28 |
| `atlas/tests/coffee_consolidation.py::coffee_source` | `atlas/tests/coffee_consolidation.py:16` | 41 | 1 | 89 | 0.02 |
| `atlas/tests/coffee_consolidation.py::coffee_parsed` | `atlas/tests/coffee_consolidation.py:21` | 13 | 3 | 42 | 0.19 |
| `atlas/tests/coffee_consolidation.py::coffee_symbols` | `atlas/tests/coffee_consolidation.py:28` | 16 | 0 | 46 | 0.00 |
| `atlas/tests/coffee_consolidation.py::coffee_node` | `atlas/tests/coffee_consolidation.py:35` | 15 | 2 | 29 | 0.12 |
| `atlas/tests/coffee_fixture.py` | `atlas/tests/coffee_fixture.py` | 49 | 3 | 68 | 0.06 |
| `atlas/tests/coffee_fixture.py::coffee_sources` | `atlas/tests/coffee_fixture.py:26` | 36 | 1 | 212 | 0.03 |
| `atlas/tests/coffee_fixture.py::coffee_graph` | `atlas/tests/coffee_fixture.py:32` | 11 | 1 | 14 | 0.08 |
| `atlas/tests/coffee_fixture.py::coffee_snapshot` | `atlas/tests/coffee_fixture.py:36` | 8 | 0 | 20 | 0.00 |
| `atlas/tests/coffee_integrity.py` | `atlas/tests/coffee_integrity.py` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_integrity.py::GraphRelations` | `atlas/tests/coffee_integrity.py:9` | 0 | 0 | 0 | N/A |
| `atlas/tests/coffee_integrity.py::assert_node_ancestry` | `atlas/tests/coffee_integrity.py:14` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_integrity.py::assert_view_edge` | `atlas/tests/coffee_integrity.py:27` | 1 | 0 | 3 | 0.00 |
| `atlas/tests/coffee_integrity.py::assert_view` | `atlas/tests/coffee_integrity.py:34` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/coffee_integrity.py::assert_cycle_edge` | `atlas/tests/coffee_integrity.py:40` | 1 | 0 | 3 | 0.00 |
| `atlas/tests/coffee_integrity.py::assert_cycle_group` | `atlas/tests/coffee_integrity.py:46` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/coffee_integrity.py::assert_level_stats` | `atlas/tests/coffee_integrity.py:56` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/coffee_integrity.py::level_node_keys` | `atlas/tests/coffee_integrity.py:64` | 2 | 0 | 3 | 0.00 |
| `atlas/tests/coffee_integrity.py::assert_coffee_integrity` | `atlas/tests/coffee_integrity.py:68` | 1 | 5 | 1 | 0.83 |
| `atlas/tests/coffee_navigation.py` | `atlas/tests/coffee_navigation.py` | 2 | 5 | 2 | 0.71 |
| `atlas/tests/coffee_navigation.py::Declaration` | `atlas/tests/coffee_navigation.py:40` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_navigation.py::Declaration.matches` | `atlas/tests/coffee_navigation.py:47` | 0 | 0 | 0 | N/A |
| `atlas/tests/coffee_navigation.py::command` | `atlas/tests/coffee_navigation.py:53` | 2 | 0 | 5 | 0.00 |
| `atlas/tests/coffee_navigation.py::declaration` | `atlas/tests/coffee_navigation.py:60` | 5 | 0 | 5 | 0.00 |
| `atlas/tests/coffee_navigation.py::file_node` | `atlas/tests/coffee_navigation.py:68` | 2 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_navigation.py::navigation_responses` | `atlas/tests/coffee_navigation.py:76` | 2 | 3 | 3 | 0.60 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation` | `atlas/tests/coffee_navigation.py:87` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.query` | `atlas/tests/coffee_navigation.py:94` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.collect` | `atlas/tests/coffee_navigation.py:99` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.find_core` | `atlas/tests/coffee_navigation.py:115` | 0 | 0 | 0 | N/A |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.select_core` | `atlas/tests/coffee_navigation.py:121` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.show_render` | `atlas/tests/coffee_navigation.py:134` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.calls` | `atlas/tests/coffee_navigation.py:144` | 0 | 0 | 0 | N/A |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.assert_go_render_boundary` | `atlas/tests/coffee_navigation.py:161` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.source` | `atlas/tests/coffee_navigation.py:174` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.imports` | `atlas/tests/coffee_navigation.py:179` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.assert_imports` | `atlas/tests/coffee_navigation.py:189` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.inheritance` | `atlas/tests/coffee_navigation.py:201` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.absent_inheritance` | `atlas/tests/coffee_navigation.py:217` | 0 | 0 | 0 | N/A |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.assert_inheritance` | `atlas/tests/coffee_navigation.py:222` | 0 | 0 | 0 | N/A |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.callback` | `atlas/tests/coffee_navigation.py:236` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.recursion` | `atlas/tests/coffee_navigation.py:271` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.unicode_search` | `atlas/tests/coffee_navigation.py:280` | 0 | 0 | 0 | N/A |
| `atlas/tests/coffee_navigation.py::CoffeeNavigation.retry_clauses` | `atlas/tests/coffee_navigation.py:307` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/coffee_navigation.py::edges_targeting` | `atlas/tests/coffee_navigation.py:319` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_navigation.py::assert_unresolved_node` | `atlas/tests/coffee_navigation.py:323` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_navigation.py::assert_no_path` | `atlas/tests/coffee_navigation.py:328` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_navigation.py::expected_import_paths` | `atlas/tests/coffee_navigation.py:332` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_navigation.py::assert_file_import_cycle` | `atlas/tests/coffee_navigation.py:340` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_navigation.py::internal_import_targets` | `atlas/tests/coffee_navigation.py:349` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_navigation.py::assert_recursion` | `atlas/tests/coffee_navigation.py:355` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_navigation.py::assert_verified_source` | `atlas/tests/coffee_navigation.py:366` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_navigation.py::assert_same_metadata` | `atlas/tests/coffee_navigation.py:377` | 1 | 0 | 4 | 0.00 |
| `atlas/tests/coffee_navigation.py::normalize_responses` | `atlas/tests/coffee_navigation.py:382` | 3 | 2 | 3 | 0.40 |
| `atlas/tests/coffee_navigation.py::normalize_root` | `atlas/tests/coffee_navigation.py:392` | 1 | 0 | 4 | 0.00 |
| `atlas/tests/coffee_pipeline.py` | `atlas/tests/coffee_pipeline.py` | 3 | 10 | 17 | 0.77 |
| `atlas/tests/coffee_pipeline.py::project_analysis` | `atlas/tests/coffee_pipeline.py:31` | 1 | 10 | 12 | 0.91 |
| `atlas/tests/coffee_pipeline.py::shared_grammar_variants` | `atlas/tests/coffee_pipeline.py:49` | 1 | 1 | 13 | 0.50 |
| `atlas/tests/coffee_pipeline.py::grammar_variant` | `atlas/tests/coffee_pipeline.py:56` | 2 | 7 | 21 | 0.78 |
| `atlas/tests/coffee_pipeline.py::grammar_resolution` | `atlas/tests/coffee_pipeline.py:70` | 1 | 0 | 22 | 0.00 |
| `atlas/tests/coffee_pipeline.py::source_structures` | `atlas/tests/coffee_pipeline.py:77` | 3 | 2 | 22 | 0.40 |
| `atlas/tests/coffee_pipeline.py::project_cli` | `atlas/tests/coffee_pipeline.py:92` | 2 | 0 | 12 | 0.00 |
| `atlas/tests/coffee_pipeline.py::coffee_pipeline` | `atlas/tests/coffee_pipeline.py:109` | 10 | 2 | 11 | 0.17 |
| `atlas/tests/coffee_pipeline.py::write_pipeline` | `atlas/tests/coffee_pipeline.py:113` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/coffee_scenarios.py` | `atlas/tests/coffee_scenarios.py` | 7 | 1 | 8 | 0.12 |
| `atlas/tests/coffee_scenarios.py::core_calls` | `atlas/tests/coffee_scenarios.py:34` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/coffee_scenarios.py::core_calls.role` | `atlas/tests/coffee_scenarios.py:38` | 1 | 0 | 3 | 0.00 |
| `atlas/tests/coffee_semantic_assertions.py` | `atlas/tests/coffee_semantic_assertions.py` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/coffee_semantic_assertions.py::named_node` | `atlas/tests/coffee_semantic_assertions.py:9` | 2 | 0 | 4 | 0.00 |
| `atlas/tests/coffee_semantic_assertions.py::assert_oo_contract` | `atlas/tests/coffee_semantic_assertions.py:13` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/coffee_semantic_assertions.py::assert_brewer_construction` | `atlas/tests/coffee_semantic_assertions.py:28` | 1 | 2 | 2 | 0.67 |
| `atlas/tests/coffee_semantic_assertions.py::assert_go_closure` | `atlas/tests/coffee_semantic_assertions.py:44` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/coffee_semantic_assertions.py::assert_elixir_recursion` | `atlas/tests/coffee_semantic_assertions.py:69` | 1 | 5 | 1 | 0.83 |
| `atlas/tests/coffee_semantic_assertions.py::calls_from_owner` | `atlas/tests/coffee_semantic_assertions.py:85` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_semantic_assertions.py::assert_recursive_dispatch` | `atlas/tests/coffee_semantic_assertions.py:89` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_semantic_assertions.py::assert_elixir_inner_metrics` | `atlas/tests/coffee_semantic_assertions.py:96` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/coffee_semantic_assertions.py::workflow_cases` | `atlas/tests/coffee_semantic_assertions.py:110` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_semantic_assertions.py::workflow_owner` | `atlas/tests/coffee_semantic_assertions.py:129` | 1 | 0 | 4 | 0.00 |
| `atlas/tests/coffee_semantic_assertions.py::WorkflowContext` | `atlas/tests/coffee_semantic_assertions.py:137` | 0 | 0 | 0 | N/A |
| `atlas/tests/coffee_semantic_assertions.py::matches_workflow` | `atlas/tests/coffee_semantic_assertions.py:143` | 1 | 1 | 3 | 0.50 |
| `atlas/tests/coffee_semantic_assertions.py::assert_workflow_case` | `atlas/tests/coffee_semantic_assertions.py:154` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/coffee_semantic_assertions.py::assert_workflow` | `atlas/tests/coffee_semantic_assertions.py:165` | 1 | 7 | 1 | 0.88 |
| `atlas/tests/coffee_semantic_assertions.py::assert_java_workflow_references` | `atlas/tests/coffee_semantic_assertions.py:178` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_semantic_assertions.py::module_imports` | `atlas/tests/coffee_semantic_assertions.py:192` | 1 | 0 | 3 | 0.00 |
| `atlas/tests/coffee_semantic_assertions.py::external_calls_named` | `atlas/tests/coffee_semantic_assertions.py:196` | 1 | 2 | 3 | 0.67 |
| `atlas/tests/coffee_semantic_assertions.py::source_edges` | `atlas/tests/coffee_semantic_assertions.py:201` | 1 | 0 | 3 | 0.00 |
| `atlas/tests/coffee_semantic_assertions.py::assert_go_module_limitations` | `atlas/tests/coffee_semantic_assertions.py:205` | 1 | 3 | 2 | 0.75 |
| `atlas/tests/coffee_semantic_assertions.py::assert_elixir_grouped_alias_limitation` | `atlas/tests/coffee_semantic_assertions.py:239` | 1 | 2 | 2 | 0.67 |
| `atlas/tests/coffee_semantic_assertions.py::assert_library_output` | `atlas/tests/coffee_semantic_assertions.py:251` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/coffee_snapshot_assertions.py` | `atlas/tests/coffee_snapshot_assertions.py` | 3 | 2 | 3 | 0.40 |
| `atlas/tests/coffee_snapshot_assertions.py::nodes_by_key` | `atlas/tests/coffee_snapshot_assertions.py:23` | 16 | 0 | 25 | 0.00 |
| `atlas/tests/coffee_snapshot_assertions.py::call_edges` | `atlas/tests/coffee_snapshot_assertions.py:27` | 8 | 0 | 16 | 0.00 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_snapshot` | `atlas/tests/coffee_snapshot_assertions.py:31` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_layout` | `atlas/tests/coffee_snapshot_assertions.py:52` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_file_hashes` | `atlas/tests/coffee_snapshot_assertions.py:61` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_coordinates` | `atlas/tests/coffee_snapshot_assertions.py:70` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_recursion_scenarios` | `atlas/tests/coffee_snapshot_assertions.py:80` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_callback_owners` | `atlas/tests/coffee_snapshot_assertions.py:86` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/coffee_snapshot_assertions.py::required_core_calls` | `atlas/tests/coffee_snapshot_assertions.py:108` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_call_sites` | `atlas/tests/coffee_snapshot_assertions.py:123` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_source_evidence` | `atlas/tests/coffee_snapshot_assertions.py:130` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_render_paths` | `atlas/tests/coffee_snapshot_assertions.py:139` | 1 | 5 | 1 | 0.83 |
| `atlas/tests/coffee_snapshot_assertions.py::calls_named` | `atlas/tests/coffee_snapshot_assertions.py:150` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_empty_and_nonempty_render` | `atlas/tests/coffee_snapshot_assertions.py:154` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_preview_render` | `atlas/tests/coffee_snapshot_assertions.py:160` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_score` | `atlas/tests/coffee_snapshot_assertions.py:171` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_snapshot_assertions.py::assert_project_calls` | `atlas/tests/coffee_snapshot_assertions.py:180` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/coffee_snapshot_assertions.py::is_external_project_call` | `atlas/tests/coffee_snapshot_assertions.py:222` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_tsx_assertions.py` | `atlas/tests/coffee_tsx_assertions.py` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/coffee_tsx_assertions.py::reference_edges` | `atlas/tests/coffee_tsx_assertions.py:6` | 2 | 0 | 3 | 0.00 |
| `atlas/tests/coffee_tsx_assertions.py::owned_references` | `atlas/tests/coffee_tsx_assertions.py:10` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_tsx_assertions.py::assert_component_references` | `atlas/tests/coffee_tsx_assertions.py:18` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/coffee_tsx_assertions.py::assert_normal_calls` | `atlas/tests/coffee_tsx_assertions.py:42` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/coffee_tsx_assertions.py::assert_file_call_coordinates` | `atlas/tests/coffee_tsx_assertions.py:54` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/coffee_tsx_assertions.py::assert_intrinsics_and_shadowing` | `atlas/tests/coffee_tsx_assertions.py:64` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/database_boundary_policy.py` | `atlas/tests/database_boundary_policy.py` | 2 | 1 | 3 | 0.33 |
| `atlas/tests/database_boundary_policy.py::boundary_sensitive` | `atlas/tests/database_boundary_policy.py:68` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/database_boundary_policy.py::node_dynamic_violations` | `atlas/tests/database_boundary_policy.py:73` | 4 | 5 | 30 | 0.56 |
| `atlas/tests/database_boundary_policy.py::syntax_dynamic_violations` | `atlas/tests/database_boundary_policy.py:83` | 1 | 0 | 31 | 0.00 |
| `atlas/tests/database_boundary_policy.py::private_reflection_path` | `atlas/tests/database_boundary_policy.py:91` | 1 | 0 | 32 | 0.00 |
| `atlas/tests/database_boundary_policy.py::reflective_port_extraction` | `atlas/tests/database_boundary_policy.py:97` | 1 | 2 | 31 | 0.67 |
| `atlas/tests/database_boundary_policy.py::dynamic_import_violations` | `atlas/tests/database_boundary_policy.py:106` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/database_boundary_policy.py::forbidden_prefixes` | `atlas/tests/database_boundary_policy.py:112` | 1 | 1 | 28 | 0.50 |
| `atlas/tests/database_boundary_policy.py::layer_prefixes` | `atlas/tests/database_boundary_policy.py:121` | 1 | 1 | 29 | 0.50 |
| `atlas/tests/database_boundary_policy.py::matches_forbidden_prefix` | `atlas/tests/database_boundary_policy.py:129` | 1 | 1 | 28 | 0.50 |
| `atlas/tests/database_boundary_policy.py::forbidden_imports` | `atlas/tests/database_boundary_policy.py:133` | 2 | 4 | 27 | 0.67 |
| `atlas/tests/database_boundary_policy.py::factory_targets_forbidden` | `atlas/tests/database_boundary_policy.py:140` | 1 | 1 | 28 | 0.50 |
| `atlas/tests/database_boundary_policy.py::unapproved_targets` | `atlas/tests/database_boundary_policy.py:148` | 1 | 1 | 29 | 0.50 |
| `atlas/tests/database_boundary_policy.py::bootstrap_violations` | `atlas/tests/database_boundary_policy.py:152` | 1 | 1 | 26 | 0.50 |
| `atlas/tests/database_boundary_policy.py::bootstrap_statement_allowed` | `atlas/tests/database_boundary_policy.py:157` | 1 | 3 | 27 | 0.75 |
| `atlas/tests/database_boundary_policy.py::bootstrap_assignment_allowed` | `atlas/tests/database_boundary_policy.py:167` | 1 | 1 | 28 | 0.50 |
| `atlas/tests/database_boundary_policy.py::bootstrap_export_allowed` | `atlas/tests/database_boundary_policy.py:171` | 1 | 0 | 28 | 0.00 |
| `atlas/tests/database_boundary_policy.py::bootstrap_all_allowed` | `atlas/tests/database_boundary_policy.py:175` | 1 | 0 | 29 | 0.00 |
| `atlas/tests/database_boundary_policy.py::factory_import_violations` | `atlas/tests/database_boundary_policy.py:179` | 1 | 1 | 26 | 0.50 |
| `atlas/tests/database_boundary_policy.py::factory_node_import_violations` | `atlas/tests/database_boundary_policy.py:183` | 1 | 4 | 27 | 0.80 |
| `atlas/tests/database_boundary_policy.py::private_import_alias` | `atlas/tests/database_boundary_policy.py:194` | 1 | 0 | 28 | 0.00 |
| `atlas/tests/database_boundary_policy.py::in_memory_repository_attributes` | `atlas/tests/database_boundary_policy.py:198` | 1 | 1 | 26 | 0.50 |
| `atlas/tests/database_boundary_policy.py::in_memory_function_attributes` | `atlas/tests/database_boundary_policy.py:207` | 1 | 2 | 27 | 0.67 |
| `atlas/tests/database_boundary_policy.py::in_memory_assignment` | `atlas/tests/database_boundary_policy.py:215` | 1 | 0 | 28 | 0.00 |
| `atlas/tests/database_boundary_policy.py::raw_sql_violations` | `atlas/tests/database_boundary_policy.py:219` | 3 | 3 | 30 | 0.50 |
| `atlas/tests/database_boundary_policy.py::raw_expression` | `atlas/tests/database_boundary_policy.py:227` | 1 | 1 | 31 | 0.50 |
| `atlas/tests/database_boundary_policy.py::raw_literal_violations` | `atlas/tests/database_boundary_policy.py:232` | 1 | 1 | 31 | 0.50 |
| `atlas/tests/database_boundary_policy.py::raw_string_execution` | `atlas/tests/database_boundary_policy.py:242` | 1 | 1 | 32 | 0.50 |
| `atlas/tests/database_boundary_policy.py::string_expression` | `atlas/tests/database_boundary_policy.py:246` | 1 | 0 | 33 | 0.00 |
| `atlas/tests/database_boundary_policy.py::setup_statement` | `atlas/tests/database_boundary_policy.py:250` | 1 | 0 | 30 | 0.00 |
| `atlas/tests/database_boundary_policy.py::infrastructure_sql_violations` | `atlas/tests/database_boundary_policy.py:256` | 1 | 5 | 28 | 0.83 |
| `atlas/tests/database_boundary_policy.py::literal_setup` | `atlas/tests/database_boundary_policy.py:273` | 1 | 0 | 29 | 0.00 |
| `atlas/tests/database_boundary_policy.py::infrastructure_domain_violations` | `atlas/tests/database_boundary_policy.py:277` | 1 | 1 | 29 | 0.50 |
| `atlas/tests/database_boundary_policy.py::infrastructure_execution_violations` | `atlas/tests/database_boundary_policy.py:287` | 1 | 1 | 29 | 0.50 |
| `atlas/tests/database_boundary_policy.py::migration_schema_text` | `atlas/tests/database_boundary_policy.py:293` | 1 | 1 | 26 | 0.50 |
| `atlas/tests/database_boundary_policy.py::migration_index_text` | `atlas/tests/database_boundary_policy.py:300` | 1 | 1 | 27 | 0.50 |
| `atlas/tests/database_boundary_policy.py::migration_sql_violations` | `atlas/tests/database_boundary_policy.py:312` | 1 | 2 | 28 | 0.67 |
| `atlas/tests/database_boundary_policy.py::factory_escape_violations` | `atlas/tests/database_boundary_policy.py:322` | 1 | 3 | 26 | 0.75 |
| `atlas/tests/database_boundary_policy.py::context_port_aliases` | `atlas/tests/database_boundary_policy.py:330` | 1 | 0 | 27 | 0.00 |
| `atlas/tests/database_boundary_policy.py::return_port_violations` | `atlas/tests/database_boundary_policy.py:336` | 2 | 1 | 29 | 0.33 |
| `atlas/tests/database_boundary_policy.py::database_behavior_violations` | `atlas/tests/database_boundary_policy.py:342` | 1 | 2 | 27 | 0.67 |
| `atlas/tests/database_boundary_policy.py::database_operation` | `atlas/tests/database_boundary_policy.py:353` | 1 | 0 | 28 | 0.00 |
| `atlas/tests/database_boundary_policy.py::service_port_violations` | `atlas/tests/database_boundary_policy.py:358` | 1 | 2 | 26 | 0.67 |
| `atlas/tests/database_boundary_policy.py::service_node_port_violations` | `atlas/tests/database_boundary_policy.py:363` | 1 | 5 | 27 | 0.83 |
| `atlas/tests/database_boundary_policy.py::port_aliases` | `atlas/tests/database_boundary_policy.py:375` | 2 | 2 | 28 | 0.50 |
| `atlas/tests/database_boundary_policy.py::annotation_expression` | `atlas/tests/database_boundary_policy.py:384` | 2 | 0 | 33 | 0.00 |
| `atlas/tests/database_boundary_policy.py::port_annotation` | `atlas/tests/database_boundary_policy.py:388` | 1 | 2 | 29 | 0.67 |
| `atlas/tests/database_boundary_policy.py::port_assignment_aliases` | `atlas/tests/database_boundary_policy.py:393` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/database_boundary_policy.py::port_argument_violations` | `atlas/tests/database_boundary_policy.py:401` | 1 | 3 | 28 | 0.75 |
| `atlas/tests/database_boundary_policy.py::port_escape_violations` | `atlas/tests/database_boundary_policy.py:409` | 4 | 2 | 32 | 0.33 |
| `atlas/tests/database_boundary_policy.py::service_constructor_violations` | `atlas/tests/database_boundary_policy.py:418` | 1 | 2 | 28 | 0.67 |
| `atlas/tests/database_boundary_policy.py::parameter_assignment_aliases` | `atlas/tests/database_boundary_policy.py:433` | 0 | 0 | 0 | N/A |
| `atlas/tests/database_boundary_policy.py::constructor_protocol_matches` | `atlas/tests/database_boundary_policy.py:439` | 1 | 2 | 29 | 0.67 |
| `atlas/tests/database_boundary_policy.py::BoundaryState` | `atlas/tests/database_boundary_policy.py:444` | 0 | 0 | 0 | N/A |
| `atlas/tests/database_boundary_policy.py::port_access_violations` | `atlas/tests/database_boundary_policy.py:453` | 1 | 3 | 27 | 0.75 |
| `atlas/tests/database_boundary_policy.py::port_attribute_allowed` | `atlas/tests/database_boundary_policy.py:467` | 1 | 1 | 28 | 0.50 |
| `atlas/tests/database_boundary_policy.py::boundary_violations` | `atlas/tests/database_boundary_policy.py:473` | 3 | 13 | 25 | 0.81 |
| `atlas/tests/database_boundary_policy.py::docstring_ids` | `atlas/tests/database_boundary_policy.py:492` | 1 | 1 | 26 | 0.50 |
| `atlas/tests/database_boundary_policy.py::has_docstring` | `atlas/tests/database_boundary_policy.py:497` | 1 | 0 | 27 | 0.00 |
| `atlas/tests/database_boundary_policy.py::boundary_node_violations` | `atlas/tests/database_boundary_policy.py:501` | 1 | 3 | 26 | 0.75 |
| `atlas/tests/database_boundary_policy.py::boundary_sql_violations` | `atlas/tests/database_boundary_policy.py:510` | 1 | 3 | 27 | 0.75 |
| `atlas/tests/database_boundary_policy.py::guarded_dynamic_violations` | `atlas/tests/database_boundary_policy.py:520` | 1 | 2 | 26 | 0.67 |
| `atlas/tests/database_boundary_syntax.py` | `atlas/tests/database_boundary_syntax.py` | 2 | 0 | 4 | 0.00 |
| `atlas/tests/database_boundary_syntax.py::belongs_to` | `atlas/tests/database_boundary_syntax.py:9` | 14 | 0 | 58 | 0.00 |
| `atlas/tests/database_boundary_syntax.py::resolved_import_module` | `atlas/tests/database_boundary_syntax.py:13` | 3 | 0 | 39 | 0.00 |
| `atlas/tests/database_boundary_syntax.py::node_import_targets` | `atlas/tests/database_boundary_syntax.py:18` | 3 | 1 | 34 | 0.25 |
| `atlas/tests/database_boundary_syntax.py::node_import_aliases` | `atlas/tests/database_boundary_syntax.py:27` | 3 | 1 | 33 | 0.25 |
| `atlas/tests/database_boundary_syntax.py::qualified_name` | `atlas/tests/database_boundary_syntax.py:36` | 16 | 0 | 56 | 0.00 |
| `atlas/tests/database_boundary_syntax.py::assignment_pairs` | `atlas/tests/database_boundary_syntax.py:48` | 1 | 0 | 28 | 0.00 |
| `atlas/tests/database_boundary_syntax.py::import_aliases` | `atlas/tests/database_boundary_syntax.py:56` | 5 | 2 | 30 | 0.29 |
| `atlas/tests/database_boundary_syntax.py::import_assignment_aliases` | `atlas/tests/database_boundary_syntax.py:67` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/database_boundary_syntax.py::apply_alias_pairs` | `atlas/tests/database_boundary_syntax.py:74` | 1 | 0 | 37 | 0.00 |
| `atlas/tests/database_boundary_syntax.py::propagate_aliases` | `atlas/tests/database_boundary_syntax.py:79` | 3 | 1 | 36 | 0.25 |
| `atlas/tests/database_boundary_syntax.py::import_targets` | `atlas/tests/database_boundary_syntax.py:88` | 2 | 4 | 26 | 0.67 |
| `atlas/tests/database_boundary_syntax.py::main_config_reflection_ids` | `atlas/tests/database_boundary_syntax.py:107` | 1 | 4 | 27 | 0.80 |
| `atlas/tests/database_boundary_syntax.py::exact_lookup_definitions` | `atlas/tests/database_boundary_syntax.py:117` | 1 | 1 | 28 | 0.50 |
| `atlas/tests/database_boundary_syntax.py::public_config_aliases` | `atlas/tests/database_boundary_syntax.py:122` | 1 | 0 | 28 | 0.00 |
| `atlas/tests/database_boundary_syntax.py::check_lookup_definition` | `atlas/tests/database_boundary_syntax.py:126` | 2 | 0 | 29 | 0.00 |
| `atlas/tests/database_boundary_syntax.py::check_lookup_getattr` | `atlas/tests/database_boundary_syntax.py:132` | 1 | 0 | 28 | 0.00 |
| `atlas/tests/graph_storage_fixture.py` | `atlas/tests/graph_storage_fixture.py` | 10 | 0 | 10 | 0.00 |
| `atlas/tests/graph_storage_fixture.py::NodeIdentity` | `atlas/tests/graph_storage_fixture.py:18` | 0 | 0 | 0 | N/A |
| `atlas/tests/graph_storage_fixture.py::_node` | `atlas/tests/graph_storage_fixture.py:24` | 1 | 0 | 31 | 0.00 |
| `atlas/tests/graph_storage_fixture.py::graph_artifact` | `atlas/tests/graph_storage_fixture.py:33` | 27 | 1 | 30 | 0.04 |
| `atlas/tests/graph_storage_fixture.py::migration_config` | `atlas/tests/graph_storage_fixture.py:63` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/graph_storage_fixture.py::normalized_rows` | `atlas/tests/graph_storage_fixture.py:67` | 17 | 0 | 17 | 0.00 |
| `atlas/tests/import_project_support.py` | `atlas/tests/import_project_support.py` | 11 | 6 | 18 | 0.35 |
| `atlas/tests/import_project_support.py::project_sources` | `atlas/tests/import_project_support.py:15` | 24 | 1 | 100 | 0.04 |
| `atlas/tests/import_project_support.py::repository` | `atlas/tests/import_project_support.py:25` | 18 | 2 | 121 | 0.10 |
| `atlas/tests/import_project_support.py::project_repository` | `atlas/tests/import_project_support.py:33` | 11 | 2 | 15 | 0.15 |
| `atlas/tests/import_project_support.py::analyze` | `atlas/tests/import_project_support.py:37` | 15 | 1 | 15 | 0.06 |
| `atlas/tests/import_project_support.py::symbols` | `atlas/tests/import_project_support.py:45` | 8 | 0 | 24 | 0.00 |
| `atlas/tests/import_project_support.py::connections_at` | `atlas/tests/import_project_support.py:52` | 2 | 1 | 29 | 0.33 |
| `atlas/tests/import_project_support.py::edges_at` | `atlas/tests/import_project_support.py:62` | 3 | 1 | 27 | 0.25 |
| `atlas/tests/import_project_support.py::imports_at` | `atlas/tests/import_project_support.py:66` | 8 | 1 | 8 | 0.11 |
| `atlas/tests/import_project_support.py::assert_call` | `atlas/tests/import_project_support.py:70` | 13 | 2 | 13 | 0.13 |
| `atlas/tests/import_project_support.py::assert_external` | `atlas/tests/import_project_support.py:78` | 10 | 1 | 11 | 0.09 |
| `atlas/tests/metric_test_support.py` | `atlas/tests/metric_test_support.py` | 2 | 0 | 2 | 0.00 |
| `atlas/tests/metric_test_support.py::assert_symbol_identity` | `atlas/tests/metric_test_support.py:4` | 2 | 0 | 2 | 0.00 |
| `atlas/tests/metric_test_support.py::restore_symbol_metrics` | `atlas/tests/metric_test_support.py:8` | 1 | 0 | 4 | 0.00 |
| `atlas/tests/metric_test_support.py::restore_file_metrics` | `atlas/tests/metric_test_support.py:13` | 2 | 1 | 3 | 0.33 |
| `atlas/tests/metric_test_support.py::restore_repository_metrics` | `atlas/tests/metric_test_support.py:18` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/project_snapshot_support.py` | `atlas/tests/project_snapshot_support.py` | 5 | 1 | 19 | 0.17 |
| `atlas/tests/project_snapshot_support.py::parsed_value` | `atlas/tests/project_snapshot_support.py:8` | 3 | 0 | 22 | 0.00 |
| `atlas/tests/project_snapshot_support.py::structure_value` | `atlas/tests/project_snapshot_support.py:21` | 7 | 1 | 32 | 0.12 |
| `atlas/tests/source_snapshot_fixture.py` | `atlas/tests/source_snapshot_fixture.py` | 4 | 0 | 21 | 0.00 |
| `atlas/tests/source_snapshot_fixture.py::snapshot_value` | `atlas/tests/source_snapshot_fixture.py:13` | 7 | 1 | 36 | 0.12 |
| `atlas/tests/source_snapshot_fixture.py::snapshot_collection` | `atlas/tests/source_snapshot_fixture.py:25` | 1 | 2 | 36 | 0.67 |
| `atlas/tests/source_snapshot_fixture.py::snapshot_collection.<anonymous>` | `atlas/tests/source_snapshot_fixture.py:33` | 0 | 0 | 0 | N/A |
| `atlas/tests/source_snapshot_fixture.py::snapshot_scalar` | `atlas/tests/source_snapshot_fixture.py:38` | 1 | 0 | 37 | 0.00 |
| `atlas/tests/test_adapter_boundaries.py` | `atlas/tests/test_adapter_boundaries.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_adapter_boundaries.py::language_literals` | `atlas/tests/test_adapter_boundaries.py:24` | 1 | 0 | 3 | 0.00 |
| `atlas/tests/test_adapter_boundaries.py::forbidden_adapter_modules` | `atlas/tests/test_adapter_boundaries.py:31` | 1 | 0 | 3 | 0.00 |
| `atlas/tests/test_adapter_boundaries.py::AdapterBoundaryTest` | `atlas/tests/test_adapter_boundaries.py:38` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_adapter_boundaries.py::AdapterBoundaryTest.assert_shared_engine_node` | `atlas/tests/test_adapter_boundaries.py:39` | 1 | 2 | 2 | 0.67 |
| `atlas/tests/test_adapter_boundaries.py::AdapterBoundaryTest.assert_shared_engine_file` | `atlas/tests/test_adapter_boundaries.py:47` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_adapter_boundaries.py::AdapterBoundaryTest.test_shared_engines_do_not_dispatch_on_language_names` | `atlas/tests/test_adapter_boundaries.py:51` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_adapter_boundaries.py::AdapterBoundaryTest.test_nested_adapter_modules_obey_size_limits` | `atlas/tests/test_adapter_boundaries.py:67` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_adapter_complexity_cleanup.py` | `atlas/tests/test_adapter_complexity_cleanup.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_adapter_complexity_cleanup.py::nodes` | `atlas/tests/test_adapter_complexity_cleanup.py:13` | 4 | 0 | 4 | 0.00 |
| `atlas/tests/test_adapter_complexity_cleanup.py::node_text` | `atlas/tests/test_adapter_complexity_cleanup.py:21` | 4 | 0 | 4 | 0.00 |
| `atlas/tests/test_adapter_complexity_cleanup.py::test_adapter_callable_complexity_budget` | `atlas/tests/test_adapter_complexity_cleanup.py:29` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_adapter_complexity_cleanup.py::test_python_irrefutable_patterns` | `atlas/tests/test_adapter_complexity_cleanup.py:58` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_adapter_complexity_cleanup.py::elixir_scheduling_calls` | `atlas/tests/test_adapter_complexity_cleanup.py:69` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/test_adapter_complexity_cleanup.py::test_elixir_default_guard_and_pipeline_arities` | `atlas/tests/test_adapter_complexity_cleanup.py:77` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_adapter_indexes.py` | `atlas/tests/test_adapter_indexes.py` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_adapter_indexes.py::indexes` | `atlas/tests/test_adapter_indexes.py:17` | 2 | 1 | 2 | 0.33 |
| `atlas/tests/test_adapter_indexes.py::test_unrelated_scans_do_not_construct_language_specific_indexes` | `atlas/tests/test_adapter_indexes.py:26` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_adapter_indexes.py::assert_index_file_ownership` | `atlas/tests/test_adapter_indexes.py:34` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_adapter_indexes.py::assert_distinct_index_files` | `atlas/tests/test_adapter_indexes.py:41` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_adapter_indexes.py::test_indexes_are_owned_by_each_repository` | `atlas/tests/test_adapter_indexes.py:49` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_adapter_ownership.py` | `atlas/tests/test_adapter_ownership.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_adapter_ownership.py::test_language_module_owns_adapter_and_parameter_policy` | `atlas/tests/test_adapter_ownership.py:28` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_adapter_ownership.py::test_language_module_owns_metric_policy` | `atlas/tests/test_adapter_ownership.py:39` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_adapter_ownership.py::test_shared_adapter_helpers_do_not_import_language_modules` | `atlas/tests/test_adapter_ownership.py:51` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_adapter_ownership.py::_language_import` | `atlas/tests/test_adapter_ownership.py:56` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_adapter_ownership.py::test_rust_module_owns_macro_evaluation` | `atlas/tests/test_adapter_ownership.py:67` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_adapters.py` | `atlas/tests/test_adapters.py` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::AdapterContractTest` | `atlas/tests/test_adapters.py:23` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::AdapterContractTest.test_registry_is_overrides_not_the_language_support_list` | `atlas/tests/test_adapters.py:24` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::AdapterContractTest.test_hooks_return_common_carriers_and_call_site_contracts` | `atlas/tests/test_adapters.py:37` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::AdapterContractTest.assert_source_contract` | `atlas/tests/test_adapters.py:52` | 1 | 4 | 1 | 0.80 |
| `atlas/tests/test_adapters.py::AdapterContractTest.assert_call_site_contract` | `atlas/tests/test_adapters.py:70` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/test_adapters.py::AdapterContractTest.test_kotlin_recovery_and_hierarchy_remain_shared` | `atlas/tests/test_adapters.py:81` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::AdapterContractTest.test_adapter_import_supplements_keep_original_evidence_and_line` | `atlas/tests/test_adapters.py:89` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::AdapterContractTest.assert_import_supplements` | `atlas/tests/test_adapters.py:103` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_adapters.py::AdapterContractTest.test_shared_import_merging_defers_inline_module_policy_to_adapter` | `atlas/tests/test_adapters.py:113` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::LanguageSupportTest` | `atlas/tests/test_adapters.py:123` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_unrecognized_filenames_return_none` | `atlas/tests/test_adapters.py:124` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_discovery_propagates_language_detection_errors` | `atlas/tests/test_adapters.py:129` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_discovery_excludes_retired_languages_without_narrowing_other_grammars` | `atlas/tests/test_adapters.py:139` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_call_parser_failure_propagates` | `atlas/tests/test_adapters.py:163` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_native_processing_failure_propagates` | `atlas/tests/test_adapters.py:169` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.test_direct_extraction_rejects_excluded_languages_before_parsing_or_queries` | `atlas/tests/test_adapters.py:175` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_adapters.py::LanguageSupportTest.assert_unsupported_extraction` | `atlas/tests/test_adapters.py:181` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_architecture.py` | `atlas/tests/test_architecture.py` | 5 | 0 | 5 | 0.00 |
| `atlas/tests/test_architecture.py::control_depth` | `atlas/tests/test_architecture.py:23` | 1 | 0 | 4 | 0.00 |
| `atlas/tests/test_architecture.py::module_dependencies` | `atlas/tests/test_architecture.py:40` | 5 | 1 | 6 | 0.17 |
| `atlas/tests/test_architecture.py::module_dependencies.visit` | `atlas/tests/test_architecture.py:44` | 1 | 2 | 7 | 0.67 |
| `atlas/tests/test_architecture.py::is_type_checking_guard` | `atlas/tests/test_architecture.py:58` | 1 | 0 | 8 | 0.00 |
| `atlas/tests/test_architecture.py::relative_import_dependencies` | `atlas/tests/test_architecture.py:66` | 1 | 1 | 8 | 0.50 |
| `atlas/tests/test_architecture.py::import_dependency` | `atlas/tests/test_architecture.py:72` | 1 | 0 | 9 | 0.00 |
| `atlas/tests/test_architecture.py::branch_complexity` | `atlas/tests/test_architecture.py:77` | 1 | 1 | 4 | 0.50 |
| `atlas/tests/test_architecture.py::is_complexity_branch` | `atlas/tests/test_architecture.py:83` | 1 | 0 | 5 | 0.00 |
| `atlas/tests/test_architecture.py::assert_function_limits` | `atlas/tests/test_architecture.py:91` | 1 | 2 | 3 | 0.67 |
| `atlas/tests/test_architecture.py::assert_tree_function_limits` | `atlas/tests/test_architecture.py:97` | 2 | 1 | 2 | 0.33 |
| `atlas/tests/test_architecture.py::module_name` | `atlas/tests/test_architecture.py:103` | 5 | 0 | 8 | 0.00 |
| `atlas/tests/test_architecture.py::module_package` | `atlas/tests/test_architecture.py:110` | 5 | 1 | 6 | 0.17 |
| `atlas/tests/test_architecture.py::ArchitectureTest` | `atlas/tests/test_architecture.py:115` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_package_boundaries_exist` | `atlas/tests/test_architecture.py:116` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_one_implementation_file_per_primary_language` | `atlas/tests/test_architecture.py:138` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_adapters_do_not_depend_on_shared_graph_orchestration` | `atlas/tests/test_architecture.py:154` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_phase_adapters_and_shared_models_are_independent` | `atlas/tests/test_architecture.py:170` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_architecture.py::ArchitectureTest.assert_package_independent` | `atlas/tests/test_architecture.py:180` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_module_size_function_size_and_relative_import_dag` | `atlas/tests/test_architecture.py:189` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_architecture.py::ArchitectureTest.test_module_size_function_size_and_relative_import_dag.visit` | `atlas/tests/test_architecture.py:203` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_atlasignore.py` | `atlas/tests/test_atlasignore.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_atlasignore.py::write_files` | `atlas/tests/test_atlasignore.py:15` | 5 | 0 | 5 | 0.00 |
| `atlas/tests/test_atlasignore.py::source_paths` | `atlas/tests/test_atlasignore.py:23` | 6 | 1 | 6 | 0.14 |
| `atlas/tests/test_atlasignore.py::test_atlasignore_patterns_and_negation` | `atlas/tests/test_atlasignore.py:28` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_atlasignore.py::test_atlasignore_preserves_fallback_and_git_metadata` | `atlas/tests/test_atlasignore.py:52` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_atlasignore.py::test_atlasignore_cannot_restore_gitignored_paths_or_be_undone_by_gitignore` | `atlas/tests/test_atlasignore.py:60` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_atlasignore.py::test_nested_atlasignore_is_relative_and_can_override_inherited_patterns` | `atlas/tests/test_atlasignore.py:71` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_atlasignore.py::test_negation_requires_visible_parent_directories` | `atlas/tests/test_atlasignore.py:90` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_atlasignore.py::test_repository_atlasignore_excludes_fixtures_only_when_scanning_repository` | `atlas/tests/test_atlasignore.py:99` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_atlasignore.py::test_repository_atlasignore_excludes_data_not_snapshot_test_implementation` | `atlas/tests/test_atlasignore.py:111` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_atlasignore.py::test_cli_reanalysis_removes_atlasignored_files_and_findings` | `atlas/tests/test_atlasignore.py:125` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_autogenerate.py` | `atlas/tests/test_autogenerate.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_autogenerate.py::test_autogenerate_detects_changed_foreign_key_actions` | `atlas/tests/test_autogenerate.py:17` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_bootstrap.py` | `atlas/tests/test_bootstrap.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_bootstrap.py::test_service_does_not_migrate_and_disposes_on_storage_error` | `atlas/tests/test_bootstrap.py:15` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_bootstrap.py::test_service_does_not_migrate_and_disposes_on_storage_error.<anonymous>` | `atlas/tests/test_bootstrap.py:20` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_bootstrap.py::test_service_does_not_migrate_and_disposes_on_storage_error.<anonymous>` | `atlas/tests/test_bootstrap.py:21` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_bootstrap.py::test_service_preserves_domain_errors` | `atlas/tests/test_bootstrap.py:32` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_bootstrap.py::test_service_factories_do_not_expose_storage_handles` | `atlas/tests/test_bootstrap.py:42` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_bootstrap.py::test_migration_translates_storage_error_and_disposes` | `atlas/tests/test_bootstrap.py:55` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_bootstrap.py::test_migration_translates_storage_error_and_disposes.<anonymous>` | `atlas/tests/test_bootstrap.py:60` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_bootstrap.py::test_migration_translates_storage_error_and_disposes.<anonymous>` | `atlas/tests/test_bootstrap.py:61` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_bootstrap.py::test_migration_translates_storage_error_and_disposes.fail_upgrade` | `atlas/tests/test_bootstrap.py:64` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_call_resolution.py` | `atlas/tests/test_call_resolution.py` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_call_resolution.py::calls_at` | `atlas/tests/test_call_resolution.py:25` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_call_resolution.py::test_member_collisions_never_use_local_or_global_name_fallback` | `atlas/tests/test_call_resolution.py:34` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_call_resolution.py::assert_call_evidence` | `atlas/tests/test_call_resolution.py:47` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_call_resolution.py::test_computed_and_qualified_targets_are_not_bare` | `atlas/tests/test_call_resolution.py:51` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_call_resolution.py::test_ambiguous_bare_call_stays_external` | `atlas/tests/test_call_resolution.py:64` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_call_resolution.py::test_query_from_does_not_resolve_to_receipt_factory` | `atlas/tests/test_call_resolution.py:73` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_callable_metric_boundaries.py` | `atlas/tests/test_callable_metric_boundaries.py` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_callable_metric_boundaries.py::test_malformed_header_and_mixed_clause_arity_are_unknown` | `atlas/tests/test_callable_metric_boundaries.py:25` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_callable_metric_boundaries.py::test_named_layout_variants_count_physical_lines` | `atlas/tests/test_callable_metric_boundaries.py:50` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_callable_metric_boundaries.py::test_python_receiver_discriminators_on_whole_tracking_source` | `atlas/tests/test_callable_metric_boundaries.py:75` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_callable_metric_boundaries.py::test_native_end_exclusive_column_zero_on_real_nested_tracking_spans` | `atlas/tests/test_callable_metric_boundaries.py:90` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_callable_metrics.py` | `atlas/tests/test_callable_metrics.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_callable_metrics.py::test_tracking_workflow_parameter_counts_and_spans` | `atlas/tests/test_callable_metrics.py:38` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_callable_metrics.py::test_coffee_parameter_counts_and_physical_spans` | `atlas/tests/test_callable_metrics.py:91` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_callable_metrics.py::test_python_receivers_only_in_methods` | `atlas/tests/test_callable_metrics.py:100` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_callable_metrics.py::test_comments_separators_and_annotations_are_not_inputs` | `atlas/tests/test_callable_metrics.py:120` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_callable_metrics.py::test_elixir_clauses_keep_identity_and_counts` | `atlas/tests/test_callable_metrics.py:125` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_callable_metrics.py::test_unknown_parameter_property_is_omitted` | `atlas/tests/test_callable_metrics.py:134` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_callable_metrics.py::test_metrics_survive_snapshot_persistence` | `atlas/tests/test_callable_metrics.py:142` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_callback_carrier_regression.py` | `atlas/tests/test_callback_carrier_regression.py` | 0 | 8 | 0 | 1.00 |
| `atlas/tests/test_callback_carrier_regression.py::tracking_source` | `atlas/tests/test_callback_carrier_regression.py:38` | 4 | 1 | 7 | 0.20 |
| `atlas/tests/test_callback_carrier_regression.py::flatten` | `atlas/tests/test_callback_carrier_regression.py:43` | 5 | 0 | 8 | 0.00 |
| `atlas/tests/test_callback_carrier_regression.py::span` | `atlas/tests/test_callback_carrier_regression.py:53` | 2 | 0 | 4 | 0.00 |
| `atlas/tests/test_callback_carrier_regression.py::binding_context` | `atlas/tests/test_callback_carrier_regression.py:61` | 3 | 4 | 3 | 0.57 |
| `atlas/tests/test_callback_carrier_regression.py::assert_carrier` | `atlas/tests/test_callback_carrier_regression.py:70` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/test_callback_carrier_regression.py::assert_local_owner` | `atlas/tests/test_callback_carrier_regression.py:82` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_callback_carrier_regression.py::assert_local_calls` | `atlas/tests/test_callback_carrier_regression.py:98` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/test_callback_carrier_regression.py::test_parenthesized_bindings_have_exact_carrier_and_local_owner` | `atlas/tests/test_callback_carrier_regression.py:114` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_callback_carrier_regression.py::binding_wrapper` | `atlas/tests/test_callback_carrier_regression.py:121` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_callback_carrier_regression.py::test_all_binding_contexts_cover_all_four_carrier_styles` | `atlas/tests/test_callback_carrier_regression.py:135` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_callback_carrier_regression.py::test_generator_ancestor_keeps_callback_and_local_call_owner` | `atlas/tests/test_callback_carrier_regression.py:146` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_callback_carrier_regression.py::test_inline_dispatch_callbacks_keep_nearest_owner` | `atlas/tests/test_callback_carrier_regression.py:164` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_callback_carrier_regression.py::assert_native_endpoint` | `atlas/tests/test_callback_carrier_regression.py:181` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/test_callback_carrier_regression.py::test_native_wrappers_correct_both_endpoints_without_mutation` | `atlas/tests/test_callback_carrier_regression.py:216` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_callback_carrier_regression.py::test_unresolved_binding_preserves_native_name_and_metadata_once` | `atlas/tests/test_callback_carrier_regression.py:234` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_callback_carrier_regression.py::receipt_callbacks` | `atlas/tests/test_callback_carrier_regression.py:249` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_callback_carrier_regression.py::test_only_parentheses_are_transparent_and_inline_names_stay_explicit` | `atlas/tests/test_callback_carrier_regression.py:259` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_check.py` | `atlas/tests/test_check.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_check.py::disabled_config` | `atlas/tests/test_check.py:16` | 8 | 0 | 8 | 0.00 |
| `atlas/tests/test_check.py::report_node` | `atlas/tests/test_check.py:20` | 5 | 0 | 5 | 0.00 |
| `atlas/tests/test_check.py::report` | `atlas/tests/test_check.py:25` | 7 | 0 | 7 | 0.00 |
| `atlas/tests/test_check.py::LimitCase` | `atlas/tests/test_check.py:31` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_check.py::<anonymous>` | `atlas/tests/test_check.py:47` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_check.py::test_equality_passes_and_only_exceeded_limits_are_returned` | `atlas/tests/test_check.py:48` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_check.py::test_null_disables_every_metric_check` | `atlas/tests/test_check.py:60` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_check.py::test_missing_measurements_cannot_silently_pass_enabled_rules` | `atlas/tests/test_check.py:70` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_check.py::test_isolated_instability_is_not_a_violation_and_zero_is_valid` | `atlas/tests/test_check.py:78` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_check.py::test_dependency_limits_apply_to_files_and_modules_not_callables` | `atlas/tests/test_check.py:84` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_check.py::test_cycle_count_maximum_and_explicit_configuration` | `atlas/tests/test_check.py:89` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_check.py::test_analysis_errors_cannot_produce_a_successful_check` | `atlas/tests/test_check.py:99` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_check.py::test_real_dependency_graph_has_trackable_impact_and_instability` | `atlas/tests/test_check.py:105` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_check_cli.py` | `atlas/tests/test_check_cli.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_check_cli.py::invoke` | `atlas/tests/test_check_cli.py:17` | 8 | 0 | 8 | 0.00 |
| `atlas/tests/test_check_cli.py::configure` | `atlas/tests/test_check_cli.py:21` | 5 | 0 | 5 | 0.00 |
| `atlas/tests/test_check_cli.py::test_check_help_describes_model_defaults_and_check_semantics` | `atlas/tests/test_check_cli.py:25` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_check_cli.py::test_default_parameter_limit_checks_current_code_and_exit_status` | `atlas/tests/test_check_cli.py:37` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_check_cli.py::test_cycles_fail_check_but_report_stays_quantitative` | `atlas/tests/test_check_cli.py:54` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_check_cli.py::test_partial_config_merges_defaults_and_disabled_checks` | `atlas/tests/test_check_cli.py:77` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_check_cli.py::test_dependency_limits_are_read_from_project_configuration` | `atlas/tests/test_check_cli.py:91` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_check_cli.py::test_check_defaults_aliases_and_analyzed_root_config` | `atlas/tests/test_check_cli.py:108` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_check_cli.py::test_check_default_never_opens_database` | `atlas/tests/test_check_cli.py:119` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_check_cli.py::test_check_default_never_opens_database.fail` | `atlas/tests/test_check_cli.py:122` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_check_cli.py::test_invalid_configuration_fails_before_analysis` | `atlas/tests/test_check_cli.py:135` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_check_cli.py::test_invalid_configuration_fails_before_analysis.fail` | `atlas/tests/test_check_cli.py:138` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_check_cli.py::test_report_does_not_apply_project_limits` | `atlas/tests/test_check_cli.py:148` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_check_cli.py::test_missing_analysis_folder_is_an_error` | `atlas/tests/test_check_cli.py:161` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_check_cli.py::test_real_syntax_errors_fail_check_even_with_all_limits_disabled` | `atlas/tests/test_check_cli.py:171` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_check_config.py` | `atlas/tests/test_check_config.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_check_config.py::test_missing_config_and_empty_object_use_defaults` | `atlas/tests/test_check_config.py:17` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_check_config.py::test_partial_overrides_and_null_disabled_limits` | `atlas/tests/test_check_config.py:23` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_check_config.py::test_every_rule_can_be_disabled` | `atlas/tests/test_check_config.py:30` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_check_config.py::test_invalid_configuration_is_an_error_with_its_path` | `atlas/tests/test_check_config.py:40` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_check_config.py::test_root_configuration_does_not_search_parent_folders` | `atlas/tests/test_check_config.py:47` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_cli.py` | `atlas/tests/test_cli.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_cli.py::CliTest` | `atlas/tests/test_cli.py:7` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_cli.py::CliTest.test_help_lists_commands_without_project_selector` | `atlas/tests/test_cli.py:8` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_cli.py::CliTest.test_migrate_is_not_a_cli_command` | `atlas/tests/test_cli.py:19` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_coffee.py` | `atlas/tests/test_coffee.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest` | `atlas/tests/test_coffee.py:26` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.setUpClass` | `atlas/tests/test_coffee.py:28` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_every_supported_sample_has_a_python_baseline` | `atlas/tests/test_coffee.py:35` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_all_supported_complete_graph_snapshots` | `atlas/tests/test_coffee.py:46` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_real_layout_hashes_and_coordinates` | `atlas/tests/test_coffee.py:51` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_hierarchy_views_cycles_and_stats_have_no_dangling_references` | `atlas/tests/test_coffee.py:56` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_recursion_inheritance_callbacks_imports_and_file_cycles` | `atlas/tests/test_coffee.py:62` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_every_reviewed_call_site_is_grounded_in_sample_source` | `atlas/tests/test_coffee.py:67` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_empty_filter_preview_and_nonempty_render_paths` | `atlas/tests/test_coffee.py:72` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_nested_score_complexity` | `atlas/tests/test_coffee.py:77` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_project_call_resolution_and_exact_known_limitations` | `atlas/tests/test_coffee.py:82` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee.py::CoffeeSnapshotTest.test_repeated_indexing_is_deterministic_except_timestamp` | `atlas/tests/test_coffee.py:87` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_coffee_check_snapshots.py` | `atlas/tests/test_coffee_check_snapshots.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_coffee_check_snapshots.py::test_coffee_check_matches_snapshot` | `atlas/tests/test_coffee_check_snapshots.py:13` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_coffee_go_rust_receiver_snapshots.py` | `atlas/tests/test_coffee_go_rust_receiver_snapshots.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_go_rust_receiver_snapshots.py::test_literal_receiver_targets_snapshot` | `atlas/tests/test_coffee_go_rust_receiver_snapshots.py:50` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_coffee_navigation_snapshots.py` | `atlas/tests/test_coffee_navigation_snapshots.py` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_coffee_navigation_snapshots.py::test_coffee_navigation_matches_snapshot` | `atlas/tests/test_coffee_navigation_snapshots.py:18` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_navigation_snapshots.py::test_inheritance_assertions_reject_incomplete_outgoing_chain` | `atlas/tests/test_coffee_navigation_snapshots.py:25` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_navigation_snapshots.py::test_normalization_rejects_inconsistent_metadata` | `atlas/tests/test_coffee_navigation_snapshots.py:40` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_navigation_snapshots.py::test_normalization_preserves_nonvolatile_content_and_order` | `atlas/tests/test_coffee_navigation_snapshots.py:47` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_pipeline.py` | `atlas/tests/test_coffee_pipeline.py` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_coffee_pipeline.py::test_complete_project_seam_snapshot` | `atlas/tests/test_coffee_pipeline.py:20` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_pipeline.py::test_every_physical_source_reaches_every_analysis_seam` | `atlas/tests/test_coffee_pipeline.py:26` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_coffee_pipeline.py::physical_source_paths` | `atlas/tests/test_coffee_pipeline.py:40` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_coffee_pipeline.py::assert_extraction_bytes` | `atlas/tests/test_coffee_pipeline.py:46` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_coffee_pipeline.py::assert_analysis_symbols` | `atlas/tests/test_coffee_pipeline.py:52` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_coffee_pipeline.py::test_staged_pipeline_matches_production_entry_point` | `atlas/tests/test_coffee_pipeline.py:59` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_coffee_pipeline.py::test_tags_only_extraction_is_deterministic` | `atlas/tests/test_coffee_pipeline.py:64` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_coffee_pipeline.py::test_projects_are_not_artificial_threshold_padding` | `atlas/tests/test_coffee_pipeline.py:71` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_coffee_pipeline.py::test_project_cli_does_not_create_storage_or_modify_source` | `atlas/tests/test_coffee_pipeline.py:79` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_coffee_pipeline.py::test_same_source_grammar_variants_are_identified_and_enriched` | `atlas/tests/test_coffee_pipeline.py:92` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_coffee_pipeline.py::test_each_physical_project_has_analysis_seams` | `atlas/tests/test_coffee_pipeline.py:106` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_pipeline.py::assert_standalone_group` | `atlas/tests/test_coffee_pipeline.py:116` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_coffee_pipeline.py::assert_standalone_project_seams` | `atlas/tests/test_coffee_pipeline.py:123` | 1 | 2 | 2 | 0.67 |
| `atlas/tests/test_coffee_pipeline.py::test_java_stocked_selects_one_argument_constructor` | `atlas/tests/test_coffee_pipeline.py:136` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_pipeline.py::test_shared_order_contract_has_real_tsx_parser_and_native_metadata` | `atlas/tests/test_coffee_pipeline.py:147` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_report_snapshots.py` | `atlas/tests/test_coffee_report_snapshots.py` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_coffee_report_snapshots.py::test_coffee_report_matches_snapshot` | `atlas/tests/test_coffee_report_snapshots.py:14` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_coffee_report_snapshots.py::test_coffee_size_measurements_include_every_source_and_callable` | `atlas/tests/test_coffee_report_snapshots.py:29` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_coffee_report_snapshots.py::assert_calibration_size` | `atlas/tests/test_coffee_report_snapshots.py:43` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_coffee_safety_review_snapshots.py` | `atlas/tests/test_coffee_safety_review_snapshots.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_safety_review_snapshots.py::safety_snapshot` | `atlas/tests/test_coffee_safety_review_snapshots.py:14` | 2 | 1 | 2 | 0.33 |
| `atlas/tests/test_coffee_safety_review_snapshots.py::test_safety_review_snapshot` | `atlas/tests/test_coffee_safety_review_snapshots.py:30` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_safety_review_snapshots.py::test_script_safety_review_targets` | `atlas/tests/test_coffee_safety_review_snapshots.py:36` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_semantics.py` | `atlas/tests/test_coffee_semantics.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest` | `atlas/tests/test_coffee_semantics.py:17` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.setUpClass` | `atlas/tests/test_coffee_semantics.py:19` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_all_oo_contracts_and_explicit_brewer_constructions` | `atlas/tests/test_coffee_semantics.py:24` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_java_method_reference_is_a_dependency_not_an_immediate_call` | `atlas/tests/test_coffee_semantics.py:29` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_go_closure_has_its_own_call_edges_and_metrics` | `atlas/tests/test_coffee_semantics.py:40` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_elixir_recursion_is_one_real_call_site_with_clause_dispatch` | `atlas/tests/test_coffee_semantics.py:43` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_python_decorators_base_abc_and_match_complexity` | `atlas/tests/test_coffee_semantics.py:46` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_python_import_styles_link_to_local_files` | `atlas/tests/test_coffee_semantics.py:67` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_python_import_styles_link_to_namespace_callables` | `atlas/tests/test_coffee_semantics.py:101` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_workflow_edges_reach_the_actual_sample_files` | `atlas/tests/test_coffee_semantics.py:123` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_coffee_semantics.py::CoffeeSemanticsTest.test_library_output_dependencies_include_rust_macros` | `atlas/tests/test_coffee_semantics.py:129` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity.py` | `atlas/tests/test_complexity.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_complexity.py::ComplexityTests` | `atlas/tests/test_complexity.py:11` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity.py::ComplexityTests.assert_fulfillment` | `atlas/tests/test_complexity.py:12` | 6 | 2 | 6 | 0.25 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_entry_and_sequential_decisions` | `atlas/tests/test_complexity.py:17` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_requested_example_across_grammars` | `atlas/tests/test_complexity.py:26` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_depths_three_and_five` | `atlas/tests/test_complexity.py:42` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_penalty_per_deep_decision_not_only_maximum` | `atlas/tests/test_complexity.py:49` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_loop_ancestor_need_not_be_immediate_parent` | `atlas/tests/test_complexity.py:52` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_boolean_ternary_and_catch` | `atlas/tests/test_complexity.py:56` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_else_if_is_not_nesting` | `atlas/tests/test_complexity.py:60` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_nested_scopes_are_not_counted` | `atlas/tests/test_complexity.py:66` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_python_method_and_inner_function_are_independent` | `atlas/tests/test_complexity.py:70` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity.py::ComplexityTests.test_artifact_only_function_and_method_properties` | `atlas/tests/test_complexity.py:79` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py` | `atlas/tests/test_complexity_regression.py` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests` | `atlas/tests/test_complexity_regression.py:12` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.assert_metrics` | `atlas/tests/test_complexity_regression.py:13` | 10 | 1 | 19 | 0.09 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.assert_python` | `atlas/tests/test_complexity_regression.py:18` | 4 | 2 | 4 | 0.33 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.assert_elixir` | `atlas/tests/test_complexity_regression.py:23` | 5 | 2 | 5 | 0.29 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_kotlin_each_short_circuit_operator_without_boolean_depth` | `atlas/tests/test_complexity_regression.py:28` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_python_refutable_match_patterns_and_fallbacks` | `atlas/tests/test_complexity_regression.py:35` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_python_fallback_guards_are_decisions` | `atlas/tests/test_complexity_regression.py:41` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_python_case_guard_depth_does_not_leak_into_body` | `atlas/tests/test_complexity_regression.py:46` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_python_match_nesting_and_nested_functions` | `atlas/tests/test_complexity_regression.py:50` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_if_unless_and_qualified_non_controls` | `atlas/tests/test_complexity_regression.py:54` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_case_and_cond_default_arm_exclusion` | `atlas/tests/test_complexity_regression.py:57` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_guarded_case_alternatives_and_deep_penalties` | `atlas/tests/test_complexity_regression.py:61` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_declaration_and_lambda_guards` | `atlas/tests/test_complexity_regression.py:66` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_reducer_calls_are_not_loops_and_fn_scopes_are_independent` | `atlas/tests/test_complexity_regression.py:77` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_nested_declaration_scopes` | `atlas/tests/test_complexity_regression.py:91` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_elixir_quoted_declarations_have_independent_bodies` | `atlas/tests/test_complexity_regression.py:96` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_else_if_chains_share_depth_across_grammars` | `atlas/tests/test_complexity_regression.py:103` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_default_arms_remain_excluded_across_grammars` | `atlas/tests/test_complexity_regression.py:117` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_braced_else_is_real_nesting_not_else_if` | `atlas/tests/test_complexity_regression.py:132` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.assert_callable_body` | `atlas/tests/test_complexity_regression.py:139` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_complexity_regression.py::GrammarComplexityRegressionTests.test_callable_roots_use_bodies_not_parameter_defaults` | `atlas/tests/test_complexity_regression.py:145` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_cycles.py` | `atlas/tests/test_cycles.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_cycles.py::file` | `atlas/tests/test_cycles.py:8` | 7 | 0 | 7 | 0.00 |
| `atlas/tests/test_cycles.py::edge` | `atlas/tests/test_cycles.py:12` | 7 | 0 | 7 | 0.00 |
| `atlas/tests/test_cycles.py::CyclesTest` | `atlas/tests/test_cycles.py:24` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_cycles.py::CyclesTest.test_acyclic_and_empty` | `atlas/tests/test_cycles.py:25` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_cycles.py::CyclesTest.test_sccs_witness_and_internal_edges` | `atlas/tests/test_cycles.py:30` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_cycles.py::CyclesTest.assert_cycle_witness` | `atlas/tests/test_cycles.py:41` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_cycles.py::CyclesTest.test_projection_preserves_evidence_without_mutation` | `atlas/tests/test_cycles.py:50` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_cycles.py::CyclesTest.test_only_genuine_file_self_import` | `atlas/tests/test_cycles.py:64` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_cycles.py::CyclesTest.test_external_missing_and_non_import_edges_ignored` | `atlas/tests/test_cycles.py:76` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_cycles.py::CyclesTest.test_determinism_and_optional_metadata` | `atlas/tests/test_cycles.py:97` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_cycles.py::CyclesTest.test_large_chain_and_cycle_are_iterative` | `atlas/tests/test_cycles.py:116` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_database_boundaries.py` | `atlas/tests/test_database_boundaries.py` | 1 | 2 | 2 | 0.67 |
| `atlas/tests/test_database_boundaries.py::violations` | `atlas/tests/test_database_boundaries.py:30` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_database_boundaries.py::test_database_boundary_policy` | `atlas/tests/test_database_boundaries.py:99` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_database_boundaries.py::test_every_production_package_is_boundary_sensitive` | `atlas/tests/test_database_boundaries.py:103` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_database_boundaries.py::test_repository_ownership_is_frozen_and_pure_records_are_not_orm` | `atlas/tests/test_database_boundaries.py:115` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_database_boundaries.py::test_production_modules_respect_database_boundaries` | `atlas/tests/test_database_boundaries.py:130` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_database_boundaries.py::test_policy_helpers_fit_architecture_limits` | `atlas/tests/test_database_boundaries.py:141` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_database_boundaries.py::assert_policy_function_limits` | `atlas/tests/test_database_boundaries.py:150` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_database_cli.py` | `atlas/tests/test_database_cli.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_database_cli.py::test_database_option_is_rejected` | `atlas/tests/test_database_cli.py:12` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_database_cli.py::test_help_has_no_database_option` | `atlas/tests/test_database_cli.py:25` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_declaration_callbacks.py` | `atlas/tests/test_declaration_callbacks.py` | 1 | 5 | 1 | 0.83 |
| `atlas/tests/test_declaration_callbacks.py::flatten` | `atlas/tests/test_declaration_callbacks.py:16` | 6 | 1 | 21 | 0.14 |
| `atlas/tests/test_declaration_callbacks.py::child_entries` | `atlas/tests/test_declaration_callbacks.py:26` | 1 | 0 | 22 | 0.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests` | `atlas/tests/test_declaration_callbacks.py:44` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_callback_carriers` | `atlas/tests/test_declaration_callbacks.py:45` | 8 | 5 | 12 | 0.38 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_declaration_nodes` | `atlas/tests/test_declaration_callbacks.py:61` | 1 | 2 | 13 | 0.67 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_declaration_node` | `atlas/tests/test_declaration_callbacks.py:72` | 1 | 0 | 14 | 0.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_callback_spans` | `atlas/tests/test_declaration_callbacks.py:82` | 1 | 0 | 13 | 0.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_callback_parentage` | `atlas/tests/test_declaration_callbacks.py:90` | 1 | 1 | 13 | 0.50 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.nearest_declaration` | `atlas/tests/test_declaration_callbacks.py:99` | 1 | 0 | 14 | 0.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_nested_callbacks_match_real_ast_and_parentage_with_or_without_native` | `atlas/tests/test_declaration_callbacks.py:109` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_application_callbacks` | `atlas/tests/test_declaration_callbacks.py:113` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_native_callbacks` | `atlas/tests/test_declaration_callbacks.py:121` | 1 | 3 | 2 | 0.75 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_native_duplicate_callback_metadata_merges_once_without_mutation` | `atlas/tests/test_declaration_callbacks.py:135` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_duplicate_callback_metadata` | `atlas/tests/test_declaration_callbacks.py:140` | 1 | 4 | 1 | 0.80 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_unbound_callback_identity_ignores_conflicting_native_names` | `atlas/tests/test_declaration_callbacks.py:161` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_go_assigned_literal_accepts_safe_binding_not_receiver_assignment` | `atlas/tests/test_declaration_callbacks.py:179` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_kotlin_anonymous_fun_and_labeled_lambda_not_wrappers` | `atlas/tests/test_declaration_callbacks.py:190` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_elixir_multiclause_fn_and_identical_expressions_stay_distinct` | `atlas/tests/test_declaration_callbacks.py:201` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_script_bindings_and_inline_functions_keep_single_identity` | `atlas/tests/test_declaration_callbacks.py:213` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.assert_script_bindings` | `atlas/tests/test_declaration_callbacks.py:219` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_declaration_callbacks.py::CallbackDeclarationTests.test_declarations_inside_callbacks_keep_expression_parent` | `atlas/tests/test_declaration_callbacks.py:235` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_declaration_canonical.py` | `atlas/tests/test_declaration_canonical.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_declaration_canonical.py::merged` | `atlas/tests/test_declaration_canonical.py:16` | 5 | 1 | 6 | 0.17 |
| `atlas/tests/test_declaration_canonical.py::names` | `atlas/tests/test_declaration_canonical.py:23` | 8 | 0 | 10 | 0.00 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests` | `atlas/tests/test_declaration_canonical.py:27` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_kotlin_unnamed_native_declarations_preserve_metadata` | `atlas/tests/test_declaration_canonical.py:28` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_kotlin_overloads_preserve_metadata_and_utf8_spans` | `atlas/tests/test_declaration_canonical.py:41` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_ts_interface_callable_properties_not_types_or_fields` | `atlas/tests/test_declaration_canonical.py:57` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.assert_interface_properties` | `atlas/tests/test_declaration_canonical.py:65` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_java_constructor_kind_and_visibility` | `atlas/tests/test_declaration_canonical.py:85` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_python_decorator_metadata_and_nested_definition` | `atlas/tests/test_declaration_canonical.py:97` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_python_stacked_utf8_decorator_discriminator` | `atlas/tests/test_declaration_canonical.py:109` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.assert_stacked_decorators` | `atlas/tests/test_declaration_canonical.py:114` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_python_native_decorated_wrapper_canonicalizes_to_definition` | `atlas/tests/test_declaration_canonical.py:127` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_declaration_canonical.py::CanonicalDeclarationTests.test_missing_tags_preserves_native_metadata` | `atlas/tests/test_declaration_canonical.py:145` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_declaration_coffee.py` | `atlas/tests/test_declaration_coffee.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_declaration_coffee.py::qualified_items` | `atlas/tests/test_declaration_coffee.py:14` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests` | `atlas/tests/test_declaration_coffee.py:25` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.test_whole_project_spans_ownership_and_native_nonmutation` | `atlas/tests/test_declaration_coffee.py:26` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_project_spans` | `atlas/tests/test_declaration_coffee.py:30` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_source_variants` | `atlas/tests/test_declaration_coffee.py:34` | 1 | 3 | 2 | 0.75 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_ast_spans` | `atlas/tests/test_declaration_coffee.py:43` | 1 | 2 | 3 | 0.67 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_ast_ancestor` | `atlas/tests/test_declaration_coffee.py:69` | 1 | 0 | 4 | 0.00 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.test_source_reviewed_kind_and_decorator_corrections` | `atlas/tests/test_declaration_coffee.py:75` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_source_corrections` | `atlas/tests/test_declaration_coffee.py:79` | 1 | 4 | 1 | 0.80 |
| `atlas/tests/test_declaration_coffee.py::CoffeeDeclarationTests.assert_corrections` | `atlas/tests/test_declaration_coffee.py:89` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_dependency_metric_persistence.py` | `atlas/tests/test_dependency_metric_persistence.py` | 0 | 10 | 0 | 1.00 |
| `atlas/tests/test_dependency_metric_persistence.py::fact_views` | `atlas/tests/test_dependency_metric_persistence.py:24` | 3 | 1 | 3 | 0.25 |
| `atlas/tests/test_dependency_metric_persistence.py::test_dependency_metrics_from_normalized_facts` | `atlas/tests/test_dependency_metric_persistence.py:31` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_dependency_metric_persistence.py::test_normalized_instability_excludes_duplicates_self_and_external_edges` | `atlas/tests/test_dependency_metric_persistence.py:61` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_dependency_metric_persistence.py::rich_artifact` | `atlas/tests/test_dependency_metric_persistence.py:84` | 2 | 1 | 2 | 0.33 |
| `atlas/tests/test_dependency_metric_persistence.py::test_normalized_facts_keep_all_dependency_occurrences_and_legacy_complexities` | `atlas/tests/test_dependency_metric_persistence.py:99` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_dependency_metric_persistence.py::test_enriched_facts_share_a_revision_and_are_repository_scoped` | `atlas/tests/test_dependency_metric_persistence.py:131` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_dependency_metric_persistence.py::test_enriched_facts_share_a_revision_and_are_repository_scoped.replace_after_header` | `atlas/tests/test_dependency_metric_persistence.py:148` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_dependency_metric_persistence.py::test_report_facts_default_collections_are_independent` | `atlas/tests/test_dependency_metric_persistence.py:175` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_dependency_metrics.py` | `atlas/tests/test_dependency_metrics.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::view` | `atlas/tests/test_dependency_metrics.py:27` | 6 | 0 | 6 | 0.00 |
| `atlas/tests/test_dependency_metrics.py::counts` | `atlas/tests/test_dependency_metrics.py:45` | 5 | 0 | 11 | 0.00 |
| `atlas/tests/test_dependency_metrics.py::expected_metrics` | `atlas/tests/test_dependency_metrics.py:49` | 8 | 1 | 8 | 0.11 |
| `atlas/tests/test_dependency_metrics.py::test_chain_diamond_and_cycles` | `atlas/tests/test_dependency_metrics.py:74` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::test_duplicate_self_and_outside_view_edges_do_not_count` | `atlas/tests/test_dependency_metrics.py:83` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::test_instability_uses_distinct_incoming_and_outgoing_peers` | `atlas/tests/test_dependency_metrics.py:101` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::reverse_reachable` | `atlas/tests/test_dependency_metrics.py:112` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_dependency_metrics.py::test_bitsets_match_independent_traversal_on_mixed_graphs` | `atlas/tests/test_dependency_metrics.py:126` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::test_deep_graph_is_iterative_and_exact` | `atlas/tests/test_dependency_metrics.py:136` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::test_large_cycle_is_iterative_and_excludes_selected_node` | `atlas/tests/test_dependency_metrics.py:145` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::declaration` | `atlas/tests/test_dependency_metrics.py:151` | 1 | 1 | 6 | 0.50 |
| `atlas/tests/test_dependency_metrics.py::projected_artifact` | `atlas/tests/test_dependency_metrics.py:159` | 5 | 2 | 5 | 0.29 |
| `atlas/tests/test_dependency_metrics.py::metric_values` | `atlas/tests/test_dependency_metrics.py:197` | 3 | 0 | 5 | 0.00 |
| `atlas/tests/test_dependency_metrics.py::assert_projected_peer_metrics` | `atlas/tests/test_dependency_metrics.py:201` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/test_dependency_metrics.py::test_all_levels_use_aggregated_internal_dependencies` | `atlas/tests/test_dependency_metrics.py:210` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::logistics_nodes` | `atlas/tests/test_dependency_metrics.py:233` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_dependency_metrics.py::assert_source_evidence` | `atlas/tests/test_dependency_metrics.py:238` | 2 | 0 | 2 | 0.00 |
| `atlas/tests/test_dependency_metrics.py::assert_no_runtime_import_cycle` | `atlas/tests/test_dependency_metrics.py:242` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_dependency_metrics.py::test_indexer_populates_metrics_and_excludes_unresolved_targets` | `atlas/tests/test_dependency_metrics.py:248` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::assert_stock_compile_time_metrics` | `atlas/tests/test_dependency_metrics.py:267` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_dependency_metrics.py::test_type_only_imports_contribute_compile_time_impact` | `atlas/tests/test_dependency_metrics.py:274` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::strip_metrics` | `atlas/tests/test_dependency_metrics.py:286` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_dependency_metrics.py::test_legacy_metrics_are_optional_and_round_trip` | `atlas/tests/test_dependency_metrics.py:291` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::test_metric_properties_require_nonnegative_integer_counts` | `atlas/tests/test_dependency_metrics.py:300` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::test_instability_accepts_none_and_finite_unit_interval_floats` | `atlas/tests/test_dependency_metrics.py:310` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_dependency_metrics.py::test_instability_requires_none_or_a_finite_unit_interval_float` | `atlas/tests/test_dependency_metrics.py:321` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_discovery.py` | `atlas/tests/test_discovery.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_discovery.py::discovered` | `atlas/tests/test_discovery.py:15` | 4 | 1 | 4 | 0.20 |
| `atlas/tests/test_discovery.py::write_source` | `atlas/tests/test_discovery.py:19` | 4 | 0 | 4 | 0.00 |
| `atlas/tests/test_discovery.py::test_gitignore_replaces_fallback_with_or_without_git` | `atlas/tests/test_discovery.py:27` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_discovery.py::test_nested_gitignore_and_negation` | `atlas/tests/test_discovery.py:44` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_discovery.py::test_empty_gitignore_disables_fallback_but_not_git_metadata` | `atlas/tests/test_discovery.py:57` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_discovery.py::test_fallback_excludes_generated_folders_not_files` | `atlas/tests/test_discovery.py:64` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_extraction_adapters.py` | `atlas/tests/test_extraction_adapters.py` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest` | `atlas/tests/test_extraction_adapters.py:15` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.test_per_language_inheritance_and_generic_fallback` | `atlas/tests/test_extraction_adapters.py:16` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.assert_inheritance` | `atlas/tests/test_extraction_adapters.py:35` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.test_jsx_tag_name_sites_are_references_without_swallowing_attribute_calls` | `atlas/tests/test_extraction_adapters.py:42` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.assert_jsx_calls` | `atlas/tests/test_extraction_adapters.py:48` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.test_decorators_visibility_and_import_supplement_owned_by_adapters` | `atlas/tests/test_extraction_adapters.py:65` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.assert_declaration_metadata` | `atlas/tests/test_extraction_adapters.py:88` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_extraction_adapters.py::ExtractionAdapterTest.test_rust_macro_payload_remains_rust_only` | `atlas/tests/test_extraction_adapters.py:93` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_extraction_integration.py` | `atlas/tests/test_extraction_integration.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_extraction_integration.py::test_elixir_heads_controls_nested_arguments_and_pipelines` | `atlas/tests/test_extraction_integration.py:9` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_extraction_integration.py::test_rust_macro_nested_arguments_offsets_and_invalid_dsl` | `atlas/tests/test_extraction_integration.py:22` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_extraction_integration.py::assert_invalid_receipt_macros` | `atlas/tests/test_extraction_integration.py:37` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_extraction_integration.py::test_rust_relative_module_paths_keep_declared_identity` | `atlas/tests/test_extraction_integration.py:43` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_extraction_integration.py::test_inheritance_headers_and_import_aliases_are_precise` | `atlas/tests/test_extraction_integration.py:56` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_extraction_integration.py::test_multiple_bases_exclude_metaclass_arguments` | `atlas/tests/test_extraction_integration.py:67` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_folder_cli.py` | `atlas/tests/test_folder_cli.py` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_folder_cli.py::FolderCase` | `atlas/tests/test_folder_cli.py:18` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_cli.py::source_contents` | `atlas/tests/test_folder_cli.py:23` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_folder_cli.py::folder_arguments` | `atlas/tests/test_folder_cli.py:27` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_folder_cli.py::assert_saved_output` | `atlas/tests/test_folder_cli.py:36` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_folder_cli.py::test_folder_default_and_aliases` | `atlas/tests/test_folder_cli.py:60` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_folder_cli.py::test_report_default_cwd_without_saving` | `atlas/tests/test_folder_cli.py:77` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_cli.py::test_skip_save_option_is_removed` | `atlas/tests/test_folder_cli.py:89` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py` | `atlas/tests/test_folder_report_cli.py` | 0 | 6 | 0 | 1.00 |
| `atlas/tests/test_folder_report_cli.py::source` | `atlas/tests/test_folder_report_cli.py:21` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_folder_report_creates_and_updates_saved_project` | `atlas/tests/test_folder_report_cli.py:29` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_folder_names_are_trimmed_for_registration` | `atlas/tests/test_folder_report_cli.py:58` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_relative_folder_uses_user_database_not_source` | `atlas/tests/test_folder_report_cli.py:70` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_folder_updates_registered_location_not_same_name` | `atlas/tests/test_folder_report_cli.py:83` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_same_basename_folders_get_distinct_projects` | `atlas/tests/test_folder_report_cli.py:99` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_default_never_accesses_database` | `atlas/tests/test_folder_report_cli.py:114` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_default_never_accesses_database.fail` | `atlas/tests/test_folder_report_cli.py:117` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_default_preserves_existing_graph` | `atlas/tests/test_folder_report_cli.py:136` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_save_analyzes_once_and_keeps_output` | `atlas/tests/test_folder_report_cli.py:158` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_folder_report_cli.py::test_save_analyzes_once_and_keeps_output.analyze` | `atlas/tests/test_folder_report_cli.py:168` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_invalid_report_arguments_do_not_create_database` | `atlas/tests/test_folder_report_cli.py:193` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_file_is_not_a_report_folder` | `atlas/tests/test_folder_report_cli.py:202` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_global_project_selector_is_rejected` | `atlas/tests/test_folder_report_cli.py:212` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_failed_update_preserves_saved_graph` | `atlas/tests/test_folder_report_cli.py:223` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_folder_report_cli.py::test_failed_save_rolls_back_registration` | `atlas/tests/test_folder_report_cli.py:245` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_contracts.py` | `atlas/tests/test_graph_contracts.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_graph_contracts.py::null_container_artifact` | `atlas/tests/test_graph_contracts.py:13` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_graph_contracts.py::test_null_containers_round_trip` | `atlas/tests/test_graph_contracts.py:26` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_graph_contracts.py::test_missing_or_empty_collections_have_no_normalized_rows` | `atlas/tests/test_graph_contracts.py:42` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_graph_contracts.py::malformed_artifact` | `atlas/tests/test_graph_contracts.py:50` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_graph_contracts.py::test_malformed_occurrence_containers_reject_without_changing_storage` | `atlas/tests/test_graph_contracts.py:71` | 0 | 8 | 0 | 1.00 |
| `atlas/tests/test_graph_migrations.py` | `atlas/tests/test_graph_migrations.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_graph_migrations.py::test_schema_upgrade_leaves_existing_artifacts_unparsed` | `atlas/tests/test_graph_migrations.py:14` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_graph_migrations.py::test_fresh_migration_late_failure_rolls_back_all_schema` | `atlas/tests/test_graph_migrations.py:37` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_graph_migrations.py::test_fresh_migration_late_failure_rolls_back_all_schema.fail_schema` | `atlas/tests/test_graph_migrations.py:42` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_migrations.py::test_fresh_migration_late_failure_rolls_back_all_schema.<anonymous>` | `atlas/tests/test_graph_migrations.py:47` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_navigation.py` | `atlas/tests/test_graph_navigation.py` | 0 | 12 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::graph` | `atlas/tests/test_graph_navigation.py:32` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::command` | `atlas/tests/test_graph_navigation.py:49` | 24 | 0 | 24 | 0.00 |
| `atlas/tests/test_graph_navigation.py::test_cli_metadata_and_optional_project` | `atlas/tests/test_graph_navigation.py:55` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_search_rank_ambiguity_and_literal_query` | `atlas/tests/test_graph_navigation.py:67` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_search_prefers_internal_declarations_and_exact_files` | `atlas/tests/test_graph_navigation.py:81` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_unicode_search_rank_and_tie_breakers_on_existing_database` | `atlas/tests/test_graph_navigation.py:88` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_unicode_search_keeps_punctuation_literal` | `atlas/tests/test_graph_navigation.py:131` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_hierarchy_pagination_and_diagnostic_scope` | `atlas/tests/test_graph_navigation.py:138` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_directions_cycles_and_evidence` | `atlas/tests/test_graph_navigation.py:151` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::<anonymous>` | `atlas/tests/test_graph_navigation.py:162` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_navigation.py::test_context_cutoffs` | `atlas/tests/test_graph_navigation.py:163` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_unresolved_and_type_only` | `atlas/tests/test_graph_navigation.py:172` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_cli_unresolved_labels_leave_storage_and_service_unchanged` | `atlas/tests/test_graph_navigation.py:181` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::driver` | `atlas/tests/test_graph_navigation.py:196` | 4 | 0 | 4 | 0.00 |
| `atlas/tests/test_graph_navigation.py::test_frontier_edge_queries_are_scoped_and_bounded` | `atlas/tests/test_graph_navigation.py:201` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_adjacency_plan_streams_endpoint_relation_index` | `atlas/tests/test_graph_navigation.py:215` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_adjacency_work_ignores_unrelated_edges` | `atlas/tests/test_graph_navigation.py:226` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_adjacency_work_ignores_unrelated_edges.count_steps` | `atlas/tests/test_graph_navigation.py:232` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_navigation.py::test_unknown_relation_is_a_usage_error` | `atlas/tests/test_graph_navigation.py:241` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_navigation.py::test_path_found_unknown_and_not_found` | `atlas/tests/test_graph_navigation.py:246` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_repository_isolation` | `atlas/tests/test_graph_navigation.py:255` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_read_snapshot_and_revision` | `atlas/tests/test_graph_navigation.py:270` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_missing_database_is_not_created` | `atlas/tests/test_graph_navigation.py:286` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_navigation.py::test_missing_schema_and_index` | `atlas/tests/test_graph_navigation.py:294` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_navigation.py::test_source_spans_use_parser_lf_coordinates` | `atlas/tests/test_graph_navigation.py:310` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_batch_source_preserves_order_status_and_metadata` | `atlas/tests/test_graph_navigation.py:335` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::assert_source_matches_single` | `atlas/tests/test_graph_navigation.py:346` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_graph_navigation.py::test_batch_source_pagination_and_duplicate_keys` | `atlas/tests/test_graph_navigation.py:352` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_batch_source_keeps_verification_failures_per_excerpt` | `atlas/tests/test_graph_navigation.py:362` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_source_numbered_text_preserves_excerpt_and_snapshot_details` | `atlas/tests/test_graph_navigation.py:374` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::assert_text_excerpt` | `atlas/tests/test_graph_navigation.py:386` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_graph_navigation.py::test_batch_source_rejects_stale_revision_and_unknown_key` | `atlas/tests/test_graph_navigation.py:394` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_navigation.py::test_source_verified_paged_changed_missing` | `atlas/tests/test_graph_navigation.py:402` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_source_unsafe_paths_and_symlink` | `atlas/tests/test_graph_navigation.py:419` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_source_fifo_never_blocks` | `atlas/tests/test_graph_navigation.py:429` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_navigation.py::test_source_symlink_loop_is_structured` | `atlas/tests/test_graph_navigation.py:438` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_source_file_size_is_bounded` | `atlas/tests/test_graph_navigation.py:445` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_navigation.py::test_source_long_line_output_is_bounded` | `atlas/tests/test_graph_navigation.py:455` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_output.py` | `atlas/tests/test_graph_output.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_output.py::test_unresolved_projection_preserves_keys_and_evidence` | `atlas/tests/test_graph_output.py:6` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py` | `atlas/tests/test_graph_persistence.py` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::database` | `atlas/tests/test_graph_persistence.py:25` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::header` | `atlas/tests/test_graph_persistence.py:31` | 5 | 0 | 5 | 0.00 |
| `atlas/tests/test_graph_persistence.py::fail_edges` | `atlas/tests/test_graph_persistence.py:36` | 2 | 0 | 2 | 0.00 |
| `atlas/tests/test_graph_persistence.py::assert_saved` | `atlas/tests/test_graph_persistence.py:41` | 5 | 4 | 5 | 0.44 |
| `atlas/tests/test_graph_persistence.py::test_full_normalized_facts` | `atlas/tests/test_graph_persistence.py:51` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::test_explicit_null_measurement_is_present_not_zero` | `atlas/tests/test_graph_persistence.py:105` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::test_scoped_cascade_and_same_keys` | `atlas/tests/test_graph_persistence.py:120` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::test_composite_references_cannot_cross_repositories` | `atlas/tests/test_graph_persistence.py:137` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::replacement` | `atlas/tests/test_graph_persistence.py:159` | 4 | 1 | 4 | 0.20 |
| `atlas/tests/test_graph_persistence.py::test_replacement_removes_stale_facts_and_always_changes_revision` | `atlas/tests/test_graph_persistence.py:168` | 0 | 8 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::test_late_replacement_failure_restores_entire_snapshot_and_session` | `atlas/tests/test_graph_persistence.py:185` | 0 | 9 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::test_save_new_failure_leaves_no_pending_or_ghost_registration` | `atlas/tests/test_graph_persistence.py:203` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::test_invalid_graph_rolls_back_existing_snapshot` | `atlas/tests/test_graph_persistence.py:223` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::connection_rows` | `atlas/tests/test_graph_persistence.py:241` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_graph_persistence.py::test_wal_reader_keeps_header_and_rows_in_one_snapshot` | `atlas/tests/test_graph_persistence.py:245` | 0 | 9 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::test_coffee_graphs_write_all_nodes_and_edge_occurrences` | `atlas/tests/test_graph_persistence.py:268` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_graph_persistence.py::test_type_only_records_literal_true` | `atlas/tests/test_graph_persistence.py:281` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_graph_project_discovery.py` | `atlas/tests/test_graph_project_discovery.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_graph_project_discovery.py::indexed_folder` | `atlas/tests/test_graph_project_discovery.py:17` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_graph_project_discovery.py::test_commands_infer_project` | `atlas/tests/test_graph_project_discovery.py:32` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_project_discovery.py::test_nearest_indexed_folder_wins` | `atlas/tests/test_graph_project_discovery.py:41` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_graph_project_discovery.py::test_outside_folder_needs_explicit_project` | `atlas/tests/test_graph_project_discovery.py:53` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_project_discovery.py::test_duplicate_locations_need_explicit_project` | `atlas/tests/test_graph_project_discovery.py:66` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_graph_project_discovery.py::test_location_symlink_is_canonicalized` | `atlas/tests/test_graph_project_discovery.py:78` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_project_discovery.py::test_inference_does_not_create_missing_database` | `atlas/tests/test_graph_project_discovery.py:95` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_schema.py` | `atlas/tests/test_graph_schema.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_schema.py::database` | `atlas/tests/test_graph_schema.py:103` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_schema.py::test_exact_table_inventory_and_deferred_parentage` | `atlas/tests/test_graph_schema.py:109` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_schema.py::test_exact_normalized_columns_and_foreign_keys` | `atlas/tests/test_graph_schema.py:119` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_schema.py::index_columns` | `atlas/tests/test_graph_schema.py:129` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_graph_schema.py::test_exact_scoped_indexes` | `atlas/tests/test_graph_schema.py:134` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_schema.py::test_name_index_collation_and_registration_uniqueness` | `atlas/tests/test_graph_schema.py:141` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_graph_transactions.py` | `atlas/tests/test_graph_transactions.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_graph_transactions.py::database` | `atlas/tests/test_graph_transactions.py:19` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_graph_transactions.py::header` | `atlas/tests/test_graph_transactions.py:25` | 4 | 0 | 4 | 0.00 |
| `atlas/tests/test_graph_transactions.py::replacement` | `atlas/tests/test_graph_transactions.py:34` | 3 | 1 | 3 | 0.25 |
| `atlas/tests/test_graph_transactions.py::assert_integrity` | `atlas/tests/test_graph_transactions.py:44` | 2 | 0 | 2 | 0.00 |
| `atlas/tests/test_graph_transactions.py::assert_replaced` | `atlas/tests/test_graph_transactions.py:51` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/test_graph_transactions.py::assert_new_graph` | `atlas/tests/test_graph_transactions.py:61` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_graph_transactions.py::test_public_write_ends_stale_orchestration_read` | `atlas/tests/test_graph_transactions.py:74` | 0 | 14 | 0 | 1.00 |
| `atlas/tests/test_graph_transactions.py::test_write_failure_is_atomic_and_same_session_reusable` | `atlas/tests/test_graph_transactions.py:109` | 0 | 11 | 0 | 1.00 |
| `atlas/tests/test_import_binding_guard.py` | `atlas/tests/test_import_binding_guard.py` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_binding_guard.py::test_selective_imports_never_bind_module_namespace` | `atlas/tests/test_import_binding_guard.py:21` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_binding_guard.py::test_member_calls_do_not_borrow_local_or_project_declarations` | `atlas/tests/test_import_binding_guard.py:70` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_import_binding_guard.py::test_member_collision_keeps_real_inventory_binding` | `atlas/tests/test_import_binding_guard.py:104` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_import_binding_guard.py::test_project_repository_uses_each_files_grammar_and_skips_manifests` | `atlas/tests/test_import_binding_guard.py:109` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_import_cycle_semantics.py` | `atlas/tests/test_import_cycle_semantics.py` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_cycle_semantics.py::test_typescript_stock_back_references` | `atlas/tests/test_import_cycle_semantics.py:27` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_import_cycle_semantics.py::cycle_keys_touching` | `atlas/tests/test_import_cycle_semantics.py:45` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_import_cycle_semantics.py::package_project` | `atlas/tests/test_import_cycle_semantics.py:51` | 5 | 1 | 5 | 0.17 |
| `atlas/tests/test_import_cycle_semantics.py::imports_at` | `atlas/tests/test_import_cycle_semantics.py:57` | 4 | 0 | 4 | 0.00 |
| `atlas/tests/test_import_cycle_semantics.py::groups_at` | `atlas/tests/test_import_cycle_semantics.py:61` | 2 | 0 | 2 | 0.00 |
| `atlas/tests/test_import_cycle_semantics.py::test_python_package_child_imports` | `atlas/tests/test_import_cycle_semantics.py:66` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_cycle_semantics.py::test_python_actual_self_imports` | `atlas/tests/test_import_cycle_semantics.py:82` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_cycle_semantics.py::test_python_runtime_child_cycle` | `atlas/tests/test_import_cycle_semantics.py:87` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_cycle_semantics.py::test_python_unresolved_child_stays_external` | `atlas/tests/test_import_cycle_semantics.py:94` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_cycle_semantics.py::test_python_package_attribute_does_not_become_self_import` | `atlas/tests/test_import_cycle_semantics.py:103` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_import_cycle_semantics.py::test_type_only_external_import_remains_visible` | `atlas/tests/test_import_cycle_semantics.py:114` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_performance.py` | `atlas/tests/test_import_performance.py` | 0 | 9 | 0 | 1.00 |
| `atlas/tests/test_import_performance.py::test_analyzes_this_repository_within_fast_cold_process_budget` | `atlas/tests/test_import_performance.py:26` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_import_performance.py::menu_source` | `atlas/tests/test_import_performance.py:48` | 2 | 1 | 2 | 0.33 |
| `atlas/tests/test_import_performance.py::test_data_grammars_do_not_parse_or_walk_for_impossible_calls` | `atlas/tests/test_import_performance.py:54` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_import_performance.py::test_default_adapter_still_extracts_calls_when_grammar_supports_them` | `atlas/tests/test_import_performance.py:60` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_import_performance.py::test_file_extraction_reuses_one_syntax_tree_per_coffee_file` | `atlas/tests/test_import_performance.py:68` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_import_performance.py::file_callables` | `atlas/tests/test_import_performance.py:85` | 2 | 0 | 3 | 0.00 |
| `atlas/tests/test_import_performance.py::assert_unmeasured_coffee_calls` | `atlas/tests/test_import_performance.py:89` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_import_performance.py::assert_metric_parsing_once` | `atlas/tests/test_import_performance.py:98` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_import_performance.py::test_data_files_do_not_create_an_extra_syntax_tree` | `atlas/tests/test_import_performance.py:112` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_performance.py::test_syntax_tree_reuse_is_local_to_each_file` | `atlas/tests/test_import_performance.py:124` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_import_performance.py::test_import_node_lookup_indexes_each_coffee_tree_once` | `atlas/tests/test_import_performance.py:134` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_import_performance.py::test_syntax_tree_and_binding_scan_are_lazy_and_cached` | `atlas/tests/test_import_performance.py:154` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_import_performance.py::test_path_resolution_is_cached_only_within_one_repository` | `atlas/tests/test_import_performance.py:170` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_import_resolution.py` | `atlas/tests/test_import_resolution.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_import_resolution.py::coffee_repository` | `atlas/tests/test_import_resolution.py:12` | 4 | 1 | 4 | 0.20 |
| `atlas/tests/test_import_resolution.py::coffee_target_keys` | `atlas/tests/test_import_resolution.py:16` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_import_resolution.py::assert_coffee_call` | `atlas/tests/test_import_resolution.py:21` | 3 | 2 | 3 | 0.40 |
| `atlas/tests/test_import_resolution.py::coffee_import_edges` | `atlas/tests/test_import_resolution.py:56` | 1 | 1 | 3 | 0.50 |
| `atlas/tests/test_import_resolution.py::assert_import_targets` | `atlas/tests/test_import_resolution.py:64` | 2 | 1 | 2 | 0.33 |
| `atlas/tests/test_import_resolution.py::test_coffee_imports_reach_exact_declarations` | `atlas/tests/test_import_resolution.py:74` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_resolution.py::test_coffee_python_namespace_and_aliased_calls` | `atlas/tests/test_import_resolution.py:86` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_import_resolution.py::test_coffee_python_combined_module_aliases` | `atlas/tests/test_import_resolution.py:90` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_resolution.py::test_coffee_go_module_namespace_limit_is_explicit` | `atlas/tests/test_import_resolution.py:100` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_resolution.py::test_namespace_import_forms` | `atlas/tests/test_import_resolution.py:115` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_import_resolution.py::test_unsafe_namespace_bindings_stay_unresolved` | `atlas/tests/test_import_resolution.py:133` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_import_resolution.py::test_namespace_shadowing_does_not_poison_other_workflows` | `atlas/tests/test_import_resolution.py:139` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_import_resolution.py::test_go_package_identity_and_explicit_alias` | `atlas/tests/test_import_resolution.py:146` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_import_source_order.py` | `atlas/tests/test_import_source_order.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_import_source_order.py::facts` | `atlas/tests/test_import_source_order.py:16` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_import_source_order.py::test_whole_project_resolution_is_independent_of_source_order` | `atlas/tests/test_import_source_order.py:28` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_import_source_order.py::test_ambiguous_roast_call_remains_external_in_every_source_order` | `atlas/tests/test_import_source_order.py:44` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_indexer.py` | `atlas/tests/test_indexer.py` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_indexer.py::copy_application` | `atlas/tests/test_indexer.py:28` | 4 | 0 | 4 | 0.00 |
| `atlas/tests/test_indexer.py::go_brewer_symbols` | `atlas/tests/test_indexer.py:33` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_indexer.py::rust_brewer_symbols` | `atlas/tests/test_indexer.py:42` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_indexer.py::elixir_brewer_symbols` | `atlas/tests/test_indexer.py:51` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_indexer.py::class_brewer_symbols` | `atlas/tests/test_indexer.py:71` | 1 | 0 | 3 | 0.00 |
| `atlas/tests/test_indexer.py::brewer_symbols` | `atlas/tests/test_indexer.py:92` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/test_indexer.py::reporting_calls` | `atlas/tests/test_indexer.py:116` | 3 | 0 | 7 | 0.00 |
| `atlas/tests/test_indexer.py::tree_contents` | `atlas/tests/test_indexer.py:130` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_indexer.py::qualified_edges` | `atlas/tests/test_indexer.py:135` | 4 | 0 | 6 | 0.00 |
| `atlas/tests/test_indexer.py::IndexerTest` | `atlas/tests/test_indexer.py:142` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_indexer.py::IndexerTest.setUpClass` | `atlas/tests/test_indexer.py:144` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_indexer.py::IndexerTest.test_indexes_polyglot_symbols_and_connections` | `atlas/tests/test_indexer.py:152` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_indexer.py::IndexerTest.test_rust_dispatch_wiring_preserves_namespace_and_encoder_ownership` | `atlas/tests/test_indexer.py:157` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_indexer.py::IndexerTest.assert_application_symbols` | `atlas/tests/test_indexer.py:173` | 1 | 4 | 1 | 0.80 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_brewer_imports` | `atlas/tests/test_indexer.py:190` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_calls` | `atlas/tests/test_indexer.py:196` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_graph_structure` | `atlas/tests/test_indexer.py:207` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_indexer.py::IndexerTest.test_builds_polyglot_module_file_type_and_callable_views` | `atlas/tests/test_indexer.py:223` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_view_inventory` | `atlas/tests/test_indexer.py:230` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_level_inventory` | `atlas/tests/test_indexer.py:234` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_views` | `atlas/tests/test_indexer.py:241` | 1 | 4 | 1 | 0.80 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_file_view` | `atlas/tests/test_indexer.py:247` | 1 | 2 | 2 | 0.67 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_callable_view` | `atlas/tests/test_indexer.py:257` | 1 | 2 | 2 | 0.67 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_type_view` | `atlas/tests/test_indexer.py:272` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_reporting_module_view` | `atlas/tests/test_indexer.py:283` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/test_indexer.py::IndexerTest.test_kotlin_class_methods_and_nested_declarations` | `atlas/tests/test_indexer.py:293` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_kotlin_nested_declarations` | `atlas/tests/test_indexer.py:310` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_indexer.py::IndexerTest.test_java_tags_add_constructors_without_losing_imports` | `atlas/tests/test_indexer.py:321` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_java_constructors` | `atlas/tests/test_indexer.py:332` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_java_service_imports` | `atlas/tests/test_indexer.py:346` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_indexer.py::IndexerTest.assert_service_dependencies` | `atlas/tests/test_indexer.py:357` | 2 | 0 | 2 | 0.00 |
| `atlas/tests/test_indexer.py::IndexerTest.test_reanalysis_reflects_source_changes_without_writing_a_file` | `atlas/tests/test_indexer.py:372` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_indexer.py::IndexerTest.test_discovers_git_files_with_special_characters` | `atlas/tests/test_indexer.py:391` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_indexer.py::IndexerTest.test_discovers_large_and_non_programming_language_files` | `atlas/tests/test_indexer.py:407` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_invalid_utf8.py` | `atlas/tests/test_invalid_utf8.py` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_invalid_utf8.py::test_original_file_digest_and_replacement_decoded_declarations` | `atlas/tests/test_invalid_utf8.py:70` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_jvm_callable_selection_snapshots.py` | `atlas/tests/test_jvm_callable_selection_snapshots.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_jvm_callable_selection_snapshots.py::selection_snapshot` | `atlas/tests/test_jvm_callable_selection_snapshots.py:15` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_jvm_callable_selection_snapshots.py::test_jvm_callable_selection_snapshot` | `atlas/tests/test_jvm_callable_selection_snapshots.py:33` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_metric_adapters.py` | `atlas/tests/test_metric_adapters.py` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_metric_adapters.py::assert_source_policy` | `atlas/tests/test_metric_adapters.py:17` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_metric_adapters.py::test_primary_policies_preserve_node_only_api` | `atlas/tests/test_metric_adapters.py:28` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_metric_adapters.py::test_policy_controls_decisions_without_changing_traversal` | `atlas/tests/test_metric_adapters.py:32` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_metric_phases.py` | `atlas/tests/test_metric_phases.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_metric_phases.py::assert_decoded_span` | `atlas/tests/test_metric_phases.py:16` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_metric_phases.py::enrich_once` | `atlas/tests/test_metric_phases.py:29` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_metric_phases.py::test_callable_metrics_are_explicit_and_use_decoded_byte_spans` | `atlas/tests/test_metric_phases.py:43` | 0 | 8 | 0 | 1.00 |
| `atlas/tests/test_metric_phases.py::test_metric_enrichment_does_not_parse_files_without_callables` | `atlas/tests/test_metric_phases.py:65` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_metric_snapshots.py` | `atlas/tests/test_metric_snapshots.py` | 0 | 13 | 0 | 1.00 |
| `atlas/tests/test_metric_snapshots.py::metric_subject` | `atlas/tests/test_metric_snapshots.py:34` | 4 | 0 | 6 | 0.00 |
| `atlas/tests/test_metric_snapshots.py::assert_thresholds` | `atlas/tests/test_metric_snapshots.py:39` | 4 | 3 | 6 | 0.43 |
| `atlas/tests/test_metric_snapshots.py::assert_metric_threshold` | `atlas/tests/test_metric_snapshots.py:57` | 1 | 2 | 7 | 0.67 |
| `atlas/tests/test_metric_snapshots.py::expected_finding` | `atlas/tests/test_metric_snapshots.py:65` | 2 | 0 | 8 | 0.00 |
| `atlas/tests/test_metric_snapshots.py::test_callable_records` | `atlas/tests/test_metric_snapshots.py:75` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_metric_snapshots.py::assert_file_callables` | `atlas/tests/test_metric_snapshots.py:96` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_metric_snapshots.py::assert_callable_record` | `atlas/tests/test_metric_snapshots.py:101` | 1 | 2 | 2 | 0.67 |
| `atlas/tests/test_metric_snapshots.py::assert_file_record` | `atlas/tests/test_metric_snapshots.py:116` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/test_metric_snapshots.py::test_grammar_complexity` | `atlas/tests/test_metric_snapshots.py:150` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_metric_snapshots.py::test_explicit_empty_policy_keeps_whole_source_scopes_excluded` | `atlas/tests/test_metric_snapshots.py:163` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_metric_snapshots.py::test_native_overload_records_keep_signatures_spans_and_order` | `atlas/tests/test_metric_snapshots.py:171` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_metric_snapshots.py::test_native_elixir_clauses_remain_separate_records` | `atlas/tests/test_metric_snapshots.py:194` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_metric_snapshots.py::test_implicit_kotlin_lambda_parameter_is_unavailable_not_zero` | `atlas/tests/test_metric_snapshots.py:216` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_models.py` | `atlas/tests/test_models.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_models.py::ModelsTest` | `atlas/tests/test_models.py:16` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_models.py::ModelsTest.artifact` | `atlas/tests/test_models.py:17` | 3 | 1 | 3 | 0.25 |
| `atlas/tests/test_models.py::ModelsTest.test_language_graphs_round_trip_without_field_changes` | `atlas/tests/test_models.py:20` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_models.py::ModelsTest.test_positional_constructors_and_default_lists` | `atlas/tests/test_models.py:28` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_models.py::ModelsTest.test_strict_constructor_and_assignment_validation` | `atlas/tests/test_models.py:37` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_models.py::ModelsTest.test_invalid_artifact_fields_are_rejected` | `atlas/tests/test_models.py:50` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_models.py::ModelsTest.test_reference_validation_runs_at_construction` | `atlas/tests/test_models.py:69` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_models.py::ModelsTest.test_mutation_is_revalidated_in_memory` | `atlas/tests/test_models.py:89` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_normalized_runtime.py` | `atlas/tests/test_normalized_runtime.py` | 0 | 6 | 0 | 1.00 |
| `atlas/tests/test_normalized_runtime.py::test_repository_multi_query_response_uses_one_revision` | `atlas/tests/test_normalized_runtime.py:17` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_normalized_runtime.py::test_repository_multi_query_response_uses_one_revision.replace_after_header` | `atlas/tests/test_normalized_runtime.py:31` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_normalized_runtime.py::test_report_facts_isolate_repositories_with_identical_node_keys` | `atlas/tests/test_normalized_runtime.py:59` | 0 | 6 | 0 | 1.00 |
| `atlas/tests/test_normalized_runtime.py::test_index_summary_counts_match_source_analysis` | `atlas/tests/test_normalized_runtime.py:83` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_parsing_snapshots.py` | `atlas/tests/test_parsing_snapshots.py` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_parsing_snapshots.py::items_tree` | `atlas/tests/test_parsing_snapshots.py:36` | 4 | 0 | 6 | 0.00 |
| `atlas/tests/test_parsing_snapshots.py::assert_symbol_record` | `atlas/tests/test_parsing_snapshots.py:42` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/test_parsing_snapshots.py::assert_call_record` | `atlas/tests/test_parsing_snapshots.py:56` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_parsing_snapshots.py::assert_import_record` | `atlas/tests/test_parsing_snapshots.py:62` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_parsing_snapshots.py::assert_file_record` | `atlas/tests/test_parsing_snapshots.py:69` | 1 | 4 | 1 | 0.80 |
| `atlas/tests/test_parsing_snapshots.py::assert_repository_records` | `atlas/tests/test_parsing_snapshots.py:82` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_parsing_snapshots.py::test_parser_records` | `atlas/tests/test_parsing_snapshots.py:91` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_parsing_snapshots.py::assert_hierarchy` | `atlas/tests/test_parsing_snapshots.py:102` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_parsing_snapshots.py::structure_spans` | `atlas/tests/test_parsing_snapshots.py:115` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/test_parsing_snapshots.py::assert_native_structure` | `atlas/tests/test_parsing_snapshots.py:120` | 1 | 5 | 1 | 0.83 |
| `atlas/tests/test_parsing_snapshots.py::test_structure_native_variants` | `atlas/tests/test_parsing_snapshots.py:136` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_parsing_snapshots.py::node_span` | `atlas/tests/test_parsing_snapshots.py:141` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_parsing_snapshots.py::scheduling_syntax` | `atlas/tests/test_parsing_snapshots.py:147` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_parsing_snapshots.py::test_native_wrappers_canonicalize_both_endpoints_without_mutation` | `atlas/tests/test_parsing_snapshots.py:160` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_parsing_snapshots.py::assert_native_wrapper` | `atlas/tests/test_parsing_snapshots.py:176` | 1 | 4 | 1 | 0.80 |
| `atlas/tests/test_parsing_snapshots.py::test_malformed_and_invalid_utf8_records_preserve_original_bytes` | `atlas/tests/test_parsing_snapshots.py:200` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_parsing_snapshots.py::test_missing_tags_preserve_native_list_and_metadata` | `atlas/tests/test_parsing_snapshots.py:223` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_persistence.py` | `atlas/tests/test_persistence.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_persistence.py::database` | `atlas/tests/test_persistence.py:22` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_persistence.py::test_current_schema_and_constraints` | `atlas/tests/test_persistence.py:28` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_persistence.py::test_service_requires_explicit_migration` | `atlas/tests/test_persistence.py:66` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_persistence.py::test_service_reindex_resolves_name_and_rolls_back_failed_write` | `atlas/tests/test_persistence.py:76` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_persistence.py::test_non_ascii_name_resolution_matches_sqlite_lower` | `atlas/tests/test_persistence.py:108` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_persistence.py::test_service_validation_and_shared_graph` | `atlas/tests/test_persistence.py:117` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_persistence.py::test_default_path_is_independent_of_working_directory` | `atlas/tests/test_persistence.py:142` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_persistence_entity_boundaries.py` | `atlas/tests/test_persistence_entity_boundaries.py` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_persistence_entity_boundaries.py::entity_violations` | `atlas/tests/test_persistence_entity_boundaries.py:72` | 5 | 2 | 8 | 0.29 |
| `atlas/tests/test_persistence_entity_boundaries.py::entity_target_forbidden` | `atlas/tests/test_persistence_entity_boundaries.py:94` | 1 | 0 | 9 | 0.00 |
| `atlas/tests/test_persistence_entity_boundaries.py::entity_behavior_violations` | `atlas/tests/test_persistence_entity_boundaries.py:104` | 1 | 0 | 9 | 0.00 |
| `atlas/tests/test_persistence_entity_boundaries.py::graph_record_violations` | `atlas/tests/test_persistence_entity_boundaries.py:123` | 4 | 1 | 4 | 0.20 |
| `atlas/tests/test_persistence_entity_boundaries.py::test_production_entities_declare_schema_without_io` | `atlas/tests/test_persistence_entity_boundaries.py:132` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_persistence_entity_boundaries.py::test_optional_production_graph_records_are_pure` | `atlas/tests/test_persistence_entity_boundaries.py:143` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py` | `atlas/tests/test_policy_snapshots.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::source` | `atlas/tests/test_policy_snapshots.py:25` | 8 | 0 | 31 | 0.00 |
| `atlas/tests/test_policy_snapshots.py::selected_source` | `atlas/tests/test_policy_snapshots.py:29` | 24 | 3 | 24 | 0.11 |
| `atlas/tests/test_policy_snapshots.py::keep_definition` | `atlas/tests/test_policy_snapshots.py:40` | 2 | 0 | 26 | 0.00 |
| `atlas/tests/test_policy_snapshots.py::project_definition` | `atlas/tests/test_policy_snapshots.py:44` | 1 | 1 | 25 | 0.50 |
| `atlas/tests/test_policy_snapshots.py::boundary` | `atlas/tests/test_policy_snapshots.py:51` | 22 | 1 | 22 | 0.04 |
| `atlas/tests/test_policy_snapshots.py::test_service_returns_domain_results_not_private_ports` | `atlas/tests/test_policy_snapshots.py:56` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_service_ports_cannot_escape_through_values_or_aliases` | `atlas/tests/test_policy_snapshots.py:67` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_service_ports_are_private_and_have_no_database_handles` | `atlas/tests/test_policy_snapshots.py:73` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_service_constructor_requires_the_domain_protocol` | `atlas/tests/test_policy_snapshots.py:79` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_nonservice_modules_cannot_accept_private_ports` | `atlas/tests/test_policy_snapshots.py:89` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_factory_wraps_context_ports_in_services` | `atlas/tests/test_policy_snapshots.py:95` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_factory_context_ports_cannot_escape` | `atlas/tests/test_policy_snapshots.py:101` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_factory_cannot_access_repository_session` | `atlas/tests/test_policy_snapshots.py:106` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_factory_operation_imports_are_exact_and_private` | `atlas/tests/test_policy_snapshots.py:114` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_infrastructure_allows_only_literal_connection_setup` | `atlas/tests/test_policy_snapshots.py:121` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_infrastructure_cannot_query_domain_data_or_loosen_setup` | `atlas/tests/test_policy_snapshots.py:131` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_in_memory_graph_repository_is_not_a_storage_port` | `atlas/tests/test_policy_snapshots.py:136` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_exact_repository_owner_allows_mapped_queries` | `atlas/tests/test_policy_snapshots.py:141` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_even_exact_orm_owners_cannot_use_raw_sql` | `atlas/tests/test_policy_snapshots.py:151` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_frozen_revision_allows_schema_and_exact_existing_collation` | `atlas/tests/test_policy_snapshots.py:157` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_revision_ownership_never_allows_data_queries` | `atlas/tests/test_policy_snapshots.py:163` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_collation_exception_is_confined_to_one_exact_revision_and_expression` | `atlas/tests/test_policy_snapshots.py:168` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_dynamic_and_reflective_access_cannot_hide_in_aliases` | `atlas/tests/test_policy_snapshots.py:186` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_public_domain_introspection_is_not_private_port_extraction` | `atlas/tests/test_policy_snapshots.py:198` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_exact_public_check_config_lookup_has_one_owner` | `atlas/tests/test_policy_snapshots.py:205` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_public_config_exception_is_exact_not_general_reflection` | `atlas/tests/test_policy_snapshots.py:217` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_entities_allow_declarative_schema_without_io` | `atlas/tests/test_policy_snapshots.py:223` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_entities_cannot_gain_database_or_filesystem_behavior` | `atlas/tests/test_policy_snapshots.py:229` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_import_scan_tracks_relative_local_type_and_chained_aliases` | `atlas/tests/test_policy_snapshots.py:234` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_architecture_dependencies_include_local_and_package_imports_not_types` | `atlas/tests/test_policy_snapshots.py:247` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_bootstrap_only_reexports_public_service_factories` | `atlas/tests/test_policy_snapshots.py:257` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_bootstrap_cannot_gain_composition_or_other_behavior` | `atlas/tests/test_policy_snapshots.py:263` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_entity_and_record_import_ownership_is_exact` | `atlas/tests/test_policy_snapshots.py:272` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_graph_records_only_transform_in_memory_values` | `atlas/tests/test_policy_snapshots.py:281` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_policy_snapshots.py::test_graph_records_cannot_gain_io` | `atlas/tests/test_policy_snapshots.py:287` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py` | `atlas/tests/test_primary_import_parsing.py` | 0 | 9 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py::application` | `atlas/tests/test_primary_import_parsing.py:21` | 7 | 2 | 7 | 0.22 |
| `atlas/tests/test_primary_import_parsing.py::test_primary_import_paths_do_not_use_polyglot_fallback` | `atlas/tests/test_primary_import_parsing.py:26` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py::test_application_import_paths_are_exact` | `atlas/tests/test_primary_import_parsing.py:58` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py::test_go_namespace_rules_do_not_use_polyglot_fallback` | `atlas/tests/test_primary_import_parsing.py:71` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py::assert_legacy_import_fallbacks` | `atlas/tests/test_primary_import_parsing.py:84` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/test_primary_import_parsing.py::test_legacy_import_path_fallback_and_reexport` | `atlas/tests/test_primary_import_parsing.py:93` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py::test_legacy_namespace_fallback_and_reexport` | `atlas/tests/test_primary_import_parsing.py:105` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py::test_jsx_alias_import_policy_uses_owned_hook` | `atlas/tests/test_primary_import_parsing.py:113` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py::test_legacy_include_paths` | `atlas/tests/test_primary_import_parsing.py:124` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py::test_legacy_unknown_import_path_is_preserved` | `atlas/tests/test_primary_import_parsing.py:132` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py::directive` | `atlas/tests/test_primary_import_parsing.py:137` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py::test_default_import_methods_dispatch_to_adapter_path_hook` | `atlas/tests/test_primary_import_parsing.py:144` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_primary_import_parsing.py::test_directive_bindings_dispatch_to_adapter_path_hook` | `atlas/tests/test_primary_import_parsing.py:156` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_primary_import_parsing.py::test_missing_required_import_node_dispatches_to_adapter_path_hook` | `atlas/tests/test_primary_import_parsing.py:170` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_project_names_cli.py` | `atlas/tests/test_project_names_cli.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_project_names_cli.py::test_root_project_selector_is_rejected` | `atlas/tests/test_project_names_cli.py:12` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_project_names_cli.py::test_command_project_selectors_are_rejected` | `atlas/tests/test_project_names_cli.py:29` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_project_names_cli.py::test_positional_folder_is_rejected` | `atlas/tests/test_project_names_cli.py:39` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_project_names_cli.py::test_help_has_no_project_selector` | `atlas/tests/test_project_names_cli.py:48` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_projects_cli.py` | `atlas/tests/test_projects_cli.py` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_projects_cli.py::database` | `atlas/tests/test_projects_cli.py:16` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_projects_cli.py::test_projects_lists_indexed_and_unindexed_projects` | `atlas/tests/test_projects_cli.py:23` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_projects_cli.py::test_projects_empty_database_is_empty_json_array` | `atlas/tests/test_projects_cli.py:45` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_projects_cli.py::test_projects_unmigrated_database_has_cli_error` | `atlas/tests/test_projects_cli.py:51` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_python_project_imports.py` | `atlas/tests/test_python_project_imports.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_python_project_imports.py::package_sources` | `atlas/tests/test_python_project_imports.py:16` | 8 | 1 | 8 | 0.11 |
| `atlas/tests/test_python_project_imports.py::child_probe` | `atlas/tests/test_python_project_imports.py:23` | 6 | 0 | 6 | 0.00 |
| `atlas/tests/test_python_project_imports.py::test_package_imports_resolve_independently_of_analysis_root` | `atlas/tests/test_python_project_imports.py:32` | 0 | 6 | 0 | 1.00 |
| `atlas/tests/test_python_project_imports.py::assert_relationship_targets` | `atlas/tests/test_python_project_imports.py:52` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_python_project_imports.py::test_child_module_imports_link_and_bind_namespace` | `atlas/tests/test_python_project_imports.py:58` | 0 | 6 | 0 | 1.00 |
| `atlas/tests/test_python_project_imports.py::test_comma_separated_module_imports` | `atlas/tests/test_python_project_imports.py:70` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_python_project_imports.py::test_duplicate_source_roots_and_ambiguous_parent_cannot_choose_child` | `atlas/tests/test_python_project_imports.py:84` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_python_project_imports.py::test_duplicate_complete_source_roots_are_ambiguous` | `atlas/tests/test_python_project_imports.py:97` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_python_project_imports.py::test_unrelated_suffix_is_not_an_import_root` | `atlas/tests/test_python_project_imports.py:106` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_python_project_imports.py::test_runtime_modules_take_precedence_over_type_stubs` | `atlas/tests/test_python_project_imports.py:116` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_python_project_imports.py::test_package_attributes_prevent_child_module_guesses` | `atlas/tests/test_python_project_imports.py:131` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_python_project_imports.py::test_annotation_only_attribute_does_not_hide_child_module` | `atlas/tests/test_python_project_imports.py:142` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_python_project_imports.py::test_ordinary_module_cannot_have_child_modules` | `atlas/tests/test_python_project_imports.py:151` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_python_project_imports.py::test_absolute_src_import_cycle_is_reported` | `atlas/tests/test_python_project_imports.py:160` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_receiver_remaining_blockers.py` | `atlas/tests/test_receiver_remaining_blockers.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_alias_field_mutation` | `atlas/tests/test_receiver_remaining_blockers.py:24` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_script_member_write_forms` | `atlas/tests/test_receiver_remaining_blockers.py:32` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_annotated_initializer_identity` | `atlas/tests/test_receiver_remaining_blockers.py:40` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_import_alias_identity_and_static_parameter_types` | `atlas/tests/test_receiver_remaining_blockers.py:60` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_rust_self_impl_identity` | `atlas/tests/test_receiver_remaining_blockers.py:72` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_compound_receiver_assignment` | `atlas/tests/test_receiver_remaining_blockers.py:84` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_go_block_shadow_is_not_a_declared_receiver` | `atlas/tests/test_receiver_remaining_blockers.py:90` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_remaining_blockers.py::test_go_range_binding_does_not_leak` | `atlas/tests/test_receiver_remaining_blockers.py:94` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_resolution.py` | `atlas/tests/test_receiver_resolution.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_receiver_resolution.py::test_coffee_declared_receivers` | `atlas/tests/test_receiver_resolution.py:50` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_receiver_resolution.py::test_coffee_receiver_limits_are_explicit` | `atlas/tests/test_receiver_resolution.py:65` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_receiver_resolution.py::test_declared_receiver_forms_absent_from_coffee` | `atlas/tests/test_receiver_resolution.py:72` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_resolution.py::test_unknown_receiver_never_uses_member_name` | `atlas/tests/test_receiver_resolution.py:94` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_resolution.py::test_reassigned_inferred_receiver_stays_external` | `atlas/tests/test_receiver_resolution.py:105` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_resolution.py::test_elixir_has_module_calls_not_instance_members` | `atlas/tests/test_receiver_resolution.py:109` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py` | `atlas/tests/test_receiver_review_fixes.py` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_reassigned_declared_receiver_is_not_trusted` | `atlas/tests/test_receiver_review_fixes.py:22` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_python_caller_field_writes_invalidate_receiver` | `atlas/tests/test_receiver_review_fixes.py:34` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_script_caller_field_writes_invalidate_receiver` | `atlas/tests/test_receiver_review_fixes.py:40` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_python_member_mutation_follows_imported_class_identity` | `atlas/tests/test_receiver_review_fixes.py:45` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_script_member_mutation_follows_imported_class_identity` | `atlas/tests/test_receiver_review_fixes.py:50` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_unchanged_receivers_remain_internal` | `atlas/tests/test_receiver_review_fixes.py:60` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_rust_impl_in_another_module_resolves_identity` | `atlas/tests/test_receiver_review_fixes.py:70` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_rust_unrelated_duplicate_and_trait_impl_members_stay_external` | `atlas/tests/test_receiver_review_fixes.py:75` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_java_constructor_subtype_field_write_is_not_trusted` | `atlas/tests/test_receiver_review_fixes.py:79` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_rust_impl_target_is_the_actual_method` | `atlas/tests/test_receiver_review_fixes.py:83` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_callback_bindings_do_not_inherit_or_poison_outer_receiver` | `atlas/tests/test_receiver_review_fixes.py:98` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_review_fixes.py::test_typed_java_callback_receiver_has_its_own_identity` | `atlas/tests/test_receiver_review_fixes.py:105` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_safety.py` | `atlas/tests/test_receiver_safety.py` | 3 | 2 | 3 | 0.40 |
| `atlas/tests/test_receiver_safety.py::assert_target` | `atlas/tests/test_receiver_safety.py:16` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_receiver_safety.py::assert_lifetime_call` | `atlas/tests/test_receiver_safety.py:25` | 32 | 3 | 32 | 0.09 |
| `atlas/tests/test_receiver_safety.py::test_constructor_and_field_receivers` | `atlas/tests/test_receiver_safety.py:58` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_safety.py::test_unsafe_receivers_stay_external` | `atlas/tests/test_receiver_safety.py:87` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_safety.py::test_type_visibility_follows_import_and_namespace_context` | `atlas/tests/test_receiver_safety.py:104` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_safety.py::test_imported_receiver_member_rebinding_is_not_ignored` | `atlas/tests/test_receiver_safety.py:110` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_safety.py::test_imported_python_receiver_member_rebinding_is_not_ignored` | `atlas/tests/test_receiver_safety.py:114` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_safety.py::test_constructor_injected_order_created_client` | `atlas/tests/test_receiver_safety.py:118` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_safety.py::test_audit_receiver_selects_one_argument_overload` | `atlas/tests/test_receiver_safety.py:125` | 0 | 6 | 0 | 1.00 |
| `atlas/tests/test_receiver_safety.py::test_unrelated_constructor_assignments_are_separate_scopes` | `atlas/tests/test_receiver_safety.py:139` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_receiver_safety.py::test_unimported_type_is_not_guessed_globally` | `atlas/tests/test_receiver_safety.py:144` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_report.py` | `atlas/tests/test_report.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_report.py::Complexity` | `atlas/tests/test_report.py:13` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_report.py::callable_node` | `atlas/tests/test_report.py:19` | 4 | 0 | 4 | 0.00 |
| `atlas/tests/test_report.py::file_node` | `atlas/tests/test_report.py:34` | 4 | 0 | 4 | 0.00 |
| `atlas/tests/test_report.py::test_report_contains_below_and_above_thresholds_and_keeps_input` | `atlas/tests/test_report.py:41` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_report.py::test_cycles_have_quantitative_counts_and_readable_paths` | `atlas/tests/test_report.py:62` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_report.py::test_empty_graph_still_has_quantitative_summary` | `atlas/tests/test_report.py:82` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_report.py::test_unavailable_metrics_and_partial_file_totals_are_explicit` | `atlas/tests/test_report.py:91` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_report.py::test_measurements_sort_by_path_line_then_symbol` | `atlas/tests/test_report.py:102` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_report.py::test_markdown_preserves_literal_names_and_shows_analysis_diagnostics` | `atlas/tests/test_report.py:112` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_report.py::test_imports_only_normalized_facts_preserve_cycle_metrics` | `atlas/tests/test_report.py:122` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_report_cli.py` | `atlas/tests/test_report_cli.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_report_cli.py::database` | `atlas/tests/test_report_cli.py:18` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_report_cli.py::test_index_then_report_analyzes_fresh_folder` | `atlas/tests/test_report_cli.py:25` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_report_cli.py::test_service_report_requires_project_name` | `atlas/tests/test_report_cli.py:66` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_report_cli.py::test_report_empty_measurements_formats` | `atlas/tests/test_report_cli.py:72` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_report_cli.py::test_saving_does_not_migrate_database` | `atlas/tests/test_report_cli.py:85` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_resolution_adapter_dispatch.py` | `atlas/tests/test_resolution_adapter_dispatch.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_resolution_adapter_dispatch.py::ResolutionAdapterDispatchTest` | `atlas/tests/test_resolution_adapter_dispatch.py:10` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_resolution_adapter_dispatch.py::ResolutionAdapterDispatchTest.test_all_supported_languages_have_concrete_policies` | `atlas/tests/test_resolution_adapter_dispatch.py:11` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_resolution_adapter_dispatch.py::ResolutionAdapterDispatchTest.test_catalog_inventory_preserves_conservative_generic_fallback` | `atlas/tests/test_resolution_adapter_dispatch.py:30` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_adapter_dispatch.py::ResolutionAdapterDispatchTest.test_python_comprehension_and_javascript_hoisting_are_separate_policies` | `atlas/tests/test_resolution_adapter_dispatch.py:38` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_resolution_adapter_dispatch.py::ResolutionAdapterDispatchTest.test_tsx_namespace_reference_uses_qualified_import_and_shadowing` | `atlas/tests/test_resolution_adapter_dispatch.py:47` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_resolution_adapter_dispatch.py::component_keys` | `atlas/tests/test_resolution_adapter_dispatch.py:61` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_resolution_adapter_dispatch.py::app_references` | `atlas/tests/test_resolution_adapter_dispatch.py:68` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_resolution_complexity_cleanup.py` | `atlas/tests/test_resolution_complexity_cleanup.py` | 0 | 13 | 0 | 1.00 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_resolution_callable_budgets` | `atlas/tests/test_resolution_complexity_cleanup.py:36` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_complexity_cleanup.py::_assert_budget` | `atlas/tests/test_resolution_complexity_cleanup.py:46` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_policy_and_scope_reexports_keep_the_same_objects` | `atlas/tests/test_resolution_complexity_cleanup.py:55` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_registry_relative_imports_target_children_not_itself` | `atlas/tests/test_resolution_complexity_cleanup.py:60` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_syntax_type_dependency_targets_independent_policy_contract` | `atlas/tests/test_resolution_complexity_cleanup.py:71` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_resolution_complexity_cleanup.py::_assert_no_syntax_dependency` | `atlas/tests/test_resolution_complexity_cleanup.py:83` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_resolution_complexity_cleanup.py::lexical_repository` | `atlas/tests/test_resolution_complexity_cleanup.py:93` | 2 | 2 | 2 | 0.50 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_js_export_deduplication_preserves_alias_keys_and_order` | `atlas/tests/test_resolution_complexity_cleanup.py:97` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_parentheses_only_unwrap_single_expressions` | `atlas/tests/test_resolution_complexity_cleanup.py:111` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_resolution_complexity_cleanup.py::parenthesized_types` | `atlas/tests/test_resolution_complexity_cleanup.py:120` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/test_resolution_complexity_cleanup.py::assert_transparent_expression` | `atlas/tests/test_resolution_complexity_cleanup.py:127` | 1 | 1 | 2 | 0.50 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_import_directives_keep_exact_source_selection` | `atlas/tests/test_resolution_complexity_cleanup.py:138` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_resolution_complexity_cleanup.py::test_recursive_binding_names_still_ignore_types_and_member_targets` | `atlas/tests/test_resolution_complexity_cleanup.py:157` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_resolution_complexity_cleanup.py::syntax_node` | `atlas/tests/test_resolution_complexity_cleanup.py:167` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_resolution_complexity_cleanup.py::assert_member_targets_have_no_bindings` | `atlas/tests/test_resolution_complexity_cleanup.py:172` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_resolution_lexical_safety.py` | `atlas/tests/test_resolution_lexical_safety.py` | 3 | 5 | 3 | 0.62 |
| `atlas/tests/test_resolution_lexical_safety.py::lexical_sources` | `atlas/tests/test_resolution_lexical_safety.py:11` | 1 | 1 | 25 | 0.50 |
| `atlas/tests/test_resolution_lexical_safety.py::lexical_repository` | `atlas/tests/test_resolution_lexical_safety.py:18` | 24 | 2 | 24 | 0.08 |
| `atlas/tests/test_resolution_lexical_safety.py::order_symbol_keys` | `atlas/tests/test_resolution_lexical_safety.py:22` | 5 | 0 | 36 | 0.00 |
| `atlas/tests/test_resolution_lexical_safety.py::assert_order_spans` | `atlas/tests/test_resolution_lexical_safety.py:29` | 1 | 0 | 31 | 0.00 |
| `atlas/tests/test_resolution_lexical_safety.py::assert_order_target` | `atlas/tests/test_resolution_lexical_safety.py:37` | 1 | 1 | 31 | 0.50 |
| `atlas/tests/test_resolution_lexical_safety.py::assert_order_call` | `atlas/tests/test_resolution_lexical_safety.py:44` | 21 | 4 | 30 | 0.16 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_blocks_bind_in_enclosing_function` | `atlas/tests/test_resolution_lexical_safety.py:59` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_module_and_class_blocks_are_not_scopes` | `atlas/tests/test_resolution_lexical_safety.py:67` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_conditional_import_order_and_scope` | `atlas/tests/test_resolution_lexical_safety.py:83` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_class_import_cannot_be_captured_by_method` | `atlas/tests/test_resolution_lexical_safety.py:95` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_callback_and_comprehension_bindings` | `atlas/tests/test_resolution_lexical_safety.py:102` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_lexical_safety.py::test_python_parameter_shadows_callable_without_hiding_module_call` | `atlas/tests/test_resolution_lexical_safety.py:117` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_lexical_safety.py::test_javascript_and_typescript_callback_bindings` | `atlas/tests/test_resolution_lexical_safety.py:124` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_lexical_safety.py::test_java_blocks_loops_catches_and_lambda_parameters` | `atlas/tests/test_resolution_lexical_safety.py:139` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_lexical_safety.py::test_go_range_and_callback_bindings` | `atlas/tests/test_resolution_lexical_safety.py:151` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_lexical_safety.py::test_kotlin_lambda_and_range_bindings` | `atlas/tests/test_resolution_lexical_safety.py:163` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_lexical_safety.py::test_resolution_does_not_mutate_parsed_projects` | `atlas/tests/test_resolution_lexical_safety.py:173` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py` | `atlas/tests/test_resolution_modules.py` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py::receipt_sources` | `atlas/tests/test_resolution_modules.py:14` | 8 | 1 | 12 | 0.11 |
| `atlas/tests/test_resolution_modules.py::receipt_repository` | `atlas/tests/test_resolution_modules.py:20` | 11 | 2 | 11 | 0.15 |
| `atlas/tests/test_resolution_modules.py::modules` | `atlas/tests/test_resolution_modules.py:24` | 7 | 1 | 7 | 0.12 |
| `atlas/tests/test_resolution_modules.py::assert_receipt` | `atlas/tests/test_resolution_modules.py:28` | 10 | 1 | 10 | 0.09 |
| `atlas/tests/test_resolution_modules.py::rust_paths` | `atlas/tests/test_resolution_modules.py:34` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_resolution_modules.py::assert_printer_imports` | `atlas/tests/test_resolution_modules.py:38` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_resolution_modules.py::assert_module_visibility` | `atlas/tests/test_resolution_modules.py:45` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_resolution_modules.py::test_external_module_owner_is_not_a_second_crate_root` | `atlas/tests/test_resolution_modules.py:55` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py::test_inline_ancestry_selects_nested_file_not_root_decoy` | `atlas/tests/test_resolution_modules.py:63` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py::test_deep_inline_modules_mod_rs_and_file_stem_layout` | `atlas/tests/test_resolution_modules.py:71` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py::test_external_path_attribute_is_relative_to_containing_file` | `atlas/tests/test_resolution_modules.py:91` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py::test_inline_path_attributes_use_inline_directory` | `atlas/tests/test_resolution_modules.py:100` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py::test_nonstandard_coffee_root_excludes_referenced_module_owners` | `atlas/tests/test_resolution_modules.py:111` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py::test_multiple_roots_remain_ambiguous` | `atlas/tests/test_resolution_modules.py:127` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py::test_relative_module_aliases_require_inline_lexical_position` | `atlas/tests/test_resolution_modules.py:137` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py::test_inline_namespaces_expose_only_direct_symbols_and_import_scopes` | `atlas/tests/test_resolution_modules.py:153` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py::test_module_visibility_syntax_is_preserved` | `atlas/tests/test_resolution_modules.py:167` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_resolution_modules.py::test_recursive_path_module_graph_terminates_without_false_root` | `atlas/tests/test_resolution_modules.py:176` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_resolution_review_regressions.py` | `atlas/tests/test_resolution_review_regressions.py` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/test_resolution_review_regressions.py::owner_calls` | `atlas/tests/test_resolution_review_regressions.py:14` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_resolution_review_regressions.py::assert_inherits` | `atlas/tests/test_resolution_review_regressions.py:20` | 2 | 2 | 2 | 0.50 |
| `atlas/tests/test_resolution_review_regressions.py::owner_call_names` | `atlas/tests/test_resolution_review_regressions.py:28` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_resolution_review_regressions.py::assert_no_nested_macro_targets` | `atlas/tests/test_resolution_review_regressions.py:32` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_resolution_review_regressions.py::test_java_base_is_looked_up_outside_derived_class_body` | `atlas/tests/test_resolution_review_regressions.py:39` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_review_regressions.py::test_python_future_class_body_bindings_do_not_shadow_base_header` | `atlas/tests/test_resolution_review_regressions.py:44` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_review_regressions.py::test_namespace_default_and_named_exports_keep_real_keys_without_private_names` | `atlas/tests/test_resolution_review_regressions.py:51` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_review_regressions.py::test_stringification_unknown_and_overridden_macros_are_not_runtime_calls` | `atlas/tests/test_resolution_review_regressions.py:60` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_review_regressions.py::test_macro_local_and_nested_bindings_do_not_become_repository_functions` | `atlas/tests/test_resolution_review_regressions.py:72` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_resolution_review_regressions.py::test_rust_closure_parameter_shadows_bare_function_only_in_callback` | `atlas/tests/test_resolution_review_regressions.py:80` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_resolution_review_regressions.py::test_macro_method_receivers_do_not_become_module_namespaces` | `atlas/tests/test_resolution_review_regressions.py:86` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_rust_root_streaming.py` | `atlas/tests/test_rust_root_streaming.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_rust_root_streaming.py::fallback_entry_sources` | `atlas/tests/test_rust_root_streaming.py:13` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_rust_root_streaming.py::test_fallback_root_references_are_merged_incrementally` | `atlas/tests/test_rust_root_streaming.py:19` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_rust_root_streaming.py::test_fallback_root_references_are_merged_incrementally.referenced_files` | `atlas/tests/test_rust_root_streaming.py:28` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_script_member_coffee_snapshots.py` | `atlas/tests/test_script_member_coffee_snapshots.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_script_member_coffee_snapshots.py::script_member_snapshot` | `atlas/tests/test_script_member_coffee_snapshots.py:13` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_script_member_coffee_snapshots.py::test_script_members_match_standalone_snapshot` | `atlas/tests/test_script_member_coffee_snapshots.py:30` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_script_member_coffee_snapshots.py::assert_script_implementations` | `atlas/tests/test_script_member_coffee_snapshots.py:47` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_script_member_coffee_snapshots.py::assert_dynamic_bases` | `atlas/tests/test_script_member_coffee_snapshots.py:61` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_semantic_contracts.py` | `atlas/tests/test_semantic_contracts.py` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_semantic_contracts.py::test_macro_inner_calls_have_original_utf8_source_spans_and_hints` | `atlas/tests/test_semantic_contracts.py:10` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_semantic_contracts.py::test_constructor_identity_never_uses_global_type_guessing` | `atlas/tests/test_semantic_contracts.py:30` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_semantic_contracts.py::test_java_static_member_import_retains_recipe_identity` | `atlas/tests/test_semantic_contracts.py:38` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_semantic_contracts.py::is_retry_clause` | `atlas/tests/test_semantic_contracts.py:44` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_semantic_contracts.py::retry_candidates` | `atlas/tests/test_semantic_contracts.py:49` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_semantic_contracts.py::assert_other_retry_targets_excluded` | `atlas/tests/test_semantic_contracts.py:53` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_semantic_contracts.py::test_elixir_clause_arity_and_unrelated_modules_remain_ambiguous` | `atlas/tests/test_semantic_contracts.py:59` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_semantic_contracts.py::test_rust_object_dot_is_not_a_module_reference` | `atlas/tests/test_semantic_contracts.py:69` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_semantic_contracts.py::test_receiver_rebinding_and_prototype_replacement` | `atlas/tests/test_semantic_contracts.py:74` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py` | `atlas/tests/test_semantic_resolution.py` | 6 | 5 | 8 | 0.45 |
| `atlas/tests/test_semantic_resolution.py::repository` | `atlas/tests/test_semantic_resolution.py:13` | 6 | 1 | 88 | 0.14 |
| `atlas/tests/test_semantic_resolution.py::call_edges` | `atlas/tests/test_semantic_resolution.py:18` | 8 | 1 | 92 | 0.11 |
| `atlas/tests/test_semantic_resolution.py::coffee_repository` | `atlas/tests/test_semantic_resolution.py:23` | 5 | 2 | 5 | 0.29 |
| `atlas/tests/test_semantic_resolution.py::coffee_symbols` | `atlas/tests/test_semantic_resolution.py:27` | 5 | 0 | 58 | 0.00 |
| `atlas/tests/test_semantic_resolution.py::coffee_target_keys` | `atlas/tests/test_semantic_resolution.py:36` | 2 | 1 | 57 | 0.33 |
| `atlas/tests/test_semantic_resolution.py::coffee_owner_keys` | `atlas/tests/test_semantic_resolution.py:43` | 2 | 1 | 56 | 0.33 |
| `atlas/tests/test_semantic_resolution.py::assert_call_source` | `atlas/tests/test_semantic_resolution.py:50` | 2 | 0 | 56 | 0.00 |
| `atlas/tests/test_semantic_resolution.py::assert_coffee_call` | `atlas/tests/test_semantic_resolution.py:58` | 13 | 4 | 54 | 0.24 |
| `atlas/tests/test_semantic_resolution.py::test_coffee_static_imported_and_constructed_calls` | `atlas/tests/test_semantic_resolution.py:99` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::test_coffee_recursion_preserves_declaration_identity` | `atlas/tests/test_semantic_resolution.py:117` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::test_coffee_go_named_closure_ownership_and_target` | `atlas/tests/test_semantic_resolution.py:125` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::ResolutionAssertions` | `atlas/tests/test_semantic_resolution.py:133` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_semantic_resolution.py::ResolutionAssertions.internal` | `atlas/tests/test_semantic_resolution.py:134` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::ResolutionAssertions.external` | `atlas/tests/test_semantic_resolution.py:148` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest` | `atlas/tests/test_semantic_resolution.py:156` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.project` | `atlas/tests/test_semantic_resolution.py:157` | 12 | 2 | 15 | 0.14 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.unresolved` | `atlas/tests/test_semantic_resolution.py:162` | 11 | 1 | 14 | 0.08 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_python_nonstatic_access_and_unknown_factory_results` | `atlas/tests/test_semantic_resolution.py:168` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_python_import_shadowing_and_rebinding` | `atlas/tests/test_semantic_resolution.py:179` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_python_conditional_bindings_do_not_select_house_recipe` | `atlas/tests/test_semantic_resolution.py:191` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_receiver_rebinding_and_destructuring_preserve_ambiguity` | `atlas/tests/test_semantic_resolution.py:205` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.assert_receiver_ambiguity` | `atlas/tests/test_semantic_resolution.py:213` | 1 | 2 | 1 | 0.67 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_javascript_aliases_defaults_strings_and_unknown_factories` | `atlas/tests/test_semantic_resolution.py:220` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.assert_javascript_aliases` | `atlas/tests/test_semantic_resolution.py:224` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_typescript_type_only_and_conflicting_imports` | `atlas/tests/test_semantic_resolution.py:245` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_javascript_callback_destructuring_shadows_only_callback` | `atlas/tests/test_semantic_resolution.py:251` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.assert_callback_shadowing` | `atlas/tests/test_semantic_resolution.py:255` | 1 | 3 | 1 | 0.75 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_java_declared_packages_same_package_and_static_imports` | `atlas/tests/test_semantic_resolution.py:273` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_java_wrong_namespace_and_duplicate_types_are_not_guessed` | `atlas/tests/test_semantic_resolution.py:290` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_rust_declared_modules_and_path_relocations` | `atlas/tests/test_semantic_resolution.py:305` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_rust_duplicate_module_roots_are_ambiguous` | `atlas/tests/test_semantic_resolution.py:320` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_semantic_resolution.py::SemanticResolutionTest.test_go_rebound_closure_keeps_owner_but_not_target` | `atlas/tests/test_semantic_resolution.py:324` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_size_report.py` | `atlas/tests/test_size_report.py` | 0 | 7 | 0 | 1.00 |
| `atlas/tests/test_size_report.py::size_config` | `atlas/tests/test_size_report.py:22` | 3 | 0 | 3 | 0.00 |
| `atlas/tests/test_size_report.py::node` | `atlas/tests/test_size_report.py:27` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_size_report.py::test_size_limits_are_strict_and_kind_specific` | `atlas/tests/test_size_report.py:35` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_size_report.py::assert_receiver_findings` | `atlas/tests/test_size_report.py:50` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_size_report.py::test_receivers_decorator_comments_and_attributes_at_parameter_threshold` | `atlas/tests/test_size_report.py:57` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_size_report.py::daily_export_source` | `atlas/tests/test_size_report.py:72` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_size_report.py::test_cli_fresh_and_saved_measurements_match_without_sources` | `atlas/tests/test_size_report.py:84` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_source_snapshot_fixture.py` | `atlas/tests/test_source_snapshot_fixture.py` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_source_snapshot_fixture.py::Record` | `atlas/tests/test_source_snapshot_fixture.py:11` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_source_snapshot_fixture.py::test_bytes_paths_and_native_record_order_are_lossless` | `atlas/tests/test_source_snapshot_fixture.py:17` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_source_snapshot_fixture.py::test_only_unordered_collections_are_sorted` | `atlas/tests/test_source_snapshot_fixture.py:25` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_structure.py` | `atlas/tests/test_structure.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_structure.py::names` | `atlas/tests/test_structure.py:13` | 6 | 0 | 6 | 0.00 |
| `atlas/tests/test_structure.py::StructureTagsTest` | `atlas/tests/test_structure.py:17` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_structure.py::StructureTagsTest.setUp` | `atlas/tests/test_structure.py:18` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_structure.py::StructureTagsTest.tearDown` | `atlas/tests/test_structure.py:21` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_structure.py::StructureTagsTest.test_uses_bundled_tags_with_graph_metadata_and_nesting` | `atlas/tests/test_structure.py:24` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_kotlin_private_visibility_discriminator` | `atlas/tests/test_structure.py:53` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_unnamed_companion_is_a_container_without_duplicate_declarations` | `atlas/tests/test_structure.py:60` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_java_methods_constructors_overloads_and_nested_types` | `atlas/tests/test_structure.py:71` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_java_private_method_visibility_discriminator` | `atlas/tests/test_structure.py:93` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_java_private_constructor_visibility` | `atlas/tests/test_structure.py:100` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_other_languages_use_the_same_nesting_and_keep_native_metadata` | `atlas/tests/test_structure.py:106` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_missing_bundled_tags_preserves_native_extraction` | `atlas/tests/test_structure.py:137` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_structure.py::StructureTagsTest.test_queries_are_cached_per_language` | `atlas/tests/test_structure.py:144` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_tsx_coffee.py` | `atlas/tests/test_tsx_coffee.py` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_tsx_coffee.py::assert_workflow_call` | `atlas/tests/test_tsx_coffee.py:24` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_tsx_coffee.py::TsxCoffeeTest` | `atlas/tests/test_tsx_coffee.py:38` | 0 | 0 | 0 | N/A |
| `atlas/tests/test_tsx_coffee.py::TsxCoffeeTest.test_component_reference_ownership_and_normal_calls` | `atlas/tests/test_tsx_coffee.py:39` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_tsx_coffee.py::TsxCoffeeTest.test_shared_workflow_calls_retain_source_and_owner` | `atlas/tests/test_tsx_coffee.py:49` | 0 | 5 | 0 | 1.00 |
| `atlas/tests/test_tsx_coffee.py::test_xml_receipt_intrinsics_fragments_closing_tags_and_shadowing` | `atlas/tests/test_tsx_coffee.py:59` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/test_tsx_coffee.py::assert_xml_receipt_references` | `atlas/tests/test_tsx_coffee.py:69` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_variant_snapshots.py` | `atlas/tests/test_variant_snapshots.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_variant_snapshots.py::test_named_project_variants` | `atlas/tests/test_variant_snapshots.py:16` | 0 | 2 | 0 | 1.00 |
| `atlas/tests/test_variant_snapshots.py::assert_scenario_inputs` | `atlas/tests/test_variant_snapshots.py:24` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/test_variant_snapshots.py::assert_source_bytes` | `atlas/tests/test_variant_snapshots.py:31` | 1 | 0 | 2 | 0.00 |
| `atlas/tests/test_variant_snapshots.py::test_legacy_c_include_has_actual_grammar_and_native_spans` | `atlas/tests/test_variant_snapshots.py:40` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_variant_snapshots.py::test_excluded_language_files_are_not_detected` | `atlas/tests/test_variant_snapshots.py:55` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/test_variant_snapshots.py::test_excluded_languages_never_reach_pipeline_or_production_graph` | `atlas/tests/test_variant_snapshots.py:61` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/test_variant_snapshots.py::assert_only_supported_nodes` | `atlas/tests/test_variant_snapshots.py:71` | 1 | 0 | 1 | 0.00 |
| `atlas/tests/test_variant_snapshots.py::test_each_variant_group_has_a_snapshot` | `atlas/tests/test_variant_snapshots.py:76` | 0 | 1 | 0 | 1.00 |
| `atlas/tests/update_coffee_snapshots.py` | `atlas/tests/update_coffee_snapshots.py` | 0 | 4 | 0 | 1.00 |
| `atlas/tests/update_coffee_snapshots.py::main` | `atlas/tests/update_coffee_snapshots.py:14` | 0 | 3 | 0 | 1.00 |
| `atlas/tests/update_coffee_snapshots.py::write_navigation` | `atlas/tests/update_coffee_snapshots.py:26` | 1 | 1 | 1 | 0.50 |
| `atlas/tests/variant_snapshot_support.py` | `atlas/tests/variant_snapshot_support.py` | 13 | 9 | 15 | 0.41 |
| `atlas/tests/variant_snapshot_support.py::variant_groups` | `atlas/tests/variant_snapshot_support.py:23` | 2 | 0 | 3 | 0.00 |
| `atlas/tests/variant_snapshot_support.py::variant_snapshot` | `atlas/tests/variant_snapshot_support.py:27` | 4 | 3 | 5 | 0.43 |
| `atlas/tests/variant_snapshot_support.py::scenario_snapshot` | `atlas/tests/variant_snapshot_support.py:37` | 1 | 3 | 6 | 0.75 |
| `atlas/tests/variant_snapshot_support.py::legacy_c_snapshot` | `atlas/tests/variant_snapshot_support.py:46` | 1 | 1 | 7 | 0.50 |
| `atlas/tests/variant_snapshot_support.py::snapshot_records` | `atlas/tests/variant_snapshot_support.py:53` | 2 | 8 | 7 | 0.80 |
| `atlas/tests/variant_snapshot_support.py::scenario_sources` | `atlas/tests/variant_snapshot_support.py:74` | 10 | 2 | 55 | 0.17 |
| `atlas/tests/variant_snapshot_support.py::write_variants` | `atlas/tests/variant_snapshot_support.py:82` | 1 | 2 | 1 | 0.67 |
| `dashboard` | `dashboard` | 0 | 0 | 0 | N/A |
| `dashboard/bunfig.toml` | `dashboard/bunfig.toml` | 0 | 0 | 0 | N/A |
| `dashboard/components.json` | `dashboard/components.json` | 0 | 0 | 0 | N/A |
| `dashboard/eslint.config.js` | `dashboard/eslint.config.js` | 0 | 0 | 0 | N/A |
| `dashboard/package.json` | `dashboard/package.json` | 0 | 0 | 0 | N/A |
| `dashboard/prettier.config.js` | `dashboard/prettier.config.js` | 0 | 0 | 0 | N/A |
| `dashboard.public` | `dashboard/public` | 0 | 0 | 0 | N/A |
| `dashboard/public/manifest.json` | `dashboard/public/manifest.json` | 0 | 0 | 0 | N/A |
| `dashboard/public/robots.txt` | `dashboard/public/robots.txt` | 0 | 0 | 0 | N/A |
| `dashboard.src` | `dashboard/src` | 1 | 0 | 2 | 0.00 |
| `dashboard/src/branding.test.ts` | `dashboard/src/branding.test.ts` | 0 | 0 | 0 | N/A |
| `dashboard/src/branding.test.ts::<anonymous>` | `dashboard/src/branding.test.ts:4` | 0 | 0 | 0 | N/A |
| `dashboard.src.components` | `dashboard/src/components` | 0 | 0 | 0 | N/A |
| `dashboard.src.components.graph` | `dashboard/src/components/graph` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx` | `dashboard/src/components/graph/graph-canvas.tsx` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-canvas.tsx::CodeNodeAction` | `dashboard/src/components/graph/graph-canvas.tsx:27` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/graph/graph-canvas.tsx::CodeNodeAction.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:39` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::CodeGraphNode` | `dashboard/src/components/graph/graph-canvas.tsx:51` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasEdges` | `dashboard/src/components/graph/graph-canvas.tsx:78` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasEdges.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:83` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasEdges.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:86` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasEdges.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:89` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-canvas.tsx::edgeLabel` | `dashboard/src/components/graph/graph-canvas.tsx:102` | 1 | 0 | 2 | 0.00 |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasEdge` | `dashboard/src/components/graph/graph-canvas.tsx:114` | 1 | 1 | 1 | 0.50 |
| `dashboard/src/components/graph/graph-canvas.tsx::canvasNode` | `dashboard/src/components/graph/graph-canvas.tsx:148` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas` | `dashboard/src/components/graph/graph-canvas.tsx:176` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:184` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:186` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:190` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:192` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:197` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:200` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:213` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:214` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:227` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:242` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:243` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:244` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::Canvas.<anonymous>` | `dashboard/src/components/graph/graph-canvas.tsx:245` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-canvas.tsx::GraphCanvas` | `dashboard/src/components/graph/graph-canvas.tsx:259` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-complexity.test.tsx` | `dashboard/src/components/graph/graph-complexity.test.tsx` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::fixture` | `dashboard/src/components/graph/graph-complexity.test.tsx:16` | 3 | 0 | 3 | 0.00 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::sidebar` | `dashboard/src/components/graph/graph-complexity.test.tsx:64` | 3 | 1 | 3 | 0.25 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:74` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-complexity.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:75` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-complexity.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:78` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-complexity.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:79` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:84` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:103` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-complexity.test.tsx:122` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-complexity.tsx` | `dashboard/src/components/graph/graph-complexity.tsx` | 1 | 0 | 6 | 0.00 |
| `dashboard/src/components/graph/graph-complexity.tsx::GraphComplexity` | `dashboard/src/components/graph/graph-complexity.tsx:3` | 1 | 0 | 24 | 0.00 |
| `dashboard/src/components/graph/graph-complexity.tsx::GraphComplexity.<anonymous>` | `dashboard/src/components/graph/graph-complexity.tsx:29` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-cycles.tsx` | `dashboard/src/components/graph/graph-cycles.tsx` | 1 | 0 | 6 | 0.00 |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles` | `dashboard/src/components/graph/graph-cycles.tsx:12` | 2 | 0 | 22 | 0.00 |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles.<anonymous>` | `dashboard/src/components/graph/graph-cycles.tsx:20` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles.<anonymous>` | `dashboard/src/components/graph/graph-cycles.tsx:39` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-cycles.tsx:44` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-cycles.tsx:53` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-cycles.tsx::GraphCycles.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-cycles.tsx:70` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::fixture` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:12` | 1 | 0 | 5 | 0.00 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:21` | 4 | 2 | 4 | 0.33 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:27` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:41` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:42` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:45` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:46` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:58` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:73` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:89` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-dependency-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.test.tsx:105` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-dependency-metrics.tsx` | `dashboard/src/components/graph/graph-dependency-metrics.tsx` | 1 | 0 | 6 | 0.00 |
| `dashboard/src/components/graph/graph-dependency-metrics.tsx::GraphDependencyMetrics` | `dashboard/src/components/graph/graph-dependency-metrics.tsx:3` | 2 | 0 | 24 | 0.00 |
| `dashboard/src/components/graph/graph-dependency-metrics.tsx::GraphDependencyMetrics.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.tsx:19` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-dependency-metrics.tsx::GraphDependencyMetrics.<anonymous>` | `dashboard/src/components/graph/graph-dependency-metrics.tsx:26` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-explorer.test.tsx` | `dashboard/src/components/graph/graph-explorer.test.tsx` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-explorer.test.tsx::explorerStates` | `dashboard/src/components/graph/graph-explorer.test.tsx:4` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/graph/graph-explorer.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-explorer.test.tsx:74` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-explorer.tsx` | `dashboard/src/components/graph/graph-explorer.tsx` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-explorer.tsx::<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:13` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-explorer.tsx::EmptyGraph` | `dashboard/src/components/graph/graph-explorer.tsx:15` | 1 | 0 | 3 | 0.00 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphViewport` | `dashboard/src/components/graph/graph-explorer.tsx:38` | 1 | 1 | 2 | 0.50 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphWorkspace` | `dashboard/src/components/graph/graph-explorer.tsx:61` | 1 | 4 | 1 | 0.80 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphWorkspace.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:103` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer` | `dashboard/src/components/graph/graph-explorer.tsx:120` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.queryFn` | `dashboard/src/components/graph/graph-explorer.tsx:131` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:152` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:160` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:174` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.select` | `dashboard/src/components/graph/graph-explorer.tsx:175` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.open` | `dashboard/src/components/graph/graph-explorer.tsx:179` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.navigate` | `dashboard/src/components/graph/graph-explorer.tsx:187` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:200` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-explorer.tsx::GraphExplorer.<anonymous>` | `dashboard/src/components/graph/graph-explorer.tsx:203` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx` | `dashboard/src/components/graph/graph-file-complexity.test.tsx` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::fixture` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:18` | 6 | 1 | 6 | 0.14 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::fixture.add` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:20` | 1 | 0 | 7 | 0.00 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::fixture.add.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:21` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::summary` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:66` | 2 | 1 | 2 | 0.33 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::selectedFile` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:82` | 4 | 1 | 4 | 0.20 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::selectedFile.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:94` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::selectedFile.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:95` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::selectedFile.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:98` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::selectedFile.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:99` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:104` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:119` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:123` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:146` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:157` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:163` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:164` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:176` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:179` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:188` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-file-complexity.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-file-complexity.test.tsx:190` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-file-complexity.tsx` | `dashboard/src/components/graph/graph-file-complexity.tsx` | 3 | 0 | 6 | 0.00 |
| `dashboard/src/components/graph/graph-file-complexity.tsx::complexityHint` | `dashboard/src/components/graph/graph-file-complexity.tsx:3` | 1 | 0 | 26 | 0.00 |
| `dashboard/src/components/graph/graph-file-complexity.tsx::GraphFileComplexity` | `dashboard/src/components/graph/graph-file-complexity.tsx:15` | 4 | 1 | 25 | 0.20 |
| `dashboard/src/components/graph/graph-layout.test.ts` | `dashboard/src/components/graph/graph-layout.test.ts` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-layout.test.ts::<anonymous>` | `dashboard/src/components/graph/graph-layout.test.ts:6` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-layout.test.ts::<anonymous>` | `dashboard/src/components/graph/graph-layout.test.ts:18` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-layout.test.ts::expectSeparated` | `dashboard/src/components/graph/graph-layout.test.ts:27` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/graph/graph-layout.test.ts::<anonymous>` | `dashboard/src/components/graph/graph-layout.test.ts:41` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-layout.test.ts::<anonymous>` | `dashboard/src/components/graph/graph-layout.test.ts:53` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-layout.ts` | `dashboard/src/components/graph/graph-layout.ts` | 2 | 0 | 2 | 0.00 |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph` | `dashboard/src/components/graph/graph-layout.ts:4` | 3 | 0 | 3 | 0.00 |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph.<anonymous>` | `dashboard/src/components/graph/graph-layout.ts:6` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph.<anonymous>` | `dashboard/src/components/graph/graph-layout.ts:16` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph.<anonymous>` | `dashboard/src/components/graph/graph-layout.ts:30` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph.<anonymous>` | `dashboard/src/components/graph/graph-layout.ts:32` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-layout.ts::layoutGraph.<anonymous>` | `dashboard/src/components/graph/graph-layout.ts:34` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-navigation.tsx` | `dashboard/src/components/graph/graph-navigation.tsx` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/graph/graph-navigation.tsx::GraphNavigation` | `dashboard/src/components/graph/graph-navigation.tsx:11` | 1 | 0 | 2 | 0.00 |
| `dashboard/src/components/graph/graph-navigation.tsx::GraphNavigation.<anonymous>` | `dashboard/src/components/graph/graph-navigation.tsx:17` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-navigation.tsx::GraphNavigation.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-navigation.tsx:23` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx` | `dashboard/src/components/graph/graph-sidebar.tsx` | 5 | 5 | 5 | 0.50 |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar` | `dashboard/src/components/graph/graph-sidebar.tsx:32` | 5 | 5 | 20 | 0.50 |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:42` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:54` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:61` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:62` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:85` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::GraphSidebar.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:89` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-sidebar.tsx::ScopeItem` | `dashboard/src/components/graph/graph-sidebar.tsx:110` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/graph/graph-sidebar.tsx::ScopeItem.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:125` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::ScopeItem.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:141` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::nodeTitle` | `dashboard/src/components/graph/graph-sidebar.tsx:151` | 1 | 0 | 23 | 0.00 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeSummary` | `dashboard/src/components/graph/graph-sidebar.tsx:156` | 1 | 3 | 22 | 0.75 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeSummary.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:175` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeMetrics` | `dashboard/src/components/graph/graph-sidebar.tsx:188` | 1 | 3 | 23 | 0.75 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails` | `dashboard/src/components/graph/graph-sidebar.tsx:203` | 1 | 2 | 21 | 0.67 |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:211` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:213` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:215` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:222` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:238` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-sidebar.tsx::NodeDetails.<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-sidebar.tsx:245` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx` | `dashboard/src/components/graph/graph-size-metrics.test.tsx` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::fixture` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:10` | 2 | 0 | 5 | 0.00 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::fixture.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:12` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::sidebar` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:16` | 3 | 2 | 3 | 0.40 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:28` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:29` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:32` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::sidebar.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:33` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:38` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:46` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:54` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:63` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/graph/graph-size-metrics.test.tsx::<anonymous>.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.test.tsx:65` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-size-metrics.tsx` | `dashboard/src/components/graph/graph-size-metrics.tsx` | 2 | 0 | 6 | 0.00 |
| `dashboard/src/components/graph/graph-size-metrics.tsx::GraphSizeMetrics` | `dashboard/src/components/graph/graph-size-metrics.tsx:3` | 3 | 0 | 25 | 0.00 |
| `dashboard/src/components/graph/graph-size-metrics.tsx::GraphSizeMetrics.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.tsx:12` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/graph/graph-size-metrics.tsx::GraphSizeMetrics.<anonymous>` | `dashboard/src/components/graph/graph-size-metrics.tsx:19` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/repository-form.tsx` | `dashboard/src/components/repository-form.tsx` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/repository-form.tsx::RepositoryForm` | `dashboard/src/components/repository-form.tsx:8` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/repository-form.tsx::RepositoryForm.mutationFn` | `dashboard/src/components/repository-form.tsx:13` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/repository-form.tsx::RepositoryForm.onSuccess` | `dashboard/src/components/repository-form.tsx:19` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/repository-form.tsx::RepositoryForm.<anonymous>` | `dashboard/src/components/repository-form.tsx:27` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/repository-form.tsx::RepositoryForm.<anonymous>` | `dashboard/src/components/repository-form.tsx:49` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/repository-form.tsx::RepositoryForm.<anonymous>` | `dashboard/src/components/repository-form.tsx:62` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/repository-row.tsx` | `dashboard/src/components/repository-row.tsx` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/repository-row.tsx::RepositoryRow` | `dashboard/src/components/repository-row.tsx:7` | 0 | 0 | 0 | N/A |
| `dashboard.src.components.ui` | `dashboard/src/components/ui` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/ui/badge.tsx` | `dashboard/src/components/ui/badge.tsx` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/ui/badge.tsx::Badge` | `dashboard/src/components/ui/badge.tsx:29` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/ui/button.tsx` | `dashboard/src/components/ui/button.tsx` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/ui/button.tsx::Button` | `dashboard/src/components/ui/button.tsx:41` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/components/ui/input.tsx` | `dashboard/src/components/ui/input.tsx` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/ui/input.tsx::Input` | `dashboard/src/components/ui/input.tsx:5` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/ui/primitives.test.tsx` | `dashboard/src/components/ui/primitives.test.tsx` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/components/ui/primitives.test.tsx::<anonymous>` | `dashboard/src/components/ui/primitives.test.tsx:6` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/components/ui/primitives.test.tsx::<anonymous>.onClick` | `dashboard/src/components/ui/primitives.test.tsx:7` | 0 | 0 | 0 | N/A |
| `dashboard/src/components/ui/primitives.test.tsx::<anonymous>` | `dashboard/src/components/ui/primitives.test.tsx:36` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/env.d.ts` | `dashboard/src/env.d.ts` | 0 | 0 | 0 | N/A |
| `dashboard/src/env.d.ts::ImportMetaEnv` | `dashboard/src/env.d.ts:3` | 0 | 0 | 0 | N/A |
| `dashboard/src/env.d.ts::ImportMeta` | `dashboard/src/env.d.ts:8` | 0 | 0 | 0 | N/A |
| `dashboard.src.lib` | `dashboard/src/lib` | 1 | 2 | 1 | 0.67 |
| `dashboard/src/lib/api.ts` | `dashboard/src/lib/api.ts` | 2 | 2 | 7 | 0.50 |
| `dashboard/src/lib/api.ts::api` | `dashboard/src/lib/api.ts:13` | 1 | 1 | 1 | 0.50 |
| `dashboard/src/lib/api.ts::queryFn` | `dashboard/src/lib/api.ts:23` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/api.ts::formatDate` | `dashboard/src/lib/api.ts:26` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/architecture-artifact.ts` | `dashboard/src/lib/architecture-artifact.ts` | 22 | 0 | 31 | 0.00 |
| `dashboard/src/lib/database.servers.test.ts` | `dashboard/src/lib/database.servers.test.ts` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/database.servers.test.ts::<anonymous>` | `dashboard/src/lib/database.servers.test.ts:6` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/file-complexity.ts` | `dashboard/src/lib/file-complexity.ts` | 4 | 1 | 22 | 0.20 |
| `dashboard/src/lib/file-complexity.ts::sumFileComplexity` | `dashboard/src/lib/file-complexity.ts:10` | 2 | 0 | 3 | 0.00 |
| `dashboard/src/lib/file-complexity.ts::sumFileComplexity.<anonymous>` | `dashboard/src/lib/file-complexity.ts:15` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/file-complexity.ts::sumFileComplexity.<anonymous>` | `dashboard/src/lib/file-complexity.ts:19` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/file-complexity.ts::sumFileComplexity.<anonymous>` | `dashboard/src/lib/file-complexity.ts:20` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/file-complexity.ts::sumFileComplexity.<anonymous>` | `dashboard/src/lib/file-complexity.ts:25` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.test.ts` | `dashboard/src/lib/graph-analysis.test.ts` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-analysis.test.ts::node` | `dashboard/src/lib/graph-analysis.test.ts:6` | 3 | 0 | 5 | 0.00 |
| `dashboard/src/lib/graph-analysis.test.ts::edge` | `dashboard/src/lib/graph-analysis.test.ts:18` | 3 | 0 | 3 | 0.00 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:28` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/graph-analysis.test.ts::hierarchyFixture` | `dashboard/src/lib/graph-analysis.test.ts:67` | 2 | 1 | 2 | 0.33 |
| `dashboard/src/lib/graph-analysis.test.ts::hierarchyFixture.add` | `dashboard/src/lib/graph-analysis.test.ts:69` | 1 | 1 | 3 | 0.50 |
| `dashboard/src/lib/graph-analysis.test.ts::hierarchyFixture.add.<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:70` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:106` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:166` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:185` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:188` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:189` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:194` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:196` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.test.ts::<anonymous>` | `dashboard/src/lib/graph-analysis.test.ts:204` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-analysis.ts` | `dashboard/src/lib/graph-analysis.ts` | 3 | 1 | 8 | 0.25 |
| `dashboard/src/lib/graph-analysis.ts::compareKeys` | `dashboard/src/lib/graph-analysis.ts:10` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/graph-analysis.ts::finishFrom` | `dashboard/src/lib/graph-analysis.ts:28` | 1 | 0 | 13 | 0.00 |
| `dashboard/src/lib/graph-analysis.ts::finishOrder` | `dashboard/src/lib/graph-analysis.ts:45` | 1 | 1 | 12 | 0.50 |
| `dashboard/src/lib/graph-analysis.ts::addReverseEdges` | `dashboard/src/lib/graph-analysis.ts:56` | 1 | 0 | 12 | 0.00 |
| `dashboard/src/lib/graph-analysis.ts::enqueueUnvisited` | `dashboard/src/lib/graph-analysis.ts:64` | 1 | 0 | 13 | 0.00 |
| `dashboard/src/lib/graph-analysis.ts::reverseGroup` | `dashboard/src/lib/graph-analysis.ts:76` | 1 | 1 | 12 | 0.50 |
| `dashboard/src/lib/graph-analysis.ts::components` | `dashboard/src/lib/graph-analysis.ts:89` | 3 | 3 | 11 | 0.50 |
| `dashboard/src/lib/graph-analysis.ts::components.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:91` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::levelOwners` | `dashboard/src/lib/graph-analysis.ts:104` | 2 | 0 | 8 | 0.00 |
| `dashboard/src/lib/graph-analysis.ts::levelOwners.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:105` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::levelOwners.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:107` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::levelOwners.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:110` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::impactCounts` | `dashboard/src/lib/graph-analysis.ts:116` | 1 | 1 | 7 | 0.50 |
| `dashboard/src/lib/graph-analysis.ts::impactCounts.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:119` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::impactCounts.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:119` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::impactCounts.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:124` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::impactCounts.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:133` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::impactCounts.<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:134` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::levelAdjacency` | `dashboard/src/lib/graph-analysis.ts:144` | 1 | 1 | 6 | 0.50 |
| `dashboard/src/lib/graph-analysis.ts::levelAdjacency.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:152` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::levelAdjacency.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:153` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::levelAdjacency.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:162` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::countIncoming` | `dashboard/src/lib/graph-analysis.ts:166` | 1 | 0 | 7 | 0.00 |
| `dashboard/src/lib/graph-analysis.ts::addLevelMetrics` | `dashboard/src/lib/graph-analysis.ts:171` | 1 | 2 | 6 | 0.67 |
| `dashboard/src/lib/graph-analysis.ts::internalNodes` | `dashboard/src/lib/graph-analysis.ts:191` | 3 | 0 | 7 | 0.00 |
| `dashboard/src/lib/graph-analysis.ts::internalNodes.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:194` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::internalNodes.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:195` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::internalNodes.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:198` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::internalNodes.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-analysis.ts:199` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-analysis.ts::dependencyMetrics` | `dashboard/src/lib/graph-analysis.ts:206` | 3 | 3 | 5 | 0.50 |
| `dashboard/src/lib/graph-cycles.test.ts` | `dashboard/src/lib/graph-cycles.test.ts` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-cycles.test.ts::node` | `dashboard/src/lib/graph-cycles.test.ts:14` | 1 | 0 | 9 | 0.00 |
| `dashboard/src/lib/graph-cycles.test.ts::fixture` | `dashboard/src/lib/graph-cycles.test.ts:33` | 8 | 1 | 8 | 0.11 |
| `dashboard/src/lib/graph-cycles.test.ts::fixture.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:37` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.test.ts::group` | `dashboard/src/lib/graph-cycles.test.ts:67` | 3 | 0 | 3 | 0.00 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:70` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:75` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:83` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:98` | 0 | 5 | 0 | 1.00 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:112` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:125` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:127` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:138` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:140` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:162` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:167` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:182` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.test.ts::<anonymous>` | `dashboard/src/lib/graph-cycles.test.ts:185` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-cycles.ts` | `dashboard/src/lib/graph-cycles.ts` | 4 | 4 | 22 | 0.50 |
| `dashboard/src/lib/graph-cycles.ts::owningFile` | `dashboard/src/lib/graph-cycles.ts:15` | 1 | 0 | 4 | 0.00 |
| `dashboard/src/lib/graph-cycles.ts::owningFile.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:19` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::owningFile.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:22` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::cycleContainsNode` | `dashboard/src/lib/graph-cycles.ts:26` | 3 | 1 | 3 | 0.25 |
| `dashboard/src/lib/graph-cycles.ts::cycleContainsNode.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:34` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope` | `dashboard/src/lib/graph-cycles.ts:40` | 2 | 0 | 2 | 0.00 |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:44` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:45` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:50` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:51` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::containingCycleScope.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:53` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::projectCycles` | `dashboard/src/lib/graph-cycles.ts:64` | 9 | 1 | 10 | 0.10 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:71` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:73` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:75` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:75` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:76` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:81` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:83` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:106` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:120` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-cycles.ts::projectCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/graph-cycles.ts:124` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/graph-data.ts` | `dashboard/src/lib/graph-data.ts` | 11 | 4 | 22 | 0.27 |
| `dashboard/src/lib/graph-details-test.helpers.ts` | `dashboard/src/lib/graph-details-test.helpers.ts` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-details-test.helpers.ts::fixtureDetails` | `dashboard/src/lib/graph-details-test.helpers.ts:5` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-details-test.helpers.ts::fixtureDetails.<anonymous>` | `dashboard/src/lib/graph-details-test.helpers.ts:9` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-details-test.helpers.ts::fixtureDetails.<anonymous>` | `dashboard/src/lib/graph-details-test.helpers.ts:10` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/graph-test-path.ts` | `dashboard/src/lib/graph-test-path.ts` | 2 | 0 | 23 | 0.00 |
| `dashboard/src/lib/graph-test-path.ts::isTestPath` | `dashboard/src/lib/graph-test-path.ts:2` | 2 | 0 | 16 | 0.00 |
| `dashboard/src/lib/graph-test-path.ts::isTestPath.<anonymous>` | `dashboard/src/lib/graph-test-path.ts:6` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-traversal.ts` | `dashboard/src/lib/graph-traversal.ts` | 2 | 1 | 23 | 0.33 |
| `dashboard/src/lib/graph-traversal.ts::pushChildren` | `dashboard/src/lib/graph-traversal.ts:4` | 3 | 0 | 45 | 0.00 |
| `dashboard/src/lib/graph-visibility.test.ts` | `dashboard/src/lib/graph-visibility.test.ts` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:23` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:33` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:35` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-visibility.test.ts::node` | `dashboard/src/lib/graph-visibility.test.ts:48` | 2 | 0 | 3 | 0.00 |
| `dashboard/src/lib/graph-visibility.test.ts::fixture` | `dashboard/src/lib/graph-visibility.test.ts:68` | 2 | 1 | 2 | 0.33 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:112` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:116` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:128` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:134` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:139` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:153` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-visibility.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/graph-visibility.test.ts:157` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-visibility.ts` | `dashboard/src/lib/graph-visibility.ts` | 4 | 4 | 22 | 0.50 |
| `dashboard/src/lib/graph-visibility.ts::isFolder` | `dashboard/src/lib/graph-visibility.ts:8` | 2 | 0 | 16 | 0.00 |
| `dashboard/src/lib/graph-visibility.ts::isTestNode` | `dashboard/src/lib/graph-visibility.ts:11` | 1 | 2 | 14 | 0.67 |
| `dashboard/src/lib/graph-visibility.ts::hideEmptyFolder` | `dashboard/src/lib/graph-visibility.ts:16` | 1 | 1 | 14 | 0.50 |
| `dashboard/src/lib/graph-visibility.ts::hideEmptyFolder.<anonymous>` | `dashboard/src/lib/graph-visibility.ts:24` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-visibility.ts::hideTestFiles` | `dashboard/src/lib/graph-visibility.ts:30` | 5 | 3 | 13 | 0.38 |
| `dashboard/src/lib/graph-visibility.ts::hideTestFiles.<anonymous>` | `dashboard/src/lib/graph-visibility.ts:53` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/graph-visibility.ts::hideTestFiles.<anonymous>` | `dashboard/src/lib/graph-visibility.ts:55` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/import-cycles.servers.ts` | `dashboard/src/lib/import-cycles.servers.ts` | 2 | 2 | 7 | 0.50 |
| `dashboard/src/lib/import-cycles.servers.ts::pythonJson` | `dashboard/src/lib/import-cycles.servers.ts:11` | 3 | 0 | 4 | 0.00 |
| `dashboard/src/lib/import-cycles.servers.ts::pythonJson.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:15` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/import-cycles.servers.ts::pythonJson.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:16` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/import-cycles.servers.ts::pythonJson.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:17` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/import-cycles.servers.ts::pythonJson.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:21` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/import-cycles.servers.ts::fileOwners` | `dashboard/src/lib/import-cycles.servers.ts:26` | 1 | 0 | 5 | 0.00 |
| `dashboard/src/lib/import-cycles.servers.ts::fileOwners.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:27` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/import-cycles.servers.ts::fileOwners.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:29` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/import-cycles.servers.ts::fileOwners.<anonymous>.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:31` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/import-cycles.servers.ts::projectImport` | `dashboard/src/lib/import-cycles.servers.ts:49` | 1 | 0 | 5 | 0.00 |
| `dashboard/src/lib/import-cycles.servers.ts::projectImports` | `dashboard/src/lib/import-cycles.servers.ts:74` | 1 | 2 | 4 | 0.67 |
| `dashboard/src/lib/import-cycles.servers.ts::projectImports.sortKey` | `dashboard/src/lib/import-cycles.servers.ts:81` | 1 | 1 | 1 | 0.50 |
| `dashboard/src/lib/import-cycles.servers.ts::projectImports.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:82` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/import-cycles.servers.ts::cyclePath` | `dashboard/src/lib/import-cycles.servers.ts:87` | 1 | 0 | 2 | 0.00 |
| `dashboard/src/lib/import-cycles.servers.ts::cycleNeighbors` | `dashboard/src/lib/import-cycles.servers.ts:106` | 1 | 0 | 2 | 0.00 |
| `dashboard/src/lib/import-cycles.servers.ts::exampleCycle` | `dashboard/src/lib/import-cycles.servers.ts:123` | 1 | 2 | 1 | 0.67 |
| `dashboard/src/lib/import-cycles.servers.ts::exampleCycle.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:132` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles` | `dashboard/src/lib/import-cycles.servers.ts:151` | 2 | 2 | 3 | 0.50 |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:167` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:171` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:174` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:175` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/import-cycles.servers.ts::importCycles.<anonymous>.<anonymous>` | `dashboard/src/lib/import-cycles.servers.ts:182` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/imported-artifact-fixture.ts` | `dashboard/src/lib/imported-artifact-fixture.ts` | 2 | 1 | 2 | 0.33 |
| `dashboard/src/lib/imported-artifact-fixture.ts::importedArtifact` | `dashboard/src/lib/imported-artifact-fixture.ts:45` | 4 | 0 | 4 | 0.00 |
| `dashboard/src/lib/imported-artifact-fixture.ts::largeArtifact` | `dashboard/src/lib/imported-artifact-fixture.ts:77` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/imported-artifact-fixture.ts::largeArtifact.add` | `dashboard/src/lib/imported-artifact-fixture.ts:88` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/imported-artifact-fixture.ts::largeArtifact.<anonymous>` | `dashboard/src/lib/imported-artifact-fixture.ts:122` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/imported-artifact-fixture.ts::largeArtifact.<anonymous>` | `dashboard/src/lib/imported-artifact-fixture.ts:124` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/imported-artifact-fixture.ts::largeArtifact.<anonymous>.<anonymous>` | `dashboard/src/lib/imported-artifact-fixture.ts:125` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/imported-artifact-fixture.ts::addFiles` | `dashboard/src/lib/imported-artifact-fixture.ts:143` | 1 | 1 | 1 | 0.50 |
| `dashboard/src/lib/imported-artifact-fixture.ts::addFunctions` | `dashboard/src/lib/imported-artifact-fixture.ts:148` | 1 | 0 | 2 | 0.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts` | `dashboard/src/lib/normalized-graph.servers.test.ts` | 0 | 8 | 0 | 1.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::python` | `dashboard/src/lib/normalized-graph.servers.test.ts:30` | 4 | 0 | 8 | 0.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:37` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:48` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::ready` | `dashboard/src/lib/normalized-graph.servers.test.ts:53` | 7 | 0 | 7 | 0.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::save` | `dashboard/src/lib/normalized-graph.servers.test.ts:58` | 5 | 1 | 5 | 0.17 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::fixture` | `dashboard/src/lib/normalized-graph.servers.test.ts:84` | 4 | 1 | 4 | 0.20 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::fixture.add` | `dashboard/src/lib/normalized-graph.servers.test.ts:86` | 1 | 0 | 5 | 0.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::fixture.add.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:87` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails` | `dashboard/src/lib/normalized-graph.servers.test.ts:177` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:178` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:186` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:204` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:207` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectPartialDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:209` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectMetrics` | `dashboard/src/lib/normalized-graph.servers.test.ts:231` | 1 | 0 | 2 | 0.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectAnalyzedDetails` | `dashboard/src/lib/normalized-graph.servers.test.ts:245` | 1 | 2 | 1 | 0.67 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::expectAnalyzedDetails.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:248` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::enqueueScopes` | `dashboard/src/lib/normalized-graph.servers.test.ts:258` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::enqueueScopes.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:263` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:269` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:316` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:321` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:335` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:338` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:345` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:349` | 0 | 8 | 0 | 1.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:388` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:389` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:392` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:393` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:403` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.edge` | `dashboard/src/lib/normalized-graph.servers.test.ts:405` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:425` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:474` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:479` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:481` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:501` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:511` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:514` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:520` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:523` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:532` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:551` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/normalized-graph.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/normalized-graph.servers.test.ts:554` | 0 | 1 | 0 | 1.00 |
| `dashboard.src.lib.persistence` | `dashboard/src/lib/persistence` | 0 | 0 | 0 | N/A |
| `dashboard.src.lib.persistence.repositories` | `dashboard/src/lib/persistence/repositories` | 1 | 1 | 1 | 0.50 |
| `dashboard/src/lib/persistence/repositories/connection.ts` | `dashboard/src/lib/persistence/repositories/connection.ts` | 4 | 0 | 8 | 0.00 |
| `dashboard/src/lib/persistence/repositories/connection.ts::defaultDatabasePath` | `dashboard/src/lib/persistence/repositories/connection.ts:11` | 2 | 0 | 15 | 0.00 |
| `dashboard/src/lib/persistence/repositories/connection.ts::openConnection` | `dashboard/src/lib/persistence/repositories/connection.ts:19` | 1 | 1 | 11 | 0.50 |
| `dashboard/src/lib/persistence/repositories/connection.ts::openConnection.close` | `dashboard/src/lib/persistence/repositories/connection.ts:27` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/factory.ts` | `dashboard/src/lib/persistence/repositories/factory.ts` | 1 | 4 | 4 | 0.80 |
| `dashboard/src/lib/persistence/repositories/factory.ts::createRepositoryContext` | `dashboard/src/lib/persistence/repositories/factory.ts:7` | 1 | 1 | 10 | 0.50 |
| `dashboard/src/lib/persistence/repositories/factory.ts::createRepositoryContext.register` | `dashboard/src/lib/persistence/repositories/factory.ts:12` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/factory.ts::createRepositoryContext.list` | `dashboard/src/lib/persistence/repositories/factory.ts:13` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/factory.ts::createRepositoryContext.view` | `dashboard/src/lib/persistence/repositories/factory.ts:14` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/factory.ts::createRepositoryContext.close` | `dashboard/src/lib/persistence/repositories/factory.ts:15` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/factory.ts::repositoryDatabasePath` | `dashboard/src/lib/persistence/repositories/factory.ts:19` | 1 | 1 | 2 | 0.50 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts` | `dashboard/src/lib/persistence/repositories/graph-queries.ts` | 1 | 4 | 6 | 0.80 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::identity` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:17` | 2 | 0 | 2 | 0.00 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::selectedRows` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:26` | 4 | 0 | 4 | 0.00 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:36` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.constructor` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:37` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.metadata` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:39` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.topology` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:58` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:80` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing.read` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:81` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:100` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:104` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:108` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.outgoing.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:110` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.relations` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:114` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.imports` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:128` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.metrics` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:143` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.metrics.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:144` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.decorators` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:177` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.decorators.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:178` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.complexities` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:196` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.complexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:197` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-queries.ts::GraphQueries.diagnostics` | `dashboard/src/lib/persistence/repositories/graph-queries.ts:214` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts` | `dashboard/src/lib/persistence/repositories/graph-store.ts` | 1 | 11 | 5 | 0.92 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::compactProperties` | `dashboard/src/lib/persistence/repositories/graph-store.ts:22` | 1 | 0 | 3 | 0.00 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::compactProperties.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:23` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::hierarchy` | `dashboard/src/lib/persistence/repositories/graph-store.ts:25` | 1 | 0 | 2 | 0.00 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::hierarchy.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:26` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::hierarchy.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:27` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore` | `dashboard/src/lib/persistence/repositories/graph-store.ts:43` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.constructor` | `dashboard/src/lib/persistence/repositories/graph-store.ts:45` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.view` | `dashboard/src/lib/persistence/repositories/graph-store.ts:49` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.view.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:51` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.details` | `dashboard/src/lib/persistence/repositories/graph-store.ts:56` | 1 | 3 | 2 | 0.75 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.details.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:92` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.details.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:93` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities` | `dashboard/src/lib/persistence/repositories/graph-store.ts:103` | 1 | 1 | 3 | 0.50 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:111` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:112` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:118` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:119` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:123` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:128` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.fileComplexities.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:130` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView` | `dashboard/src/lib/persistence/repositories/graph-store.ts:144` | 1 | 8 | 1 | 0.89 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:161` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:163` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:178` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:182` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:183` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:186` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:187` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:191` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/graph-store.ts::GraphStore.readView.<anonymous>` | `dashboard/src/lib/persistence/repositories/graph-store.ts:198` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/repository-store.ts` | `dashboard/src/lib/persistence/repositories/repository-store.ts` | 1 | 3 | 5 | 0.75 |
| `dashboard/src/lib/persistence/repositories/repository-store.ts::RepositoryStore` | `dashboard/src/lib/persistence/repositories/repository-store.ts:7` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/repository-store.ts::RepositoryStore.constructor` | `dashboard/src/lib/persistence/repositories/repository-store.ts:8` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/repository-store.ts::RepositoryStore.register` | `dashboard/src/lib/persistence/repositories/repository-store.ts:10` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/persistence/repositories/repository-store.ts::RepositoryStore.list` | `dashboard/src/lib/persistence/repositories/repository-store.ts:21` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/persistence/repositories/repository-store.ts::RepositoryStore.list.<anonymous>` | `dashboard/src/lib/persistence/repositories/repository-store.ts:38` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/schema.ts` | `dashboard/src/lib/persistence/repositories/schema.ts` | 2 | 0 | 8 | 0.00 |
| `dashboard/src/lib/persistence/repositories/schema.ts::nodeIdentity` | `dashboard/src/lib/persistence/repositories/schema.ts:19` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:37` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:46` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:59` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:73` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:82` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:102` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/persistence/repositories/schema.ts::<anonymous>` | `dashboard/src/lib/persistence/repositories/schema.ts:114` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts` | `dashboard/src/lib/project-graph-boundary.test.ts` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/project-graph-boundary.test.ts::fixture` | `dashboard/src/lib/project-graph-boundary.test.ts:5` | 4 | 1 | 4 | 0.20 |
| `dashboard/src/lib/project-graph-boundary.test.ts::fixture.add` | `dashboard/src/lib/project-graph-boundary.test.ts:7` | 1 | 0 | 5 | 0.00 |
| `dashboard/src/lib/project-graph-boundary.test.ts::fixture.add.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:8` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::link` | `dashboard/src/lib/project-graph-boundary.test.ts:54` | 5 | 0 | 5 | 0.00 |
| `dashboard/src/lib/project-graph-boundary.test.ts::ids` | `dashboard/src/lib/project-graph-boundary.test.ts:63` | 2 | 0 | 2 | 0.00 |
| `dashboard/src/lib/project-graph-boundary.test.ts::ids.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:64` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:66` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:94` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:100` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:105` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:107` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:111` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:128` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:137` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:142` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::addExternalChild` | `dashboard/src/lib/project-graph-boundary.test.ts:148` | 1 | 1 | 1 | 0.50 |
| `dashboard/src/lib/project-graph-boundary.test.ts::addExternalChild.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:149` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:162` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:164` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:181` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:182` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:187` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:194` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:196` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:199` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-boundary.test.ts:217` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.ts` | `dashboard/src/lib/project-graph-boundary.ts` | 1 | 4 | 22 | 0.80 |
| `dashboard/src/lib/project-graph-boundary.ts::isFolder` | `dashboard/src/lib/project-graph-boundary.ts:6` | 2 | 0 | 38 | 0.00 |
| `dashboard/src/lib/project-graph-boundary.ts::boundaryTarget` | `dashboard/src/lib/project-graph-boundary.ts:9` | 1 | 1 | 36 | 0.50 |
| `dashboard/src/lib/project-graph-boundary.ts::boundaryTarget.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:15` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.ts::boundaryTarget.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:18` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/project-graph-boundary.ts::boundaryTarget.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:31` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.ts::boundaryTarget.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:32` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.ts::renderBoundary` | `dashboard/src/lib/project-graph-boundary.ts:42` | 1 | 0 | 36 | 0.00 |
| `dashboard/src/lib/project-graph-boundary.ts::renderBoundary.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:51` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.ts::renderBoundary.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:53` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.ts::isBoundaryEdge` | `dashboard/src/lib/project-graph-boundary.ts:63` | 1 | 0 | 36 | 0.00 |
| `dashboard/src/lib/project-graph-boundary.ts::addBoundaryDependencies` | `dashboard/src/lib/project-graph-boundary.ts:80` | 1 | 3 | 35 | 0.75 |
| `dashboard/src/lib/project-graph-boundary.ts::addBoundaryDependencies.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:88` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-boundary.ts::addBoundaryDependencies.<anonymous>` | `dashboard/src/lib/project-graph-boundary.ts:89` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-fixture.ts` | `dashboard/src/lib/project-graph-fixture.ts` | 1 | 1 | 1 | 0.50 |
| `dashboard/src/lib/project-graph-fixture.ts::fixtureNodes` | `dashboard/src/lib/project-graph-fixture.ts:10` | 1 | 1 | 16 | 0.50 |
| `dashboard/src/lib/project-graph-fixture.ts::fixtureNodes.add` | `dashboard/src/lib/project-graph-fixture.ts:13` | 1 | 0 | 17 | 0.00 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts` | `dashboard/src/lib/project-graph-projection-test-helpers.ts` | 1 | 2 | 1 | 0.67 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::canAlias` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:5` | 1 | 0 | 5 | 0.00 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::canAlias.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:12` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::registerFolderAliases` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:30` | 1 | 1 | 4 | 0.50 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::projectAncestors` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:44` | 1 | 0 | 4 | 0.00 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::projectAncestors.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:54` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::projectAncestors.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:60` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectedEdges` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:66` | 1 | 0 | 4 | 0.00 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:86` | 3 | 3 | 3 | 0.50 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:91` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:92` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:93` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:94` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectDirectProjection.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:101` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::recordReachableNodes` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:121` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectNavigableTrail` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:134` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::expectNavigableTrail.<anonymous>` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:140` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-projection-test-helpers.ts::enqueueFolders` | `dashboard/src/lib/project-graph-projection-test-helpers.ts:143` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts` | `dashboard/src/lib/project-graph-real.test.ts` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:7` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:11` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:14` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:17` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:23` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:32` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:38` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:51` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:55` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:59` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:65` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:69` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:76` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:78` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:86` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:90` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:94` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-real.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph-real.test.ts:97` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-test.helpers.ts` | `dashboard/src/lib/project-graph-test.helpers.ts` | 2 | 2 | 2 | 0.50 |
| `dashboard/src/lib/project-graph-test.helpers.ts::buildProjectGraph` | `dashboard/src/lib/project-graph-test.helpers.ts:6` | 18 | 1 | 18 | 0.05 |
| `dashboard/src/lib/project-graph-test.helpers.ts::buildProjectGraph.<anonymous>` | `dashboard/src/lib/project-graph-test.helpers.ts:11` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-test.helpers.ts::buildProjectGraph.<anonymous>` | `dashboard/src/lib/project-graph-test.helpers.ts:12` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-test.helpers.ts::buildProjectGraph.<anonymous>` | `dashboard/src/lib/project-graph-test.helpers.ts:13` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-test.helpers.ts::ids` | `dashboard/src/lib/project-graph-test.helpers.ts:16` | 11 | 0 | 11 | 0.00 |
| `dashboard/src/lib/project-graph-test.helpers.ts::ids.<anonymous>` | `dashboard/src/lib/project-graph-test.helpers.ts:17` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph-types.ts` | `dashboard/src/lib/project-graph-types.ts` | 9 | 1 | 24 | 0.10 |
| `dashboard/src/lib/project-graph.test.ts` | `dashboard/src/lib/project-graph.test.ts` | 0 | 6 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:15` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::fixture` | `dashboard/src/lib/project-graph.test.ts:19` | 10 | 2 | 15 | 0.17 |
| `dashboard/src/lib/project-graph.test.ts::fixture.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:22` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::fixture.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:23` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::fixture.link` | `dashboard/src/lib/project-graph.test.ts:29` | 1 | 0 | 16 | 0.00 |
| `dashboard/src/lib/project-graph.test.ts::tree` | `dashboard/src/lib/project-graph.test.ts:69` | 5 | 1 | 5 | 0.17 |
| `dashboard/src/lib/project-graph.test.ts::tree.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:74` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::relation` | `dashboard/src/lib/project-graph.test.ts:93` | 2 | 0 | 7 | 0.00 |
| `dashboard/src/lib/project-graph.test.ts::relation.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:94` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::expectRelations` | `dashboard/src/lib/project-graph.test.ts:103` | 5 | 1 | 5 | 0.17 |
| `dashboard/src/lib/project-graph.test.ts::expectRelations.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:114` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:121` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:122` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:125` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:129` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:159` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:165` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:169` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:195` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:196` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:200` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:223` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:231` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:234` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:270` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:282` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:283` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:293` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:295` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:310` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:313` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:314` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:320` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:323` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:327` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:329` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:341` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:344` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:370` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:394` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:395` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:400` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:401` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:407` | 0 | 5 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:444` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:452` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:471` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:486` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:502` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:515` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:527` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:543` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/project-graph.test.ts:544` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.test.ts::<anonymous>` | `dashboard/src/lib/project-graph.test.ts:548` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.ts` | `dashboard/src/lib/project-graph.ts` | 11 | 5 | 22 | 0.31 |
| `dashboard/src/lib/project-graph.ts::GraphScopeError` | `dashboard/src/lib/project-graph.ts:19` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.ts::isExternal` | `dashboard/src/lib/project-graph.ts:22` | 5 | 0 | 45 | 0.00 |
| `dashboard/src/lib/project-graph.ts::isFolder` | `dashboard/src/lib/project-graph.ts:24` | 7 | 0 | 48 | 0.00 |
| `dashboard/src/lib/project-graph.ts::isFile` | `dashboard/src/lib/project-graph.ts:26` | 5 | 0 | 46 | 0.00 |
| `dashboard/src/lib/project-graph.ts::indexChildren` | `dashboard/src/lib/project-graph.ts:28` | 1 | 0 | 35 | 0.00 |
| `dashboard/src/lib/project-graph.ts::descendants` | `dashboard/src/lib/project-graph.ts:38` | 3 | 2 | 40 | 0.40 |
| `dashboard/src/lib/project-graph.ts::isTransparent` | `dashboard/src/lib/project-graph.ts:52` | 2 | 1 | 41 | 0.33 |
| `dashboard/src/lib/project-graph.ts::rootNodes` | `dashboard/src/lib/project-graph.ts:56` | 1 | 5 | 36 | 0.83 |
| `dashboard/src/lib/project-graph.ts::scopeNode` | `dashboard/src/lib/project-graph.ts:71` | 2 | 2 | 40 | 0.50 |
| `dashboard/src/lib/project-graph.ts::scopeNode.<anonymous>` | `dashboard/src/lib/project-graph.ts:75` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.ts::scopeNode.<anonymous>` | `dashboard/src/lib/project-graph.ts:76` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.ts::scopeNode.<anonymous>` | `dashboard/src/lib/project-graph.ts:79` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.ts::visibleNodes` | `dashboard/src/lib/project-graph.ts:92` | 1 | 3 | 35 | 0.75 |
| `dashboard/src/lib/project-graph.ts::visibleNodes.<anonymous>` | `dashboard/src/lib/project-graph.ts:101` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.ts::visibleNodes.<anonymous>` | `dashboard/src/lib/project-graph.ts:104` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.ts::compactChain` | `dashboard/src/lib/project-graph.ts:108` | 1 | 1 | 2 | 0.50 |
| `dashboard/src/lib/project-graph.ts::compactChain.<anonymous>` | `dashboard/src/lib/project-graph.ts:115` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.ts::nodeLabel` | `dashboard/src/lib/project-graph.ts:124` | 2 | 0 | 12 | 0.00 |
| `dashboard/src/lib/project-graph.ts::sourceLines` | `dashboard/src/lib/project-graph.ts:127` | 1 | 0 | 3 | 0.00 |
| `dashboard/src/lib/project-graph.ts::graphNode` | `dashboard/src/lib/project-graph.ts:136` | 1 | 5 | 2 | 0.83 |
| `dashboard/src/lib/project-graph.ts::projectNodes` | `dashboard/src/lib/project-graph.ts:173` | 1 | 1 | 35 | 0.50 |
| `dashboard/src/lib/project-graph.ts::aggregateEdges` | `dashboard/src/lib/project-graph.ts:184` | 1 | 0 | 35 | 0.00 |
| `dashboard/src/lib/project-graph.ts::buildProjectGraph` | `dashboard/src/lib/project-graph.ts:218` | 15 | 5 | 34 | 0.25 |
| `dashboard/src/lib/project-graph.ts::buildProjectGraph.render` | `dashboard/src/lib/project-graph.ts:224` | 1 | 2 | 1 | 0.67 |
| `dashboard/src/lib/project-graph.ts::buildProjectGraph.render.<anonymous>` | `dashboard/src/lib/project-graph.ts:234` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/project-graph.ts::buildProjectGraph.<anonymous>` | `dashboard/src/lib/project-graph.ts:239` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/project-graph.ts::getGraphTrail` | `dashboard/src/lib/project-graph.ts:254` | 7 | 5 | 8 | 0.42 |
| `dashboard/src/lib/project-graph.ts::getGraphTrail.<anonymous>` | `dashboard/src/lib/project-graph.ts:263` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts` | `dashboard/src/lib/repositories.servers.test.ts` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::openDatabase` | `dashboard/src/lib/repositories.servers.test.ts:27` | 2 | 0 | 2 | 0.00 |
| `dashboard/src/lib/repositories.servers.test.ts::registerRepository` | `dashboard/src/lib/repositories.servers.test.ts:29` | 6 | 0 | 6 | 0.00 |
| `dashboard/src/lib/repositories.servers.test.ts::listRepositories` | `dashboard/src/lib/repositories.servers.test.ts:31` | 8 | 0 | 8 | 0.00 |
| `dashboard/src/lib/repositories.servers.test.ts::getArchitecture` | `dashboard/src/lib/repositories.servers.test.ts:32` | 7 | 0 | 13 | 0.00 |
| `dashboard/src/lib/repositories.servers.test.ts::ready` | `dashboard/src/lib/repositories.servers.test.ts:35` | 3 | 1 | 6 | 0.25 |
| `dashboard/src/lib/repositories.servers.test.ts::fileView` | `dashboard/src/lib/repositories.servers.test.ts:45` | 3 | 1 | 3 | 0.25 |
| `dashboard/src/lib/repositories.servers.test.ts::python` | `dashboard/src/lib/repositories.servers.test.ts:48` | 7 | 0 | 7 | 0.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:63` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:71` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:77` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:112` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:114` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:121` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:129` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:131` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:143` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:145` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:148` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:153` | 0 | 4 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:165` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:170` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:172` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:181` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:197` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:209` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:213` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:223` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:230` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:235` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:259` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:274` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:281` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:286` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:290` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:311` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:315` | 0 | 3 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:327` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>.<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:350` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.test.ts::<anonymous>` | `dashboard/src/lib/repositories.servers.test.ts:354` | 0 | 2 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.ts` | `dashboard/src/lib/repositories.servers.ts` | 3 | 4 | 3 | 0.57 |
| `dashboard/src/lib/repositories.servers.ts::RepositoryError` | `dashboard/src/lib/repositories.servers.ts:9` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.ts::RepositoryError.constructor` | `dashboard/src/lib/repositories.servers.ts:10` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.ts::requiredText` | `dashboard/src/lib/repositories.servers.ts:19` | 3 | 0 | 6 | 0.00 |
| `dashboard/src/lib/repositories.servers.ts::register` | `dashboard/src/lib/repositories.servers.ts:31` | 1 | 1 | 1 | 0.50 |
| `dashboard/src/lib/repositories.servers.ts::createRepositoryService` | `dashboard/src/lib/repositories.servers.ts:49` | 6 | 1 | 9 | 0.14 |
| `dashboard/src/lib/repositories.servers.ts::createRepositoryService.registerRepository` | `dashboard/src/lib/repositories.servers.ts:52` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.ts::createRepositoryService.listRepositories` | `dashboard/src/lib/repositories.servers.ts:53` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.ts::createRepositoryService.getArchitecture` | `dashboard/src/lib/repositories.servers.ts:54` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.ts::createRepositoryService.close` | `dashboard/src/lib/repositories.servers.ts:64` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/repositories.servers.ts::defaultDatabasePath` | `dashboard/src/lib/repositories.servers.ts:69` | 1 | 1 | 1 | 0.50 |
| `dashboard/src/lib/repositories.servers.ts::getService` | `dashboard/src/lib/repositories.servers.ts:71` | 3 | 1 | 3 | 0.25 |
| `dashboard/src/lib/repositories.servers.ts::registerRepository` | `dashboard/src/lib/repositories.servers.ts:72` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.ts::listRepositories` | `dashboard/src/lib/repositories.servers.ts:74` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.ts::getArchitecture` | `dashboard/src/lib/repositories.servers.ts:75` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/lib/repositories.servers.ts::architectureScope` | `dashboard/src/lib/repositories.servers.ts:78` | 2 | 1 | 2 | 0.33 |
| `dashboard/src/lib/repositories.servers.ts::repositoryErrorResponse` | `dashboard/src/lib/repositories.servers.ts:86` | 2 | 0 | 2 | 0.00 |
| `dashboard/src/lib/repository-ports.ts` | `dashboard/src/lib/repository-ports.ts` | 2 | 3 | 5 | 0.60 |
| `dashboard/src/lib/utils.ts` | `dashboard/src/lib/utils.ts` | 0 | 0 | 0 | N/A |
| `dashboard/src/lib/utils.ts::cn` | `dashboard/src/lib/utils.ts:5` | 0 | 0 | 0 | N/A |
| `dashboard/src/router.tsx` | `dashboard/src/router.tsx` | 0 | 0 | 0 | N/A |
| `dashboard/src/router.tsx::getRouter` | `dashboard/src/router.tsx:7` | 0 | 0 | 0 | N/A |
| `dashboard.src.routes` | `dashboard/src/routes` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/__root.tsx` | `dashboard/src/routes/__root.tsx` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/__root.tsx::head` | `dashboard/src/routes/__root.tsx:15` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/__root.tsx::notFoundComponent` | `dashboard/src/routes/__root.tsx:34` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/__root.tsx::errorComponent` | `dashboard/src/routes/__root.tsx:40` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/__root.tsx::RootDocument` | `dashboard/src/routes/__root.tsx:52` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/__root.tsx::RootComponent` | `dashboard/src/routes/__root.tsx:66` | 0 | 0 | 0 | N/A |
| `dashboard.src.routes.api` | `dashboard/src/routes/api` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/api/architecture.ts` | `dashboard/src/routes/api/architecture.ts` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/api/architecture.ts::GET` | `dashboard/src/routes/api/architecture.ts:11` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/api/repositories.ts` | `dashboard/src/routes/api/repositories.ts` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/api/repositories.ts::GET` | `dashboard/src/routes/api/repositories.ts:11` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/api/repositories.ts::POST` | `dashboard/src/routes/api/repositories.ts:18` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/graph-project-name.test.ts` | `dashboard/src/routes/graph-project-name.test.ts` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/graph-project-name.test.ts::renderRoute` | `dashboard/src/routes/graph-project-name.test.ts:4` | 3 | 0 | 3 | 0.00 |
| `dashboard/src/routes/graph-project-name.test.ts::<anonymous>` | `dashboard/src/routes/graph-project-name.test.ts:30` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/routes/graph-project-name.test.ts::<anonymous>` | `dashboard/src/routes/graph-project-name.test.ts:42` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/routes/graph-project-name.test.ts::<anonymous>` | `dashboard/src/routes/graph-project-name.test.ts:47` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/routes/graph.$repositoryId.tsx` | `dashboard/src/routes/graph.$repositoryId.tsx` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/graph.$repositoryId.tsx::GraphPage` | `dashboard/src/routes/graph.$repositoryId.tsx:14` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/routes/graph.$repositoryId.tsx::GraphPage.queryFn` | `dashboard/src/routes/graph.$repositoryId.tsx:19` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/graph.$repositoryId.tsx::GraphPage.<anonymous>` | `dashboard/src/routes/graph.$repositoryId.tsx:26` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/graph.$repositoryId.tsx::GraphPage.refresh` | `dashboard/src/routes/graph.$repositoryId.tsx:28` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/graph.$repositoryId.tsx::GraphContent` | `dashboard/src/routes/graph.$repositoryId.tsx:64` | 1 | 1 | 1 | 0.50 |
| `dashboard/src/routes/graph.$repositoryId.tsx::WaitingForImport` | `dashboard/src/routes/graph.$repositoryId.tsx:116` | 1 | 0 | 2 | 0.00 |
| `dashboard/src/routes/index.tsx` | `dashboard/src/routes/index.tsx` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/index.tsx::AddRepositoryButton` | `dashboard/src/routes/index.tsx:12` | 1 | 0 | 1 | 0.00 |
| `dashboard/src/routes/index.tsx::RepositoriesPage` | `dashboard/src/routes/index.tsx:27` | 0 | 1 | 0 | 1.00 |
| `dashboard/src/routes/index.tsx::RepositoriesPage.<anonymous>` | `dashboard/src/routes/index.tsx:34` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/index.tsx::RepositoriesPage.<anonymous>` | `dashboard/src/routes/index.tsx:47` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/index.tsx::RepositoriesPage.<anonymous>` | `dashboard/src/routes/index.tsx:61` | 0 | 0 | 0 | N/A |
| `dashboard/src/routes/index.tsx::RepositoriesPage.<anonymous>` | `dashboard/src/routes/index.tsx:81` | 0 | 0 | 0 | N/A |
| `dashboard/src/server.ts` | `dashboard/src/server.ts` | 1 | 0 | 8 | 0.00 |
| `dashboard/src/server.ts::fetch` | `dashboard/src/server.ts:4` | 1 | 0 | 2 | 0.00 |
| `dashboard/src/start.ts` | `dashboard/src/start.ts` | 0 | 0 | 0 | N/A |
| `dashboard/src/start.ts::<anonymous>` | `dashboard/src/start.ts:3` | 0 | 0 | 0 | N/A |
| `dashboard.src.styles` | `dashboard/src/styles` | 0 | 0 | 0 | N/A |
| `dashboard/src/styles.css` | `dashboard/src/styles.css` | 0 | 0 | 0 | N/A |
| `dashboard/src/styles/base.css` | `dashboard/src/styles/base.css` | 0 | 0 | 0 | N/A |
| `dashboard/src/styles/graph.css` | `dashboard/src/styles/graph.css` | 0 | 0 | 0 | N/A |
| `dashboard/src/styles/responsive.css` | `dashboard/src/styles/responsive.css` | 0 | 0 | 0 | N/A |
| `dashboard/src/test.setup.ts` | `dashboard/src/test.setup.ts` | 0 | 0 | 0 | N/A |
| `dashboard/src/test.setup.ts::<anonymous>` | `dashboard/src/test.setup.ts:8` | 0 | 0 | 0 | N/A |
| `dashboard.tests` | `dashboard/tests` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-access-policy.ts` | `dashboard/tests/database-access-policy.ts` | 1 | 2 | 5 | 0.67 |
| `dashboard/tests/database-access-policy.ts::pragmaCall` | `dashboard/tests/database-access-policy.ts:21` | 1 | 2 | 14 | 0.67 |
| `dashboard/tests/database-access-policy.ts::sensitiveOwner` | `dashboard/tests/database-access-policy.ts:29` | 2 | 2 | 16 | 0.50 |
| `dashboard/tests/database-access-policy.ts::checkRawAccess` | `dashboard/tests/database-access-policy.ts:33` | 1 | 2 | 13 | 0.67 |
| `dashboard/tests/database-access-policy.ts::checkOrmAccess` | `dashboard/tests/database-access-policy.ts:41` | 1 | 2 | 13 | 0.67 |
| `dashboard/tests/database-access-policy.ts::checkWriteAccess` | `dashboard/tests/database-access-policy.ts:54` | 1 | 1 | 14 | 0.50 |
| `dashboard/tests/database-access-policy.ts::checkOperationAccess` | `dashboard/tests/database-access-policy.ts:63` | 1 | 1 | 13 | 0.50 |
| `dashboard/tests/database-access-policy.ts::checkComputedBinding` | `dashboard/tests/database-access-policy.ts:75` | 1 | 1 | 13 | 0.50 |
| `dashboard/tests/database-access-policy.ts::invokedAccess` | `dashboard/tests/database-access-policy.ts:86` | 1 | 0 | 14 | 0.00 |
| `dashboard/tests/database-access-policy.ts::checkComputedAccess` | `dashboard/tests/database-access-policy.ts:92` | 1 | 3 | 13 | 0.75 |
| `dashboard/tests/database-access-policy.ts::checkAccess` | `dashboard/tests/database-access-policy.ts:105` | 1 | 5 | 12 | 0.83 |
| `dashboard/tests/database-architecture.test.ts` | `dashboard/tests/database-architecture.test.ts` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-architecture.test.ts::productionFiles` | `dashboard/tests/database-architecture.test.ts:14` | 2 | 0 | 2 | 0.00 |
| `dashboard/tests/database-architecture.test.ts::productionFiles.<anonymous>` | `dashboard/tests/database-architecture.test.ts:15` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:29` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-architecture.test.ts:31` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-architecture.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-architecture.test.ts:32` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-architecture.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-architecture.test.ts:34` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:40` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:118` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:124` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:139` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-architecture.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-architecture.test.ts:146` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:152` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-architecture.test.ts::serviceProgram` | `dashboard/tests/database-architecture.test.ts:192` | 1 | 0 | 1 | 0.00 |
| `dashboard/tests/database-architecture.test.ts::serviceProgram.getSourceFile` | `dashboard/tests/database-architecture.test.ts:202` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-architecture.test.ts::<anonymous>` | `dashboard/tests/database-architecture.test.ts:209` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-architecture.ts` | `dashboard/tests/database-architecture.ts` | 4 | 4 | 4 | 0.50 |
| `dashboard/tests/database-architecture.ts::sensitiveValue` | `dashboard/tests/database-architecture.ts:22` | 1 | 1 | 14 | 0.50 |
| `dashboard/tests/database-architecture.ts::trackBinding` | `dashboard/tests/database-architecture.ts:32` | 1 | 1 | 13 | 0.50 |
| `dashboard/tests/database-architecture.ts::sensitiveBindings` | `dashboard/tests/database-architecture.ts:47` | 1 | 1 | 11 | 0.50 |
| `dashboard/tests/database-architecture.ts::sensitiveBindings.visit` | `dashboard/tests/database-architecture.ts:66` | 1 | 1 | 12 | 0.50 |
| `dashboard/tests/database-architecture.ts::checkSql` | `dashboard/tests/database-architecture.ts:73` | 1 | 1 | 12 | 0.50 |
| `dashboard/tests/database-architecture.ts::checkIdentifier` | `dashboard/tests/database-architecture.ts:85` | 1 | 0 | 12 | 0.00 |
| `dashboard/tests/database-architecture.ts::checkReferences` | `dashboard/tests/database-architecture.ts:109` | 1 | 3 | 12 | 0.75 |
| `dashboard/tests/database-architecture.ts::auditSource` | `dashboard/tests/database-architecture.ts:118` | 10 | 2 | 10 | 0.17 |
| `dashboard/tests/database-architecture.ts::auditSource.report` | `dashboard/tests/database-architecture.ts:127` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-architecture.ts::auditSource.visit` | `dashboard/tests/database-architecture.ts:132` | 1 | 4 | 11 | 0.80 |
| `dashboard/tests/database-boundary-regressions.test.ts` | `dashboard/tests/database-boundary-regressions.test.ts` | 0 | 2 | 0 | 1.00 |
| `dashboard/tests/database-boundary-regressions.test.ts::fixtureProgram` | `dashboard/tests/database-boundary-regressions.test.ts:23` | 2 | 0 | 6 | 0.00 |
| `dashboard/tests/database-boundary-regressions.test.ts::fixtureProgram.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:25` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::fixtureProgram.getSourceFile` | `dashboard/tests/database-boundary-regressions.test.ts:29` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::fixtureProgram.fileExists` | `dashboard/tests/database-boundary-regressions.test.ts:37` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::fixtureProgram.readFile` | `dashboard/tests/database-boundary-regressions.test.ts:38` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::dependencyErrors` | `dashboard/tests/database-boundary-regressions.test.ts:42` | 4 | 1 | 4 | 0.20 |
| `dashboard/tests/database-boundary-regressions.test.ts::dependencyErrors.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:44` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::dependencyErrors.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:49` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::dependencyErrors.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:53` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::dependencyErrors.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:57` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:80` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:86` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:103` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:107` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:118` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:131` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:139` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:162` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:168` | 0 | 3 | 0 | 1.00 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:187` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:194` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:204` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:210` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-boundary-regressions.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-boundary-regressions.test.ts:218` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-dependency-policy.ts` | `dashboard/tests/database-dependency-policy.ts` | 1 | 1 | 1 | 0.50 |
| `dashboard/tests/database-dependency-policy.ts::ownsRepositoryDependencies` | `dashboard/tests/database-dependency-policy.ts:4` | 2 | 0 | 6 | 0.00 |
| `dashboard/tests/database-dependency-policy.ts::applicationDeclaration` | `dashboard/tests/database-dependency-policy.ts:14` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-dependency-policy.ts::structuralPort` | `dashboard/tests/database-dependency-policy.ts:18` | 1 | 0 | 6 | 0.00 |
| `dashboard/tests/database-dependency-policy.ts::structuralPort.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:19` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-dependency-policy.ts::referencedTypes` | `dashboard/tests/database-dependency-policy.ts:31` | 1 | 0 | 6 | 0.00 |
| `dashboard/tests/database-dependency-policy.ts::dependencyBinding` | `dashboard/tests/database-dependency-policy.ts:40` | 1 | 0 | 5 | 0.00 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector` | `dashboard/tests/database-dependency-policy.ts:50` | 1 | 0 | 4 | 0.00 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect` | `dashboard/tests/database-dependency-policy.ts:51` | 5 | 2 | 5 | 0.29 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:63` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:69` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:73` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:78` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:81` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:94` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-dependency-policy.ts::argumentValue` | `dashboard/tests/database-dependency-policy.ts:105` | 1 | 0 | 2 | 0.00 |
| `dashboard/tests/database-dependency-policy.ts::dependencyInitializer` | `dashboard/tests/database-dependency-policy.ts:114` | 1 | 0 | 2 | 0.00 |
| `dashboard/tests/database-dependency-policy.ts::dependencyAssignments` | `dashboard/tests/database-dependency-policy.ts:123` | 1 | 1 | 5 | 0.50 |
| `dashboard/tests/database-dependency-policy.ts::dependencyAssignments.visit` | `dashboard/tests/database-dependency-policy.ts:125` | 1 | 0 | 6 | 0.00 |
| `dashboard/tests/database-dependency-policy.ts::valueInspector` | `dashboard/tests/database-dependency-policy.ts:143` | 1 | 1 | 4 | 0.50 |
| `dashboard/tests/database-dependency-policy.ts::valueInspector.inspect` | `dashboard/tests/database-dependency-policy.ts:149` | 1 | 2 | 1 | 0.67 |
| `dashboard/tests/database-dependency-policy.ts::valueInspector.inspect.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:163` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-dependency-policy.ts::externalCall` | `dashboard/tests/database-dependency-policy.ts:168` | 1 | 1 | 5 | 0.50 |
| `dashboard/tests/database-dependency-policy.ts::auditRepositoryDependencies` | `dashboard/tests/database-dependency-policy.ts:180` | 3 | 4 | 3 | 0.57 |
| `dashboard/tests/database-dependency-policy.ts::auditRepositoryDependencies.report` | `dashboard/tests/database-dependency-policy.ts:189` | 1 | 0 | 5 | 0.00 |
| `dashboard/tests/database-dependency-policy.ts::auditRepositoryDependencies.visit` | `dashboard/tests/database-dependency-policy.ts:193` | 1 | 3 | 4 | 0.75 |
| `dashboard/tests/database-dependency-policy.ts::auditRepositoryDependencies.visit.<anonymous>` | `dashboard/tests/database-dependency-policy.ts:201` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-factory-boundary.test.ts` | `dashboard/tests/database-factory-boundary.test.ts` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-factory-boundary.test.ts::<anonymous>` | `dashboard/tests/database-factory-boundary.test.ts:12` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-factory-boundary.test.ts::<anonymous>` | `dashboard/tests/database-factory-boundary.test.ts:33` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-factory-boundary.test.ts::<anonymous>.getSourceFile` | `dashboard/tests/database-factory-boundary.test.ts:57` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-factory-boundary.test.ts::<anonymous>.<anonymous>` | `dashboard/tests/database-factory-boundary.test.ts:74` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-module-policy.ts` | `dashboard/tests/database-module-policy.ts` | 1 | 2 | 5 | 0.67 |
| `dashboard/tests/database-module-policy.ts::modulePath` | `dashboard/tests/database-module-policy.ts:14` | 1 | 0 | 15 | 0.00 |
| `dashboard/tests/database-module-policy.ts::permittedFactory` | `dashboard/tests/database-module-policy.ts:21` | 1 | 0 | 16 | 0.00 |
| `dashboard/tests/database-module-policy.ts::permittedFactory.<anonymous>` | `dashboard/tests/database-module-policy.ts:30` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-module-policy.ts::checkRepositoryModule` | `dashboard/tests/database-module-policy.ts:36` | 1 | 4 | 14 | 0.80 |
| `dashboard/tests/database-module-policy.ts::checkServiceFactory` | `dashboard/tests/database-module-policy.ts:55` | 1 | 1 | 15 | 0.50 |
| `dashboard/tests/database-module-policy.ts::checkPortModule` | `dashboard/tests/database-module-policy.ts:62` | 1 | 0 | 15 | 0.00 |
| `dashboard/tests/database-module-policy.ts::checkRepositoryOwner` | `dashboard/tests/database-module-policy.ts:70` | 1 | 0 | 15 | 0.00 |
| `dashboard/tests/database-module-policy.ts::checkDriverModule` | `dashboard/tests/database-module-policy.ts:74` | 1 | 0 | 14 | 0.00 |
| `dashboard/tests/database-module-policy.ts::checkModule` | `dashboard/tests/database-module-policy.ts:87` | 1 | 3 | 13 | 0.75 |
| `dashboard/tests/database-module-policy.ts::checkOrmModule` | `dashboard/tests/database-module-policy.ts:97` | 1 | 2 | 14 | 0.67 |
| `dashboard/tests/database-module-policy.ts::checkOrmModule.visit` | `dashboard/tests/database-module-policy.ts:102` | 1 | 0 | 15 | 0.00 |
| `dashboard/tests/database-module-policy.ts::checkOrmNamespace` | `dashboard/tests/database-module-policy.ts:109` | 1 | 0 | 15 | 0.00 |
| `dashboard/tests/database-policy.ts` | `dashboard/tests/database-policy.ts` | 4 | 0 | 8 | 0.00 |
| `dashboard/tests/database-service-exports.ts` | `dashboard/tests/database-service-exports.ts` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-service-exports.ts::typeDeclarations` | `dashboard/tests/database-service-exports.ts:3` | 2 | 0 | 4 | 0.00 |
| `dashboard/tests/database-service-exports.ts::persistenceDeclaration` | `dashboard/tests/database-service-exports.ts:9` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-service-exports.ts::persistenceType` | `dashboard/tests/database-service-exports.ts:20` | 1 | 1 | 2 | 0.50 |
| `dashboard/tests/database-service-exports.ts::persistenceType.<anonymous>` | `dashboard/tests/database-service-exports.ts:24` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-service-exports.ts::applicationDeclaration` | `dashboard/tests/database-service-exports.ts:29` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-service-exports.ts::applicationMembers` | `dashboard/tests/database-service-exports.ts:32` | 1 | 1 | 2 | 0.50 |
| `dashboard/tests/database-service-exports.ts::applicationMembers.<anonymous>` | `dashboard/tests/database-service-exports.ts:36` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-service-exports.ts::typeArguments` | `dashboard/tests/database-service-exports.ts:38` | 1 | 0 | 2 | 0.00 |
| `dashboard/tests/database-service-exports.ts::typeArguments.<anonymous>` | `dashboard/tests/database-service-exports.ts:45` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-service-exports.ts::exportInspector` | `dashboard/tests/database-service-exports.ts:55` | 1 | 0 | 1 | 0.00 |
| `dashboard/tests/database-service-exports.ts::exportInspector.inspect` | `dashboard/tests/database-service-exports.ts:57` | 1 | 4 | 1 | 0.80 |
| `dashboard/tests/database-service-exports.ts::exportInspector.inspect.<anonymous>` | `dashboard/tests/database-service-exports.ts:69` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-service-exports.ts::exportInspector.inspect.<anonymous>` | `dashboard/tests/database-service-exports.ts:71` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-service-exports.ts::exportInspector.inspect.inspect` | `dashboard/tests/database-service-exports.ts:77` | 3 | 0 | 3 | 0.00 |
| `dashboard/tests/database-service-exports.ts::exportInspector.inspect.<anonymous>` | `dashboard/tests/database-service-exports.ts:79` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-service-exports.ts::exportInspector.<anonymous>` | `dashboard/tests/database-service-exports.ts:81` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-service-exports.ts::inspectSignatures` | `dashboard/tests/database-service-exports.ts:86` | 1 | 0 | 2 | 0.00 |
| `dashboard/tests/database-service-exports.ts::inspectSignatures.<anonymous>` | `dashboard/tests/database-service-exports.ts:99` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-service-exports.ts::inspectSignatures.<anonymous>.<anonymous>` | `dashboard/tests/database-service-exports.ts:101` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-service-exports.ts::auditServiceExports` | `dashboard/tests/database-service-exports.ts:108` | 0 | 1 | 0 | 1.00 |
| `dashboard/tests/database-service-exports.ts::auditServiceExports.<anonymous>` | `dashboard/tests/database-service-exports.ts:117` | 0 | 0 | 0 | N/A |
| `dashboard/tests/database-syntax.ts` | `dashboard/tests/database-syntax.ts` | 3 | 1 | 7 | 0.25 |
| `dashboard/tests/database-syntax.ts::loaderCall` | `dashboard/tests/database-syntax.ts:6` | 1 | 0 | 14 | 0.00 |
| `dashboard/tests/database-syntax.ts::moduleReferences` | `dashboard/tests/database-syntax.ts:14` | 1 | 2 | 13 | 0.67 |
| `dashboard/tests/database-syntax.ts::importEqualsReferences` | `dashboard/tests/database-syntax.ts:24` | 1 | 0 | 14 | 0.00 |
| `dashboard/tests/database-syntax.ts::literal` | `dashboard/tests/database-syntax.ts:28` | 3 | 0 | 19 | 0.00 |
| `dashboard/tests/database-syntax.ts::namedProperty` | `dashboard/tests/database-syntax.ts:32` | 1 | 0 | 17 | 0.00 |
| `dashboard/tests/database-syntax.ts::bindingProperty` | `dashboard/tests/database-syntax.ts:44` | 1 | 0 | 17 | 0.00 |
| `dashboard/tests/database-syntax.ts::property` | `dashboard/tests/database-syntax.ts:49` | 3 | 3 | 16 | 0.50 |
| `dashboard/tests/database-syntax.ts::allowedPragma` | `dashboard/tests/database-syntax.ts:60` | 2 | 0 | 16 | 0.00 |
| `dashboard/tests/database-syntax.ts::rootName` | `dashboard/tests/database-syntax.ts:76` | 4 | 0 | 23 | 0.00 |
| `dashboard/tests/database-syntax.ts::accessOwner` | `dashboard/tests/database-syntax.ts:82` | 1 | 0 | 17 | 0.00 |
| `dashboard/tsconfig.json` | `dashboard/tsconfig.json` | 0 | 0 | 0 | N/A |
| `dashboard/vite.config.ts` | `dashboard/vite.config.ts` | 0 | 0 | 0 | N/A |
| `reports` | `reports` | 0 | 0 | 0 | N/A |
| `reports.atlas-navigation` | `reports/atlas-navigation` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/REPORT.md` | `reports/atlas-navigation/REPORT.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evaluation-original.md` | `reports/atlas-navigation/evaluation-original.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evaluation-revised.md` | `reports/atlas-navigation/evaluation-revised.md` | 0 | 0 | 0 | N/A |
| `reports.atlas-navigation.evidence` | `reports/atlas-navigation/evidence` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evidence/EX-ATLAS.md` | `reports/atlas-navigation/evidence/EX-ATLAS.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evidence/EX-PLAIN.md` | `reports/atlas-navigation/evidence/EX-PLAIN.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evidence/EX-REVISED.md` | `reports/atlas-navigation/evidence/EX-REVISED.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evidence/PY-ATLAS.md` | `reports/atlas-navigation/evidence/PY-ATLAS.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evidence/PY-PLAIN.md` | `reports/atlas-navigation/evidence/PY-PLAIN.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evidence/PY-REVISED.md` | `reports/atlas-navigation/evidence/PY-REVISED.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evidence/TS-ATLAS.md` | `reports/atlas-navigation/evidence/TS-ATLAS.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evidence/TS-PLAIN.md` | `reports/atlas-navigation/evidence/TS-PLAIN.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evidence/TS-REVISED.md` | `reports/atlas-navigation/evidence/TS-REVISED.md` | 0 | 0 | 0 | N/A |
| `reports.atlas-navigation.evidence.skill-measured` | `reports/atlas-navigation/evidence/skill-measured` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evidence/skill-measured/SKILL.md` | `reports/atlas-navigation/evidence/skill-measured/SKILL.md` | 0 | 0 | 0 | N/A |
| `reports.atlas-navigation.evidence.skill-measured.references` | `reports/atlas-navigation/evidence/skill-measured/references` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/evidence/skill-measured/references/commands.md` | `reports/atlas-navigation/evidence/skill-measured/references/commands.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/metrics.json` | `reports/atlas-navigation/metrics.json` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/prompts.json` | `reports/atlas-navigation/prompts.json` | 0 | 0 | 0 | N/A |
| `reports/atlas-navigation/provenance.json` | `reports/atlas-navigation/provenance.json` | 0 | 0 | 0 | N/A |
| `reports.atlas-vs-graphify` | `reports/atlas-vs-graphify` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/REPORT.md` | `reports/atlas-vs-graphify/REPORT.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/evaluation.json` | `reports/atlas-vs-graphify/evaluation.json` | 0 | 0 | 0 | N/A |
| `reports.atlas-vs-graphify.evidence` | `reports/atlas-vs-graphify/evidence` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/evidence/EX-ATLAS.md` | `reports/atlas-vs-graphify/evidence/EX-ATLAS.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/evidence/EX-GRAPHIFY.md` | `reports/atlas-vs-graphify/evidence/EX-GRAPHIFY.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/evidence/EX-PLAIN.md` | `reports/atlas-vs-graphify/evidence/EX-PLAIN.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/evidence/PY-ATLAS.md` | `reports/atlas-vs-graphify/evidence/PY-ATLAS.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/evidence/PY-GRAPHIFY.md` | `reports/atlas-vs-graphify/evidence/PY-GRAPHIFY.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/evidence/PY-PLAIN.md` | `reports/atlas-vs-graphify/evidence/PY-PLAIN.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/evidence/TS-ATLAS.md` | `reports/atlas-vs-graphify/evidence/TS-ATLAS.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/evidence/TS-GRAPHIFY.md` | `reports/atlas-vs-graphify/evidence/TS-GRAPHIFY.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/evidence/TS-PLAIN.md` | `reports/atlas-vs-graphify/evidence/TS-PLAIN.md` | 0 | 0 | 0 | N/A |
| `reports/atlas-vs-graphify/metrics.json` | `reports/atlas-vs-graphify/metrics.json` | 0 | 0 | 0 | N/A |

Dependency metrics count distinct internal peers at each item's level, including tests and type-only dependencies. Impact excludes the item itself. Instability = fan-out / (fan-in + fan-out); isolated items are N/A.
