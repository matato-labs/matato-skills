#!/usr/bin/env python3
"""Observe real NavigationService path/context traversal through its reader port."""
from pathlib import Path
import sys
import unittest

repoPath = Path(sys.argv.pop(1)).resolve()
sys.path.insert(0, str(repoPath / "atlas/src"))
from atlas.domain.navigation import GraphSnapshot, PathRequest, TraversalRequest
from atlas.services.navigation import NavigationService


class GraphReader:
    snapshot = GraphSnapshot("repo", "revision", None, "/unused")

    def __init__(self, pairs, extraNodes=(), externalNodes=()):
        keys = set(extraNodes) | {key for pair in pairs for key in pair[:2]}
        self.nodes = {key: {"stableKey": key, "external": key in externalNodes, "path": None} for key in keys}
        self.rows = [{"ordinal": ordinal, "sourceStableKey": source, "targetStableKey": target, "type": relation}
                     for ordinal, (source, target, relation) in enumerate(pairs)]
        self.edgeCalls = []

    def node(self, key):
        return self.nodes[key]

    def edges(self, request):
        self.edgeCalls.append(request.key)
        return [row for row in self.rows if row["type"] in request.relations and (
            (request.direction in ("out", "both") and row["sourceStableKey"] == request.key) or
            (request.direction in ("in", "both") and row["targetStableKey"] == request.key))][:request.limit]

    def diagnostics(self, paths, limit):
        return []


def requestFor(start="root", depth=10, maxNodes=100, maxEdges=100, direction="out", relations=None):
    return TraversalRequest(start, direction, ["CALLS"] if relations is None else relations, depth, maxNodes, maxEdges)


class PathEarlyExitTests(unittest.TestCase):
    def testShortestRouteStopsBeforeUnrelatedExpansion(self):
        reader = GraphReader([("root", "a", "CALLS"), ("root", "b", "CALLS"),
                              ("a", "target", "CALLS"), ("b", "noise", "CALLS"),
                              ("target", "tail", "CALLS")])
        result = NavigationService(reader).path(PathRequest("target", requestFor()))
        self.assertEqual(result["path"], ["root", "a", "target"])
        self.assertEqual([edge["ordinal"] for edge in result["pathEdges"]], [0, 2])
        self.assertEqual(result["status"], "found")
        self.assertEqual(reader.edgeCalls, ["root", "a"], "no edge fetch after target discovery")
        self.assertNotIn("noise", [node["stableKey"] for node in result["nodes"]])

    def testAlreadyAtTargetNeedsNoExpansion(self):
        reader = GraphReader([("root", "noise", "CALLS")])
        result = NavigationService(reader).path(PathRequest("root", requestFor(depth=0)))
        self.assertEqual(result["path"], ["root"])
        self.assertEqual(result["pathEdges"], [])
        self.assertFalse(result["truncated"])
        self.assertEqual(reader.edgeCalls, [])

    def testFoundAtBudgetBoundaryDoesNotAcquireLaterCutoffs(self):
        reader = GraphReader([("root", "target", "CALLS"), ("root", "noise", "CALLS")])
        result = NavigationService(reader).path(PathRequest("target", requestFor(maxNodes=2, maxEdges=1)))
        self.assertEqual(result["status"], "found")
        self.assertEqual(result["path"], ["root", "target"])
        self.assertFalse(result["truncated"], "later neighbors must not create cutoffs after success")
        self.assertEqual(result["boundaries"], [])

    def testUnreachableAndLimitedSearchStayDistinct(self):
        for options, expectedStatus in [(requestFor(), "not_found"), (requestFor(depth=0), "unknown"),
                                        (requestFor(maxNodes=1), "unknown"), (requestFor(maxEdges=0), "unknown")]:
            with self.subTest(options=options):
                reader = GraphReader([("root", "a", "CALLS")], extraNodes=["target"])
                result = NavigationService(reader).path(PathRequest("target", options))
                self.assertEqual(result["status"], expectedStatus)
                self.assertEqual(result["path"], [])
                self.assertEqual(result["truncated"], expectedStatus == "unknown")

    def testReachableTargetCannotBypassDepthOrResourceLimits(self):
        for options in (requestFor(depth=0), requestFor(maxNodes=1), requestFor(maxEdges=0)):
            with self.subTest(options=options):
                reader = GraphReader([("root", "target", "CALLS")])
                result = NavigationService(reader).path(PathRequest("target", options))
                self.assertEqual(result["status"], "unknown")
                self.assertEqual(result["path"], [])
        reader = GraphReader([("root", "target", "CALLS"), ("target", "tail", "CALLS")])
        result = NavigationService(reader).path(PathRequest("target", requestFor(depth=1)))
        self.assertEqual(result["path"], ["root", "target"])
        self.assertFalse(result["truncated"])
        self.assertEqual(reader.edgeCalls, ["root"])

    def testExternalIntermediateIsNotExpanded(self):
        reader = GraphReader([("root", "external", "CALLS"), ("external", "target", "CALLS")], externalNodes=["external"])
        result = NavigationService(reader).path(PathRequest("target", requestFor()))
        self.assertEqual(result["status"], "not_found")
        self.assertEqual(reader.edgeCalls, ["root"])

    def testContextStillExpandsAllReachableNodes(self):
        reader = GraphReader([("root", "a", "CALLS"), ("root", "b", "CALLS"),
                              ("a", "target", "CALLS"), ("b", "noise", "CALLS")])
        result = NavigationService(reader).context(requestFor())
        self.assertEqual(set(reader.edgeCalls), {"root", "a", "b", "target", "noise"})
        self.assertEqual(len(result["edges"]), 4)
        self.assertFalse(result["truncated"])

    def testDirectionRelationsExternalTargetsAndMissingKeys(self):
        for direction in ("in", "both"):
            with self.subTest(direction=direction):
                reader = GraphReader([("target", "root", "IMPORTS"), ("root", "wrong", "CALLS")], externalNodes=["target"])
                result = NavigationService(reader).path(PathRequest("target", requestFor(direction=direction, relations=["IMPORTS"])))
                self.assertEqual(result["path"], ["root", "target"])
                self.assertEqual(len(result["edges"]), 1)
                self.assertEqual(result["boundaries"], [{"stableKey": "target", "reason": "external_unresolved_or_ambiguous", "expandable": False}])
        reader = GraphReader([], extraNodes=["root"])
        with self.assertRaises(KeyError):
            NavigationService(reader).path(PathRequest("missing", requestFor()))
        self.assertEqual(reader.edgeCalls, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
