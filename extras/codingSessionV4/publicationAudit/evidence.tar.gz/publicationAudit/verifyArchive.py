"""Independent post-build archive verifier. Reads streams, never extracts or imports preparer."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
from typing import TypedDict, cast

from scanInputs import patterns, safeMember


class Member(TypedDict):
    sha256: str
    size: int
    mode: int


class Pin(TypedDict):
    record: str
    target: str
    sha256: str
    classification: str
    status: str


owned = Path('/home/leon/.cache/codingSessionV4Owned')
audit = owned / 'publicationAudit'
destination = Path('/home/leon/.t3/worktrees/matato-pi/codingSessionV4Experiment/extras/codingSessionV4')
root = Path('/tmp/codingSessionV4')


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def checkMember(member: tarfile.TarInfo, data: bytes, expected: Member) -> list[str]:
    errors: list[str] = []
    if not safeMember(member.name) or str(PurePosixPath(member.name)) != member.name:
        errors.append('unsafePath')
    if member.type != tarfile.REGTYPE or member.linkname:
        errors.append('nonRegularOrLink')
    if member.uid != 0 or member.gid != 0 or member.mtime != 0 or member.uname or member.gname or member.pax_headers:
        errors.append('unexpectedMetadata')
    if (hashlib.sha256(data).hexdigest(), len(data), member.size, member.mode) != (expected['sha256'], expected['size'], expected['size'], expected['mode']):
        errors.append('contentSizeOrModeMismatch')
    for label, pattern in patterns.items():
        if re.search(pattern, data):
            errors.append('secretPattern:' + label)
    return errors


def checkPins(observed: dict[str, Member]) -> dict[str, int | list[str]]:
    pins = cast(dict[str, list[Pin]], json.loads((audit / 'scans/independentPins.json').read_text()))['records']
    included = [pin for pin in pins if pin['classification'] == 'includedFrozenArtifact']
    errors: list[str] = []
    for pin in included:
        name = str(Path(pin['target']).relative_to(root))
        if name not in observed or observed[name]['sha256'] != pin['sha256']:
            errors.append(pin['record'] + ': archive pin mismatch: ' + name)
    return {'includedPinRecordsCheckedAgainstTarContent': len(included),
            'uniqueFrozenPinnedMembers': len({pin['target'] for pin in included}), 'errors': errors}


def main() -> None:
    expected = cast(dict[str, Member], json.loads((destination / 'evidenceMembers.json').read_text()))
    candidate = (owned / 'publicationPrep/candidateMembers.json').read_bytes()
    errors: list[dict[str, str]] = []
    if (destination / 'evidenceMembers.json').read_bytes() != candidate:
        errors.append({'path': 'evidenceMembers.json', 'pattern': 'notExactApprovedManifest'})
    counts: Counter[str] = Counter()
    observed: dict[str, Member] = {}
    with tarfile.open(destination / 'evidence.tar.gz', mode='r:gz') as archive:
        for member in archive:
            counts[member.name] += 1
            if member.name not in expected or counts[member.name] != 1:
                errors.append({'path': member.name, 'pattern': 'extraOrDuplicate'})
                continue
            stream = archive.extractfile(member)
            if stream is None:
                errors.append({'path': member.name, 'pattern': 'noContent'})
                continue
            data = stream.read()
            errors.extend({'path': member.name, 'pattern': label} for label in checkMember(member, data, expected[member.name]))
            observed[member.name] = {'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data), 'mode': member.mode}
    if set(observed) != set(expected):
        errors.append({'path': 'evidence.tar.gz', 'pattern': 'missingOrExtraMemberSet'})
    checksums = (destination / 'evidence.sha256').read_text().splitlines()
    actualChecksums = [digest(destination / name) + '  ' + name for name in ('evidence.tar.gz', 'evidenceMembers.json')]
    if checksums != actualChecksums:
        errors.append({'path': 'evidence.sha256', 'pattern': 'externalChecksumMismatch'})
    pinProof = checkPins(observed)
    if pinProof['errors']:
        errors.append({'path': 'evidence.tar.gz', 'pattern': 'frozenPinMismatch'})
    report = {'verifier': 'verifyArchive.py v1, Python stdlib; no preparer imports/no extraction',
              'allMembersRead': len(observed), 'allContentBytesRead': sum(item['size'] for item in observed.values()),
              'exactApprovedManifest': (destination / 'evidenceMembers.json').read_bytes() == candidate,
              'archiveSha256': digest(destination / 'evidence.tar.gz'),
              'manifestSha256': digest(destination / 'evidenceMembers.json'),
              'checksumFileSha256': digest(destination / 'evidence.sha256'),
              'archiveBytes': (destination / 'evidence.tar.gz').stat().st_size,
              'manifestBytes': (destination / 'evidenceMembers.json').stat().st_size,
              'executableMembers': sum(item['mode'] == 0o755 for item in observed.values()),
              'extensionlessArchiveMembers': [name for name in observed if not Path(name).suffix],
              'frozenPinProof': pinProof, 'errors': errors,
              'verified': not errors, 'selfCycleAbsent': not any(name in observed for name in ('evidence.tar.gz', 'evidenceMembers.json', 'evidence.sha256')),
              'metadata': 'regular files only; safe paths; no duplicate/extra/missing; SHA256/size/mode all matched; uid/gid/mtime zero, blank names, no pax metadata; separate content secret rescan'}
    (audit / 'scans/archiveVerification.json').write_text(json.dumps(report, indent=2) + '\n')
    (audit / 'scans/archiveMembersObserved.json').write_text(json.dumps(observed, indent=2, sort_keys=True) + '\n')
    print(json.dumps(report, indent=2))
    if errors:
        raise ValueError('Independent archive verification failed; see names/patterns only report')


if __name__ == '__main__':
    main()
