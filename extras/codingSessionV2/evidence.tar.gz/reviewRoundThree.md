# Independent review — round three

## Verdict

**A bounded combined-patch/repeated-file-work improvement, not an overall production-code or resource win.** Coding has **365 vs 372 combined churn lines**, but **112 vs 93 production churn lines** and **+38 vs +33 production net lines**. It actually shares decoded source lines: 100 same-file nodes now cause **1 vs 100 full-file transformations**, including failed decoding. This is useful reuse, not merely fewer reader-port calls. However, distinct-file retained memory increases, and this round **Ponytail**, not coding, uses Croner's production constructor more precisely.

All frozen original and supplemental acceptance checks pass both arms, without assertion changes. All focused native checks pass their own implementations. An additional cross-suite diagnostic exposes a **real distinction**: Ponytail's injected-factory empty-zone rollback test fails on coding. Both production/default factories reject empty/invalid zones correctly; neither provides factory-independent rejection of ordinary bad zones. Thus “no loss of any distinct behavior” would be too strong, even though the frozen standalone-worker acceptance domain passes.

If “less code” means the entire maintained patch, and efficiency means repeated-file transformation work, this pair supports that narrow outcome. If it means smaller production implementation, universal resource improvement, or strictly identical exported-factory behavior, it does not. Do not silently change the winning metric after seeing the results. This adaptively tuned third round does not establish profile causality or general superiority and is insufficient alone to justify a superiority-labelled PR/Ponytail removal.

No implementation, profile, brief, oracle, saved patch or parent-project code was edited. No delegation, fixes, cherry-picks, thresholds changed, commits, PR creation or removal. Added this report and review-only scripts/logs under `research/`.

## Integrity and exact accounting

Audited all eight production/test diffs, their callers and the complete structural contents of the minified snapshot changes. Actual `git diff --binary HEAD` equals each saved third-round patch after normalizing diff prefixes only. Actual numstats equal `thirdMetrics.json`. Candidate HEADs equal their corresponding clean base HEADs; all eight whitespace checks pass, with no untracked candidate files. Starting commits remain Atlas `64017b798a75fccff7d6d545172251851fcef615`, CSV `4b1e143abc40f4582d90bfcdc7c55b06d787a934`, scheduler `92ec28467170bb8b520ebe53dea234b7623dec46`.

The pre-run manifest covers **5,252 files**, including all tracked candidate/base files, profiles, patches, briefs and frozen checks. It is unchanged after native/cross/resource checks. Prior-round oracle/supplement hashes also match, and every supplemental SHA manifest verifies. Evidence: `research/reviewRoundThreeLogs/{inputHashes.json,immutability.json,finalImmutability.log,hygiene.json,manifests.log}`.

Cells are **added/deleted; churn; net**, relative to common starting commits. Tests include config tests, coffee assertions and snapshots.

| Case / variant | Production | Tests | Combined |
|---|---:|---:|---:|
| sourceBatchReads / Ponytail | 18/6; 24; +12 | 36/0; 36; +36 | 54/6; 60; +48 |
| sourceBatchReads / coding | 26/14; 40; +12 | 42/0; 42; +42 | 68/14; 82; +54 |
| isinCsvRecords / Ponytail | 24/16; 40; +8 | 49/0; 49; +49 | 73/16; 89; +57 |
| isinCsvRecords / coding | 24/15; 39; +9 | 54/0; 54; +54 | 78/15; 93; +63 |
| scheduleTimeZones / Ponytail | 13/3; 16; +10 | 106/5; 111; +101 | 119/8; 127; +111 |
| scheduleTimeZones / coding | 17/3; 20; +14 | 99/14; 113; +85 | 116/17; 133; +99 |
| pathEarlyExit / Ponytail | 8/5; 13; +3 | 74/9; 83; +65 | 82/14; 96; +68 |
| pathEarlyExit / coding | 8/5; 13; +3 | 34/10; 44; +24 | 42/15; 57; +27 |
| **Total / Ponytail** | **63/30; 93; +33** | **265/14; 279; +251** | **328/44; 372; +284** |
| **Total / coding** | **75/37; 112; +38** | **229/24; 253; +205** | **304/61; 365; +243** |

Coding's differences are **+19 production churn, −26 test churn, −7 combined churn**, and **+5 production net, −46 test net, −41 combined net**. The combined churn saving comes entirely from the path-test difference overcoming larger combined patches in the other three cases: **+22, +4, +6, −39** respectively. Source caching's larger churn is partly movement: its final service/helper files are **74/117 lines in both arms**. Production nevertheless remains larger in aggregate; there is no production shrink hidden in the totals.

### Formatting-independent and semantic accounting

There is no language-independent numeric “semantic complexity” measure here. To expose formatting effects, the audit also recomputes a diff after removing blank/comment-only lines and horizontal whitespace, retaining all other tokens and line boundaries. This **normalized-line proxy is not an operation count or proof of semantic equivalence**.

| Variant | Normalized source a/d; churn; net | Normalized tests a/d; churn; net | Normalized combined a/d; churn; net |
|---|---:|---:|---:|
| Ponytail | 60/26; 86; +34 | 242/12; 254; +230 | 302/38; 340; +264 |
| coding | 68/31; 99; +37 | 205/15; 220; +190 | 273/46; 319; +227 |

Source normalized churn by case is Ponytail **22/35/16/13**, coding **32/35/19/13**. CSV production is identical after normalization: coding's one-line raw churn advantage is just retaining a blank line, while its final file is one line longer. Traversal implementations are **AST-identical**; only their service call's positional/keyword spelling differs.

Python AST node counts, excluding location attributes, add **132 vs 136** in the source service/helper pair and **55 vs 56** in the path service/helper pair, Ponytail/coding. These include annotations and keyword nodes, not just executable work; they are structural observations, not complexity scores. Both arms add exactly **two production helper definitions** across the four cases: verified bytes/lines and the CSV reader helper. Neither adds a traversal helper, dependency, persistence layer or new production module.

All eight snapshot files are byte-identical between arms. Exactly **one successful response per language** changes, only `nodes`, `edges`, `boundaries`. Nodes/edges remain exact ordered prefixes ending at discovery/the route edge; path, status, schema, filters, metadata and all other responses are unchanged. Earlier retained external nodes still have the expected CLI boundary labels. Each arm removes **45 gathered nodes and 61 edges** across those eight responses. Their minified replacements count as **16 test churn lines**, not sixteen units of semantic change. No safety or limit assertion was deleted to approve them.

Reproducible audit: `research/auditRoundThree.py`. Its two handled missing-HEAD-file diagnostics concern newly added Go test files, not test failures. Detailed per-case physical/normalized counts, Python structure and snapshots: `research/reviewRoundThreeLogs/{verifiedMetrics.json,footprint.json,methodFootprint.log,snapshots.json,finalAudit.log}`.

## Checks executed

`research/runRoundThreeChecks.py` records commands, cwd, environment, output and exit status. All **42 runner entries** exit zero; these include import proofs and observations as well as tests. Base negative controls were already executed/logged in rounds one/two and **were not rerun this round**.

| Frozen suite | Ponytail third | coding third |
|---|---:|---:|
| Original source, 5 methods | pass | pass |
| Original CSV, 13 scenarios | pass | pass |
| Original scheduler, 7 tests | pass | pass |
| Original path, 8 methods | pass | pass |
| Existing source supplement, 3 methods | pass | pass |
| Existing CSV supplement, 12 scenarios | pass | pass |
| Existing scheduler supplement, 9 tests | pass | pass |
| Existing real-SQL supplement, 4 cases | pass | pass |
| Frozen round-two path supplement, 6 methods | pass | pass |

The ninth scheduler supplement observes installed dependency behavior; it is not an extra invented acceptance condition. CSV uses immutable public embedded-data overlays, not just the newly extracted helper. The SQL portable wrapper changes only the subprocess interpreter, not frozen assertions.

| Native check | Ponytail | coding |
|---|---:|---:|
| Source: `PYTHONPATH=src .venv/bin/python -m pytest tests/test_graph_navigation.py -q` | 49 pass | 50 pass |
| Path: same focused test file | 57 pass | 51 pass |
| Coffee snapshots, separately in both Python cases | 14 pass each | 14 pass each |
| `GOWORK=off GOPROXY=off GOSUMDB=off go test ./data -count=1 -v` | pass | pass |
| `bun test worker/scheduler.test.ts src/automationConfig.test.ts` | 17 pass | 15 pass |

Bun native checks pass independently in **Asia/Tokyo, UTC and America/Los_Angeles**. Python import logs explicitly resolve `atlas.services.navigation` to the actual candidate. Resource measurements use **CPython 3.11.16**, not an accidentally linked editable candidate; Bun is **1.4.1**, Go **1.26.1**, and both Croner paths resolve to the same installed **10.0.1** package. Version/path evidence: `environment.log` and `import-*` logs.

### Cross-suite diagnostic — one genuine behavioral difference

`research/crossTestsRoundThree.py` additionally runs each arm's native regression tests on the other's source, without changing either candidate: explicit Python import paths, temporary Go overlays and relocated Bun test imports. **Seven of eight cross invocations pass.** Source/path/CSV pass both ways; coding's scheduler tests pass Ponytail. Ponytail's scheduler tests on coding give **10 pass / 1 fail**:

> `invalid zone "" disposes candidates and preserves old schedules`: replacement did not throw with the injected callback-bearing Croner factory.

This is not a frozen-original failure or an import accident. Ponytail checks empty zones in `buildSchedules`; coding validates only inside its default factory. The injected factory bypasses that default validation, while Croner itself treats empty timezone as omitted. The script's nonzero exit and full failure are intentionally retained in `crossRunner.log`, `crossResults.json`, and `cross-ponytailThird-tests-on-codingThird-scheduleTimeZones.log`; no assertion was weakened to turn it green.

## Source batch: real transformation reuse, bounded query guarantee, memory tradeoff

Both preserve the clarified **reader.file verification-port** requirement: at most one verification lookup and local-byte read per distinct eligible path per call, including failures. External/pathless entries return before lookup. Neither deduplicates every SQL query. Real SQLite traces for ten repeated file keys, and separately ten repeated symbol keys, remain **42 SELECTs**, with **10 node-enrichment file-metadata queries and 1 verification query**; one node takes six SELECTs. These are the same costs in both arms. Do not claim O(distinct paths) total SQL or one total file-related query.

The new coding cache stores the reusable **decoded LF-coordinate line list**, rather than bytes every node must decode again:

```text
Ponytail: path → cached verification/bytes → decode+split per node → independent excerpt
coding:   path → cached verification/lines ───────────────────────→ independent excerpt
```

Both still slice and byte-check each consumer excerpt. Coding does not eliminate all per-node work. It does eliminate repeated full-file UTF-8 decoding, splitting and CRLF normalization; encoding failure is now a cached file-level result too.

| Same-file eligible nodes | Verification / reads / hashes, either arm | Ponytail decodes | coding decodes |
|---:|---:|---:|---:|
| 1 | 1 / 1 / 1 | 1 | 1 |
| 10 | 1 / 1 / 1 | 10 | 1 |
| 100 | 1 / 1 / 1 | 100 | 1 |

Those counts hold for both valid input and unsupported encoding. Two separate ten-node encoding-failure calls repeat verification twice in both, and decoding **20 vs 2** times. No negative result leaks across calls.

For 100 nodes sharing a **1,064,960-byte** file containing 16,384 distinct 64-character lines, full decode-helper calls are **100 vs 1** and input bytes handed to that helper **106,496,000 vs 1,064,960**. Eight distinct such files take eight verifications/eight decodes in both arms. This verifies reduced repeated transformation work; it is **not a measured 100× latency/scheduler-throughput improvement**. No timing speedup is claimed, including for failing decoding that may abort at its first byte.

Allocation probes use identical real-file workloads, one-line excerpts, GC disabled only during tracing, and no mocks during allocation measurements:

| Workload | Ponytail traced peak B | coding traced peak B |
|---|---:|---:|
| 20,000 ineligible entries | 4,027,664 | 4,027,664 |
| One distinct 1,064,960-byte/64-character-line file | 8,398,379 | 8,398,379 |
| Four distinct such files | 11,595,081 | 14,363,835 |
| Eight distinct such files | 15,857,529 | 22,317,955 |
| 100 nodes repeating one such file | 8,399,171 | 8,399,171 |
| Prior probe: four ~1 MiB files of very short lines | 13,585,020 | 24,504,119 |

The earlier double-materialization penalty for ineligible batches is gone: both now directly build final response dictionaries in one comprehension. However, retaining decoded line arrays across many distinct paths costs more than retaining their bytes, especially for short lines. The existing bounded-read allocation dominates these repeated-single-file peak measurements; fewer decodes do not automatically lower that peak. Both caches are per-call, but neither has a batch-wide memory cap. The unchanged 8 MiB limit is **per file**, not a decoded/batch allocation limit.

With the eight-file response retained after return, traced current allocations are only **6,840 vs 7,232 B**; this probe finds no whole-file cache surviving the call. Returned line lists are independently mutable. Sharing immutable strings is safe. These are synthetic **traced allocations**, not RSS, production workload distributions or latency benchmarks. Logs/scripts: `resources-*`, `old-resources-*`, `supplemental-*-sourceBatchReads.log`, `sql-*`, and `research/sourceResourcesRoundThree.py`.

### Safety, status precedence and changed internal signature

Structural AST checks confirm unchanged `local_bytes`, pinned-descriptor `contained_bytes`, `source_lines`, `source_status`, `excerpt_lines`, and both limits. Existing native safety tests cover containment/symlinks, FIFO/nonregular files, file/excerpt size bounds; frozen supplements cover the broader failure/recovery matrix. Verification still precedes decoding, which still precedes span/excerpt evaluation. Explicit combined-failure probes preserve **unverified before local safety, changed before invalid encoding, unsupported_encoding before missing span**, then independent span status. External/pathless entries remain unavailable without file access. Both public single-source and duplicate batch results agree in these probes.

Coding changes internal `verified_excerpt(node, bytes, options)` to accept decoded lines. Repository-wide Python caller search finds only its updated `source_excerpt` caller; no tests or other consumers directly invoke the old signature. Public `NavigationService.source`, request/response schemas and metadata stay unchanged. Single-source coding does allocate a temporary cache dictionary where Ponytail takes its uncached branch; behavior is preserved, not literally identical internal work. Evidence: `safetyAndCallers.log` and source-resource logs.

## CSV: same stdlib algorithm, no coding efficiency advantage

Both replace physical-line scanning with strict `encoding/csv`: unrestricted-width one-record header, then exactly three fields, errors checked before indexing, record limit checked before another `Read`, and early nonpositive return in the helper. Both still open/close the embedded file in the exported wrapper, including nonpositive limits. Both preserve whitespace, quoted commas/doubled quotes/multiline records/CRLF, large names, empty/header-only input and normal data; malformed quoting/width inside a requested prefix errors, and bad/oversized tails cannot invalidate a completed prefix.

Production differs only by a blank line. No parser dependency, `ReadAll`, custom CSV implementation, embedded-data change or README change. Both expose the same unexported `io.Reader` helper for native testing. Underlying buffering can prefetch suffix bytes; the guarantee is bounded **record parsing**, not an exact byte-read boundary.

Ponytail adds two Go test functions; coding three. Both cover thirteen table-driven data scenarios distributed differently, plus four embedded limit values. Ponytail explicitly tests a malformed header; coding separately tests trailing junk after a closing quote and malformed second records. Both cross suites and all 25 original/supplemental public-overlay scenarios pass. Coding's extra five test lines buy some distinct cases, not a smaller parser.

## Scheduler: native precision favors Ponytail this round

Both add `Automation.timezone?: string`, pass it through the existing factory seam, and let installed Croner handle scheduling. Stored config's existing spread preserves it; the worker uses the default factory. Both preserve paused candidate construction/atomic rollback, disabled-job inertness, duplicate/monitor/cron-mode checks, cross-reload overlap guards and terminal stop behavior. Frozen real-timer tests cover candidate cleanup and old-timer survival; both five/six-field Lord Howe half-hour DST cases pass. No config-wide zone, daily-session change, new dependency or date-conversion algorithm.

**The round-two scheduler advantage does not carry forward.** Ponytail now delegates ordinary zone validation to the actual callback-bearing Croner constructor and closes just its explicit-empty-string gap. Coding eagerly creates `Intl.DateTimeFormat` for every explicit zone inside its default factory. Its comment that paused jobs defer zone validation until after construction is inaccurate for this production callback path: Croner executes date logic while constructing it, before timer ownership is established.

Instrumented actual default factories produce **8 vs 9 formatter constructions** for one valid UTC or Kathmandu candidate, Ponytail/coding. Omitted zones use zero in both; empty rejects with **0 vs 1** constructions. Ordinary invalid zones use one and reject in both. Thus coding adds four production churn/net lines and one redundant formatter per valid zoned candidate here, not more precise native reuse. These counts are construction observations, not throughput measurements.

With an injected Croner factory that omits its callback, **both accept ordinary bad zones** because neither validates those outside the default factory. Ponytail still rejects empty before factory invocation; coding accepts it. The callback-bearing cross test exposes the same empty-zone difference. There is no production custom-factory caller in this repository, and existing cron validation was already factory-owned. Therefore actual-worker acceptance passes both; **if invalid-zone rejection is required for every exported injected-factory path, coding has a concrete remaining gap (and both need ordinary-invalid validation ownership clarified)**. Do not represent this as established factory-independent equivalence. Exact observations: `semantics-*`, dependency observations in scheduler supplements, `safetyAndCallers.log`, and the cross-suite failure.

Coding tests the real default factory using prototype spies and checks real candidate disposal. Ponytail reuses callback-bearing validation in its existing fake fixture and separately captures real zoned jobs for both cron widths, both DST transitions, local omission and fractional offsets. Coding's captured real-default jobs cover five-field New York and six-field Kathmandu, rather than every width/zone combination. Neither removes an existing scheduler behavior: coding parameterizes the old invalid-cron replacement test, preserving its original scenario, and adds an invalid-zone scenario. But its native suite lacks Ponytail's distinct injected-empty-zone rejection assertion; that omission must remain visible.

## Path: same implementation, smaller coding tests

Both third-round traversal modules are AST-identical. They reuse existing BFS, ordering, admission budgets, parent reconstruction and external-node rules; pass a target only from `path`; stop before expansion for identity; and return immediately after budget-checked target admission, before processing later neighbors or manufacturing fetch-limit/depth cutoffs. `context` leaves target absent and continues its full bounded traversal. Storage queries and public requests are unchanged.

The frozen path suites check deterministic diamond/cycle ties, both-direction edge deduplication, relation/direction filters, processed rows versus prefetched rows, preceding external boundaries, exact success limits, a **36-combination** budget grid, ordinary/external self-completion, missing start/target, exhausted not_found versus bounded unknown, and full context traversal. Both pass; no target bypasses admission limits. A storage fetch may already have returned later rows; the requirement is no later processing/adjacency request after discovery, not eliminating storage prefetch.

Ponytail adds four native functions expanding to twelve cases; coding adds two expanding to six and strengthens the existing coffee assertion from membership to an exact gathered-prefix check plus target/truncation assertions. Ponytail's added cases explicitly exercise in/both directions, preceding external boundaries and continued bounded context; coding's compact native additions rely more on existing/frozen coverage for these. Both native suites cross-pass against the other implementation. No base test function is removed or weakened. The **39-line test-churn saving is real**, but fewer added combinations is not proof that every Ponytail assertion was redundant.

## Method/fixture footprint and skill ceiling

| Case | Added production helper definitions, P/C | Added native test definition sites, P/C | New fixture/helper scaffolding |
|---|---:|---:|---|
| Source | 1 / 1 | 1 / 2 Python functions | No new fixture; same existing `graph` |
| CSV | 1 / 1 | 2 / 3 Go test functions | Reader injection in the production helper; compact tables |
| Scheduler | 0 / 0 | 3 / 2 Bun sites | Existing `setup` modified in both; no new fixture helper; existing config fixture extended |
| Path | 0 / 0 | 4 / 2 Python functions | Same existing `graph`; coding strengthens existing coffee method |

Bun definition sites are not runtime test counts (`test.each` expands); source/path Python counts likewise expand under parameterization. Both retain the original Python fixture and all base test functions. No implementation function exceeds 100 lines, no changed file exceeds 600 lines, and no complexity is hidden in a new dependency or moved production module. Logs preserve function names/modified definitions and exact file lengths.

Frozen `profiles/codingThird.md` measures **4,544 bytes / 618 whitespace words / 33 lines**, versus original **5,121 / 740 / 36**: **577 bytes / 122 words / 3 lines smaller**, inside every ceiling. It was not edited. No additional profile wording or task-specific recipe is proposed in this review.

## Disposition and replication

Keep the demonstrated lessons: compare whole adapters, and cache the reusable result that actually avoids repeated transformation. Here that removes the earlier native-adapter penalty and repeated decoding, while exposing a legitimate retained-memory tradeoff. Do not erase the opposite scheduler result, larger production patch, or factory-seam counterexample to manufacture an overall win.

**Yes: a fresh fixed-profile replication without further tuning is warranted before claiming robust superiority.** Freeze both current profiles, complete-arm evaluation, original requirements/oracles and separately reported source/test/combined/resource measures before fresh agents run. Include genuinely new tasks or a new blinded holdout; reusing these tasks alone only tests stochastic replication, not generalization. Do not select per-case winners, retune after this first positive combined result, or stop on a convenient metric. Report failed/inconclusive replications too. This guards adaptive stopping; another success would still not prove universal dominance.

No full-project suite/typecheck/lint, additive four-patch integration, live worker endurance, concurrent filesystem-swap stress, representative latency benchmark or RSS measurement was performed. Existing negative controls remain prior evidence, not reruns. Native/cross checks and synthetic allocation/work probes are the independent evidence claimed here.

Reproduce from `/tmp/codingSessionV2`:

```sh
python research/runRoundThreeChecks.py
python research/auditRoundThree.py
for v in ponytailThird codingThird; do
  runs/$v/sourceBatchReads/atlas/.venv/bin/python research/sourceResourcesRoundThree.py runs/$v/sourceBatchReads
done
python research/crossTestsRoundThree.py  # nonzero: preserves the disclosed injected-empty-zone failure
```

All logs are under `research/reviewRoundThreeLogs/`. The profile stays frozen; this review does not authorize changing the candidates or declaring the broader comparison finished.
