#!/usr/bin/python3
"""Execute the actual bootstrap and its dependency consumer with inert commands."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

fakeTool = r'''#!/bin/bash
set -euo pipefail
toolName=${0##*/}
{ printf '%s\037' "$PWD" "$toolName" "$@"; printf '\n'; } >> "$fixtureTrace"
case "$toolName" in
  uname) printf 'Linux\n' ;;
  sudo) if [[ "$fixtureFailDep" == 1 ]]; then exit 23; fi ;;
  chezmoi|mise|fallbackChez) exit "$fixtureLaunchStatus" ;;
  curl)
    case "$*" in
      *devpod-linux-amd64*) printf 'inert fixture\n' > devpod ;;
      *get.chezmoi.io*) printf 'exec "$fixtureBin/fallbackChez" "$@"\n' ;;
      *) printf ':\n' ;;
    esac
    ;;
esac
'''


def putExecutable(path: Path, content: str) -> None:
    path.write_text(content)
    path.chmod(0o755)


def prepareFixture(root: Path, stage: Path, route: str, spaced: bool) -> tuple[Path, Path, Path]:
    repo = stage / ('checkout with spaces' if spaced else 'checkout')
    repo.mkdir()
    for name in ('setup', 'manual_deps'):
        shutil.copy2(root / name, repo / name)
    home = stage / 'home with spaces'
    home.mkdir()
    binPath = stage / 'bin'
    binPath.mkdir()
    tools = ['uname', 'sudo', 'curl', 'chsh', 'zsh', 'rm', 'fallbackChez']
    tools += ['chezmoi'] if route == 'installed' else []
    tools += ['mise'] if route == 'mise' else []
    for name in tools:
        putExecutable(binPath / name, fakeTool)
    for name in ('bash', 'sh'):
        (binPath / name).symlink_to('/bin/' + name)
    for name in ('dirname', 'readlink', 'realpath', 'pwd'):
        (binPath / name).symlink_to('/usr/bin/' + name)
    if route == 'home':
        localBin = home / '.local' / 'bin'
        localBin.mkdir(parents=True)
        putExecutable(localBin / 'mise', fakeTool)
    (stage / 'archRelease').write_text('fixture\n')
    return repo, home, binPath


def readEvents(trace: Path) -> list[list[str]]:
    if not trace.exists():
        return []
    return [line.split('\x1f')[:-1] for line in trace.read_text().splitlines()]


def validateEvents(events: list[list[str]], repo: Path, route: str, failDeps: bool) -> list[str]:
    errors = []
    dependencies = [event for event in events if event[1] == 'sudo']
    launchers = [event for event in events if event[1] in ('chezmoi', 'mise', 'fallbackChez')]
    expectedDeps = [['pacman', '-Sy', '--noconfirm', 'git', 'zsh', 'xclip', 'docker']]
    if not failDeps:
        expectedDeps += [['install', '-c', '-m', '0755', 'devpod', '/usr/local/bin']]
    actualDeps = [event[2:] for event in dependencies]
    if actualDeps != expectedDeps or any(event[0] != str(repo) for event in dependencies):
        errors.append(f'dependency consumer must execute once from repository; got {dependencies!r}')
    expectedName = {'installed': 'chezmoi', 'mise': 'mise', 'home': 'mise', 'curl': 'fallbackChez'}[route]
    expectedArgs = ['init', '--apply', '--source', str(repo)]
    if route in ('mise', 'home'):
        expectedArgs = ['exec', 'chezmoi', '--', 'chezmoi'] + expectedArgs
    expectedLaunch = [] if failDeps else [[str(repo), expectedName] + expectedArgs]
    if launchers != expectedLaunch:
        errors.append(f'launcher argv/cwd mismatch; expected {expectedLaunch!r}; got {launchers!r}')
    if launchers and dependencies and events.index(launchers[0]) < events.index(dependencies[-1]):
        errors.append('launched chezmoi before completing dependency consumer')
    if any(event[1] == 'decoy' for event in events):
        errors.append('executed caller-local manual_deps decoy')
    if failDeps and dependencies and events[events.index(dependencies[0]) + 1:]:
        errors.append('continued after dependency failure')
    return errors


def runCase(root: Path, name: str, route: str, outside: bool, spaced: bool,
            relative: bool = False, decoy: bool = False, failDeps: bool = False,
            launchStatus: int = 0) -> bool:
    with tempfile.TemporaryDirectory(prefix='reserveFixture') as folder:
        stage = Path(folder)
        repo, home, binPath = prepareFixture(root, stage, route, spaced)
        caller = stage / 'caller with spaces' if outside else repo
        caller.mkdir(exist_ok=True)
        trace = stage / 'events'
        if decoy:
            putExecutable(caller / 'manual_deps', '#!/bin/bash\nprintf "%s\\037decoy\\037\\n" "$PWD" >> "$fixtureTrace"\n')
        script = os.path.relpath(repo / 'setup', caller) if relative else str(repo / 'setup')
        environment = {
            'HOME': str(home), 'USER': 'fixture', 'PATH': str(binPath),
            'fixtureBin': str(binPath), 'fixtureTrace': str(trace),
            'fixtureFailDep': '1' if failDeps else '0',
            'fixtureLaunchStatus': str(launchStatus),
        }
        command = ['/usr/bin/bwrap', '--unshare-all', '--die-with-parent',
                   '--ro-bind', '/', '/', '--bind', str(stage), str(stage),
                   '--ro-bind', str(stage / 'archRelease'), '/etc/arch-release',
                   '--proc', '/proc', '--dev', '/dev', '--chdir', str(caller), '--clearenv']
        for key, value in environment.items():
            command += ['--setenv', key, value]
        command += ['/bin/bash', script]
        result = subprocess.run(command, capture_output=True, text=True, timeout=10, check=False)
        events = readEvents(trace)
        errors = validateEvents(events, repo, route, failDeps)
        expectedStatus = 23 if failDeps else launchStatus
        if result.returncode != expectedStatus:
            errors.append(f'exit status expected {expectedStatus}; got {result.returncode}')
        print(f'{"FAIL" if errors else "PASS"} {name}')
        for error in errors:
            print(f'  {error}')
        if errors:
            print(f'  stderr: {result.stderr.strip()!r}')
            print(f'  events: {events!r}')
        return not errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--native', action='store_true')
    args = parser.parse_args()
    root = args.root.resolve()
    results = []
    if args.native:
        for route in ('installed', 'mise', 'home', 'curl'):
            results.append(runCase(root, f'native{route.title()}', route, False, False))
            results.append(runCase(root, f'native{route.title()}Failure', route, False, False, launchStatus=29))
        results.append(runCase(root, 'nativeDependencyFailure', 'installed', False, False, failDeps=True))
        return 0 if all(results) else 1
    results.append(runCase(root, 'installedUnrelatedCaller', 'installed', True, False))
    results.append(runCase(root, 'installedCallerDecoy', 'installed', True, True, decoy=True))
    results.append(runCase(root, 'installedSpacedSource', 'installed', False, True))
    results.append(runCase(root, 'relativeInvocation', 'installed', True, True, relative=True))
    for route in ('mise', 'home', 'curl'):
        results.append(runCase(root, f'{route}SpacedCaller', route, True, True, decoy=True))
        results.append(runCase(root, f'{route}SpacedSource', route, False, True))
    results.append(runCase(root, 'relocatedDependencyFailure', 'installed', True, True, failDeps=True))
    results.append(runCase(root, 'relocatedLauncherFailure', 'installed', True, True, decoy=True, launchStatus=29))
    return 0 if all(results) else 1


if __name__ == '__main__':
    raise SystemExit(main())
