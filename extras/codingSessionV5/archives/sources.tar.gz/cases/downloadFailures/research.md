# Selection and architectural fit

Compatible as a Bash scripting case. It exercises the real checked-in `manual_deps`, not an inline replacement. Distinct from the previous `setup` bootstrap-cwd task: `setup` remains unchanged, caller-directory behavior is out of scope, and the bug is downloaded-tool failure propagation.

`manual_deps:14–52` selects macOS/Arch/Debian package routes. Lines 30 and 45 own DevPod transfer/install/removal; line 54 owns SDKMAN transfer/execution; lines 56–61 own optional shell change and completion. `setup:11` invokes this installer before choosing chezmoi. The fix belongs at the failing phase owners in manual_deps. Replacing the outer bootstrap or modifying OS/package policy would cross the task boundary. Advancing to SDKMAN/shell change after a failed earlier phase is the detecting counterexample.

Source inspection and inert execution confirm two real shell hazards: HTTP failure bodies can be treated as successful transfers, and a failed non-final command in an AND-list does not provide the apparent set-e fail-fast behavior. Acceptance checks observable failure and phase ordering, not exact Bash source text or a prescribed fix.

Fixtures execute candidate bytes in Bubblewrap with all namespaces unshared and the host root read-only. Only approved-cache runtime is writable in the inner installer sandbox; source stays read-only there. /etc OS markers and uname select branches without touching host configuration. Fake curl/sudo/brew/chsh/zsh/rm never invoke the real tools. HTTP doubles model curl's failure flags; transport and install failures have independent nonzero statuses. SDKMAN's successful body invokes only an inert logging command. Original fixtures cover three successful OS routes, six Linux DevPod failures and two SDK failures. No package manager, service, network, credential, real-home or privileged installation is used.

There is no repository-owned behavioral Bash suite. Native coverage is explicitly limited to `bash -n manual_deps`; separately recorded successful inert routes are new positive controls, not mislabeled existing tests.

Third-language search: Elixir 1.20.4 is installed but beer-game-elixir has neither deps nor _build. Its business rules use Ecto (order_delivery/game schemas) or Phoenix/Plug (LiveSession and runner modules). LiveSessionStore's standard-library paths were inspected but no fresh confirmed dependency-free bug was established; put requires PubSub. No Ecto/Phoenix stubs were fabricated and no dependency installation attempted. Bash provides a confirmed executable alternative.
