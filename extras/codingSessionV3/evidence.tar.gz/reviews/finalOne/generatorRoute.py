import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch
from tests import update_coffee_snapshots as generator
from tests import variant_snapshot_support as variants

writes = []

def capture(path, content, **options):
    expected = path.read_text(encoding=options.get('encoding', 'utf-8'))
    actualJson, expectedJson = json.loads(content), json.loads(expected)
    assert actualJson == expectedJson, str(path)
    writes.append(dict(path=str(path), bytes=len(content.encode()), hash=hashlib.sha256(content.encode()).hexdigest(), exactBytes=content == expected))
    return len(content)

sys.argv = ['update_coffee_snapshots.py', '--navigation']
with patch.object(generator, 'LANGUAGES', ('python',)), patch.object(variants, 'variant_groups', return_value=['python']), patch.object(Path, 'write_text', capture):
    generator.main()
print(json.dumps(writes, indent=2))
assert writes
print('Real maintained generator, Python seam selection, all emitted JSON parsed completely and matched; snapshot writes intercepted.')
