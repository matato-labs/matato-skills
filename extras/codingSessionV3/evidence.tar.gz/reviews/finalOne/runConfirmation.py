import hashlib
import io
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import subprocess
import tarfile
import time
from runReview import root, review, results, paths, git, pythonPrefix

records = json.loads((review / 'confirmationCommands.json').read_text()) if (review / 'confirmationCommands.json').exists() else []
extraTemp = review / 'confirmationTemp'
extraTemp.mkdir(exist_ok=True)

def run(label, command, folder):
    if any(r['label'] == label for r in records):
        return
    log = review / 'commands' / (label + '.log')
    start = time.monotonic()
    with log.open('w') as output:
        output.write(f'CWD {folder}\nCOMMAND {command}\n')
        output.flush()
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', CI='1', DO_NOT_TRACK='1', TMPDIR=str(extraTemp))
        process = subprocess.Popen(['bash', '-c', command], cwd=folder, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=120)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            code = 124
        seconds = round(time.monotonic() - start, 3)
        output.write(f'\nEXIT {code}\nSECONDS {seconds}\n')
    records.append(dict(label=label, command=command, cwd=str(folder), exit=code, seconds=seconds, output=str(log), sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    (review / 'confirmationCommands.json').write_text(json.dumps(records, indent=2))
    print(label, code, seconds, flush=True)
    for p in extraTemp.iterdir():
        shutil.rmtree(p) if p.is_dir() and not p.is_symlink() else p.unlink()

for arm in ['candidateThree', 'main', 'pr', 'ponytail']:
    folder = review / 'copies' / arm / 'sessionTreeConfinement'
    target = review / 'probes' / (arm + 'StableSessionConfirmation.test.ts')
    target.write_text((review / 'stableSessionConfirmation.ts').read_text().replace('candidateRoot/', str(folder) + '/'))
    home = extraTemp / 'home'
    home.mkdir(exist_ok=True)
    run(arm + 'StableSessionConfirmation', f'HOME="{home}" bun test "{target}"', folder)
