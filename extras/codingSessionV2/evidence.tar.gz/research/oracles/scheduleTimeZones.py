#!/usr/bin/env python3
"""Run a Bun oracle with real Croner, recording its jobs without replacing date logic."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

repoPath = Path(sys.argv[1]).resolve()
cronPath = str(repoPath / "node_modules/croner/dist/croner.js")
schedulerPath = str(repoPath / "worker/scheduler.ts")
automationPath = str(repoPath / "src/automation.ts")
configPath = str(repoPath / "src/automationConfig.ts")
testSource = r'''
import { afterEach, expect, mock, test } from "bun:test";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Cron as RealCron } from __cronPath__;
import type { Automation } from __automationPath__;
import { loadAutomationConfig } from __configPath__;

const cronJobs: Array<RealCron> = [];
class ObservedCron extends RealCron {
  constructor(...args: ConstructorParameters<typeof RealCron>) {
    super(...args);
    cronJobs.push(this);
  }
}
mock.module(__cronPath__, () => ({ Cron: ObservedCron }));
const { createScheduler }: typeof import(__schedulerPath__) = await import(__schedulerPath__);
type ZonedAutomation = Automation & { timezone?: string };
const cleanups: Array<() => void> = [];
afterEach(() => {
  for (const cleanup of cleanups.splice(0)) cleanup();
  for (const job of cronJobs.splice(0)) job.stop();
});

function jobFor(overrides: Partial<ZonedAutomation> = {}): ZonedAutomation {
  return { jobName: "daily", enabled: true, schedule: "0 9 * * *", userPrompt: "run",
    canOverlap: false, model: "test", thinkingLevel: "off", canLaunchSubAgents: false,
    useSkill: false, ...overrides };
}
function schedulerFor() {
  const scheduler = createScheduler({ run: async () => {}, onError: () => {} });
  cleanups.push(scheduler.stop);
  return scheduler;
}
function nextAt(job: RealCron, reference: string): string | undefined {
  return job.nextRun(new Date(reference))?.toISOString();
}

test("each job uses its own zone, including non-hour offsets and six fields", () => {
  const scheduler = schedulerFor();
  scheduler.replace([
    jobFor({ jobName: "newYork", timezone: "America/New_York" }),
    jobFor({ jobName: "kathmandu", timezone: "Asia/Kathmandu", schedule: "0 0 9 * * *" }),
    jobFor({ jobName: "utc", timezone: "UTC" }),
  ]);
  expect(scheduler.names()).toEqual(["newYork", "kathmandu", "utc"]);
  expect(cronJobs.map(job => nextAt(job, "2026-01-15T00:00:00Z"))).toEqual([
    "2026-01-15T14:00:00.000Z", "2026-01-15T03:15:00.000Z", "2026-01-15T09:00:00.000Z",
  ]);
});

test("daylight-saving changes affect future wall-clock schedules", () => {
  schedulerFor().replace([jobFor({ timezone: "America/New_York" })]);
  const job = cronJobs[0];
  expect(nextAt(job, "2026-03-07T00:00:00Z")).toBe("2026-03-07T14:00:00.000Z");
  expect(nextAt(job, "2026-03-08T00:00:00Z")).toBe("2026-03-08T13:00:00.000Z");
  expect(nextAt(job, "2026-11-01T00:00:00Z")).toBe("2026-11-01T14:00:00.000Z");
});

test("omitted zone retains process-local time", () => {
  schedulerFor().replace([jobFor()]);
  expect(nextAt(cronJobs[0], "2026-01-14T23:00:00Z")).toBe("2026-01-15T00:00:00.000Z");
});

test("bad enabled zone rejects replacement atomically and stops candidates", () => {
  const scheduler = schedulerFor();
  scheduler.replace([jobFor({ jobName: "old", timezone: "UTC" })]);
  const oldJob = cronJobs[0];
  expect(() => scheduler.replace([
    jobFor({ jobName: "candidate", timezone: "Asia/Tokyo" }),
    jobFor({ jobName: "invalid", timezone: "Mars/Olympus" }),
  ])).toThrow();
  expect(scheduler.names()).toEqual(["old"]);
  expect(oldJob.isStopped()).toBe(false);
  expect(cronJobs[1].isStopped()).toBe(true);
});

test("disabled invalid zones stay inert, duplicate and cron validation remain", () => {
  const scheduler = schedulerFor();
  scheduler.replace([jobFor({ jobName: "enabled", timezone: "UTC" }),
    jobFor({ jobName: "disabled", enabled: false, timezone: "Mars/Olympus", schedule: "bad", monitor: true })]);
  expect(scheduler.names()).toEqual(["enabled"]);
  expect(() => scheduler.replace([jobFor({ schedule: "0 0 0 * * * 2026", timezone: "UTC" })])).toThrow();
  expect(() => scheduler.replace([jobFor(), jobFor({ enabled: false })])).toThrow("Duplicate jobName");
  expect(scheduler.names()).toEqual(["enabled"]);
});

test("timezone reloads preserve overlap guards and stop behavior", async () => {
  let release: () => void = () => {};
  const pending = new Promise<void>(resolve => { release = resolve; });
  let calls = 0;
  const scheduler = createScheduler({
    run: async () => { calls += 1; await pending; }, onError: () => {},
  });
  cleanups.push(scheduler.stop);
  scheduler.replace([jobFor({ timezone: "UTC" })]);
  const firstRun = cronJobs[0].trigger();
  await cronJobs[0].trigger();
  scheduler.replace([jobFor({ timezone: "Europe/Berlin" })]);
  await cronJobs[1].trigger();
  expect(calls).toBe(1);
  expect(cronJobs[0].isStopped()).toBe(true);
  release();
  await firstRun;
  await cronJobs[1].trigger();
  expect(calls).toBe(2);
  scheduler.stop();
  await cronJobs[1].trigger();
  expect(calls).toBe(2);
  expect(scheduler.names()).toEqual([]);
});

test("stored zones reach the scheduler without disturbing legacy defaults", async () => {
  const folder = await mkdtemp(join(tmpdir(), "scheduleZoneOracle"));
  try {
    const file = join(folder, "automations.json");
    const { canOverlap, useSkill, ...legacyJob } = jobFor({ timezone: "Europe/Berlin" });
    await writeFile(file, JSON.stringify({ automations: [legacyJob] }));
    const config = await loadAutomationConfig(file);
    expect(config.automations[0].canOverlap).toBe(false);
    expect(config.automations[0].useSkill).toBe(true);
    schedulerFor().replace(config.automations);
    expect(nextAt(cronJobs[0], "2026-01-15T00:01:00Z")).toBe("2026-01-15T08:00:00.000Z");
  } finally { await rm(folder, { recursive: true, force: true }); }
});
'''
for token, value in {"__cronPath__": cronPath, "__schedulerPath__": schedulerPath,
                     "__automationPath__": automationPath, "__configPath__": configPath}.items():
    testSource = testSource.replace(token, json.dumps(value))
with tempfile.TemporaryDirectory(prefix="scheduleZoneOracle") as tempPath:
    testPath = Path(tempPath) / "scheduleTimeZones.test.ts"
    testPath.write_text(testSource)
    result = subprocess.run(["bun", "test", str(testPath)], cwd=repoPath,
                            env={**os.environ, "TZ": "Asia/Tokyo"}, timeout=30)
sys.exit(result.returncode)
