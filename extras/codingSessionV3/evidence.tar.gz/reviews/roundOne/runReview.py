import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tarfile
import time

root = Path('/tmp/codingSessionV3')
review = root / 'reviews/roundOne'
records = []

def git(folder, *args):
    return subprocess.check_output(['git', '-C', str(folder), *args])

def fingerprint(folder):
    paths = git(folder, 'diff', '--name-only', '-z').decode().split('\0')
    return {name: hashlib.sha256((folder / name).read_bytes()).hexdigest()
            for name in paths if name and (folder / name).is_file() and name != 'node_modules'}

def run(label, command, folder):
    log = review / 'commands' / (label + '.log')
    log.parent.mkdir(exist_ok=True)
    start = time.monotonic()
    with log.open('w') as output:
        output.write('CWD ' + str(folder) + '\nCOMMAND ' + command + '\n')
        output.flush()
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', CI='1', DO_NOT_TRACK='1')
        proc = subprocess.Popen(['bash', '-c', command], cwd=folder, env=env,
                                stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = proc.wait(timeout=120)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait()
            code = 124
        elapsed = round(time.monotonic() - start, 3)
        output.write(f'\nEXIT {code}\nSECONDS {elapsed}\n')
    record = dict(label=label, command=command, cwd=str(folder), exit=code, seconds=elapsed, output=str(log))
    records.append(record)
    (review / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    return record

def prepare(result, case):
    source = Path(result['worktree'])
    target = review / 'copies' / result['arm'] / result['case']
    target.mkdir(parents=True)
    archive = review / (result['arm'] + result['case'] + '.tar')
    archive.write_bytes(git(source, 'archive', result['base']))
    with tarfile.open(archive) as stream:
        stream.extractall(target, filter='data')
    archive.unlink()
    changed = git(source, 'diff', '--name-only', '-z').decode().split('\0')
    for name in changed:
        if not name or name == 'node_modules':
            continue
        origin, destination = source / name, target / name
        if origin.is_file():
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(origin, destination)
        elif destination.exists():
            destination.unlink()
    if result['case'] == 'memoryReferenceResolution':
        (target / 'node_modules').symlink_to(Path(case['repo']) / 'node_modules', target_is_directory=True)
    return target

def maintained(caseId, folder, result, suffix=''):
    if caseId == 'pythonUnicodeGraphFind':
        command = f'cd "{folder}/atlas" && PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTEST_ADDOPTS= PYTHONPATH="{folder}/atlas/src:{folder}/atlas" /home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B -m pytest -q -p no:cacheprovider --basetemp="{review}/temp/{result["arm"]}{caseId}Maintained{suffix}" tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py'
    elif caseId == 'memoryReferenceResolution':
        home = review / 'temp' / (result['arm'] + 'Home' + suffix)
        home.mkdir(parents=True, exist_ok=True)
        command = f'HOME="{home}" bun test src/storage/memoryBlock.test.ts src/storage/database.test.ts src/agent/matatoAgentTools.test.ts'
    else:
        tests = sorted(folder.glob('test/beer_game/quantity*test.exs'))
        expression = 'ExUnit.start(seed: 0); ' + '; '.join(f'Code.require_file("{path}")' for path in tests)
        command = f'elixir -pa "/tmp/codingSessionV3/research/elixir/runtime/lib/*/ebin" -r "lib/beer_game/game/*.ex" -e \'{expression}\''
    return command

def trial(result, case):
    folder = prepare(result, case)
    label = result['arm'] + result['case']
    run(label + 'Acceptance', case['checkCommand'].format(root=folder), folder)
    command = case['nativeCommand'].format(root=folder).replace('/tmp/codingSessionV3/research/python/tuning/nativeTemp', str(review / 'temp' / (label + 'Native')))
    run(label + 'Native', command, folder)
    run(label + 'Maintained', maintained(result['case'], folder, result), folder)
    if result['arm'] != 'candidateOne':
        return
    # Separate copies leave the experiment, positive copy and shared dependencies untouched.
    negative = review / 'negative' / result['case']
    shutil.copytree(folder, negative, symlinks=True)
    production = [entry['path'] for entry in result['files'] if entry['category'] == 'production']
    for name in production:
        (negative / name).write_bytes(git(Path(result['worktree']), 'show', result['base'] + ':' + name))
    run(label + 'BaseNegative', maintained(result['case'], negative, result, 'Base'), negative)
    if result['case'] == 'pythonUnicodeGraphFind':
        # Run each changed test file separately, so an early graph failure cannot hide coffee failure.
        command = maintained(result['case'], negative, result, 'CoffeeBase').replace('tests/test_graph_navigation.py ', '')
        run(label + 'CoffeeBaseNegative', command, negative)

cases = {}
for language in ['python', 'typescript', 'elixir']:
    for case in json.loads((root / 'research' / language / 'tuning/manifest.json').read_text())['cases']:
        cases[case['id']] = case
results = [json.loads(path.read_text()) for path in sorted((root / 'runs/tuningOne').glob('*/*/result.json'))]
before = {result['worktree']: fingerprint(Path(result['worktree'])) for result in results}
(review / 'before.json').write_text(json.dumps(before, indent=2))
# Serial execution avoids shared frozen runner temporary-directory and resource collisions.
for result in results:
    trial(result, cases[result['case']])
after = {result['worktree']: fingerprint(Path(result['worktree'])) for result in results}
(review / 'after.json').write_text(json.dumps(after, indent=2))
assert before == after
print(json.dumps(records, indent=2))
