"""Independent V4 patch/live-byte accounting and publication-doc consistency checks."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
from typing import TypeAlias, TypedDict, cast

JsonValue: TypeAlias = str | int | float | bool | None | list['JsonValue'] | dict[str, 'JsonValue']


class FileMetric(TypedDict):
    path: str
    category: str
    added: int
    deleted: int
    churn: int
    baseBytes: int
    resultBytes: int
    byteGrowth: int
    normalizedAdded: int
    normalizedDeleted: int
    binary: bool


class Row(TypedDict):
    draw: str
    arm: str
    case: str
    status: str
    agentExit: int | None
    acceptanceExit: int | None
    nativeExit: int | None
    profileSha256: str | None
    categories: dict[str, dict[str, int]]
    qualification: str


root = Path('/tmp/codingSessionV4')
owned = Path('/home/leon/.cache/codingSessionV4Owned')
audit = owned / 'publicationAudit'
bound = Path('/home/leon/.t3/worktrees/matato-pi/codingSessionV4Experiment')
errors: list[str] = []
checks: list[dict[str, str | int | bool]] = []
metricKeys = ['added', 'deleted', 'churn', 'baseBytes', 'resultBytes', 'byteGrowth', 'normalizedAdded', 'normalizedDeleted']


def readJson(path: Path) -> JsonValue:
    return cast(JsonValue, json.loads(path.read_text()))


def category(path: str, recorded: str) -> str:
    return 'production' if path == 'setup' else recorded


def patchCounts(patch: Path) -> dict[str, tuple[int, int]]:
    command = ['git', 'apply', '--numstat', '--', str(patch)]
    result = subprocess.run(command, cwd=audit, capture_output=True, text=True, check=True, timeout=20)
    values: dict[str, tuple[int, int]] = {}
    for line in result.stdout.splitlines():
        added, deleted, path = line.split('\t', 2)
        values[path] = (int(added), int(deleted))
    return values


def baseFolder(case: str) -> Path:
    if case == 'pythonConfinedIgnoreFiles':
        return root / 'research/python/base'
    if case == 'shellBootstrapLocation':
        return root / 'research/additional/base/dotfiles'
    return root / 'research/typescript/base'


def checkRow(row: Row) -> None:
    identity = '/'.join(row[key] for key in ('draw', 'arm', 'case'))
    folder = root / 'runs' / identity
    try:
        trial = cast(dict[str, JsonValue], readJson(folder / 'result.json'))
    except (FileNotFoundError, ValueError):
        if row['status'] != 'unavailable' or row['categories']:
            errors.append('Missing/truncated output represented as metric: ' + identity)
        return
    for key in ('status', 'agentExit', 'acceptanceExit', 'nativeExit', 'profileSha256'):
        if row[key] != trial[key]:
            errors.append('Frozen status differs: ' + identity + '/' + key)
    files = cast(list[FileMetric], trial.get('files', []))
    totals: dict[str, dict[str, int]] = {}
    for item in files:
        target = totals.setdefault(category(item['path'], item['category']), {key: 0 for key in metricKeys})
        for key in metricKeys:
            target[key] += item[key]
    if totals != row['categories']:
        errors.append('Result aggregation differs: ' + identity)
    if not (folder / 'changes.patch').exists():
        return
    counts = patchCounts(folder / 'changes.patch')
    if set(counts) != {item['path'] for item in files}:
        errors.append('Patch/file inventory differs: ' + identity)
    for item in files:
        inspectFile(identity, row['case'], item, counts)


def inspectFile(identity: str, case: str, item: FileMetric, counts: dict[str, tuple[int, int]]) -> None:
    path = item['path']
    base = baseFolder(case) / path
    live = root / 'worktrees' / identity / path
    baseSize = base.stat().st_size if base.exists() else 0
    liveSize = live.stat().st_size if live.exists() else 0
    match = (counts.get(path) == (item['added'], item['deleted']) and
             (baseSize, liveSize, liveSize - baseSize) == (item['baseBytes'], item['resultBytes'], item['byteGrowth']))
    checks.append({'identity': identity, 'path': path, 'patchAndLiveBytesMatch': match,
                   'baseBytes': baseSize, 'resultBytes': liveSize})
    if not match:
        errors.append('Patch/live metrics differ: ' + identity + '/' + path)


def finalTotals(rows: list[Row]) -> dict[str, JsonValue]:
    values: dict[str, JsonValue] = {}
    for draw in ('finalOne', 'finalTwo'):
        arms: dict[str, JsonValue] = {}
        for arm in ('v3', 'v2', 'ponytail', 'candidateTwo'):
            selected = [row for row in rows if row['draw'] == draw and row['arm'] == arm]
            prod = {key: sum(row['categories'].get('production', {}).get(key, 0) for row in selected) for key in metricKeys}
            combined = {key: sum(value[key] for row in selected for value in row['categories'].values()) for key in metricKeys}
            arms[arm] = {'production': prod, 'combined': combined}
        values[draw] = arms
    return values


def checkCopies() -> dict[str, str]:
    hashes: dict[str, str] = {}
    for phase in ('ablationOne', 'tuningOne', 'tuningTwo', 'finalOne', 'finalTwo'):
        source = root / 'reviews' / phase / 'review.md'
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        hashes[phase] = digest
        if source.read_bytes() != (bound / 'extras/codingSessionV4/report' / (phase + '.md')).read_bytes():
            errors.append('Published review copy differs: ' + phase)
    for name in ('plan.json', 'candidateOneDecision.json', 'candidateTwoDecision.json', 'historicalInspection.md', 'finalFreeze.json', 'profilePins.json'):
        if (root / name).read_bytes() != (bound / 'extras/codingSessionV4' / name).read_bytes():
            errors.append('Published metadata copy differs: ' + name)
    return hashes


def main() -> None:
    publication = cast(dict[str, JsonValue], readJson(bound / 'extras/codingSessionV4/results.json'))
    rows = cast(list[Row], publication['implementations'])
    for row in rows:
        checkRow(row)
    hashes = checkCopies()
    if publication['independentReviewHashes'] != hashes:
        errors.append('Published review hashes differ')
    ledger = cast(dict[str, JsonValue], readJson(root / 'control/budget.json'))
    invocationCount = sum((root / 'runs' / row['draw'] / row['arm'] / row['case'] / 'invocation.json').exists() for row in rows)
    runtime = (bound / 'skills/coding-session/SKILL.md').read_bytes()
    profile = (root / 'profiles/candidateTwo.md').read_bytes()
    if runtime != profile or len(runtime) != 2630:
        errors.append('Runtime differs from frozen candidate')
    counts = {'requested': len(rows), 'reservations': ledger['reserved'], 'reservationIdentities': len(cast(list[str], ledger['runs'])), 'actualInvocationArtifacts': invocationCount}
    if (counts['requested'], counts['reservations'], counts['actualInvocationArtifacts']) != (52, 51, 50):
        errors.append('Execution identity counts differ')
    exits = {draw: {key: dict(Counter(str(row[key]) for row in rows if row['draw'] == draw))
                   for key in ('status', 'agentExit', 'acceptanceExit', 'nativeExit')}
             for draw in ('ablationOne', 'tuningOne', 'tuningTwo', 'finalOne', 'finalTwo')}
    report = {'errors': errors, 'counts': counts, 'originalStatuses': exits, 'finalTotals': finalTotals(rows),
              'reviewHashes': hashes, 'patchLiveMetricFilesChecked': len(checks), 'checks': checks,
              'runtimeBytes': len(runtime), 'runtimeSha256': hashlib.sha256(runtime).hexdigest(),
              'sourceQuality': 'Independent production patch inspection agrees with retained reviews: canonical-root guard, async finally lifetime/exact absent sentinel and existing transaction owner preserved; candidate snapshot-first owned seam gap persists. No new behavioral executions by publication auditor.',
              'limits': 'Frozen original rows and selected changed-file bytes checked; metadata/code bytes separate. No full historical exhaustive rehash. No mutation score.'}
    (audit / 'scans/metricsAndDocs.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key != 'checks'}, indent=2))


if __name__ == '__main__':
    main()
