# Reserve validation: literal SQLite filesystem paths

## Source-derived requirement

`atlas/src/atlas/persistence/database.py:26-29` resolves the desired filesystem path and interpolates it into a SQLite URL string. URL parsing can then reinterpret characters in an otherwise valid POSIX path. A direct base probe of `graph?literal.sqlite` created the sibling `graph`, not the requested file. The oracle also demonstrates percent-decoding of an encoded-looking literal name and accidental parsing of filename text as connection options.

`database.py:18-23` centralizes DATABASE_PATH/XDG defaults. `database.py:48-65` and `:69-78` route explicit migrations and repository sessions through the same engine factory. In contrast, read-only navigation in `atlas/src/atlas/persistence/navigation_database.py:42-47` already constructs a URL object from an escaped file URI. Consequently writes can target one path while read-only navigation correctly looks for the intended file. This is a concrete local-data correctness problem, not a request for arbitrary URL support.

```mermaid
flowchart LR
    A["explicit path or configured default"] --> B["shared create_engine"]
    C["migrate_database"] --> B
    D["repository session and graph writes"] --> B
    B --> E["requested literal SQLite file"]
    F["read-only navigation URL"] --> E
```

The diagram describes inspected factory call paths; it does not imply read navigation invokes a writer.

## Language, dependency, and reuse opportunities

This is a deliberately small production fix with a substantial maintained-regression surface, not an excuse to redesign migrations. Python `pathlib` already supplies expansion, absolute resolution, and parent creation; these behaviors should be reused unchanged. Installed SQLAlchemy's structured URL API is relevant to separating database-path data from URL syntax. Its existing engine events preserve sqlite3 transaction control, foreign keys, busy timeout, and migration-time WAL configuration. No ad-hoc escaping table, parallel engine factory, new dependency, schema change, or filename validation framework is warranted.

The primary production touch point is `persistence/database.py`; `persistence/navigation_database.py` and `services/factories.py` supply integration context. Existing `test_persistence.py`, `test_graph_transactions.py`, `test_graph_migrations.py`, and `test_database_cli.py` are natural regression coverage. Per AGENTS.md, this connection/path lifecycle logic is outside the indexing/check/report/navigation algorithms and warrants unit coverage, plus focused production-boundary integration assertions. The oracle does not require a particular file layout or implementation.

## Why the oracle discriminates

The executable oracle imports only the supplied worktree's production modules. It tests both Path and string inputs against ordinary filenames, spaces/Unicode, `#`, percent-encoded-looking literals, `?`, connection-option-looking suffixes, and a question mark in a parent directory. Separate cases exercise DATABASE_PATH, XDG_DATA_HOME, relative paths, and home expansion. Ordinary/space/hash round trips already pass on base, demonstrating the test setup is not simply broken.

Each round trip runs explicit migration twice, registers a repository, verifies duplicate-name conflict recovery, persists a small graph using the real store, reopens via the service, lists via the CLI, and reads via read-only navigation. Independent sqlite3 integrity and row checks establish that all access paths reached the intended physical file. `PRAGMA database_list` on the production engine tests the direct connection boundary; foreign-key state is observed as behavior, not event-listener source shape. Existing native tests additionally protect broader transaction/migration behavior.

A prefix sibling containing sentinel bytes must remain untouched while the requested database is created. Directory inventories reject extra truncated or decoded databases while permitting normal WAL, SHM, and rollback-journal sidecars. Percent literals reject a partial fix that only quotes question marks; parent-directory and environment cases reject basename-only or explicit-argument-only fixes. Filename text resembling options must not configure connection timeout/URI behavior.

All files and databases are private temporary resources beneath `validation/`; no user's database or optional service is involved. Unexpected storage exceptions are converted into explicit assertion failures describing the required path behavior, so negative-control evidence is not counted as infrastructure success. The final base run has 14 assertion failures, no unittest errors, across seven tests. Its native baseline is 23 passing tests. Draft evidence is preserved separately; the final oracle corrected an overly strict sidecar check before freezing. No production patch or patched-positive control was implemented.
