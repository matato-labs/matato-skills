import concurrent.futures
import difflib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/tmp/codingSessionV4')
out = root / 'reviews/tuningOne'
private = Path('/dev/shm/codingSessionV4tuningReview')
private.mkdir(exist_ok=True)
(out / 'logs').mkdir(exist_ok=True)
specification = importlib.util.spec_from_file_location('reviewSandbox', root / 'sandboxTrial.py')
helper = importlib.util.module_from_spec(specification)
specification.loader.exec_module(helper)
python = '/home/leon/workspace/projects/atlas/atlas/.venv/bin/python'
cases = [json.loads((root / path).read_text())['cases'][0] for path in ['research/python/manifest.json', 'research/typescript/tuning/manifest.json']]
checksums = {}
metrics = {}
audit = {}
jobs = []
wrapper = "bun test src/worker/bus/preScript.test.ts && bun test src/worker/scheduledJobs/preScript.test.ts -t 'runs a TypeScript pre-script module|runs a shell pre-script|runs the product-manager|throws when a pre-script|throws when a TypeScript'"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def archive(case: dict, target: Path) -> None:
    target.mkdir(parents=True)
    data = subprocess.check_output(['git', '-C', case['repo'], 'archive', case['base']])
    with tarfile.open(fileobj=io.BytesIO(data)) as packed:
        packed.extractall(target, filter='data')
    if case['id'] == 'preScriptEnvironmentLifetime':
        (target / 'node_modules').symlink_to(Path(case['repo']) / 'node_modules')


def runJob(case: dict, arm: str, target: Path, label: str, command: str, timeout: int) -> dict:
    runtime = private / 'runtime' / arm / case['id'] / label
    oracle = root / ('research/python' if case['id'] == 'pythonConfinedIgnoreFiles' else 'research/typescript/tuning')
    repo = Path(case['repo'])
    dependencies = [Path('/home/leon/.local/share/uv/python/cpython-3.11-linux-x86_64-gnu'), Path('/home/leon/.cache/tree-sitter-language-pack/v1.20.0/libs')] if case['id'] == 'pythonConfinedIgnoreFiles' else []
    spec = {'worktree': target, 'repo': repo, 'common': repo / '.git', 'oracle': oracle, 'runtime': runtime, 'profile': out / 'unused', 'profileSnapshot': out / 'unused', 'config': out / 'unused', 'auth': out / 'unused', 'dependencies': dependencies, 'pi': Path('/home/leon/.local/share/mise/installs/pi/1.1.0/pi/pi')}
    log = out / 'logs' / arm / case['id']
    log.mkdir(parents=True, exist_ok=True)
    result = helper.shell(spec, label, command, log, timeout)
    print(arm, case['id'], label, result['exit'], result['seconds'], flush=True)
    return {'arm': arm, 'case': case['id'], 'label': label, **result}


def category(name: str) -> str:
    if '/snapshots/' in name:
        return 'snapshots'
    if '/fixtures/' in name:
        return 'fixtures'
    return 'tests' if '/tests/' in name or '.test.' in name else 'production'


for case in cases:
    caseId = case['id']
    original = private / 'original' / caseId
    archive(case, original)
    jobs.append((case, 'original', original, 'frozenBehavior', case['checkCommand'].replace('{root}', str(original)), 240))
    for arm in ['v3', 'v2', 'ponytail', 'candidateOne']:
        trial = root / 'runs/tuningOne' / arm / caseId
        live = root / 'worktrees/tuningOne' / arm / caseId
        target = private / arm / caseId
        archive(case, target)
        patch = (trial / 'changes.patch').read_bytes()
        subprocess.run(['git', 'apply', '--unsafe-paths', '-p1', '-'], input=patch, cwd=target, check=True)
        changed = subprocess.check_output(['git', '-C', live, 'diff', '--name-only']).decode().splitlines()
        untracked = subprocess.check_output(['git', '-C', live, 'ls-files', '--others', '--exclude-standard']).decode().splitlines()
        changed += [name for name in untracked if name != 'node_modules']
        details = []
        for name in sorted(set(changed)):
            baseFile = original / name
            newFile = target / name
            old = baseFile.read_bytes() if baseFile.exists() else b''
            new = newFile.read_bytes()
            assert new == (live / name).read_bytes(), name
            checksums[f'{arm}/{caseId}/{name}'] = digest(new)
            difference = subprocess.run(['git', 'diff', '--no-index', '--numstat', '--', str(baseFile) if baseFile.exists() else '/dev/null', str(newFile)], stdout=subprocess.PIPE, check=False).stdout.decode()
            added, deleted = map(int, difference.split()[:2])
            oldLines = [line.strip() for line in old.decode().splitlines() if line.strip()]
            newLines = [line.strip() for line in new.decode().splitlines() if line.strip()]
            normalized = list(difflib.unified_diff(oldLines, newLines, n=0))
            diagnosticAdded = sum(line.startswith('+') and not line.startswith('+++') for line in normalized)
            diagnosticDeleted = sum(line.startswith('-') and not line.startswith('---') for line in normalized)
            details.append({'path': name, 'category': category(name), 'additions': added, 'deletions': deleted, 'churn': added + deleted, 'baseBytes': len(old), 'resultBytes': len(new), 'byteGrowth': len(new) - len(old), 'baseLines': len(old.splitlines()), 'resultLines': len(new.splitlines()), 'nonblankStrippedAdditions': diagnosticAdded, 'nonblankStrippedDeletions': diagnosticDeleted})
        metrics[f'{arm}/{caseId}'] = details
        profile = (trial / 'currentProfile.md').read_bytes()
        invocation = json.loads((trial / 'invocation.json').read_text())
        agent = json.loads((trial / 'agent.json').read_text())
        audit[f'{arm}/{caseId}'] = {'profileBytes': len(profile), 'profileSha256': digest(profile), 'profileAudit': json.loads((trial / 'profileAudit.json').read_text()), 'argvTail': invocation['argv'][invocation['argv'].index('--print'):], 'agentExit': agent.get('exit'), 'agentTimeout': agent.get('timedOut'), 'agentSeconds': agent.get('seconds'), 'agentBudget': agent.get('timeoutSeconds'), 'promptSha256': digest((trial / 'prompt.txt').read_bytes()), 'base': subprocess.check_output(['git', '-C', live, 'rev-parse', 'HEAD']).decode().strip()}
        for label, key in [('frozenBehavior', 'checkCommand'), ('frozenNative', 'nativeCommand')]:
            jobs.append((case, arm, target, label, case[key].replace('{root}', str(target)), 420 if caseId == 'pythonConfinedIgnoreFiles' and label == 'frozenNative' else 240))
        negative = private / (arm + 'OriginalProduction') / caseId
        archive(case, negative)
        for item in details:
            if item['category'] != 'production':
                destination = negative / item['path']
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes((target / item['path']).read_bytes())
        if caseId == 'preScriptEnvironmentLifetime':
            jobs.append((case, arm, target, 'addedMaintained', 'bun test src/worker/preScript.test.ts', 180))
            jobs.append((case, arm, target, 'changedLint', 'bun node_modules/eslint/bin/eslint.js src/worker/preScript.ts src/worker/preScript.test.ts src/worker/bus/preScript.test.ts src/worker/scheduledJobs/preScript.test.ts', 180))
            jobs.append((case, arm, negative, 'originalProductionWrappers', wrapper, 180))
            negativeCommand = 'bun test src/worker/preScript.test.ts'
        else:
            extra = ' tests/test_coffee_pipeline.py' if arm == 'ponytail' else ''
            negativeCommand = f'cd atlas && PYTHONPATH="{negative}/atlas/src" {python} -B -m pytest -p no:cacheprovider -q tests/test_discovery.py tests/test_atlasignore.py{extra}'
        jobs.append((case, arm, negative, 'originalProductionMaintained', negativeCommand, 180))

case = cases[1]
for arm in ['v3', 'reuseAblation']:
    negative = private / ('ablation' + arm + 'OriginalProduction') / case['id']
    archive(case, negative)
    live = root / 'worktrees/ablationOne' / arm / case['id']
    for name in ['src/worker/bus/preScript.test.ts', 'src/worker/scheduledJobs/preScript.test.ts']:
        (negative / name).write_bytes((live / name).read_bytes())
    jobs.append((case, 'ablation' + arm, negative, 'originalProductionWrappers', wrapper, 180))

(out / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
(out / 'audit.json').write_text(json.dumps(audit, indent=2) + '\n')
for path in [root / 'reviewContract.md', root / 'plan.json', root / 'candidateOneDecision.json', root / 'sandboxTrial.py', out / 'supplementPlan.json', out / 'reviewRunner.py']:
    checksums[str(path)] = digest(path.read_bytes())
for case in cases:
    folder = root / ('research/python' if case['id'] == 'pythonConfinedIgnoreFiles' else 'research/typescript/tuning')
    for path in folder.iterdir():
        if path.is_file():
            checksums[str(path)] = digest(path.read_bytes())
(out / 'checksums.json').write_text(json.dumps(checksums, indent=2) + '\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(lambda args: runJob(*args), jobs))
(out / 'commands.json').write_text(json.dumps(results, indent=2) + '\n')
