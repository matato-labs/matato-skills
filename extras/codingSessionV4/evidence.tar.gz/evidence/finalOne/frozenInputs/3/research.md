# V4 reserve research: fourth-language feasibility

Language: Bash (shell), distinct from V3 Python, TypeScript, and Elixir. Project: existing local dotfiles, `/home/leon/workspace/projects/dotfiles`. Pinned committed HEAD: `a372e3293f2efad088b7719a693127042d26a1af`. Owned detached disposable checkout: `/tmp/codingSessionV4/research/additional/base/dotfiles`. No implementation was made.

## Selection and instruction review

Inspected the tracked shell entrypoints in dotfiles and omarchy-dotfiles without running them live. Searched existing workspace projects for Cargo.toml and go.mod through depth six, excluding node_modules and .git; no local Rust or Go package was found within that inventory. The Bash task is independently meaningful, so the Elixir fallback was not needed. No projects were cloned. No credential files or live home configuration were inspected, and no original source, README, system configuration, or home configuration was changed.

Checked AGENTS.md at the repository and each ancestor through filesystem root: none applies to the selected repository beyond the supplied session instructions. Its tracked tree has no AGENTS.md. The original repository had no working-tree edits, as captured in originalStatus.txt; the detached checkout ignores uncommitted state by construction and was verified clean after research. Instructions and material belonging to other projects were not treated as dotfiles instructions.

## Native-facility opportunity

The maintained bootstrap currently conflates caller location with source location. That is a real installation boundary: it invokes a relative dependency consumer and hands its chosen source path to an external configuration manager. Bash has native script provenance, parameter expansion, quoted argument boundaries, directory-changing semantics, and fail-fast execution for expressing the intended boundary without a replacement runtime or a dependency. This exercises shell behavior rather than importing a Python-style validation problem into another language.

The scope is one maintained source file, setup. The existing manual_deps remains unmodified and is an important actual consumer: its commands create a relative devpod artifact and install package dependencies before configuration is applied. It must run from the correct source context, not an unrelated caller directory. The brief preserves installer order and all existing launch routes rather than replacing the package-management design.

```mermaid
flowchart LR
  caller[Unrelated caller / relative invocation] --> setup[Actual setup bytes]
  setup --> deps[Actual manual_deps bytes]
  setup --> launcher[Installed / PATH mise / HOME mise / shell fallback]
  deps --> fake[Inert command fixtures]
  launcher --> trace[Captured argv, cwd, status]
  fake --> trace
```

## Behavioral evidence and safety

behaviorCheck.py copies setup and manual_deps byte-for-byte from its supplied checkout into disposable fixtures. It executes those actual Bash scripts, not a translated model, and makes assertions only about observed process status and command events. There are no source-string, source-length, LOC, or implementation-shape assertions. The source constraint and use of native Bash are brief requirements, not text-based tests.

Each process runs in bubblewrap with all namespaces isolated, no network, a read-only host filesystem, and only its own temporary fixture tree writable. HOME and PATH are replaced; package managers, privilege escalation, downloads, shell changes, and configuration-manager launchers are inert fake commands. The original dependency consumer's real control flow runs, but its downstream operations cannot install software, use credentials, change services, or access the network. The only emitted download bodies are local inert shell text. The standard harmless dirname, realpath, readlink, and pwd utilities are available for ordinary implementations. No real package manager or configuration manager runs.

The reserve oracle has twelve interacting behavior cases covering unrelated callers, a caller-local dependency decoy, spaced source paths, relative invocation, each launch route, dependency failure, and selected-launcher failure. All twelve fail against unchanged committed HEAD; negative.log records real errors, events, argument boundaries, and exit statuses. Failures include missing relative dependency execution, wrong caller-local dependency execution, and fragmented source arguments. No mutation or candidate implementation was needed to establish the failures.

There are no maintained test files for these entrypoints. The nativeCommand therefore exercises the maintained affected consumers directly under the same isolation: setup and its unchanged manual_deps, from the conventional repository working directory. Its nine baseline compatibility cases all pass on committed HEAD, including every launcher success/failure route and dependency fail-fast. This separates an actually working existing usage from the proposed behavior, and checks that the fixtures themselves support all existing routes.

## Frozen reserve contract

brief.txt, behaviorCheck.py, negative.log, native.log, manifest.json, this research note, originalStatus.txt, and sourceHashes.txt are frozen read-only before implementation. freezeHashes.txt records their SHA-256 digests; its own digest is the reserve bundle identity. sourceHashes.txt separately pins the original two entrypoints. manifest.json is the only manifest created and has exactly the requested single reserve case. There is no aggregate manifest exposing this reserve.

The manifest's repo is the owned base checkout, not the original. Its setupCommands use the caller-substituted {root}, check syntax without execution, and verify that namespace isolation is available. checkCommand runs the reserve behavior oracle; nativeCommand runs the maintained consumers' compatibility cases. Both commands accept an independent candidate checkout via {root}. Neither fetches dependencies. SourcePaths contains only setup.

Do not run setup or manual_deps directly outside the supplied isolated harness. Do not communicate the brief, implementation direction, or detailed behavior cases in the parent-facing result: report language, project, base commit, artifact paths, hash, and feasibility only.
