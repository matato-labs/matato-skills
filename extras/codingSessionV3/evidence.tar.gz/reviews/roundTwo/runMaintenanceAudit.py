from pathlib import Path

review = Path('/tmp/codingSessionV3/reviews/roundTwo')
source = (review / 'runReview.py').read_text().split('\ncases = {}')[0]
exec(source.replace("'commands.json'", "'maintenanceCommands.json'"))
folder = review / 'copies/candidateTwo/pythonUnicodeGraphFind'
command = pythonPrefix(folder) + '''/home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B - <<'PY'
from pathlib import Path
from unittest.mock import patch
from tests.update_coffee_snapshots import write_navigation

writes = []
def capture(path, content, **options):
    writes.append(str(path))
    return len(content)

with patch.object(Path, 'write_text', capture):
    write_navigation('python')
print('Existing Python navigation generator write targets:', writes)
assert len(writes) == 1 and writes[0].endswith('/python/navigation.json')
assert all(not path.endswith('/unicode_find.json') for path in writes)
print('New unicode_find.json is not regenerated. No snapshot files written by this audit.')
PY'''
run('candidateSnapshotGeneratorRoute', command, folder)
