from pathlib import Path
import ast
import json
import re

out = Path(__file__).parent
runs = Path('/home/leon/.cache/codingSessionV5/harness/runs/initialReady')
summary = []
traces = []
snapshots = []
for arm in sorted(runs.iterdir()):
    label = {'26cf': 'A', 'b167': 'B', 'ba68': 'C'}[arm.name.split('.')[1][:4]]
    for run in sorted(arm.iterdir()):
        evidence = run / 'evidence'
        audit = json.loads((evidence / 'audit.json').read_text())
        result = json.loads((evidence / 'result.json').read_text())
        row = {'label': label, 'path': str(run), 'status': result['status'],
               'agent': json.loads((evidence/'agent.json').read_text()),
               'checks': result['checks'], 'audit': {k: audit.get(k) for k in ['valid','settled','aborted','toolStarts','toolEnds','turns','replyWords']}}
        patch = (evidence / 'changes.patch').read_text()
        paths = re.findall(r'^diff --git a/(.*?) b/.*$', patch, re.M)
        row['files'] = []
        for path in paths:
            p = run/'workspace'/path
            item = {'path': path, 'symlink': str(p.readlink()) if p.is_symlink() else None}
            if p.is_file() and not p.is_symlink():
                text = p.read_text()
                item['lines'] = len(text.splitlines())
                if p.suffix == '.py':
                    tree = ast.parse(text)
                    item['functionsOver99'] = [{'name': n.name, 'line': n.lineno, 'lines': n.end_lineno-n.lineno+1} for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.end_lineno-n.lineno+1 >= 100]
            row['files'].append(item)
        summary.append(row)
        traces.append(f'\n## {label} {run.name}')
        starts = {}
        for line in (evidence / 'toolTrace.jsonl').read_text().splitlines():
            event = json.loads(line)
            if event['event'] == 'tool_execution_start':
                starts[event['id']] = event
                action = event.get('command') or event.get('path') or ''
                traces.append(f"START {event['name']} {action} timeout={event.get('timeout')}")
            else:
                start = starts.pop(event['id'], {})
                traces.append(f"END {event['name']} ms={event.get('durationMs')} error={event.get('isError')} bytes={event.get('payloadBytes')}")
        if starts:
            traces.append('UNFINISHED '+json.dumps(list(starts.values())))
        for chunk in patch.split('diff --git ')[1:]:
            path = chunk.splitlines()[0].split(' b/')[1]
            if '/snapshots/' not in path or not path.endswith('.json'):
                continue
            minus = [line[1:] for line in chunk.splitlines() if line.startswith('-') and not line.startswith('---')]
            plus = [line[1:] for line in chunk.splitlines() if line.startswith('+') and not line.startswith('+++')]
            before, after = json.loads('\n'.join(minus)), json.loads('\n'.join(plus))
            snap = {'label': label, 'path': path, 'addedKeys': sorted(set(after)-set(before)) if isinstance(after,dict) else [], 'removedKeys': sorted(set(before)-set(after)) if isinstance(after,dict) else []}
            if isinstance(after,dict):
                snap['changedExistingKeys'] = [k for k in before if k in after and before[k] != after[k]]
                snap['unchangedExistingCount'] = sum(before[k] == after[k] for k in before if k in after)
            snapshots.append(snap)
(out/'inventory.json').write_text(json.dumps(summary, indent=2)+'\n')
(out/'traces.txt').write_text('\n'.join(traces)+'\n')
(out/'snapshotChanges.json').write_text(json.dumps(snapshots, indent=2)+'\n')
print('Saved inventory.json, traces.txt, snapshotChanges.json')
