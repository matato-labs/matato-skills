import collections
import json
from pathlib import Path
import subprocess

root = Path('/tmp/codingSessionV3')
review = root / 'reviews/roundTwo'

def compare(before, after, path, counts, examples):
    if before == after:
        return
    if isinstance(before, dict) and isinstance(after, dict):
        for key in sorted(before.keys() | after.keys()):
            compare(before.get(key), after.get(key), path + '/' + key, counts, examples)
        return
    if isinstance(before, list) and isinstance(after, list):
        if len(before) != len(after):
            counts['listLengthChanges'] += 1
        for index in range(max(len(before), len(after))):
            compare(before[index] if index < len(before) else None,
                    after[index] if index < len(after) else None,
                    path + '/' + str(index), counts, examples)
        return
    counts[path.split('/')[1] if '/' in path else path] += 1
    if len(examples) < 12:
        examples.append(dict(path=path, before=str(before)[:250], after=str(after)[:250]))

summaries = []
for file in sorted((root / 'runs/tuningTwo').glob('*/pythonUnicodeGraphFind/result.json')):
    result = json.loads(file.read_text())
    folder = Path(result['worktree'])
    changed = subprocess.check_output(['git', '-C', str(folder), 'diff', '--name-only', '-z']).decode().split('\0')
    for name in changed:
        if '/snapshots/' not in name:
            continue
        after = json.loads((folder / name).read_text())
        previous = subprocess.run(['git', '-C', str(folder), 'show', result['base'] + ':' + name], capture_output=True)
        before = json.loads(previous.stdout) if previous.returncode == 0 else None
        counts, examples = collections.Counter(), []
        compare(before, after, '', counts, examples)
        summaries.append(dict(arm=result['arm'], path=name, new=before is None,
                              topLevel=list(after) if isinstance(after, dict) else len(after),
                              changes=counts, examples=examples))
(review / 'snapshotAudit.json').write_text(json.dumps(summaries, ensure_ascii=False, indent=2) + '\n')
print(json.dumps([{key: value for key, value in entry.items() if key != 'examples'} for entry in summaries], ensure_ascii=False, indent=2))
