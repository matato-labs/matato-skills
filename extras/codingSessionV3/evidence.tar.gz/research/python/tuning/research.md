# Tuning: Unicode literal graph search

## Source-derived requirement

`atlas/src/atlas/persistence/navigation.py:79-96` implements `GraphReader.find` with SQLAlchemy `instr(lower(field), lower(query))` and repeats `lower()` in its exact-match ranks. SQLite's built-in lower function is ASCII-only in this environment. Thus normal indexed multilingual names are searchable under some spellings but not their caseless equivalents. The unchanged base returns only the raw key `STRASSE` and the ASCII-named declaration for query `STRASSE`, omitting Straße-named, qualified-name, and path matches. `CAFÉ` returns no café declaration.

`atlas/src/atlas/services/navigation.py:22-24` owns limit-plus-one truncation and response assembly. `atlas/src/atlas/persistence/navigation_database.py:42-69` owns the private, existing-file-only read-only connection lifecycle. Those boundaries constrain a realistic small-to-medium backend change: search predicate/rank behavior and, if needed, read-connection configuration, not graph extraction or database storage. Existing project-name matching in `navigation.py:42` and `repositories.py:102` is intentionally separate and must not change.

```mermaid
flowchart LR
    A["graph find CLI"] --> B["NavigationService.find"]
    B --> C["GraphReader.find: match and rank"]
    C --> D["SQLAlchemy ORM select"]
    D --> E["read-only SQLite snapshot"]
    B --> F["limit, metadata, path diagnostics"]
```

This flow is established by the inspected CLI/factories/service/reader source, not inferred from dependency edges.

## Language, dependency, and reuse opportunities

Python's Unicode-aware string operations, nullable text handling, and small typed callbacks are directly relevant. `str.casefold` supplies the semantic distinction from ASCII lowering, including expanding ß and unifying Greek sigma variants. Standard-library sqlite3 supports per-connection functions; installed SQLAlchemy already owns expression construction and connection events. A solver can reuse those boundaries instead of duplicating schema inspection, snapshot management, DTO projection, or CLI formatting. This is an opportunity, not a required implementation design. No new dependency or persisted normalized search column is needed.

Likely production touch points are `persistence/navigation.py` and possibly `persistence/navigation_database.py`. Reuse `services/navigation.py` rather than reimplementing limit/diagnostic behavior. Maintained coverage should follow AGENTS.md's coffee-sample/navigation-snapshot strategy, with existing focused navigation regressions retained. Relevant test paths and the coffee Python fixture root are listed in the manifest; the oracle's synthetic graph fixtures are independent evaluation inputs, not a prescription for repository test style.

## Why the oracle discriminates

The oracle migrates a private temporary database and writes a normalized graph using real `repository_store`, then queries real `navigation_service` and Click CLI code. Its own fixture includes exact names, a qualified-name-only match, a path-only match, a substring name, an external record, and exact stable-key controls. No production result supplies expected keys.

The fixed ordered answer for `STRASSE` separates filter-only fixes from complete rank fixes: raw stable key first, internal exact names before the external exact name, exact qualified name before substrings, and original tie ordering. A full Unicode path query separates file-first exact-path ranking from generic name search. Queries in both directions exercise folding the query as well as stored text. Greek final sigma distinguishes case folding from ordinary Unicode lowercasing; accents and Cyrillic prevent an ß-only special case.

Limits 1, 2, 7, 8, and 20 straddle an eight-result answer and verify the service's truncation boundary. Metadata/query echo, fresh connections, path-scoped diagnostics, and a second repository constrain integration. Literal `%`, `_`, `!`, and backslash queries reject wildcard interpretations. Accent stripping, canonical normalization, and caseless stable-key lookup are explicitly excluded. A logical database dump before/after verifies navigation leaves persisted data/schema unchanged, without brittle SQLite file-byte or query-shape assertions.

`negativeControl.log` records 12 assertion failures, no errors, over eight tests on base. Existing native tests all pass: 52 passed, 7 non-Python sample snapshots deselected. Setup/native/oracle wall times are recorded in the root research report. A full repaired implementation was not attempted, so these are verified negative controls and feasibility measurements, not a claim of patched-positive success.
