"""Offline reporting regressions; synthetic evidence and disposable Git only, never a model."""
from copy import deepcopy
from dataclasses import asdict, replace
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from typing import cast
import unittest

from evidenceTypes import FileMeasure
from measureTrial import loc
from summarizeResults import (Case, Measurement, Profile, Result, Run, armTotals, comparisons,
                              completeSum, compressed, derive, derivedCategory, digest, direction,
                              gitQuote, patchSections, profiles, readRun, runMetrics, setupDependency, total)


def fileMeasure(path: str, kind: str = 'other', before: bytes = b'', after: bytes = b'') -> FileMeasure:
    return {'path': path, 'category': kind, 'binary': False, 'added': len(after.splitlines()),
            'deleted': len(before.splitlines()), 'addedBytes': len(after), 'deletedBytes': len(before),
            'baseBytes': len(before), 'resultBytes': len(after), 'byteGrowth': len(after) - len(before),
            'beforeLoc': loc(before), 'afterLoc': loc(after)}


def patch(path: str, added: bytes, mode: str = '100644') -> bytes:
    return (b'diff --git ' + gitQuote('a/' + path) + b' ' + gitQuote('b/' + path) + b'\n' +
            f'new file mode {mode}\n--- /dev/null\n'.encode() + b'+++ ' + gitQuote('b/' + path) +
            b'\n@@ -0,0 +1 @@\n+' + added + b'\n\\ No newline at end of file\n')


def measurement(files: list[FileMeasure], changes: bytes) -> Measurement:
    # Captured totals are deliberately not derived: exact preservation is asserted separately.
    return {'base': 'base', 'patchSha256': digest(changes), 'patchBytes': len(changes), 'files': files,
            'totals': {}, 'scope': 'captured scope', 'locNote': 'captured LOC', 'compressionNote': 'captured compression'}


def caseSpec() -> Case:
    target = '/offline/node_modules'
    return {'id': 'workspaceCheckoutRoots', 'repo': '/absent', 'base': 'base', 'sourcePaths': [],
            'dependencyPaths': [target], 'setupCommands': [f'ln -s "{target}" "{{root}}/node_modules"']}


def capturedResult() -> Result:
    return {'identity': 'draw/arm/workspaceCheckoutRoots', 'status': 'completed', 'modelLaunched': True,
            'base': 'base', 'native': True, 'arm': 'nativeVariant',
            'agent': {'exit': 0, 'timedOut': False, 'seconds': 2.0, 'timeoutSeconds': 600},
            'audit': {'valid': True, 'profileSha256': 'profile', 'turns': 2, 'toolStarts': 3,
                      'toolEnds': 3, 'replyWords': 4, 'outputWords': 10, 'permissionDenials': None,
                      'usage': {'tokens': {'input': 1, 'output': 2, 'cacheRead': 3, 'cacheWrite': 0,
                                           'cacheWrite1h': None, 'reasoning': None, 'totalTokens': 6},
                                'piReportedCostUsd': {'input': 0.1, 'output': 0.2, 'cacheRead': 0.3,
                                                      'cacheWrite': 0.0, 'total': 0.6},
                                'actualBilledCostUsd': None, 'unavailable': ['cacheWrite1h', 'reasoning'],
                                'unavailableCost': []}},
            'measurement': measurement([], b''), 'checks': {'acceptance': 0, 'native': 0}, 'seconds': 3.0}


def saveJson(path: Path, value: Result | Case | dict[str, str] | dict[str, bool]) -> None:
    path.write_text(json.dumps(value))


def evidence(root: Path, result: Result) -> Path:
    folder = root / 'draw' / 'arm' / 'workspaceCheckoutRoots' / 'evidence'
    folder.mkdir(parents=True)
    result = deepcopy(result)
    result['profileSha256'] = digest(b'frozen profile')
    saveJson(folder / 'result.json', result)
    (folder / 'manifest.json').write_text(json.dumps({'cases': [caseSpec()]}))
    (folder / 'profile.md').write_bytes(b'frozen profile')
    (folder / 'changes.patch').write_bytes(b'')
    (folder / 'finalSummary.txt').write_text('PRIVATE REPLY CONTENT OMITTED')
    saveJson(folder / 'activation.json', {'valid': True})
    saveJson(folder / 'integrity.json', {path.name: digest(path.read_bytes()) for path in folder.iterdir()})
    return folder


def mapping() -> dict[str, Profile]:
    return {'testArm': Profile('profile.md', digest(b'frozen profile'), None, None)}


class SummaryTests(unittest.TestCase):
    def testDerivedExtensionlessUsesActualBaseSource(self):
        with TemporaryDirectory() as name:
            repo = Path(name)
            subprocess.run(['git', 'init', '-q', name], check=True)
            source = b'#!/bin/bash\necho original\n'
            (repo / 'manual_deps').write_bytes(source)
            (repo / 'manual_deps').chmod(0o755)
            subprocess.run(['git', '-C', name, 'add', 'manual_deps'], check=True)
            subprocess.run(['git', '-C', name, '-c', 'user.name=Test', '-c', 'user.email=test@example.invalid',
                            'commit', '-qm', 'base'], check=True)
            item = fileMeasure('manual_deps', before=source, after=b'#!/bin/bash\necho result\n')
            changes = b'diff --git a/manual_deps b/manual_deps\n@@ -2 +2 @@\n-echo original\n+echo result\n'
            captured = measurement([item], changes)
            original = deepcopy(captured)
            spec = {**caseSpec(), 'base': 'HEAD', 'sourcePaths': ['manual_deps']}
            totals, corrections, excluded = derive(captured, changes, cast(Case, spec), repo)
            self.assertEqual(captured, original)
            self.assertEqual(totals['production'].churn, 4)
            self.assertEqual(totals['other'].files, 0)
            self.assertEqual(corrections[0].baseMode, '100755')
            self.assertEqual(corrections[0].baseSha256, digest(source))
            self.assertEqual(excluded, [])

    def testSourcePathsAloneDoNotProveExecutableContent(self):
        item = fileMeasure('manual_deps')
        self.assertEqual(derivedCategory(item, ['manual_deps'], '100755', b'plain data', b'')[0], 'other')
        # A shebang added in the middle of an existing non-script is not a first-line shebang.
        self.assertEqual(derivedCategory(item, ['manual_deps'], '100755', b'plain data',
                                        patch('manual_deps', b'#!/bin/bash'))[0], 'other')
        self.assertEqual(derivedCategory(item, [], '100755', b'#!/bin/bash', b'')[0], 'production')

    def testNewExecutableAndTestSeparation(self):
        for path, expected in [('tool', 'production'), ('tests/tool', 'tests'),
                               ('tests/fixtures/tool', 'fixtures'), ('tests/snapshots/tool', 'snapshots')]:
            item = fileMeasure(path, 'other' if expected in ('production', 'tests') else expected)
            self.assertEqual(derivedCategory(item, [], None, b'', patch(path, b'#!/bin/sh', '100755'))[0], expected)

    def testSetupExclusionAllArmsOnlyKnownLink(self):
        item = fileMeasure('node_modules', after=b'/offline/node_modules')
        changes = patch('node_modules', b'/offline/node_modules', '120000')
        spec = caseSpec()
        for arm in ('ponytail', 'ponytailNarrative', 'legacyNative'):
            with self.subTest(arm=arm):
                totals, corrections, excluded = derive(measurement([item], changes), changes, spec, Path('/absent'))
                self.assertEqual(excluded, ['node_modules'])
                self.assertEqual(totals['combined'].files, 0)
                self.assertEqual(totals['combined'].added, 0)
                self.assertEqual(corrections, [])
        self.assertFalse(setupDependency(item, spec, patch('node_modules', b'/other', '120000')))
        self.assertFalse(setupDependency(item, spec, patch('node_modules', b'/offline/node_modules')))
        self.assertFalse(setupDependency(item, {**spec, 'id': 'otherCase'}, changes))
        self.assertFalse(setupDependency({**item, 'baseBytes': 1}, spec, changes))

    def testBinaryNullIsNotZeroAndCaptureUntouched(self):
        binary = {**fileMeasure('image.bin', after=b'\x00\xff'), 'binary': True,
                  'added': None, 'deleted': None, 'addedBytes': None, 'deletedBytes': None}
        item = cast(FileMeasure, binary)
        original = deepcopy(item)
        values = total([item], {})
        for key in ('added', 'deleted', 'churn', 'addedBytes', 'deletedBytes', 'beforeLoc',
                    'afterLoc', 'compressedAddedBytes'):
            self.assertIsNone(getattr(values, key))
        self.assertEqual(values.resultBytes, 2)
        self.assertEqual(item, original)
        self.assertEqual(total([], {}).compressedAddedBytes, 0)

    def testNullPropagationIncludingNonbinaryAndEmptyAggregate(self):
        item = fileMeasure('a.py', 'production', after=b'a')
        item['added'] = None
        self.assertIsNone(total([item], {'a.py': patch('a.py', b'a')}).churn)
        self.assertIsNone(completeSum([1, None]))
        self.assertIsNone(completeSum([]))
        self.assertEqual(completeSum([0, 0]), 0)
        result = capturedResult()
        result['audit'] = None
        result['agent'] = None
        values = runMetrics(result, None, None, None)
        for key in ('tokens.input', 'piCostUsd.total', 'production.churn', 'agentSeconds', 'finalReplyWords'):
            self.assertIsNone(values[key])

    def testPatchCompressionSortedAndQuotedNoFinalNewline(self):
        paths = ['b.py', 'a space.py', 'é.py', 'tab\tfile.py']
        files = [fileMeasure(path, 'production', after=path.encode()) for path in paths]
        changes = b''.join(patch(path, path.encode()) for path in paths)
        sections = patchSections(changes, files)
        value = total(files, sections)
        self.assertEqual(value.compressedAddedBytes, compressed(b''.join(path.encode() for path in sorted(paths))))
        self.assertEqual(len(sections), 4)

    def testFailedRunRetainedWithoutManifest(self):
        with TemporaryDirectory() as name:
            folder = evidence(Path(name), capturedResult())
            result = capturedResult()
            result.update(status='failed', modelLaunched=False, agent=None, audit=None, measurement=None,
                          error='RuntimeError; inspect private failure locally (never publish)')
            saveJson(folder / 'result.json', result)
            (folder / 'manifest.json').unlink()
            row = readRun(folder, mapping())
            self.assertEqual(row.status, 'failed')
            self.assertFalse(row.validCompletion)
            self.assertFalse(row.metricComparisonEligible)
            self.assertIsNone(row.metrics['production.churn'])
            self.assertEqual(armTotals([row])[0].attempts, 1)
            self.assertEqual(armTotals([row])[0].statusCounts, {'failed': 1})

    def testTimeoutChecksPassCannotBecomeSuccess(self):
        result = capturedResult()
        result['status'] = 'invalidAgentRun'
        result['agent'] = {'exit': 124, 'timedOut': True, 'seconds': 600.001, 'timeoutSeconds': 600}
        result['audit']['valid'] = False
        with TemporaryDirectory() as name:
            row = readRun(evidence(Path(name), result), mapping())
            self.assertEqual(row.checks, {'acceptance': 0, 'native': 0})
            self.assertFalse(row.validCompletion)
            self.assertIsNone(row.metrics['finalReplyWords'])
            self.assertIsNone(row.metrics['finalReplyDensity'])
            self.assertGreater(row.metrics['lastAssistantTextBytes'], 0)
            summary = armTotals([row])[0]
            self.assertEqual(summary.sourceChurnAllAttempts, 0)
            self.assertIsNone(summary.sourceChurnMetricEligible)
            self.assertEqual(summary.excludedIdentities, [row.identity])
            self.assertIsNone(summary.superiority)

    def testQualityIsUnreviewedEvenWithGoodCompletion(self):
        with TemporaryDirectory() as name:
            row = readRun(evidence(Path(name), capturedResult()), mapping())
            self.assertTrue(row.validCompletion)
            self.assertTrue(row.metricComparisonEligible)
            self.assertEqual(row.qualityGate, 'unreviewed')
            self.assertIn('owned tests catch original', row.qualityUnavailable)
            self.assertIsNone(armTotals([row])[0].sourceChurnQualityQualified)
            self.assertIsNone(row.metrics['actualBilledCostUsd'])
            self.assertIsNone(row.metrics['tokens.reasoning'])

    def testDirectionsAndInvalidComparison(self):
        self.assertEqual([direction(1, 2), direction(2, 2), direction(3, 2), direction(None, 2)],
                         ['better', 'tie', 'worse', 'unavailable'])
        with TemporaryDirectory() as name:
            row = readRun(evidence(Path(name), capturedResult()), mapping())
            reference = replace(row, arm='ponytail', identity='reference')
            candidate = replace(row, identity='candidate', metrics={**row.metrics, 'production.churn': -1})
            comparison = comparisons([candidate, reference], 'ponytail')[0]
            self.assertEqual(comparison.directions['production.churn'].qualified, 'better')
            self.assertIsNone(comparison.strictSuperiority)
            self.assertIsNone(comparison.boundedParetoImprovement)
            candidate = replace(candidate, metricComparisonEligible=False, status='invalidAgentRun')
            comparison = comparisons([candidate, reference], 'ponytail')[0]
            self.assertEqual(comparison.directions['production.churn'].observed, 'better')
            self.assertIsNone(comparison.directions['production.churn'].qualified)
            summary = armTotals([row, candidate])[0]
            self.assertEqual(summary.sourceChurnAllAttempts, -1)
            self.assertEqual(summary.sourceChurnMetricEligible, 0)
            self.assertEqual(summary.statusCounts, {'completed': 1, 'invalidAgentRun': 1})
            self.assertNotIn('success', asdict(summary))

    def testUnpairedComparisonExplicitUnavailable(self):
        with TemporaryDirectory() as name:
            row = readRun(evidence(Path(name), capturedResult()), mapping())
            comparison = comparisons([row], 'ponytail')[0]
            self.assertEqual(comparison.status, 'unpaired')
            self.assertIsNone(comparison.reference)
            self.assertEqual(comparison.directions['production.churn'].observed, 'unavailable')
            self.assertIsNone(comparison.strictSuperiority)

    def testFailedChecksAndEvidenceTamperDoNotChangeCapturedStatus(self):
        result = capturedResult()
        result['checks']['native'] = 1
        with TemporaryDirectory() as name:
            folder = evidence(Path(name), result)
            (folder / 'profile.md').write_bytes(b'tampered')
            row = readRun(folder, mapping())
            self.assertEqual(row.status, 'completed')
            self.assertTrue(row.validCompletion)
            self.assertFalse(row.metricComparisonEligible)
            self.assertEqual(row.checks['native'], 1)
            self.assertIn('profile.md: hash mismatch', row.integrityProblems)
            self.assertIn('failed or unavailable acceptance/maintained checks', row.gateReasons)

    def testPatchLikeTextInsideHunkIsNotHeader(self):
        path = 'main.py'
        data = b'print("diff --git ")'
        sections = patchSections(patch(path, data), [fileMeasure(path, 'production', after=data)])
        self.assertEqual(total([fileMeasure(path, 'production', after=data)], sections).compressedAddedBytes,
                         compressed(data))

    def testActualProfileHashesNotFilenameStems(self):
        mapped = profiles([])
        self.assertEqual(set(mapped), {'ponytail', 'ponytailNarrative', 'legacyNative'})
        for value in mapped.values():
            self.assertEqual(value.sha256, digest(Path(value.path).read_bytes()))
            self.assertTrue(value.matchesPlanPin)
        self.assertEqual(mapped['ponytail'].sha256, 'ba68ff26239c3c3b05b2a9a47ee0d9a6b93a69639a2555ec87a5d44bffaf2f0c')

    def testEmptyDensityAndUpstreamChangedFileAlias(self):
        result = capturedResult()
        item = fileMeasure('main.py', 'production', after=b'# comment\n\npass\n')
        totals = {'production': total([item], {'main.py': patch('main.py', b'pass')})}
        totals.update({kind: total([], {}) for kind in ('tests', 'fixtures', 'snapshots', 'other', 'combined')})
        values = runMetrics(result, totals, b'', True)
        self.assertIsNone(values['finalReplyDensity'])
        self.assertEqual(values['lastAssistantTextRawDeflateBytes'], 0)
        self.assertEqual(values['upstreamStyleDiff.srcLoc'], 3)
        self.assertEqual(values['upstreamStyleDiff.totalLoc'], 3)
        self.assertEqual(values['production.afterLoc.nonblank'], 2)

    def testCliReproducibleExplicitDrawWithoutContentExposure(self):
        with TemporaryDirectory() as name:
            root = Path(name)
            folder = evidence(root, capturedResult())
            output = root / 'results.json'
            command = [sys.executable, '-B', str(Path(__file__).with_name('summarizeResults.py')),
                       '--runs', str(root / 'draw'), '--profile', 'testArm=' + str(folder / 'profile.md'),
                       '--output', str(output)]
            subprocess.run(command, check=True, capture_output=True, timeout=20)
            original = output.read_bytes()
            subprocess.run(command, check=True, capture_output=True, timeout=20)
            self.assertEqual(output.read_bytes(), original)
            report = json.loads(original)
            self.assertEqual(len(report['runs']), 1)
            self.assertEqual(report['runs'][0]['arm'], 'testArm')
            self.assertNotIn(b'PRIVATE REPLY CONTENT OMITTED', original)
            self.assertNotIn(b'frozen profile', original)
            self.assertLess(len(original.splitlines()), 600)


if __name__ == '__main__':
    unittest.main()
