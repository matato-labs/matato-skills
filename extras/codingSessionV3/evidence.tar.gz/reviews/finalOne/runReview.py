import hashlib
import io
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import subprocess
import tarfile
import time

root = Path('/tmp/codingSessionV3')
review = root / 'reviews/finalOne'
records = json.loads((review / 'commands.json').read_text()) if (review / 'commands.json').exists() else []
results = [json.loads(p.read_text()) for p in sorted((root / 'runs/finalOne').glob('*/*/result.json'))]
cases = {}
for language in ['python', 'typescript', 'elixir']:
    for phase in ['tuning', 'validation']:
        for case in json.loads((root / 'research' / language / phase / 'manifest.json').read_text())['cases']:
            cases[case['id']] = case

def git(folder, *args):
    return subprocess.check_output(['git', '-C', str(folder), *args])

def paths(folder):
    names = (git(folder, 'diff', 'HEAD', '--name-only', '-z') + git(folder, 'ls-files', '--others', '--exclude-standard', '-z')).decode().split('\0')
    return sorted({p for p in names if p and p not in ['node_modules', 'atlas/.venv'] and not p.startswith(('_build/', 'deps/'))})

def fingerprint():
    files = [p for p in (root / 'runs/finalOne').rglob('*') if p.is_file()]
    files += list((root / 'profiles').glob('*.md')) + [root / 'plan.json', root / 'finalFreeze.json', root / 'revisionTwo.md', root / 'runTrial.py']
    for language in ['python', 'typescript', 'elixir']:
        for phase in ['tuning', 'validation']:
            files += [p for p in (root / 'research' / language / phase).glob('*') if p.is_file()]
    states = {}
    for result in results:
        folder = Path(result['worktree'])
        files += [folder / name for name in paths(folder) if (folder / name).is_file()]
        states[str(folder)] = dict(head=git(folder, 'rev-parse', 'HEAD').decode().strip(), status=git(folder, 'status', '--porcelain=v1', '-z').decode())
    return dict(files={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}, states=states)

def run(label, command, folder):
    prior = next((r for r in records if r['label'] == label), None)
    if prior:
        return prior
    log = review / 'commands' / (label + '.log')
    log.parent.mkdir(exist_ok=True)
    start = time.monotonic()
    with log.open('w') as output:
        output.write('CWD ' + str(folder) + '\nCOMMAND ' + command + '\n')
        output.flush()
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', CI='1', DO_NOT_TRACK='1', TMPDIR=str(review / 'temp'))
        proc = subprocess.Popen(['bash', '-c', command], cwd=folder, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = proc.wait(timeout=120)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait()
            code = 124
        elapsed = round(time.monotonic() - start, 3)
        output.write(f'\nEXIT {code}\nSECONDS {elapsed}\n')
    record = dict(label=label, command=command, cwd=str(folder), exit=code, seconds=elapsed, output=str(log), sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    records.append(record)
    (review / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, code, elapsed, flush=True)
    for p in (review / 'temp').iterdir():
        if p.is_dir() and not p.is_symlink():
            shutil.rmtree(p)
        else:
            p.unlink()
    return record

def prepare(result):
    source = Path(result['worktree'])
    target = review / 'copies' / result['arm'] / result['case']
    if target.exists():
        return target
    target.mkdir(parents=True)
    with tarfile.open(fileobj=io.BytesIO(git(source, 'archive', result['base']))) as stream:
        stream.extractall(target, filter='data')
    transfers = []
    for name in paths(source):
        origin, destination = source / name, target / name
        if origin.is_file():
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(origin, destination)
            assert origin.read_bytes() == destination.read_bytes()
            transfers.append(dict(path=name, sha256=hashlib.sha256(destination.read_bytes()).hexdigest()))
        elif destination.exists():
            destination.unlink()
    if result['case'] in ['memoryReferenceResolution', 'sessionTreeConfinement']:
        (target / 'node_modules').symlink_to('/home/leon/workspace/projects/matato/node_modules', target_is_directory=True)
    if result['case'].startswith('python'):
        (target / 'atlas/.venv').symlink_to('/home/leon/workspace/projects/atlas/atlas/.venv', target_is_directory=True)
    (review / 'transfers' / (result['arm'] + result['case'] + '.json')).write_text(json.dumps(transfers, indent=2))
    return target

def pythonPrefix(folder):
    return f'cd "{folder}/atlas" && PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTEST_ADDOPTS= PYTHONPATH="{folder}/atlas/src:{folder}/atlas" '

def pytest(folder, label, files):
    return pythonPrefix(folder) + f'/home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B -m pytest -q -p no:cacheprovider --basetemp="{review}/temp/{label}" ' + files

def maintained(result, folder, suffix=''):
    name = result['case']
    changed = paths(Path(result['worktree']))
    if name.startswith('python'):
        files = sorted(set(p.removeprefix('atlas/') for p in changed if p.startswith('atlas/tests/') and Path(p).name.startswith('test_') and p.endswith('.py')))
        files += ['tests/test_graph_navigation.py', 'tests/test_coffee_navigation_snapshots.py'] if name == 'pythonUnicodeGraphFind' else ['tests/test_persistence.py', 'tests/test_graph_transactions.py', 'tests/test_graph_migrations.py', 'tests/test_database_cli.py']
        return pytest(folder, result['arm'] + name + 'Maintained' + suffix, ' '.join(shlex.quote(p) for p in sorted(set(files))))
    if name in ['memoryReferenceResolution', 'sessionTreeConfinement']:
        files = [p for p in changed if p.endswith('.test.ts')]
        files += ['src/storage/database.test.ts', 'src/agent/matatoAgentTools.test.ts'] if name == 'memoryReferenceResolution' else ['src/agent/matatoAgentSessions.test.ts', 'src/agent/matatoAgentPaths.test.ts']
        home = review / 'temp' / (result['arm'] + name + 'Home' + suffix)
        home.mkdir(parents=True, exist_ok=True)
        return f'HOME="{home}" bun test ' + ' '.join(shlex.quote(p) for p in sorted(set(files)))
    tests = [p for p in changed if p.startswith('test/') and p.endswith('_test.exs')]
    assert tests, name
    expression = 'ExUnit.start(seed: 0); ' + '; '.join(f'Code.require_file("{p}")' for p in tests)
    return f'elixir -pa "{root}/research/elixir/runtime/lib/*/ebin" -r "lib/beer_game/game/*.ex" -e ' + shlex.quote(expression)

def main():
    for name in ['temp', 'transfers', 'commands']:
        (review / name).mkdir(exist_ok=True)
    before = fingerprint()
    if (review / 'before.json').exists():
        assert before == json.loads((review / 'before.json').read_text())
    else:
        (review / 'before.json').write_text(json.dumps(before, indent=2))
    for language in ['python', 'typescript', 'elixir']:
        for phase in ['tuning', 'validation']:
            destination = review / 'research' / language / phase
            destination.mkdir(parents=True, exist_ok=True)
            for p in (root / 'research' / language / phase).glob('*'):
                if p.is_file():
                    shutil.copy2(p, destination / p.name)
    if not (review / 'research/elixir/runtime').exists():
        (review / 'research/elixir/runtime').symlink_to(root / 'research/elixir/runtime', target_is_directory=True)
    shutil.copy2(root / 'research/elixir/run.exs', review / 'research/elixir/run.exs')
    for result in results:
        folder = prepare(result)
        case = cases[result['case']]
        label = result['arm'] + result['case']
        command = case['checkCommand'].format(root=folder).replace(str(root / 'research'), str(review / 'research'))
        run(label + 'Acceptance', command, folder)
        command = case['nativeCommand'].format(root=folder).replace(str(root / 'research/python/tuning/nativeTemp'), str(review / 'temp' / (label + 'Native'))).replace(str(root / 'research/python/validation/nativeTemp'), str(review / 'temp' / (label + 'Native')))
        if case['id'] in ['memoryReferenceResolution', 'sessionTreeConfinement']:
            command = command.replace(str(root / 'research'), str(review / 'research'))
        run(label + 'Native', command, folder)
        run(label + 'Maintained', maintained(result, folder), folder)
        changed = paths(Path(result['worktree']))
        if result['case'].startswith('python'):
            if result['case'] == 'pythonUnicodeGraphFind':
                run(result['arm'] + 'PythonIntegration', pytest(folder, label + 'Integration', 'tests/test_coffee_pipeline.py tests/test_variant_snapshots.py tests/test_declaration_coffee.py -k "python or each_physical"'), folder)
                run(result['arm'] + 'PythonStandaloneFixture', pytest(folder, label + 'Standalone', 'tests/test_script_member_coffee_snapshots.py -k python'), folder)
            files = [p.removeprefix('atlas/') for p in changed if p.endswith('.py')]
            prefix = pythonPrefix(folder) + '/home/leon/workspace/projects/atlas/atlas/.venv/bin/'
            run(label + 'Lint', prefix + 'ruff check --no-cache ' + ' '.join(shlex.quote(p) for p in files), folder)
            files = [p for p in files if '/fixtures/' not in p]
            run(label + 'Types', prefix + 'pyright ' + ' '.join(shlex.quote(p) for p in files), folder)
        if result['case'] in ['memoryReferenceResolution', 'sessionTreeConfinement']:
            files = [p for p in changed if p.endswith('.test.ts')]
            run(label + 'TestLint', 'bun node_modules/eslint/bin/eslint.js ' + ' '.join(shlex.quote(p) for p in files), folder)
        if result['arm'] != 'candidateThree':
            continue
        negative = review / 'negative' / result['case']
        shutil.copytree(folder, negative, symlinks=True)
        production = [p for p in changed if p.startswith(('atlas/src/', 'lib/')) or (p.startswith('src/') and '.test.' not in p)]
        for p in production:
            (negative / p).write_bytes(git(Path(result['worktree']), 'show', result['base'] + ':' + p))
        run(label + 'OriginalProduction', maintained(result, negative, 'Original'), negative)
        if result['case'] == 'pythonUnicodeGraphFind':
            run(label + 'CoffeeOriginal', pytest(negative, 'candidateCoffeeOriginal', 'tests/test_coffee_navigation_snapshots.py'), negative)
        if result['case'].startswith('elixir'):
            for p in production:
                target = review / 'individualOriginal' / result['case'] / Path(p).stem
                shutil.copytree(folder, target, symlinks=True)
                (target / p).write_bytes(git(Path(result['worktree']), 'show', result['base'] + ':' + p))
                run(label + 'Original' + Path(p).stem, maintained(result, target), target)
                shutil.rmtree(target)
        shutil.rmtree(negative)
    after = fingerprint()
    (review / 'after.json').write_text(json.dumps(after, indent=2))
    assert before == after
    (review / 'integrity.json').write_text(json.dumps(dict(unchanged=True, files=len(before['files']), worktrees=len(before['states'])), indent=2))

if __name__ == '__main__':
    main()
