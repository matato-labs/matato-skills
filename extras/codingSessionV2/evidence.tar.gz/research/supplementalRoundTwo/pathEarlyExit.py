#!/usr/bin/env python3
"""Frozen additional public-service holdout checks, no candidate edits.
Checks record processing separately from the permitted batched adjacency fetch.
"""
from pathlib import Path
import sys
import unittest

repo = Path(sys.argv.pop(1)).resolve()
sys.path.insert(0, str(repo / 'atlas/src'))
from atlas.domain.navigation import GraphSnapshot, PathRequest, TraversalRequest
from atlas.services.navigation import NavigationService


class Row(dict):
    def __init__(self, reader, **values):
        super().__init__(values)
        self.reader = reader

    def __getitem__(self, key):
        ordinal = dict.__getitem__(self, 'ordinal')
        if ordinal not in self.reader.processed:
            self.reader.processed.append(ordinal)
        return super().__getitem__(key)


class Reader:
    snapshot = GraphSnapshot('repo', 'rev', None, '/unused')

    def __init__(self, pairs=(), external=(), extra=()):
        self.nodes = {k: dict(stableKey=k, external=k in external, path=None)
                      for k in set(extra) | {k for a, b, _ in pairs for k in (a, b)}}
        self.rows = [Row(self, ordinal=i, sourceStableKey=a, targetStableKey=b, type=r)
                     for i, (a, b, r) in enumerate(pairs)]
        self.fetches, self.node_calls, self.processed = [], [], []

    def node(self, key):
        self.node_calls.append(key)
        return self.nodes[key]

    def edges(self, request):
        self.fetches.append(request)
        # Bypass instrumentation during filtering: rows returned != rows processed.
        selected = [row for row in self.rows if dict.__getitem__(row, 'type') in request.relations and (
            request.direction in ('out', 'both') and dict.__getitem__(row, 'sourceStableKey') == request.key or
            request.direction in ('in', 'both') and dict.__getitem__(row, 'targetStableKey') == request.key)]
        return selected[:request.limit]

    def diagnostics(self, paths, limit):
        return []


def options(direction='out', relations=None, depth=10, nodes=100, edges=100, key='root'):
    return TraversalRequest(key, direction, relations or ['CALLS'], depth, nodes, edges)


def boundary(key):
    return dict(stableKey=key, reason='external_unresolved_or_ambiguous', expandable=False)


class SupplementalPath(unittest.TestCase):
    def test_diamond_tie_order_cycles_and_preceding_external_boundary(self):
        pairs = [('root', 'external', 'CALLS'), ('root', 'a', 'CALLS'), ('root', 'b', 'CALLS'),
                 ('a', 'a', 'CALLS'), ('a', 'root', 'CALLS'), ('a', 'target', 'CALLS'),
                 ('a', 'later', 'CALLS'), ('b', 'target', 'CALLS')]
        for direction in ('out', 'in'):
            with self.subTest(direction=direction):
                rows = pairs if direction == 'out' else [(b, a, r) for a, b, r in pairs]
                reader = Reader(rows, external=['external'])
                result = NavigationService(reader).path(PathRequest('target', options(direction)))
                self.assertEqual(result['path'], ['root', 'a', 'target'])
                self.assertEqual([e['ordinal'] for e in result['pathEdges']], [1, 5])
                self.assertEqual([e['ordinal'] for e in result['edges']], list(range(6)))
                self.assertEqual([n['stableKey'] for n in result['nodes']], ['root', 'external', 'a', 'b', 'target'])
                self.assertEqual(result['boundaries'], [boundary('external')])
                self.assertFalse(result['truncated'])
                self.assertEqual([r.key for r in reader.fetches], ['root', 'a'])
                self.assertEqual(reader.processed, list(range(6)))
                self.assertNotIn('later', reader.node_calls)

    def test_both_direction_dedup_and_relation_filter(self):
        reader = Reader([('root', 'a', 'CALLS'), ('a', 'root', 'CALLS'),
                         ('a', 'target', 'CALLS'), ('target', 'later', 'CALLS'),
                         ('root', 'wrong', 'IMPORTS')])
        result = NavigationService(reader).path(PathRequest('target', options('both')))
        self.assertEqual(result['path'], ['root', 'a', 'target'])
        self.assertEqual([e['ordinal'] for e in result['edges']], [0, 1, 2])
        self.assertEqual(reader.processed, [0, 1, 2])
        self.assertEqual([r.key for r in reader.fetches], ['root', 'a'])
        self.assertFalse(result['truncated'])

    def test_success_at_exact_limits_does_not_process_later_row(self):
        for direction in ('out', 'in', 'both'):
            for relation in ('CALLS', 'IMPORTS'):
                with self.subTest(direction=direction, relation=relation):
                    pairs = [('root', 'target', relation), ('root', 'later', relation)]
                    if direction == 'in':
                        pairs = [(b, a, r) for a, b, r in pairs]
                    reader = Reader(pairs, external=['target'])
                    result = NavigationService(reader).path(PathRequest('target', options(direction, [relation], 1, 2, 1)))
                    self.assertEqual(result['status'], 'found')
                    self.assertEqual(result['boundaries'], [boundary('target')])
                    self.assertEqual(reader.processed, [0])
                    self.assertEqual(len(reader.fetches), 1)
                    self.assertEqual(reader.fetches[0].limit, 2)
                    self.assertFalse(result['truncated'])

    def test_second_neighbor_budget_grid(self):
        for depth in range(3):
            for nodes in range(1, 4):
                for edges in range(4):
                    with self.subTest(depth=depth, nodes=nodes, edges=edges):
                        reader = Reader([('root', 'first', 'CALLS'), ('root', 'target', 'CALLS')])
                        result = NavigationService(reader).path(PathRequest('target', options(depth=depth, nodes=nodes, edges=edges)))
                        found = depth >= 1 and nodes >= 3 and edges >= 2
                        self.assertEqual(result['status'], 'found' if found else 'unknown')
                        self.assertEqual(result['path'], ['root', 'target'] if found else [])
                        self.assertEqual(result['truncated'], not found)

    def test_context_full_walk_and_unreachable_exhaustion(self):
        pairs = [('root', 'external', 'CALLS'), ('root', 'a', 'CALLS'),
                 ('a', 'b', 'CALLS'), ('b', 'a', 'CALLS'), ('external', 'target', 'CALLS')]
        reader = Reader(pairs, external=['external'])
        result = NavigationService(reader).context(options())
        self.assertEqual([r.key for r in reader.fetches], ['root', 'a', 'b'])
        self.assertEqual([e['ordinal'] for e in result['edges']], [0, 1, 2, 3])
        self.assertEqual(result['boundaries'], [boundary('external')])
        self.assertFalse(result['truncated'])
        reader = Reader(pairs, external=['external'])
        result = NavigationService(reader).path(PathRequest('target', options()))
        self.assertEqual(result['status'], 'not_found')
        self.assertFalse(result['truncated'])
        self.assertEqual([r.key for r in reader.fetches], ['root', 'a', 'b'])

    def test_self_and_missing_keys_without_expansion(self):
        for external in ([], ['root']):
            reader = Reader(extra=['root'], external=external)
            result = NavigationService(reader).path(PathRequest('root', options(depth=0, nodes=1, edges=0)))
            self.assertEqual(result['status'], 'found')
            self.assertEqual(result['path'], ['root'])
            self.assertEqual(result['pathEdges'], [])
            self.assertEqual(result['boundaries'], [boundary('root')] if external else [])
            self.assertFalse(result['truncated'])
            self.assertEqual(reader.fetches, [])
        for start, target in [('missing', 'root'), ('root', 'missing')]:
            reader = Reader(extra=['root'])
            with self.assertRaises(KeyError):
                NavigationService(reader).path(PathRequest(target, options(key=start)))
            self.assertEqual(reader.fetches, [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
