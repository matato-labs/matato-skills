#!/usr/bin/env python3
"""Compile real commons/sintropy with an external Go test overlay; no sockets."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

repo = Path(sys.argv[1]).resolve()
source = r'''package sintropy_test

import (
 "commons/sintropy"
 "encoding/json"
 "errors"
 "fmt"
 "io"
 "net/http"
 "reflect"
 "strings"
 "testing"
)
type transport func(*http.Request) (*http.Response, error)
func (f transport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }
func response(code int, text string) *http.Response {
 return &http.Response{StatusCode: code, Header: make(http.Header), Body: io.NopCloser(strings.NewReader(text))}
}
func TestFinalPollProcess(t *testing.T) {
 for _, mode := range []string{"success", "empty", "pollError", "processorError", "dualError", "dequeueError"} {
  t.Run(mode, func(t *testing.T) {
   pollFailure := errors.New("poll transport sentinel")
   processFailure := errors.New("processor sentinel")
   var paths []string
   var ids []string
   fallbackCalls, calls := 0, 0
   count := 3
   request := sintropy.PollRequest{ChannelName:"desk/α", RoutingKey:"prices", PollingCount:&count}
   handler := func(r *http.Request) (*http.Response, error) {
    paths = append(paths, r.URL.Path)
    if r.Method != "POST" { t.Errorf("method = %s", r.Method) }
    if r.Header.Get("Content-Type") != "application/json" { t.Error("lost JSON content type") }
    if strings.HasSuffix(r.URL.Path, "/queues/poll") {
     var got sintropy.PollRequest
     if err := json.NewDecoder(r.Body).Decode(&got); err != nil { t.Error(err) }
     if !reflect.DeepEqual(got, request) { t.Errorf("poll payload = %#v", got) }
     if mode == "pollError" { return nil, pollFailure }
     if mode == "empty" { return response(200, "[]"), nil }
     return response(200, `[{"messageId":"first","message":"one"},{"messageId":"second","message":"two"},{"messageId":"first","message":"three"}]`), nil
    }
    var body sintropy.MessageBulkRequest
    if err := json.NewDecoder(r.Body).Decode(&body); err != nil { t.Error(err) }
    ids = body.MessagesIds
    if mode == "dualError" || mode == "dequeueError" { return response(503, "ack refused"), nil }
    return response(204, ""), nil
   }
   old := http.DefaultTransport
   http.DefaultTransport = transport(func(r *http.Request) (*http.Response, error) {
    fallbackCalls++
    return handler(r)
   })
   defer func() { http.DefaultTransport = old }()
   client := sintropy.NewClient("http://holdout.invalid/prefix", sintropy.WithHTTPClient(&http.Client{Transport:transport(handler)}))
   err := client.PollAndProcess(request, func(messages []sintropy.Message) error {
    calls++
    if len(messages) != 3 || messages[0].Message != "one" || messages[2].Message != "three" { t.Errorf("processor messages = %#v", messages) }
    if mode == "processorError" || mode == "dualError" { return processFailure }
    return nil
   })
   if fallbackCalls != 0 { t.Errorf("ignored receiver's configured HTTP client: %d default calls", fallbackCalls) }
   for _, path := range paths { if !strings.HasPrefix(path, "/prefix/") { t.Errorf("ignored receiver base URL: %s", path) } }
   wantCalls := 1
   if mode == "empty" || mode == "pollError" { wantCalls = 0 }
   if calls != wantCalls { t.Errorf("processor calls = %d, want %d", calls, wantCalls) }
   wantRequests := 2
   if wantCalls == 0 { wantRequests = 1 }
   if len(paths) != wantRequests { t.Errorf("requests = %v", paths) }
   if wantCalls != 0 {
    if !reflect.DeepEqual(ids, []string{"first","second","first"}) { t.Errorf("bulk IDs = %#v", ids) }
    suffix := "/queues/messages/dequeue/bulk"
    if mode == "processorError" || mode == "dualError" { suffix = "/queues/messages/failed/bulk" }
    if len(paths) > 1 && !strings.HasSuffix(paths[1], suffix) { t.Errorf("wrong acknowledgement: %v", paths) }
   }
   switch mode {
   case "success", "empty": if err != nil { t.Errorf("unexpected error: %v", err) }
   case "pollError": if !errors.Is(err, pollFailure) { t.Errorf("lost poll cause: %v", err) }
   case "processorError": if !errors.Is(err, processFailure) { t.Errorf("lost processor cause: %v", err) }
   case "dualError":
    if !errors.Is(err, processFailure) { t.Errorf("lost processor cause with ack failure: %v", err) }
    fallthrough
   case "dequeueError":
    var apiError *sintropy.Error
    if !errors.As(err, &apiError) || apiError.StatusCode != 503 || apiError.Message != "ack refused" { t.Errorf("lost typed ack cause: %v", err) }
   default: t.Fatal(fmt.Sprint("unknown mode", mode))
   }
  })
 }
}
'''
with tempfile.TemporaryDirectory(prefix="finalPollOracle-") as folder:
    folder = Path(folder)
    test = folder / "contract_test.go"
    test.write_text(source)
    overlay = folder / "overlay.json"
    overlay.write_text(json.dumps({"Replace": {str(repo / "commons/sintropy/final_holdout_test.go"): str(test)}}))
    result = subprocess.run(["go", "test", "-vet=off", "-overlay", str(overlay), "-count=1", "-run", "^TestFinalPollProcess$", "-v", "./sintropy"], cwd=repo / "commons", env={**os.environ, "GOWORK":"off", "GOPROXY":"off", "GOSUMDB":"off"}, timeout=90)
sys.exit(result.returncode)
