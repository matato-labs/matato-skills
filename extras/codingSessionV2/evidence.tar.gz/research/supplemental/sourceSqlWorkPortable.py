#!/usr/bin/env python3
"""Run frozen SQL checks with one supplied interpreter; base has no private venv.

Only the subprocess interpreter is adapted; test source and assertions unchanged.
Invoke with a Python containing the already installed Atlas test dependencies.
"""
from pathlib import Path
import runpy
import subprocess
import sys

run = subprocess.run

def with_current_python(args, *positional, **keywords):
    return run([sys.executable, *args[1:]], *positional, **keywords)

subprocess.run = with_current_python
runpy.run_path(str(Path(__file__).with_name("sourceSqlWork.py")), run_name="__main__")
