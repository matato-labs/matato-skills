import hashlib
import json
from pathlib import Path

root = Path('/tmp/codingSessionV4')
output = root / 'reviews/ablationOne'
files = json.loads((output / 'metrics.json').read_text())
fields = ['additions', 'deletions', 'churn', 'baseBytes', 'resultBytes', 'byteGrowth', 'baseLines', 'resultLines', 'nonblankStrippedAdditions', 'nonblankStrippedDeletions']
caseSummary = {}
armSummary = {}
for identity, rows in files.items():
    caseSummary[identity] = {category: {field: sum(row[field] for row in rows if category == 'combined' or row['category'] == category) for field in fields} for category in ['production', 'tests', 'fixtures', 'snapshots', 'combined']}
for arm in ['v3', 'reuseAblation']:
    armSummary[arm] = {category: {field: sum(summary[category][field] for identity, summary in caseSummary.items() if identity.startswith(arm + '/')) for field in fields} for category in ['production', 'tests', 'fixtures', 'snapshots', 'combined']}
metrics = {'scope': 'Changed files only; resultBytes counts entire resulting changed files, not whole repository. Test files separate; zero fixture/snapshot changes. Git no-index numstat against pinned base; trimmed nonblank unified-diff diagnostic preserves wrapping.', 'files': files, 'cases': caseSummary, 'arms': armSummary, 'verdict': 'narrow structural hypothesis unestablished; metric outcomes mixed'}
(output / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
checksums = json.loads((output / 'checksums.json').read_text())
unchanged = {}
for key, expected in checksums.items():
    if key.startswith('/'):
        assert hashlib.sha256(Path(key).read_bytes()).hexdigest() == expected, key
    else:
        arm, case, name = key.split('/', 2)
        path = root / 'worktrees/ablationOne' / arm / case / name
        unchanged[key] = hashlib.sha256(path.read_bytes()).hexdigest() == expected
        copy = root / 'private/ablationReview' / arm / case / name
        assert hashlib.sha256(copy.read_bytes()).hexdigest() == expected, str(copy)
assert all(unchanged.values())
(output / 'integrity.json').write_text(json.dumps({'allRecordedInputsStillMatch': True, 'liveImplementationFilesUnchanged': unchanged, 'noImplementationRuns': True, 'sandbox': 'bwrap --unshare-all; original repositories/dependencies read-only; writable private copies and private stages only'}, indent=2) + '\n')
for arm in ['v3', 'reuseAblation']:
    for case in ['pythonConfinedIgnoreFiles', 'preScriptEnvironmentLifetime']:
        trial = root / 'runs/ablationOne' / arm / case
        for name in ['changes.patch', 'currentProfile.md', 'invocation.json', 'prompt.txt', 'agent.json', 'profileAudit.json', 'result.json', 'toolTrace.jsonl', 'acceptance.json', 'native.json']:
            path = trial / name
            checksums[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
for path in output.rglob('*'):
    if path.is_file() and path.name not in ['checksums.json', 'artifacts.sha256']:
        checksums[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
(output / 'checksums.json').write_text(json.dumps(checksums, indent=2) + '\n')
(output / 'artifacts.sha256').write_text(''.join(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(output)}\n' for path in sorted(output.rglob('*')) if path.is_file() and path.name != 'artifacts.sha256'))
print(json.dumps(armSummary, indent=2))
