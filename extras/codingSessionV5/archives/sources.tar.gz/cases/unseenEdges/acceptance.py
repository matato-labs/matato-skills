"""Independent expectations over the unchanged, production-indexed coffee sample."""
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from unittest.mock import patch

import pytest

from atlas.domain.navigation import EdgeRequest, PathRequest, Record, TraversalRequest
from atlas.persistence.database import migrate_database
from atlas.persistence.navigation import GraphReader, navigation_reader
from atlas.services.navigation import NavigationService
from tests.coffee_fixture import FIXTURE_ROOT
from tests.coffee_navigation import CliRunner, Declaration, command, declaration


@pytest.fixture(scope="module")
def indexed(tmp_path_factory: pytest.TempPathFactory) -> tuple[Path, str]:
    database = tmp_path_factory.mktemp("indexed") / "graph.sqlite"
    migrate_database(database)
    with patch.dict("os.environ", {"DATABASE_PATH": str(database)}):
        payload = command(CliRunner(), "index", "--folder", str(FIXTURE_ROOT / "python"))
    assert payload["stats"]["parseErrors"] == 0
    return database, payload["repositoryId"]


def brew_key(reader: GraphReader) -> str:
    return declaration(reader.find("brew", 100), Declaration(
        "src/coffee/brewing/brewer.py", "Brewer.brew", "function"
    ))["stableKey"]


@dataclass
class Expected:
    nodes: list[str]
    edges: dict[int, Record] = field(default_factory=dict)
    parents: dict[str, tuple[str, int]] = field(default_factory=dict)
    cut: bool = False


def exhaustive_fixture_walk(reader: GraphReader, request: TraversalRequest) -> Expected:
    """Oracle-only exhaustive adjacency; never used by the candidate implementation."""
    expected = Expected([request.key])
    queue = deque([request.key])
    while queue:
        key = queue.popleft()
        if reader.node(key)["external"]:
            continue
        rows = reader.edges(EdgeRequest(key, request.direction, request.relations, 10_000))
        assert len(rows) < 10_000, "fixture oracle requires complete adjacency"
        for edge in rows:
            ordinal = edge["ordinal"]
            if ordinal in expected.edges:
                continue
            if len(expected.edges) == request.max_edges:
                expected.cut = True
                break
            expected.edges[ordinal] = edge
            neighbor = edge["targetStableKey"] if edge["sourceStableKey"] == key else edge["sourceStableKey"]
            if neighbor not in expected.nodes:
                expected.nodes.append(neighbor)
                expected.parents[neighbor] = (key, ordinal)
                queue.append(neighbor)
    return expected


def assert_response(actual: Record, expected: Expected) -> None:
    assert [edge["ordinal"] for edge in actual["edges"]] == list(expected.edges), "unique-edge budget must preserve deterministic BFS evidence"
    assert [node["stableKey"] for node in actual["nodes"]] == expected.nodes
    assert actual["truncated"] == expected.cut, "already included evidence is not an omitted-edge boundary"
    assert len({edge["ordinal"] for edge in actual["edges"]}) == len(actual["edges"])


@pytest.mark.parametrize("budget", [7, 8, 11])
def test_shared_incident_edges_do_not_hide_later_evidence(indexed: tuple[Path, str], budget: int) -> None:
    database, project = indexed
    with navigation_reader(project, None, database) as reader:
        request = TraversalRequest(brew_key(reader), "both", ["CALLS"], 20, 300, budget)
        expected = exhaustive_fixture_walk(reader, request)
        with patch.object(reader, "edges", wraps=reader.edges) as reads:
            actual = NavigationService(reader).context(request)
        assert reads.call_count > 1
        assert all(0 < call.args[0].limit <= budget + 1 for call in reads.call_args_list), "production adjacency reads must remain budget-bounded"
        assert_response(actual, expected)
        target = expected.nodes[-1]
        path = NavigationService(reader).path(PathRequest(target, request))
        assert_response(path, expected)
        assert path["status"] == "found"
        keys, ordinals = [target], []
        while keys[-1] != request.key:
            parent, ordinal = expected.parents[keys[-1]]
            keys.append(parent)
            ordinals.append(ordinal)
        assert path["path"] == list(reversed(keys))
        assert [edge["ordinal"] for edge in path["pathEdges"]] == list(reversed(ordinals))
        with patch.dict("os.environ", {"DATABASE_PATH": str(database)}):
            cli = command(CliRunner(), "graph", "--project", project, "context", request.key,
                          "--direction", "both", "--relations", "CALLS", "--depth", "20", "--max-nodes", "300", "--max-edges", str(budget))
        assert_response(cli, expected)


def test_exact_cycle_budget_has_no_false_cutoff(indexed: tuple[Path, str]) -> None:
    database, project = indexed
    with navigation_reader(project, None, database) as reader:
        key = "file:src/coffee/brewing/recipe.py"
        complete = exhaustive_fixture_walk(reader, TraversalRequest(key, "both", ["IMPORTS"], 20, 300, 1000))
        assert len(complete.edges) > 1 and not complete.cut
        request = TraversalRequest(key, "both", ["IMPORTS"], 20, 300, len(complete.edges))
        expected = exhaustive_fixture_walk(reader, request)
        assert not expected.cut
        assert_response(NavigationService(reader).context(request), expected)


def test_positive_control_generous_budget_and_self_recursion(indexed: tuple[Path, str]) -> None:
    database, project = indexed
    with navigation_reader(project, None, database) as reader:
        keys = [brew_key(reader), reader.find("retry", 100)[0]["stableKey"]]
        for key in keys:
            for direction in ("out", "in", "both"):
                request = TraversalRequest(key, direction, ["CALLS"], 20, 300, 1000)
                expected = exhaustive_fixture_walk(reader, request)
                assert not expected.cut
                assert_response(NavigationService(reader).context(request), expected)
                assert_response(NavigationService(reader).path(PathRequest(expected.nodes[-1], request)), expected)
                with patch.dict("os.environ", {"DATABASE_PATH": str(database)}):
                    cli = command(CliRunner(), "graph", "--project", project, "context", key,
                                  "--direction", direction, "--relations", "CALLS", "--depth", "20",
                                  "--max-nodes", "300", "--max-edges", "1000")
                assert_response(cli, expected)
