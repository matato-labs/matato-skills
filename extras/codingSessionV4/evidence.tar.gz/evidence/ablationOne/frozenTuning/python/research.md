# V4 Python tuning research: confined discovery policies

Selected exactly one fresh task, `pythonConfinedIgnoreFiles`: confine `.gitignore` and `.atlasignore` rule inputs to the canonical analyzed root while preserving existing ignore-layer behavior. This is unrelated to the V3 Unicode graph-find and literal database-path tasks. No implementation, solution patch, dependency change, or README edit was made. No V4 rival profiles or results were inspected.

## Repository and ownership

Original repository: `/home/leon/workspace/projects/atlas`. Pinned HEAD: `835be1ac26bfb0b0003a01a741afed21bd550278`. Owned detached worktree: `/tmp/codingSessionV4/research/python/base`. The initial original status was clean; final original and detached-base statuses/diffs are empty in `environment.json`. Normal Git worktree registration writes Git administrative metadata, not original source. The owned base is deliberately retained for the parent, not removed or repurposed.

Read the root `AGENTS.md`; no nested instructions exist. Source investigation used ordinary current-file reads. The existing Atlas database was checked before the read-only `projects` query; it returned `[]`, so no registered graph was available and no graph/index evidence is claimed. No index, migration, or graph was created in the original project or user-data database.

## Why this task

`atlas/src/atlas/parsing/discovery.py:91–96` reads an ignore entry after `is_file()` without checking its resolved target against the analysis root. The root mode switch at line 136 also follows a root `.gitignore` symlink even when its target is outside. Consequently external rules can suppress real sources, resurrect inherited exclusions, change fallback policy, and make analysis fail on external undecodable bytes. External policy changes affect analysis even though the repository's own sources did not change.

This is a discovery trust-boundary/behavior defect, not a claim of remote exploitability, file disclosure, or race protection. The deliberate product policy is explicit in the brief: unusable ignore entries act as absent; confined regular-file symlinks stay usable; aliases do not rebase patterns to their targets. The task does not request changing errors from ordinary local policy contents.

The opportunity is existing composition rather than a new ignore implementation: pathlib already supplies canonicalization and containment primitives, discovery's `_contained_files` already uses root containment, and `services/navigation_source.py` demonstrates existing canonical-path handling. The installed `pathspec.GitIgnoreSpec` already implements pattern ordering and negation. Preserve that dependency's behavior instead of duplicating its parser. This rationale is intentionally separate from the implementation-neutral brief and manifest.

Feasible scope is the discovery policy-file/mode boundary and maintained discovery tests, principally `atlas/src/atlas/parsing/discovery.py`, `atlas/tests/test_discovery.py`, and `atlas/tests/test_atlasignore.py`. Existing index/report consumers need no new API, schema, service, or dependency. This should fit a 900-second implementation: the independent oracle takes about one second, and the deliberately broad maintained-consumer/generator check takes about one minute. The task does not require a new shared Coffee project or snapshot family.

## Existing consumers and maintained coverage

```mermaid
flowchart LR
  Rules["Root/nested ignore entries"] --> Discovery["discover_files"]
  Discovery --> Analysis["analyze_repository"]
  Analysis --> Report["report / report --save"]
  Analysis --> Index["index"]
  Index --> Saved["Persisted file nodes"]
  Report --> Saved
  Samples["Coffee source fixtures"] --> Discovery
  Samples --> Consumers["Pipeline / inventory / variants / navigation tests"]
  Samples --> Generator["update_coffee_snapshots --navigation"]
```

The source-grounded chain is `indexer.py:29–33`, `services/repositories.py:25–27`, and `cli/commands.py:24–38,55–81`. Existing `test_atlasignore.py` already copies maintained Coffee sources and exercises exclusion/reanalysis through both index and saved report. `test_discovery.py` owns exact path-set assertions, root/nested rules, negation and fallback. These are appropriate maintained seams for this change; the external oracle is not a replacement for repository regression coverage.

`nativeCommand` runs the complete maintained discovery/Atlas-ignore suites, folder index/report CLI suites, Coffee graph/pipeline/inventory tests, variant consumers, navigation snapshots, and standalone script-member/safety-review consumers. It then invokes the actual existing `python -m tests.update_coffee_snapshots --navigation` entrypoint for every registered language and variants. Parsed JSON before/after must agree for all 71 existing outputs. It does not weaken assertions or silently accept regenerated baselines.

To keep generator writes out of source trees, `nativeCheck.py` copies the supplied candidate tree to a unique research-local temporary directory, preserving candidate edits and fixture symlinks. Pytest and the generator run in that copy; all bytecode and pytest caching are disabled. Temporary copies are removed after the check, while command logs remain. This is a maintained suite plus a real generator, not a second execution of the acceptance oracle.

## V3 lessons applied

Read `extras/codingSessionV3/evaluation.md`, the archived Python research notes, and `reviews/roundOne/review.md`, `reviews/roundTwo/review.md`, and `reviews/finalTwo/review.md`. Those review copies are under `history/`; no V4 results were opened.

R1 showed an unregistered fixture root can pass a new regression but fail maintained inventory. R2 showed shared fixture changes fan out to overlay variants. R4 showed that a green snapshot test does not establish a regeneration route. The evaluation also distinguishes physical-line counts from generated bytes and green frozen checks from completeness. Accordingly this native command includes consumers and the real full generator from the outset; no churn/size metric or source-shape assertion is part of acceptance. Source analysis is deliberately narrow so the tuning task has a real reuse opportunity without requiring large new test machinery.

## Frozen brief and independent behavioral oracle

`brief.txt`, `oracle.py`, `nativeCheck.py`, and `manifest.json` were frozen at `2026-10-15T20:31:31.198773+00:00`, before baseline execution and before any implementation. They are read-only files. `freeze.json` and `artifacts.sha256` record their SHA-256 digests. Manifest brief is byte-for-byte the complete `brief.txt`, including its final newline. Freeze verification passed after all executions; no frozen file was revised.

The oracle imports production modules from the supplied candidate `atlas/src` and verifies their provenance. It never imports maintained test helpers as expected behavior, uses source-string/LOC checks, reads implementation text, or patches production. Its eight unittest methods assert exact discovered path sets, fallback versus Git-ignore mode, both independent inherited rule layers, direct/chained escaping links, valid entry-relative confined links through a root alias, pruning, missing/dangling/cyclic/directory policy entries, external-content independence, and no attempted decoding of external invalid UTF-8.

The production-consumer scenario copies the existing Python Coffee fixture, checks the in-memory report, and exercises index and saved report over external-link -> real local policy -> external-link transitions. Expected physical source membership is independent of production discovery. It checks persisted file nodes and unchanged source/external-policy bytes. The final frozen scenario fails early on base, as expected. Separately, `oracleCompatibility.log` exercises these exact report/persistence assertion helpers with normal local-policy creation/removal on unchanged base: both index and saved report correctly perform 11 -> 8 -> 11 file transitions. This validates the otherwise masked helper path without a solution, mock, or oracle change.

## Baseline evidence

`setup.log`: exit 0, 0.431 seconds. Existing offline dependencies and candidate import provenance verified.

`negative.log`: exit 1, 0.978 seconds, 8 tests run. Two compatibility methods pass. The six affected methods produce eight assertion failures and four expected `UnicodeDecodeError` subtest errors from consuming external policy bytes. These are actual baseline behavior failures, not missing packages or a malformed oracle. Examples: an external root Atlas policy suppresses `main.py` and `dist/keep.py`; external nested policies resurrect `src/a.skip.py` and `src/b.ban.py`; report loses the three maintained Coffee reporting files. Counts include subtests, not twelve distinct top-level tests.

`nativeBaseline.log`: exit 0, 60.579 seconds. **193 maintained tests and 78 subtests pass** in 36.58 seconds. The full real generator runs all nine languages plus variants and preserves all **71 parsed snapshot outputs**. Setup/oracle metadata is in `checkEvidence.json`; native command metadata is in `nativeEvidence.json`.

## Reproduction and limits

Use the original Atlas environment read-only: `/home/leon/workspace/projects/atlas/atlas/.venv/bin/python`. No activation, installation, sync, network, external service, or database server is needed. The only migrations are for disposable local SQLite oracle fixtures. All new scratch/output is under this research directory; no output is written to the original repository or shared dependencies. `PYTHONDONTWRITEBYTECODE=1`, `-B`, `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`, `-p no:cacheprovider`, and unique pytest basetemps are supplied where applicable.

Acceptance command:

```sh
PYTHONDONTWRITEBYTECODE=1 /home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B /tmp/codingSessionV4/research/python/oracle.py /tmp/codingSessionV4/research/python/base
```

Maintained command:

```sh
PYTHONDONTWRITEBYTECODE=1 /home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B /tmp/codingSessionV4/research/python/nativeCheck.py /tmp/codingSessionV4/research/python/base
```

Integrity command: `cd /tmp/codingSessionV4/research/python && sha256sum -c artifacts.sha256`. `manifest.json` supplies the same setup/check/native commands with `{root}` placeholders for another candidate tree.

No blocker for this tuning task. This is a local environment-dependent bundle, not a hermetic installer. No positive implemented control, full Python release suite, full-project Atlas analysis, dashboard checks, concurrent symlink-swap defense, permission-error policy, or mutation score is claimed. All scripts are below 600 lines and functions below 100 lines; new helper and case names are camelCase. The original and detached-base source trees remain unchanged.
