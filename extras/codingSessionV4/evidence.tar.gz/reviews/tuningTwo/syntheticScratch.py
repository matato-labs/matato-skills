import json
import os
from pathlib import Path
import subprocess

out = Path('/tmp/codingSessionV4/reviews/tuningTwo')
logical = '/tmp/v4Synthetic'
results = []
for physical in [Path('/dev/shm/codingSessionV4tuningTwoSynthetic'), Path('/home/leon/.cache/codingSessionV4Review/tuningTwoSynthetic')]:
    physical.mkdir(parents=True, mode=0o700)
    immutable = physical / 'immutable'
    immutable.mkdir()
    (immutable / 'marker').write_text('unchanged')
    writable = physical / 'writable'
    writable.mkdir()
    for name in ['home', 'tmp', 'cache', 'oracle', 'worktree']:
        (writable / name).mkdir()
    (writable / 'worktree/module.ts').write_text('export const value: number = 7\n')
    environment = {'PATH': os.environ['PATH'], 'HOME': logical + '/home', 'TMPDIR': logical + '/tmp', 'XDG_CACHE_HOME': logical + '/cache', 'LANG': 'C.UTF-8'}
    script = """python3 - <<'PY'
import errno, os, tempfile
from pathlib import Path
with tempfile.TemporaryDirectory(dir='/tmp/v4Synthetic/oracle') as d:
    p=Path(d)/'bytes'
    p.write_bytes(bytes(8*1024*1024))
    assert p.stat().st_blocks*512 >= 8*1024*1024
with tempfile.TemporaryDirectory() as d:
    assert d.startswith(os.environ['TMPDIR'])
try:
    Path('/tmp/v4Immutable/marker').write_text('changed')
    raise AssertionError('immutable marker was writable')
except OSError as e:
    assert e.errno == errno.EROFS
print('Python TMPDIR, adjacent-oracle scratch and readonly boundary verified')
PY
bun -e 'const module = await import("/tmp/v4Synthetic/worktree/module.ts"); if (module.value !== 7) throw new Error("synthetic import"); await Bun.write(process.env.TMPDIR + "/bunOutput", "seven"); console.log("Bun synthetic import/write verified")'
"""
    argv = ['bwrap', '--die-with-parent', '--new-session', '--unshare-all', '--ro-bind', '/', '/', '--tmpfs', '/tmp', '--dev', '/dev', '--proc', '/proc', '--cap-drop', 'ALL', '--bind', str(writable), logical, '--ro-bind', str(immutable), '/tmp/v4Immutable', '--remount-ro', '/tmp', '--chdir', logical + '/worktree', '--', '/bin/bash', '--noprofile', '--norc', '-euc', script]
    result = subprocess.run(argv, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    results.append({'physical': str(physical), 'logical': logical, 'argv': argv, 'environment': environment, 'exit': result.returncode, 'stdout': result.stdout.decode(), 'stderr': result.stderr.decode(), 'immutableUnchanged': (immutable / 'marker').read_text() == 'unchanged'})
(out / 'syntheticScratch.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
