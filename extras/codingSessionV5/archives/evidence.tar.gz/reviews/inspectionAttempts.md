# Review attempt retention

All nine initialReady runs, their patches, workspaces and public evidence were left unchanged. All three initial Python invalidAgentRun/600-second attempts remain invalid; supplemental checks do not replace or repair them.

Every executed supplemental check used sandboxTrial.shell (110-second child limit, 120-second enclosing command), on a new disposable copy under this directory. Candidate and original-control outputs and exit records are retained in checks/, including all expected failing original controls and all three failing candidate wholeCheck attempts. baselineWholeCheck used a git archive of the same immutable Atlas HEAD, inside the sandbox. No model invocation occurred.

Two unsuccessful static inspection operations are retained here rather than silently omitted:

- A combined filesystem-inspection / rg command returned 1 because `rg -n 'atlas check|error|failed|block|unavailable|timeout' .../navigationUnseenEdgeBudget/evidence/finalSummary.txt` matched nothing (case-sensitive). It had established that atlas/src/atlas/__main__.py exists and the run workspace dashboard/node_modules does not. Subsequently read B's public finalSummary.txt directly; no raw/private logs were consulted.
- A read of A's navigation workspace `/atlas.json` returned ENOENT. No file was created or changed. The repository whole-project checker was run using its normal configuration discovery instead; it reported the policy violations recorded in wholeCheck.stdout.

The first broad public-result display exceeded tool output limits. The complete derived inventory and sanitized trace summaries are retained in inventory.json and traces.txt; no private/raw output was opened to recover truncated text. snapshotDetails.txt uses positional list comparison and therefore exaggerates insertion churn; snapshotIdentity.json is the identity-preserving audit used for conclusions.

Profiles and holdout contents were not opened. Disposable copies omit directories named profiles/holdout. No installations, services, network access, prompt tuning, live workspace edits or source-workspace Git mutations were performed.
