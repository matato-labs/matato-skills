[root, testFile] = System.argv()

for {app, version} <- [decimal: ~c"3.2.0", ecto: ~c"3.14.2", telemetry: ~c"1.4.2"] do
  :ok = Application.load(app)
  ^version = Application.spec(app, :vsn)
end

files = Path.wildcard(Path.join(root, "lib/beer_game/game/**/*.ex"))
{:ok, _modules, _warnings} = Kernel.ParallelCompiler.compile(files, return_diagnostics: true)
ExUnit.start(seed: 0)
Code.require_file(testFile)
