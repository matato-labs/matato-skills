import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile
import time

artifacts = Path('/tmp/codingSessionV3/reviews/mutation')
isolation = Path(tempfile.mkdtemp(prefix='atlasMutationProbe'))
origin = Path('/tmp/codingSessionV3/worktrees/finalOne/candidateThree')
cases = ['memoryReferenceResolution', 'sessionTreeConfinement']
ledger = {'started': time.strftime('%Y-%m-%dT%H:%M:%S%z'), 'isolation': str(isolation), 'commandTimeoutSeconds': 120, 'maximumMutants': 3, 'commands': [], 'targets': {}, 'selected': [], 'executed': [], 'skipped': [], 'outcome': 'blocked: installed Atlas has no mutations command'}
started = time.monotonic()


def saveJson(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def git(root, *args):
    return subprocess.check_output(['/usr/bin/git', '-C', str(root), *args], timeout=120)


def fingerprint(root, names):
    result = {}
    for name in names:
        file = root / name
        if file.is_symlink():
            data = os.fsencode(os.readlink(file))
            kind = 'symlink'
        elif file.is_file():
            data = file.read_bytes()
            kind = 'file'
        else:
            result[name] = {'kind': 'missing'}
            continue
        result[name] = {'kind': kind, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'mode': oct(file.lstat().st_mode & 0o777)}
    return result


def run(label, command, cwd, runtime):
    if time.monotonic() - started > 780:
        raise RuntimeError('overall cutoff before next command')
    runtime.mkdir(parents=True, exist_ok=True)
    for name in ['home', 'storage', 'tmp', 'cache']:
        (runtime / name).mkdir(exist_ok=True)
    environment = {'PATH': os.environ['PATH'], 'HOME': str(runtime / 'home'), 'STORAGE_PATH': str(runtime / 'storage'), 'TMPDIR': str(runtime / 'tmp'), 'XDG_CACHE_HOME': str(isolation / 'cache'), 'XDG_CONFIG_HOME': str(runtime / 'home' / '.config'), 'PYTHONDONTWRITEBYTECODE': '1', 'DO_NOT_TRACK': '1', 'CI': '1', 'BUN_CONFIG_NO_CLEAR_TERMINAL': '1'}
    sandbox = ['/usr/bin/bwrap', '--ro-bind', '/', '/', '--bind', str(isolation), str(isolation), '--unshare-net', '--proc', '/proc', '--dev', '/dev', '--chdir', str(cwd), '--', *command]
    entry = {'label': label, 'command': command, 'sandboxCommand': sandbox, 'cwd': str(cwd), 'environment': environment, 'timeoutSeconds': 120, 'stdout': str(artifacts / (label + '.stdout.log')), 'stderr': str(artifacts / (label + '.stderr.log'))}
    begin = time.monotonic()
    with open(entry['stdout'], 'wb') as stdout, open(entry['stderr'], 'wb') as stderr:
        process = subprocess.Popen(sandbox, cwd=cwd, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
        entry['pid'] = process.pid
        try:
            entry['exit'] = process.wait(timeout=120)
            entry['timedOut'] = False
        except subprocess.TimeoutExpired:
            entry['timedOut'] = True
            os.killpg(process.pid, signal.SIGKILL)
            entry['exit'] = process.wait(timeout=5)
        finally:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    entry['durationSeconds'] = round(time.monotonic() - begin, 3)
    entry['processGroupCleanup'] = 'SIGKILL sent to remaining process group, or group already absent'
    ledger['commands'].append(entry)
    saveJson(artifacts / 'ledger.json', ledger)
    print(label, entry['exit'], entry['durationSeconds'], flush=True)
    return entry


def copyTarget(case):
    source = origin / case
    folder = isolation / case
    pristine = isolation / 'pristine' / case
    names = sorted(set(git(source, 'ls-files', '-z').decode().split('\0')) - {''})
    untracked = sorted(set(git(source, 'ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''})
    if untracked:
        raise RuntimeError('Unreviewed untracked files: ' + repr(untracked))
    initial = fingerprint(source, names)
    for target in [folder, pristine]:
        target.mkdir(parents=True)
        for name in names:
            file = source / name
            dest = target / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            if file.is_symlink():
                dest.symlink_to(os.readlink(file))
            elif file.is_file():
                shutil.copy2(file, dest)
    assert fingerprint(folder, names) == initial
    assert fingerprint(pristine, names) == initial
    caseArtifacts = artifacts / case
    caseArtifacts.mkdir()
    for label, args in [('status', ['status', '--porcelain=v2', '--untracked-files=all']), ('headDiff', ['diff', 'HEAD', '--binary', '--no-ext-diff']), ('stagedDiff', ['diff', '--cached', '--binary', '--no-ext-diff']), ('unstagedDiff', ['diff', '--binary', '--no-ext-diff'])]:
        (caseArtifacts / (label + '.txt')).write_bytes(git(source, *args))
    target = {'source': str(source), 'copy': str(folder), 'pristine': str(pristine), 'base': '4f2b75f73087b5f2c60995629c591dc91a591567', 'head': git(source, 'rev-parse', 'HEAD').decode().strip(), 'initial': initial, 'untracked': untracked, 'copyVerified': True}
    ledger['targets'][case] = target
    saveJson(caseArtifacts / 'sourceHashes.json', initial)
    (caseArtifacts / 'AGENTS.md').write_bytes((source / 'AGENTS.md').read_bytes())
    return folder


def main():
    print('Isolation:', isolation, flush=True)
    folders = {case: copyTarget(case) for case in cases}
    cache = Path('/home/leon/.cache/tree-sitter-language-pack')
    if cache.is_dir():
        shutil.copytree(cache, isolation / 'cache' / cache.name, symlinks=True)
    atlas = '/home/leon/.local/bin/atlas'
    bun = shutil.which('bun')
    runtime = isolation / 'runtime'
    for label, args in [('atlasHelp', ['--help']), ('mutationsHelp', ['mutations', '--help']), ('mutationsRules', ['mutations', '--rules']), ('atlasCheckHelp', ['check', '--help']), ('atlasReportHelp', ['report', '--help'])]:
        run(label, [atlas, *args], isolation, runtime / 'atlas')
    for case, folder in folders.items():
        run(case + 'FreshMutations', [atlas, 'mutations', '-f', str(folder)], folder, runtime / case)
        run(case + 'FreshWholeProjectAnalysis', [atlas, 'report', '-f', str(folder), '--format', 'json'], folder, runtime / case)
        if case == 'memoryReferenceResolution':
            tests = ['src/storage/memoryBlock.test.ts', 'src/agent/matatoAgentTools.test.ts', 'src/storage/database.test.ts']
            lint = ['src/storage/memoryBlock.ts', 'src/storage/memoryBlock.test.ts', 'src/storage/memoryRoomStore.ts', 'src/storage/memoryTopicStore.ts', 'src/storage/memoryItemStore.ts', 'src/storage/database.ts']
        else:
            tests = ['src/agent/matatoAgentSessions.test.ts', 'src/agent/matatoAgentPaths.test.ts', 'src/storage/work.test.ts']
            lint = ['src/agent/matatoAgentSessions.ts', 'src/agent/matatoAgentSessions.test.ts', 'src/agent/matatoAgentPaths.ts', 'src/config/configUtils.ts', 'src/storage/work.test.ts']
        run(case + 'BaselineTests', [bun, 'test', *tests], folder, runtime / case)
        run(case + 'BaselineTypes', [bun, 'node_modules/typescript/bin/tsc', '--noEmit'], folder, runtime / case)
        run(case + 'BaselineLint', [bun, 'node_modules/eslint/bin/eslint.js', *lint], folder, runtime / case)
    for case, target in ledger['targets'].items():
        names = list(target['initial'])
        target['sourceUnchanged'] = fingerprint(Path(target['source']), names) == target['initial']
        target['copyUnchanged'] = fingerprint(Path(target['copy']), names) == target['initial']
        target['pristineUnchanged'] = fingerprint(Path(target['pristine']), names) == target['initial']
        target['statusUnchanged'] = git(Path(target['source']), 'status', '--porcelain=v2', '--untracked-files=all') == (artifacts / case / 'status.txt').read_bytes()
        assert all(target[key] for key in ['sourceUnchanged', 'copyUnchanged', 'pristineUnchanged', 'statusUnchanged'])
    ledger['durationSeconds'] = round(time.monotonic() - started, 3)
    ledger['finished'] = time.strftime('%Y-%m-%dT%H:%M:%S%z')
    saveJson(artifacts / 'ledger.json', ledger)


main()
