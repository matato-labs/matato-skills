// Offline mock dispatch of the unmodified native factory; no Pi session/provider/auth.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import ponytail from '/experiment/package/pi-extension/index.js';
import { registerNativeTrace } from '/experiment/nativeTrace.ts';

const require = createRequire(import.meta.url);
const { getPonytailInstructions, filterSkillBodyForMode } = require('/experiment/package/hooks/ponytail-instructions.js');
const skill = readFileSync('/experiment/package/skills/ponytail/SKILL.md', 'utf8');
const expected = 'PONYTAIL MODE ACTIVE — level: full\n\n' + filterSkillBodyForMode(skill, 'full');
assert.equal(getPonytailInstructions('full'), expected, 'must use the real skill, not fallback');
const events = new Map();
const commands = new Map();
const entries = [];
const sent = [];
const pi = {
  on(name, handler) { events.set(name, [...(events.get(name) ?? []), handler]); },
  registerCommand(name, options) { commands.set(name, options); },
  appendEntry(customType, data) { entries.push({ customType, data }); },
  sendUserMessage(text, options) { sent.push({ text, options }); },
};
const ctx = { sessionManager: { getBranch: () => [] }, ui: { notify() {} }, isIdle: () => true };
async function emit(name, event) {
  for (const handler of events.get(name) ?? []) await handler(event, ctx);
}
ponytail(pi);
registerNativeTrace(pi, expected);
await emit('session_start', {});
for (let number = 0; number < 2; number += 1) {
  const event = { systemPrompt: 'BASE', systemPromptOptions: { sections: {}, appendSystemPrompt: '' } };
  await emit('before_agent_start', event);
  assert.equal(event.systemPromptOptions.sections.ponytail, expected);
  assert.equal(event.systemPrompt, 'BASE');
  await emit('context_with_system', { messages: [{ role: 'system', sections: { ponytail: `<ponytail>\n${expected}\n</ponytail>` } }] });
}
assert.equal(entries.filter((entry) => entry.customType === 'v5NativeActivation').length, 4);
assert.ok(entries.every((entry) => entry.data.valid));
// The observer must detect missing, wrong and removed sections, and redundant append.
for (const actual of ['', 'wrong', null]) {
  await emit('context_with_system', { messages: [{ role: 'system', sections: { ponytail: actual } }] });
  assert.equal(entries.at(-1).data.valid, false);
}
await emit('before_agent_start', { systemPromptOptions: { sections: {}, appendSystemPrompt: skill } });
assert.equal(entries.at(-1).data.valid, false);
for (const alias of ['review', 'audit', 'gain', 'debt', 'help']) {
  readFileSync(`/experiment/package/skills/ponytail-${alias}/SKILL.md`);
  await commands.get(`ponytail-${alias}`).handler('argument', ctx);
  assert.deepEqual(sent.at(-1), { text: `/skill:ponytail-${alias} argument`, options: { expandPromptTemplates: true } });
}
await commands.get('ponytail').handler('off', ctx);
const off = { systemPromptOptions: { sections: { ponytail: expected }, appendSystemPrompt: '' } };
await emit('before_agent_start', off);
assert.equal(off.systemPromptOptions.sections.ponytail, undefined);
assert.equal(entries.at(-1).data.valid, false);
console.log(JSON.stringify({ kind: 'offlineNativeFactoryAndObserverMock', instructions: expected,
  checks: ['real skill not fallback', 'full transformed body twice', 'base prompt unchanged',
    'observer detects absent/wrong/removed body and raw append', 'five aliases and resources', 'off removes section'] }));
