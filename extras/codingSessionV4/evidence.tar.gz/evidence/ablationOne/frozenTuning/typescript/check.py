import os
from pathlib import Path
import subprocess
import sys
import tempfile

caseFolder = Path(__file__).resolve().parent
caseRoot = Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory(prefix='checkRuntime', dir=caseFolder) as scratch:
    environment = {'PATH': os.environ['PATH'], 'HOME': scratch, 'TMPDIR': scratch,
                   'codingSessionCaseRoot': str(caseRoot), 'CI': 'true', 'NO_COLOR': '1'}
    command = ['bun', 'test', str(caseFolder / 'oracle.test.ts')]
    print('cwd:', caseRoot, flush=True)
    print('command:', ' '.join(command), flush=True)
    result = subprocess.run(command, cwd=caseRoot, env=environment, timeout=120)
    print('exit:', result.returncode, flush=True)
    sys.exit(result.returncode)
