#!/usr/bin/env python3
"""Cross native suites with explicit imports or temporary Go overlays."""
import json
from pathlib import Path
import tempfile
from reviewFrozenChecks import ROOT, LOGS, run

results=[]
with tempfile.TemporaryDirectory(prefix='crossFrozen-') as directory:
    scratch=Path(directory)
    for left,right in [('ponytailFrozen','codingFrozen'),('ponytailReplication','codingReplication')]:
        for tests,implementation in [(left,right),(right,left)]:
            for case in ['sourceBatchReads','pathEarlyExit','isinCsvRecords','scheduleTimeZones','pollProcessContract','preScriptIsolation']:
                origin=ROOT/'runs'/tests/case; target=ROOT/'runs'/implementation/case
                name=f'cross-{tests}-on-{implementation}-{case}'
                extra={}
                if case in ['sourceBatchReads','pathEarlyExit']:
                    cmd=[str(origin/'atlas/.venv/bin/python'),'-m','pytest','tests/test_graph_navigation.py','-q']
                    cwd=origin/'atlas'; extra={'PYTHONPATH':str(target/'atlas/src')}
                elif case in ['isinCsvRecords','pollProcessContract']:
                    package='data' if case=='isinCsvRecords' else 'sintropy'
                    filename='isin_loader_test.go' if package=='data' else 'messages_test.go'
                    overlay=scratch/'overlay.json'
                    overlay.write_text(json.dumps({'Replace':{str(target/'commons'/package/filename):str(origin/'commons'/package/filename)}}))
                    cmd=['go','test','-vet=off','-overlay',str(overlay),'./'+package,'-count=1','-v']
                    cwd=target/'commons'; extra={'GOWORK':'off','GOPROXY':'off','GOSUMDB':'off'}
                elif case=='scheduleTimeZones':
                    text=(origin/'worker/scheduler.test.ts').read_text()
                    for old,new in [('"./scheduler.ts"',target/'worker/scheduler.ts'),('"./testFixtures.ts"',origin/'worker/testFixtures.ts'),('"croner"',(target/'node_modules/croner/dist/croner.js').resolve())]:
                        text=text.replace(old,json.dumps(str(new)))
                    path=scratch/'scheduler.test.ts'; path.write_text(text)
                    cmd=['bun','test',str(path)]; cwd=target; extra={'TZ':'Asia/Tokyo'}
                else:
                    text=(origin/'src/worker/preScript.test.ts').read_text().replace("'./preScript'",json.dumps(str(target/'src/worker/preScript.ts')))
                    path=scratch/'preScript.test.ts'; path.write_text(text)
                    cmd=['bun','test',str(path)]; cwd=target; extra={'OTEL_SDK_DISABLED':'true','MATATO_TEST_STORAGE_PATH':str(scratch/'storage')}
                results.append(run((name,cmd,cwd,extra)))
(LOGS/'crossResults.json').write_text(json.dumps(results,indent=2)+'\n')
print('SUMMARY',json.dumps(results))
