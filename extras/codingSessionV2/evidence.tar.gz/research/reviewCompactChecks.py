#!/usr/bin/env python3
"""Reuse the frozen review runner unchanged except arm names and artifact paths."""
from pathlib import Path
import sys
import types

ROOT = Path(__file__).resolve().parent.parent
OLD = ['ponytailFrozen', 'codingFrozen', 'ponytailReplication', 'codingReplication']
NEW = ['ponytailCompact', 'codingCompact', 'ponytailCompactRepeat', 'codingCompactRepeat']

def adapted(name):
    text = (ROOT/'research'/name).read_text().replace('reviewFrozenLogs', 'reviewCompactLogs').replace('frozenMetrics.json', 'compactMetrics.json')
    for old, new in zip(OLD, NEW):
        text = text.replace(old, new)
    return text

def execute(name, namespace):
    namespace['__file__'] = str(ROOT/'research'/name)
    exec(compile(adapted(name), namespace['__file__'], 'exec'), namespace)

if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'checks'
    if mode == 'checks':
        execute('reviewFrozenChecks.py', {'__name__': '__main__'})
    elif mode == 'audit':
        execute('auditFrozen.py', {'__name__': '__main__'})
    else:
        module = types.ModuleType('reviewFrozenChecks')
        execute('reviewFrozenChecks.py', module.__dict__)
        sys.modules['reviewFrozenChecks'] = module
        if mode == 'cross':
            execute('crossFrozen.py', {'__name__': '__main__'})
        elif mode == 'integrity':
            text = adapted('frozenIntegrity.py')
            text = text[:text.index('# Prove the sole dynamic snapshot adapter')] + "print('UNCHANGED_INPUT_FILES',len(before))\n"
            exec(compile(text, str(ROOT/'research/frozenIntegrity.py'), 'exec'), {'__name__': '__main__'})
        else:
            raise SystemExit('mode must be checks, audit, cross or integrity')
