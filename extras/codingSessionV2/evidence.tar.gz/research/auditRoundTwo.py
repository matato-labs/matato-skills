#!/usr/bin/env python3
"""Verify actual diffs, metrics and all coffee snapshot changes."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
root = Path(__file__).resolve().parent.parent
logs = root / 'research/reviewRoundTwoLogs'
logs.mkdir(exist_ok=True)

def git(repo, *args):
    return subprocess.check_output(['git','-C',str(repo),*args])

def normalized(text):
    return text.replace('diff --git i/', 'diff --git a/').replace('diff --git c/', 'diff --git a/').replace(' w/', ' b/').replace('--- i/', '--- a/').replace('--- c/', '--- a/').replace('+++ w/', '+++ b/')

results, metrics = [], []
expected = {(row['variant'], row['caseName']): row['numstat'] for row in json.loads((root / 'finalMetrics.json').read_text())}
for variant in ['ponytailFinal', 'codingFinal']:
    for case in ['sourceBatchReads', 'isinCsvRecords', 'scheduleTimeZones', 'pathEarlyExit']:
        repo = root / 'runs' / variant / case
        patch = root / 'patches' / variant / (case + '.patch')
        actual = git(repo, 'diff', '--binary', 'HEAD').decode()
        assert normalized(actual) == normalized(patch.read_text()), (variant, case, 'patch differs')
        numstat = git(repo, 'diff','--numstat','HEAD').decode()
        assert numstat == expected[variant,case], (variant,case,'numstat differs')
        base = root / 'base' / case
        assert git(repo, 'rev-parse','HEAD') == git(base, 'rev-parse','HEAD')
        source, tests = [0,0], [0,0]
        for line in numstat.splitlines():
            add, delete, path = line.split('\t')
            dest = tests if ('/tests/' in path or '.test.' in path or path.endswith('_test.go')) else source
            dest[0] += int(add); dest[1] += int(delete)
        def counts(pair):
            return dict(added=pair[0], deleted=pair[1], churn=sum(pair), net=pair[0]-pair[1])
        metrics.append(dict(variant=variant,case=case,source=counts(source),tests=counts(tests),combined=counts([source[i]+tests[i] for i in [0,1]])))
        changed = git(repo,'diff','--name-only','HEAD').decode().splitlines()
        untracked = git(repo,'ls-files','--others','--exclude-standard').decode().splitlines()
        results.append(dict(variant=variant,case=case,head=git(repo,'rev-parse','HEAD').decode().strip(),patchSha256=hashlib.sha256(patch.read_bytes()).hexdigest(),changed=changed,untracked=untracked,diffCheck=subprocess.run(['git','-C',str(repo),'diff','--check'],capture_output=True).returncode))
        for path in [p for p in changed if '/snapshots/' in p]:
            old = json.loads(git(repo,'show','HEAD:'+path))
            new = json.loads((repo/path).read_text())
            assert old.keys() == new.keys()
            differences = [key for key in old if old[key] != new[key]]
            assert len(differences) == 1, (path,differences)
            key, = differences
            before, after = old[key], new[key]
            assert before.keys() == after.keys()
            fields = [field for field in before if before[field] != after[field]]
            assert set(fields) <= {'nodes','edges','boundaries'}
            assert before['status'] == after['status'] == 'found'
            assert after['edges'] == before['edges'][:len(after['edges'])]
            assert after['edges'][-1] == after['pathEdges'][-1]
            assert after['nodes'] == before['nodes'][:len(after['nodes'])]
            external = sorted(node['stableKey'] for node in after['nodes'] if node.get('unresolved'))
            assert after['boundaries'] == [{'stableKey':k,'reason':'unresolved_or_ambiguous','expandable':False} for k in external]
            other = root / 'runs' / ('codingFinal' if variant == 'ponytailFinal' else 'ponytailFinal') / case / path
            assert (repo/path).read_bytes() == other.read_bytes()
            print('SNAPSHOT',variant,path,key,'fields='+','.join(fields),'nodes='+str(len(before['nodes']))+'->'+str(len(after['nodes'])),'edges='+str(len(before['edges']))+'->'+str(len(after['edges'])),'external='+str(len(external)))
for variant in ['ponytailFinal','codingFinal']:
    for group in ['source','tests','combined']:
        total = {key:sum(m[group][key] for m in metrics if m['variant']==variant) for key in ['added','deleted','churn','net']}
        print('TOTAL',variant,group,total)
for profile in sorted((root/'profiles').glob('*.md')):
    data = profile.read_bytes()
    print('PROFILE',profile.name,len(data),len(data.split()),len(data.splitlines()))
(logs/'verifiedMetrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
(logs/'hygiene.json').write_text(json.dumps(results,indent=2)+'\n')
manifest = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for directory in ['profiles','patches','research/oracles','research/supplemental'] for p in sorted((root/directory).rglob('*')) if p.is_file()}
(logs/'inputHashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
