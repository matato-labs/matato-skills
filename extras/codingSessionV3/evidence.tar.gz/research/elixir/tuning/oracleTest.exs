defmodule QuantityBoundaryTest do
  use ExUnit.Case, async: true

  alias BeerGame.Game.{Board, CpuOrderData, Order, Player, PlayerOrders}
  import Ecto.Changeset, only: [apply_action: 2, apply_changes: 1, get_field: 2, put_assoc: 3]

  @player %{name: "Retailer", role: "retailer", stock: 8, backlog: 8,
            weekly_orders: 4, last_order: 4}
  @cases [{Order, %{amount: 4, type: "PLAYER_ORDER"}, [:amount]},
          {CpuOrderData, %{amount: 4}, [:amount]},
          {Player, @player, [:stock, :backlog, :weekly_orders, :last_order]}]

  defp params(attrs, :atoms), do: attrs
  defp params(attrs, :strings), do: Map.new(attrs, fn {key, value} -> {Atom.to_string(key), value} end)

  defp record(schema, attrs, action), do: struct(schema, if(action == :insert, do: %{}, else: attrs))

  defp changed(attrs, field, value, action) do
    if action == :insert, do: Map.put(attrs, field, value), else: %{field => value}
  end

  defp invalid(changeset, fields, action) do
    refute changeset.valid?
    assert Enum.sort(Keyword.keys(changeset.errors)) == Enum.sort(fields)
    assert {:error, _changeset} = apply_action(changeset, action)
  end

  for {schema, attrs, fields} <- @cases,
      field <- fields,
      value <- [-1, -41, "-1", "-41"],
      keys <- [:atoms, :strings],
      action <- [:insert, :update] do
    test "#{inspect(schema)} #{field}=#{inspect(value)} #{keys} #{action} is rejected" do
      schema = unquote(schema)
      attrs = unquote(Macro.escape(attrs))
      field = unquote(field)
      action = unquote(action)
      original = record(schema, attrs, action)
      changes = changed(attrs, field, unquote(value), action)
      changeset = schema.changeset(original, params(changes, unquote(keys)))
      invalid(changeset, [field], action)
      assert changeset.data == original
    end
  end

  for {schema, attrs, fields} <- @cases,
      value <- [0, "0", 1, "17", 1_000_000_000],
      keys <- [:atoms, :strings],
      action <- [:insert, :update] do
    test "#{inspect(schema)} allows #{inspect(value)} on all quantity fields #{keys} #{action}" do
      schema = unquote(schema)
      attrs = unquote(Macro.escape(attrs))
      fields = unquote(fields)
      value = unquote(value)
      original = if unquote(action) == :insert, do: struct(schema), else: struct(schema, attrs)
      changed = Enum.reduce(fields, attrs, &Map.put(&2, &1, value))
      changeset = schema.changeset(original, params(changed, unquote(keys)))
      assert changeset.valid?
      assert changeset.errors == []
      assert {:ok, applied} = apply_action(changeset, unquote(action))
      expected = unquote(if is_binary(value), do: String.to_integer(value), else: value)
      assert Enum.all?(fields, &(Map.fetch!(applied, &1) == expected))
      assert changeset.data == original
    end
  end

  for mask <- 1..15, keys <- [:atoms, :strings] do
    test "all invalid player fields are reported for subset #{mask} #{keys}" do
      fields = [:stock, :backlog, :weekly_orders, :last_order]
      invalidFields = fields |> Enum.with_index() |> Enum.filter(fn {_field, index} ->
        Bitwise.band(unquote(mask), Bitwise.bsl(1, index)) != 0
      end) |> Enum.map(&elem(&1, 0))
      changes = Map.new(invalidFields, &{&1, "-2"})
      original = struct(Player, @player)
      changeset = Player.changeset(original, params(changes, unquote(keys)))
      invalid(changeset, invalidFields, :update)
      assert changeset.data == original
    end
  end

  for {schema, attrs, fields} <- @cases, field <- fields,
      value <- [nil, "", "not an integer", "1.5", 1.5], keys <- [:atoms, :strings] do
    test "#{inspect(schema)} preserves required/cast error #{field}=#{inspect(value)} #{keys}" do
      schema = unquote(schema)
      original = struct(schema, unquote(Macro.escape(attrs)))
      changeset = schema.changeset(original, params(%{unquote(field) => unquote(value)}, unquote(keys)))
      invalid(changeset, [unquote(field)], :update)
      {_message, metadata} = Keyword.fetch!(changeset.errors, unquote(field))
      expected = if unquote(value) in [nil, ""], do: :required, else: :cast
      assert metadata[:validation] == expected
      assert changeset.data == original
    end
  end

  test "empty inserts retain all existing required fields and the order default" do
    for {schema, fields} <- [{Order, [:amount, :type]}, {CpuOrderData, [:amount]},
                            {Player, [:name, :role, :stock, :backlog, :weekly_orders, :last_order]}] do
      changeset = schema.changeset(struct(schema), %{})
      invalid(changeset, fields, :insert)
      assert Enum.all?(changeset.errors, fn {_field, {_message, metadata}} -> metadata[:validation] == :required end)
    end
    assert get_field(Order.changeset(%Order{}, %{}), :state) == "PENDING"
  end

  test "existing initial inventories, no-op changesets and partial changes remain valid" do
    for {role, stock, weekly} <- [{"retailer", 8, 4}, {"wholesaler", 120, 60}, {"factory", 1200, 600}] do
      original = struct(Player, Map.merge(@player, %{role: role, stock: stock, backlog: stock,
                                                  weekly_orders: weekly, last_order: weekly}))
      assert {:ok, ^original} = original |> Player.changeset(%{}) |> apply_action(:update)
      changed = Player.changeset(original, %{"weekly_orders" => "0", "name" => "Renamed"})
      assert {:ok, applied} = apply_action(changed, :update)
      assert applied.weekly_orders == 0
      assert applied.name == "Renamed"
      assert applied.stock == stock and applied.last_order == weekly and applied.backlog == stock
    end
    for type <- ["CPU_ORDER", "PLAYER_ORDER"] do
      original = %Order{amount: 4, type: type}
      assert {:ok, ^original} = original |> Order.changeset(%{}) |> apply_action(:update)
      assert {:ok, %Order{amount: 4, state: "DELIVERED", type: ^type}} =
        original |> Order.changeset(%{state: "DELIVERED"}) |> apply_action(:update)
    end
    original = %CpuOrderData{amount: 4}
    assert {:ok, ^original} = original |> CpuOrderData.changeset(%{}) |> apply_action(:update)
  end

  test "schema associations can still be attached through existing Ecto helpers" do
    board = %Board{name: "Workshop"}
    player = Player.changeset(%Player{}, @player) |> put_assoc(:board, board)
    assert player.valid?
    assert apply_changes(player).board == board
    cpu = CpuOrderData.changeset(%CpuOrderData{}, %{amount: "0"}) |> put_assoc(:player, apply_changes(player))
    assert cpu.valid?
    assert apply_changes(cpu).player.role == "retailer"
    order = Order.changeset(%Order{}, %{amount: "0", type: "PLAYER_ORDER"}) |> apply_changes()
    association = PlayerOrders.changeset(%PlayerOrders{}, %{type: "SENDING"})
                  |> put_assoc(:order, order) |> put_assoc(:player, apply_changes(player))
    assert association.valid?
    assert apply_changes(association).order.amount == 0
  end
end
