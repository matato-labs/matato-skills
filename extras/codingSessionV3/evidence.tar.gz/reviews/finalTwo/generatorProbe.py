import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

from tests.coffee_fixture import SNAPSHOT_ROOT
from tests import update_coffee_snapshots
from tests.variant_snapshot_support import variant_snapshot

records = []


def differences(before, after, path='$'):
    if isinstance(before, dict) and isinstance(after, dict):
        return [item for key in sorted(before.keys() | after.keys()) for item in differences(before.get(key), after.get(key), path+'.'+key)]
    if isinstance(before, list) and isinstance(after, list):
        if len(before) != len(after):
            return [dict(path=path, beforeLength=len(before), afterLength=len(after))]
        return [item for index, (old, new) in enumerate(zip(before, after)) for item in differences(old, new, f'{path}[{index}]')]
    return [] if before == after else [dict(path=path, before=before, after=after)]


def capture(path, text, encoding=None, errors=None, newline=None):
    if not path.is_relative_to(SNAPSHOT_ROOT):
        raise RuntimeError(f'Unexpected write outside snapshot root: {path}')
    actual = json.loads(text)
    expected = json.loads(path.read_text()) if path.exists() else None
    delta = differences(expected, actual)
    records.append(dict(path=str(path.relative_to(SNAPSHOT_ROOT)), sha256=hashlib.sha256(text.encode()).hexdigest(), bytes=len(text.encode()), differences=len(delta), examples=delta[:10]))
    return len(text)


if sys.argv[1:] == ['operational']:
    path = SNAPSHOT_ROOT / 'variants/operational.json'
    capture(path, json.dumps(variant_snapshot('operational'), ensure_ascii=False, separators=(',', ':'))+'\n')
else:
    sys.argv = [sys.argv[0], '--navigation']
    with patch.object(Path, 'write_text', capture):
        update_coffee_snapshots.main()
print(json.dumps(records, indent=2))
