import { afterEach, beforeEach, expect, test } from 'bun:test'
import { mkdir, mkdtemp, rm } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import type { SequenceStepConfig } from '../base/src/config/sequences'

const caseRoot = process.env.codingSessionCaseRoot!
const store = await import(path.join(caseRoot, 'src/storage/sequenceConfig.ts')) as typeof import('../base/src/storage/sequenceConfig')
const { withDatabaseConnection, migrateStorageDatabase, runInStorageTransaction } = await import(path.join(caseRoot, 'src/storage/database.ts')) as typeof import('../base/src/storage/database')
const { initializeBootstrapConfigStorage, loadBootstrapConfigFromStorage } = await import(path.join(caseRoot, 'src/storage/config.ts')) as typeof import('../base/src/storage/config')
const { createTestBootstrapConfig } = await import(path.join(caseRoot, 'src/test/bootstrapConfig.ts')) as typeof import('../base/src/test/bootstrapConfig')
const schema = await import(path.join(caseRoot, 'src/storage/schema.ts')) as typeof import('../base/src/storage/schema')
let scratchPath = ''
let previousPath: string | undefined

const bootstrap = (): ReturnType<typeof createTestBootstrapConfig> => ({
  ...createTestBootstrapConfig({ provider: 'openrouter', id: 'low' }),
  enabledThinkingLevels: ['low', 'medium', 'minimal'],
  models: [
    { provider: 'openrouter', modelId: 'low', enabled: true },
    { provider: 'openrouter', modelId: 'disabled', enabled: false },
  ],
})

const step = (name: string, model = 'low'): SequenceStepConfig => ({
  step: name, model, thinkingLevel: 'low', canLaunchSubAgents: true,
  skillName: 'example', loop: false, delay: null,
})

const snapshot = () => withDatabaseConnection((database) => ({
  parents: database.select().from(schema.sequence).all(),
  steps: database.select().from(schema.sequenceStep).all(),
  config: database.select().from(schema.config).all(),
  models: database.select().from(schema.models).all(),
}))

beforeEach(async () => {
  previousPath = process.env.MATATO_TEST_STORAGE_PATH
  scratchPath = await mkdtemp(path.join(os.tmpdir(), 'sequenceOracle'))
  process.env.MATATO_TEST_STORAGE_PATH = scratchPath
  withDatabaseConnection(migrateStorageDatabase)
  initializeBootstrapConfigStorage(bootstrap())
  await mkdir(path.join(scratchPath, 'agent', 'skills', 'example'), { recursive: true })
})

afterEach(async () => {
  if (previousPath === undefined) delete process.env.MATATO_TEST_STORAGE_PATH
  else process.env.MATATO_TEST_STORAGE_PATH = previousPath
  await rm(scratchPath, { recursive: true, force: true })
})

for (const model of ['missing', 'disabled']) {
  test(`later ${model} model leaves no rows and permits corrected retry`, async () => {
    const sentinel = await store.createSequenceConfigInStorage('sentinel', 'free', [step('existing')])
    const before = snapshot()
    await expect(store.createSequenceConfigInStorage('retry', 'project', [step('first'), step('last', model)])).rejects.toThrow()
    const after = snapshot()
    const retry = await store.createSequenceConfigInStorage('retry', 'project', [step('first'), step('last')]).then(
      (value) => value,
      (error: Error) => ({ error: error.message }),
    )
    expect(after).toEqual(before)
    expect(retry).toMatchObject({ name: 'retry', mode: 'project', steps: [{ step: 'first' }, { step: 'last' }] })
    expect(await store.readSequenceConfigFromStorage(sentinel.id)).toEqual(sentinel)
  })
}

test('invalid thinking level rolls back parent and retains model selection rejection', async () => {
  const before = snapshot()
  await expect(store.createSequenceConfigInStorage('thinking', 'free', [{ ...step('first'), thinkingLevel: 'xhigh' }])).rejects.toThrow()
  expect(snapshot()).toEqual(before)
})

test('later database failure rolls back earlier steps and preserves error and existing definitions', async () => {
  await store.createSequenceConfigInStorage('sentinel', 'project', [step('existing')])
  const before = snapshot()
  withDatabaseConnection((database) => database.run(`
    create trigger rejectLaterStep before insert on sequenceStep
    when new.step = 'blocked' begin select raise(abort, 'deliberateStepFailure'); end;
  `))
  let failure = ''
  try {
    await store.createSequenceConfigInStorage('retry', 'free', [step('first'), step('blocked')])
  } catch (error) {
    if (!(error instanceof Error)) throw error
    failure = error.message + String(error.cause ?? '')
  } finally {
    withDatabaseConnection((database) => database.run('drop trigger rejectLaterStep'))
  }
  const after = snapshot()
  const retry = await store.createSequenceConfigInStorage('retry', 'free', [step('first'), step('last')]).then(
    (value) => value,
    (error: Error) => ({ error: error.message }),
  )
  expect(failure).toContain('deliberateStepFailure')
  expect(after).toEqual(before)
  expect(retry).toMatchObject({ name: 'retry', steps: [{ step: 'first' }, { step: 'last' }] })
})

test('successful drafts and rich ordered steps retain stable read/list/state semantics', async () => {
  const draft = await store.createSequenceConfigInStorage('draft', 'free', [])
  await Bun.write(path.join(scratchPath, 'agent', 'skills', 'example', 'prepare.ts'), 'export const run = () => null')
  const steps: Array<SequenceStepConfig> = [
    { ...step('secondByName'), loop: true, delay: '5m', preScriptName: 'prepare.ts' },
    { ...step('firstByName'), canLaunchSubAgents: false, preScriptName: null },
  ]
  const created = await store.createSequenceConfigInStorage('ordered', 'project', steps)
  expect(created.id.length).toBeGreaterThan(0)
  expect(created.id).not.toBe(draft.id)
  expect(created.steps).toEqual(steps)
  expect(await store.readSequenceConfigFromStorage(created.id)).toEqual(created)
  expect(await store.readSequenceConfigFromStorage('ordered')).toEqual(created)
  expect(await store.listSequenceConfigsFromStorage()).toEqual([draft, created])
  expect(await store.readSequenceStateFromStorage('ordered')).toMatchObject({ steps, totalWorks: 0, pendingMessages: 0 })
  const before = snapshot()
  await expect(store.createSequenceConfigInStorage('ordered', 'free', [])).rejects.toThrow('already exists')
  expect(snapshot()).toEqual(before)
})

test('existing transactional replacement still rolls back when a later step insert fails', async () => {
  const created = await store.createSequenceConfigInStorage('replace', 'free', [step('old')])
  const before = snapshot()
  withDatabaseConnection((database) => database.run(`
    create trigger rejectReplacement before insert on sequenceStep
    when new.step = 'blocked' begin select raise(abort, 'replacementFailure'); end;
  `))
  await expect(store.updateSequenceConfigInStorage('replace', 'project', [step('first'), step('blocked')])).rejects.toThrow()
  expect(snapshot()).toEqual(before)
  expect(await store.readSequenceConfigFromStorage(created.id)).toEqual(created)
})

test('record helper remains composable within a caller transaction', () => {
  const before = snapshot()
  expect(() => withDatabaseConnection((database) => runInStorageTransaction(database, () => {
    store.createSequenceConfigs(database, [{ name: 'bulk', mode: 'free', steps: [step('first')] }])
    throw new Error('callerFailure')
  }))).toThrow('callerFailure')
  expect(snapshot()).toEqual(before)
})

test('bootstrap creates multiple sequences atomically without nesting transactions', async () => {
  process.env.MATATO_TEST_STORAGE_PATH = path.join(scratchPath, 'bootstrap')
  withDatabaseConnection(migrateStorageDatabase)
  const before = snapshot()
  const file = {
    ...bootstrap(),
    sequences: [
      { name: 'one', mode: 'free' as const, steps: [step('first')] },
      { name: 'two', mode: 'project' as const, steps: [step('last', 'missing')] },
    ],
  }
  expect(() => initializeBootstrapConfigStorage(file)).toThrow()
  expect(snapshot()).toEqual(before)
  file.sequences[1]!.steps = [step('last')]
  initializeBootstrapConfigStorage(file)
  expect(await store.listSequenceConfigsFromStorage()).toMatchObject([
    { name: 'one', mode: 'free', steps: [{ step: 'first' }] },
    { name: 'two', mode: 'project', steps: [{ step: 'last' }] },
  ])
  const after = snapshot()
  initializeBootstrapConfigStorage(file)
  expect(snapshot()).toEqual(after)
  expect(await loadBootstrapConfigFromStorage()).toMatchObject({ sequences: [{ name: 'one' }, { name: 'two' }] })
})
