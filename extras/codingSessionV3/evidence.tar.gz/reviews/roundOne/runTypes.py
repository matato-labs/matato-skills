from pathlib import Path

review = Path('/tmp/codingSessionV3/reviews/roundOne')
source = (review / 'runReview.py').read_text().split('\ncases = {}')[0]
exec(source.replace("'commands.json'", "'typesCommands.json'"))
for arm in ['candidateOne', 'main', 'pr', 'ponytail']:
    folder = review / 'copies' / arm / 'pythonUnicodeGraphFind'
    (folder / 'atlas/.venv').symlink_to('/home/leon/workspace/projects/atlas/atlas/.venv', target_is_directory=True)
    command = f'cd "{folder}/atlas" && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="{folder}/atlas/src:{folder}/atlas" /home/leon/workspace/projects/atlas/atlas/.venv/bin/pyright'
    run(arm + 'PythonTypesWithSharedVenv', command, folder)
