from collections import Counter
from pathlib import Path
import json

root = Path(__file__).parent
row = next(x for x in json.loads((root/'inventory.json').read_text()) if x['label'] == 'A' and x['path'].endswith('navigationUnseenEdgeBudget'))
patch = (Path(row['path'])/'evidence/changes.patch').read_text()
data = {}
for chunk in patch.split('diff --git ')[1:]:
    path = chunk.splitlines()[0].split(' b/')[1]
    if '/snapshots/' not in path:
        continue
    data[Path(path).stem] = [json.loads('\n'.join(x[1:] for x in chunk.splitlines() if x.startswith(mark) and not x.startswith(mark*3))) for mark in ['-', '+']]

result = []
def identified(name, before, after, key):
    a, b = {key(x): x for x in before}, {key(x): x for x in after}
    assert len(a) == len(before) and len(b) == len(after)
    changed = {k: [a[k], b[k]] for k in a if k in b and a[k] != b[k]}
    result.append({'collection': name, 'before': len(a), 'after': len(b), 'removed': sorted(a.keys()-b.keys()), 'added': sorted(b.keys()-a.keys()), 'changedExisting': changed})

def multiset(name, before, after):
    a, b = [Counter(json.dumps(x, sort_keys=True) for x in rows) for rows in [before, after]]
    result.append({'collection': name, 'removed': [json.loads(x) for x in (a-b).elements()], 'added': [json.loads(x) for x in (b-a).elements()]})

a, b = data['extraction']
identified('extraction.files', a['files'], b['files'], lambda x: x['source']['path'])
a, b = data['analysis']
identified('analysis.symbols', a['symbols'], b['symbols'], lambda x: x['key'])
multiset('analysis.connections', a['resolved']['connections'], b['resolved']['connections'])
a, b = data['graph']
identified('graph.nodes', a['nodes'], b['nodes'], lambda x: x['stableKey'])
multiset('graph.edges', a['edges'], b['edges'])
a, b = data['cli']
identified('report.nodes', a['report-json']['output']['nodes'], b['report-json']['output']['nodes'], lambda x: x['stableKey'])
(root/'snapshotIdentity.json').write_text(json.dumps(result, indent=2)+'\n')
for item in result:
    print(item['collection'], 'removed', len(item['removed']), 'added', len(item['added']), 'changedExisting', len(item.get('changedExisting', {})))
