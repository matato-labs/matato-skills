"""V4 independent pin census; no preparer imports and no excluded sensitive input reads."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
from typing import TypeAlias, TypedDict, cast

JsonValue: TypeAlias = str | int | float | bool | None | list['JsonValue'] | dict[str, 'JsonValue']


class Pin(TypedDict):
    record: str
    target: str
    sha256: str
    classification: str
    status: str


root = Path('/tmp/codingSessionV4')
owned = Path('/home/leon/.cache/codingSessionV4Owned')
audit = owned / 'publicationAudit'
manifest = cast(dict[str, dict[str, str | int]], json.loads((owned / 'publicationPrep/candidateMembers.json').read_text()))
errors: list[str] = []
records: list[Pin] = []
metadata: list[dict[str, str]] = []
externalNames = {'pi', 'bun', 'bwrap', 'bash', 'python3.14', 'python3.11', 'git'}
dependencyNames = {'activate', 'alembic', 'atlas', 'atlas-migrate', 'mako-render', 'nodeenv',
                   'pygmentize', 'pyright', 'pyright-langserver', 'pyright-python',
                   'pyright-python-langserver', 'pytest', 'python', 'python3', 'ruff'}


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def parse(name: str) -> list[tuple[str, str]]:
    text = (root / name).read_text()
    if text.lstrip().startswith('{'):
        value = cast(dict[str, JsonValue], json.loads(text))
        entries = cast(dict[str, JsonValue], value.get('artifacts', value))
        result: list[tuple[str, str]] = []
        for target, entry in entries.items():
            sha = cast(str, entry['sha256'] if isinstance(entry, dict) else entry)
            if not re.fullmatch('[a-f0-9]{64}', sha):
                raise ValueError('Unparsed JSON pin in ' + name)
            result.append((target, sha))
        return result
    result = []
    for index, line in enumerate(text.splitlines()):
        match = re.fullmatch(r'([a-f0-9]{64})\s+\*?(.+)', line)
        if match:
            result.append((match[2], match[1]))
            continue
        if name.endswith('sourceHashes.txt') and (line.startswith('base ') or re.fullmatch('[a-f0-9]{40}', line)):
            metadata.append({'record': name, 'line': str(index + 1), 'classification': 'git revision metadata, not file pin'})
            continue
        raise ValueError('Unparsed checksum line in ' + name)
    return result


def classify(path: Path, name: str) -> str:
    if '.git' in path.parts or path.name in {'config', 'auth.json', 'settings.json', '.env'}:
        return 'excludedSensitiveOrGitMetadataNotRead'
    if 'private' in path.parts or path.name.startswith('.env'):
        return 'excludedPrivateNotRead'
    if path.is_relative_to(root) and str(path.relative_to(root)) in manifest:
        return 'includedFrozenArtifact'
    if path.name in externalNames and str(path).startswith(('/usr/bin/', '/home/leon/.local/share/')):
        return 'excludedInstalledLauncher'
    if path.name in dependencyNames and '/oracle/' in str(path):
        return 'excludedCopiedDependencyLauncher'
    if name.endswith('extensionlessLauncherHashes.json'):
        return 'excludedSourceOrGeneratedCacheInventory'
    if name.endswith('sourceHashes.txt') and path.name in {'setup', 'manual_deps'}:
        return 'excludedPinnedOriginalSource'
    return 'unclassified'


def check(name: str, target: str, sha: str) -> None:
    path = Path(target)
    if not path.is_absolute():
        path = root / Path(name).parent / path
    path = Path(os.path.normpath(path))
    kind = classify(path, name)
    status = 'notReadByExplicitSafetyPolicy'
    if kind == 'unclassified':
        errors.append(name + ': unclassified target ' + str(path))
    elif kind not in {'excludedSensitiveOrGitMetadataNotRead', 'excludedPrivateNotRead'}:
        status = 'matches' if path.is_file() and digest(path) == sha else 'missingOrMismatch'
        if status != 'matches':
            errors.append(name + ': ' + status + ': ' + str(path))
    if kind == 'includedFrozenArtifact':
        logical = str(path.relative_to(root))
        if manifest[logical]['sha256'] != sha:
            errors.append(name + ': archive candidate differs: ' + logical)
    records.append({'record': name, 'target': str(path), 'sha256': sha, 'classification': kind, 'status': status})


def main() -> None:
    selected = sorted(name for name in manifest if
        (name.startswith('research/') and (any(term in Path(name).name.lower() for term in ('freeze', 'hash')) or name.endswith('.sha256'))) or
        (name.startswith('evidence/') and ('launcher' in Path(name).name.lower() or Path(name).name == 'driverAndHarnessHashes.json')))
    for name in selected:
        for target, sha in parse(name):
            check(name, target, sha)
    # Snapshot freeze/hash files duplicate canonical frozen research inputs; verify their complete bytes.
    snapshots: list[dict[str, str | bool]] = []
    canonical = [name for name in selected if name.startswith('research/')]
    for name in manifest:
        if '/frozenInputs/' not in name and '/frozenTuning/' not in name:
            continue
        if not any(term in Path(name).name.lower() for term in ('freeze', 'hash')) and not name.endswith('.sha256'):
            continue
        matches = [source for source in canonical if manifest[source]['sha256'] == manifest[name]['sha256']]
        snapshots.append({'path': name, 'canonical': ','.join(matches), 'matches': bool(matches)})
        if not matches:
            errors.append('Frozen snapshot not identical to canonical pin record: ' + name)
    summary = {'independentParser': 'auditPins.py v1, no preparer imports', 'pinFiles': selected,
               'pinRecords': len(records), 'classifications': dict(Counter(item['classification'] for item in records)),
               'statuses': dict(Counter(item['status'] for item in records)), 'errors': errors,
               'metadata': metadata, 'snapshotPinCopies': snapshots, 'records': records,
               'scope': 'Every record parsed/classified. Sensitive/git metadata not read; explicitly excluded. Broad extensionless inventory includes copied source and caches, not just launchers. No actual custom frozen extensionless launcher exists in selected V4 research tree; original extensionless setup is omitted source, whole patches retained. Installed/copied dependency launchers hashed, never distributed. Non-hermetic.'}
    (audit / 'scans/independentPins.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k not in {'records', 'snapshotPinCopies'}}, indent=2))


if __name__ == '__main__':
    main()
