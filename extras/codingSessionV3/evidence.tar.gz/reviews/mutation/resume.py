import json
from pathlib import Path
import shutil

artifacts = Path('/tmp/codingSessionV3/reviews/mutation')
script = (artifacts / 'probe.py').read_text()
script = script.removesuffix('main()\n').replace("isolation = Path(tempfile.mkdtemp(prefix='atlasMutationProbe'))", "isolation = Path('/tmp/atlasMutationProbexdlsom_3')")
context = {}
exec(compile(script, str(artifacts / 'probe.py'), 'exec'), context)
ledger = context['ledger']
ledger['commands'] = json.loads((artifacts / 'recoveredCommands.json').read_text())
ledger['started'] = '2026-10-15T20:27:17+0200'
ledger['infrastructureIncident'] = 'Initial ledger rewrite hit disk quota after completed memory lint. All command records recovered intact from its complete commands array; initial source hashes retained separately. Removed only owned copied parser bundles and Bun cache; no source/test command changed. Resumed remaining target; no mutant executed.'
for case in context['cases']:
    source = context['origin'] / case
    initial = json.loads((artifacts / case / 'sourceHashes.json').read_text())
    ledger['targets'][case] = {'source': str(source), 'copy': str(context['isolation'] / case), 'pristine': str(context['isolation'] / 'pristine' / case), 'base': '4f2b75f73087b5f2c60995629c591dc91a591567', 'head': context['git'](source, 'rev-parse', 'HEAD').decode().strip(), 'initial': initial, 'untracked': [], 'copyVerified': True}
case = 'sessionTreeConfinement'
folder = context['isolation'] / case
runtime = context['isolation'] / 'runtime' / case
run = context['run']
atlas = '/home/leon/.local/bin/atlas'
bun = shutil.which('bun')
run(case + 'FreshMutations', [atlas, 'mutations', '-f', str(folder)], folder, runtime)
run(case + 'FreshWholeProjectAnalysis', [atlas, 'report', '-f', str(folder), '--format', 'json'], folder, runtime)
shutil.rmtree(context['isolation'] / 'cache' / 'tree-sitter-language-pack')
run(case + 'BaselineTests', [bun, 'test', 'src/agent/matatoAgentSessions.test.ts', 'src/agent/matatoAgentPaths.test.ts', 'src/storage/work.test.ts'], folder, runtime)
run(case + 'BaselineTypes', [bun, 'node_modules/typescript/bin/tsc', '--noEmit'], folder, runtime)
run(case + 'BaselineLint', [bun, 'node_modules/eslint/bin/eslint.js', 'src/agent/matatoAgentSessions.ts', 'src/agent/matatoAgentSessions.test.ts', 'src/agent/matatoAgentPaths.ts', 'src/config/configUtils.ts', 'src/storage/work.test.ts'], folder, runtime)
for case, target in ledger['targets'].items():
    names = list(target['initial'])
    for key, root in [('sourceUnchanged', target['source']), ('copyUnchanged', target['copy']), ('pristineUnchanged', target['pristine'])]:
        target[key] = context['fingerprint'](Path(root), names) == target['initial']
        assert target[key], (case, key)
    target['statusUnchanged'] = context['git'](Path(target['source']), 'status', '--porcelain=v2', '--untracked-files=all') == (artifacts / case / 'status.txt').read_bytes()
    assert target['statusUnchanged']
ledger['finished'] = context['time'].strftime('%Y-%m-%dT%H:%M:%S%z')
ledger['mutants'] = {'selected': 0, 'executed': 0, 'skipped': 0, 'killed': 0, 'survived': 0, 'invalid': 0, 'timeout': 0, 'inconclusive': 0}
context['saveJson'](artifacts / 'ledger.json', ledger)
print('FINISHED. All tracked bytes, modes, symlinks, source status and pristine copies verified unchanged.', flush=True)
