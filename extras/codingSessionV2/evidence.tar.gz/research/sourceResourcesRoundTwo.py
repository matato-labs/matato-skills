#!/usr/bin/env python3
"""Observations only: real bytes, returned buffers and batch adaptation allocations."""
import gc
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import tracemalloc

repo = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(repo / 'atlas/src'))
from atlas.domain.navigation import GraphSnapshot
from atlas.services.navigation import NavigationService
from atlas.services import navigation_source as source


class Reader:
    def __init__(self, root, nodes, hashes):
        self.snapshot = GraphSnapshot('repo', 'rev', None, str(root))
        self.nodes, self.hashes = nodes, hashes

    def node(self, key):
        return self.nodes[key]

    def file(self, path):
        return [{'sha256': self.hashes[path]}]

    def diagnostics(self, paths, limit):
        return []


def measure(label, service, keys):
    gc.collect()
    gc.disable()
    tracemalloc.start()
    result = service.sources(keys, 1, None)
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    gc.enable()
    assert len(result['sources']) == len(keys)
    print(json.dumps(dict(workload=label, rows=len(keys), current_bytes=current, peak_bytes=peak)))


with tempfile.TemporaryDirectory() as d:
    root = Path(d)
    ineligible = dict(stableKey='x', path=None, level='external')
    service = NavigationService(Reader(root, {'x':ineligible}, {}))
    measure('ineligible_batch', service, ['x'] * 20000)
    data = b'short\n' + b'x\n' * (512 * 1024)
    hashes, nodes = {}, {}
    for i in range(4):
        key = str(i)
        (root/key).write_bytes(data)
        hashes[key] = hashlib.sha256(data).hexdigest()
        nodes[key] = dict(stableKey=key,path=key,level='file',startLine=None,endLine=None)
    del data
    service = NavigationService(Reader(root, nodes, hashes))
    measure('four_distinct_mib_buffers', service, list(nodes))
    # No tracemalloc timing claims. Verify bytes don't stay rooted past the call.
    assert all(row['lines'] == ['short'] for row in service.sources(list(nodes), 1, None)['sources'])
    counts = {}
    def profile(frame, event, arg):
        if event == 'call' and frame.f_code.co_filename == source.__file__:
            name = frame.f_code.co_name
            counts[name] = counts.get(name, 0) + 1
    sys.setprofile(profile)
    service.source('0', 1, None)
    sys.setprofile(None)
    print('SINGLE_SOURCE_MODULE_CALLS', json.dumps(counts, sort_keys=True))
