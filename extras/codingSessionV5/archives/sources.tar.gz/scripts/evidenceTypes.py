"""Only the Pi 1.2.0 JSON fields consumed by this harness (docs/json.md)."""
from typing import NotRequired, TypedDict


class Cost(TypedDict, total=False):
    input: float
    output: float
    cacheRead: float
    cacheWrite: float
    total: float


class Usage(TypedDict, total=False):
    input: int
    output: int
    cacheRead: int
    cacheWrite: int
    cacheWrite1h: int
    reasoning: int
    totalTokens: int
    cost: Cost


class Content(TypedDict):
    type: str
    text: NotRequired[str]


class Message(TypedDict):
    role: str
    content: list[Content]
    provider: str
    model: str
    usage: NotRequired[Usage]
    responseModel: NotRequired[str]
    responseId: NotRequired[str]
    thinkingLevel: NotRequired[str]
    providerThinkingLevel: NotRequired[str]
    stopReason: NotRequired[str]


class Arguments(TypedDict, total=False):
    path: str
    command: str
    offset: int
    limit: int
    timeout: int


class ToolResult(TypedDict):
    content: list[Content]


class Event(TypedDict):
    type: str
    message: NotRequired[Message]
    toolCallId: NotRequired[str]
    toolName: NotRequired[str]
    args: NotRequired[Arguments]
    result: NotRequired[ToolResult]
    isError: NotRequired[bool]
    durationMs: NotRequired[float]
    aborted: NotRequired[bool]


class Loc(TypedDict):
    physical: int
    nonblank: int
    code: int


class FileMeasure(TypedDict):
    path: str
    category: str
    binary: bool
    added: int | None
    deleted: int | None
    addedBytes: int | None
    deletedBytes: int | None
    baseBytes: int
    resultBytes: int
    byteGrowth: int
    beforeLoc: Loc
    afterLoc: Loc
