import concurrent.futures
import difflib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/tmp/codingSessionV4')
out = Path('/home/leon/.cache/codingSessionV4Owned/reviews/finalOne')
private = out / 'copies'
specification = importlib.util.spec_from_file_location('reviewSandbox', root / 'sandboxTrial.py')
helper = importlib.util.module_from_spec(specification)
specification.loader.exec_module(helper)
cases = [json.loads((root / path).read_text())['cases'][0] for path in ['research/python/manifest.json', 'research/typescript/tuning/manifest.json', 'research/typescript/reserve/manifest.json', 'research/additional/reserve/manifest.json']]
python = '/home/leon/workspace/projects/atlas/atlas/.venv/bin/python'
metrics = {}
checksums = {}
audit = {}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def archive(case, target):
    target.mkdir(parents=True)
    data = subprocess.check_output(['git', '-C', case['repo'], 'archive', case['base']])
    with tarfile.open(fileobj=io.BytesIO(data)) as packed:
        packed.extractall(target, filter='data')
    if case['id'] in ['preScriptEnvironmentLifetime', 'sequenceCreateRecovery']:
        (target / 'node_modules').symlink_to(Path(case['repo']) / 'node_modules')

def category(name):
    if '/snapshots/' in name:
        return 'snapshots'
    if '/fixtures/' in name:
        return 'fixtures'
    return 'tests' if '/tests/' in name or '.test.' in name else 'production'

def runJob(case, identity, target, label, command, timeout=240):
    runtime = out / 'runtime' / identity / case['id'] / label
    oracle = root / ('research/python' if case['id'] == 'pythonConfinedIgnoreFiles' else 'research/typescript/tuning' if case['id'] == 'preScriptEnvironmentLifetime' else 'research/typescript/reserve' if case['id'] == 'sequenceCreateRecovery' else 'research/additional/reserve')
    repo = Path(case['repo'])
    dependencies = [Path('/home/leon/.local/share/uv/python/cpython-3.11-linux-x86_64-gnu'), Path('/home/leon/.cache/tree-sitter-language-pack/v1.20.0/libs')] if case['id'] == 'pythonConfinedIgnoreFiles' else []
    spec = {'worktree': target, 'repo': repo, 'common': repo / '.git', 'oracle': oracle, 'runtime': runtime, 'profile': out / 'unused', 'profileSnapshot': out / 'unused', 'config': out / 'unused', 'auth': out / 'unused', 'dependencies': dependencies, 'pi': Path('/home/leon/.local/share/mise/installs/pi/1.1.0/pi/pi')}
    log = out / 'logs' / identity / case['id']
    log.mkdir(parents=True, exist_ok=True)
    result = helper.shell(spec, label, command, log, timeout)
    print(identity, case['id'], label, result['exit'], result['seconds'], flush=True)
    return {'identity': identity, 'case': case['id'], 'label': label, **result}

def prepare(case, roundName, arm):
    identity = roundName + '/' + arm
    caseId = case['id']
    trial = root / 'runs' / roundName / arm / caseId
    live = root / 'worktrees' / roundName / arm / caseId
    target = private / identity / caseId
    original = private / 'original' / caseId
    archive(case, target)
    patch = (trial / 'changes.patch').read_bytes()
    subprocess.run(['git', 'apply', '--unsafe-paths', '-p1', '-'], input=patch, cwd=target, check=True)
    changed = subprocess.check_output(['git', '-C', live, 'diff', '--name-only']).decode().splitlines()
    changed += subprocess.check_output(['git', '-C', live, 'ls-files', '--others', '--exclude-standard']).decode().splitlines()
    details = []
    for name in sorted(set(changed) - {'node_modules'}):
        baseFile, newFile = original / name, target / name
        old = baseFile.read_bytes() if baseFile.exists() else b''
        new = newFile.read_bytes() if newFile.exists() else b''
        assert new == (live / name).read_bytes(), name
        checksums[f'{identity}/{caseId}/{name}'] = digest(new)
        diff = subprocess.run(['git', 'diff', '--no-index', '--numstat', '--', str(baseFile) if baseFile.exists() else '/dev/null', str(newFile)], stdout=subprocess.PIPE).stdout.decode()
        added, deleted = map(int, diff.split()[:2])
        normalized = list(difflib.unified_diff([line.strip() for line in old.decode().splitlines() if line.strip()], [line.strip() for line in new.decode().splitlines() if line.strip()], n=0))
        details.append({'path': name, 'category': category(name), 'additions': added, 'deletions': deleted, 'churn': added + deleted, 'baseBytes': len(old), 'resultBytes': len(new), 'byteGrowth': len(new) - len(old), 'nonblankStrippedAdditions': sum(line.startswith('+') and not line.startswith('+++') for line in normalized), 'nonblankStrippedDeletions': sum(line.startswith('-') and not line.startswith('---') for line in normalized)})
    metrics[f'{identity}/{caseId}'] = details
    return identity, trial, target, details

def currentTask(case, arm):
    identity, trial, target, details = prepared[(case['id'], arm)]
    results = []
    for label, key in [('frozenBehavior', 'checkCommand'), ('frozenNative', 'nativeCommand')]:
        results.append(runJob(case, identity, target, label, case[key].replace('{root}', str(target)), 120))
    if case['id'] in ['pythonConfinedIgnoreFiles', 'sequenceCreateRecovery']:
        results.append(runJob(case, identity, target, 'nativeDiagnostic240', case['nativeCommand'].replace('{root}', str(target))))
    if case['id'] in ['preScriptEnvironmentLifetime', 'sequenceCreateRecovery']:
        tests = [item['path'] for item in details if item['path'].endswith('.test.ts')]
        command = 'bun test ' + ' '.join(tests)
        if case['id'] == 'sequenceCreateRecovery' and 'src/api/routes/sequenceRoutes.test.ts' not in tests:
            command += ' src/api/routes/sequenceRoutes.test.ts'
        results.append(runJob(case, identity, target, 'allMaintainedAndApi', command))
        paths = [item['path'] for item in details if item['path'].endswith('.ts')]
        results.append(runJob(case, identity, target, 'changedLint', 'bun node_modules/eslint/bin/eslint.js ' + ' '.join(paths)))
    negative = private / (identity + 'OriginalProduction') / case['id']
    archive(case, negative)
    for item in details:
        if item['category'] == 'production':
            continue
        destination = negative / item['path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((target / item['path']).read_bytes())
    if case['id'] == 'pythonConfinedIgnoreFiles':
        command = f'cd atlas && PYTHONPATH="{negative}/atlas/src" {python} -B -m pytest -p no:cacheprovider -q tests/test_discovery.py tests/test_atlasignore.py tests/test_coffee_pipeline.py'
    elif case['id'] == 'shellBootstrapLocation':
        command = case['checkCommand'].replace('{root}', str(negative))
    else:
        command = 'bun test ' + ' '.join(item['path'] for item in details if item['path'].endswith('.test.ts'))
    results.append(runJob(case, identity, negative, 'originalProductionMaintained', command))
    return results


def correctedPython(arm):
    case = cases[0]
    identity = 'finalOne/' + arm
    target = private / identity / case['id']
    results = []
    for label, key, limit in [('frozenBehaviorMountCorrected', 'checkCommand', 120), ('frozenNativeMountCorrected', 'nativeCommand', 120), ('nativeDiagnostic240MountCorrected', 'nativeCommand', 240)]:
        results.append(runJob(case, identity, target, label, case[key].replace('{root}', str(target)), limit))
    return results

jobs = [('python', arm) for arm in ['v3', 'v2', 'ponytail', 'candidateTwo']]
jobs += [('lifetime', ('finalOne', arm)) for arm in ['v3', 'v2', 'ponytail', 'candidateTwo']]
for roundName, arms in [('ablationOne', ['v3', 'reuseAblation']), ('tuningOne', ['v3', 'v2', 'ponytail', 'candidateOne']), ('tuningTwo', ['v3', 'v2', 'candidateTwo'])]:
    for arm in arms:
        jobs += [('earlierPython', (roundName, arm))]
        if arm != 'candidateTwo' or roundName != 'tuningTwo':
            jobs += [('lifetime', (roundName, arm))]
jobs += [('consumers', arm) for arm in ['v3', 'v2', 'ponytail', 'candidateTwo']]

def additionalTask(job):
    kind, value = job
    if kind == 'python':
        return correctedPython(value)
    if kind == 'consumers':
        case = cases[2]
        identity = 'finalOne/' + value
        target = private / identity / case['id']
        return [runJob(case, identity, target, 'existingApiAndAgentConsumers', 'bun test src/api/server.test.ts src/agent/matatoAgentTools.test.ts')]
    roundName, arm = value
    case = cases[0] if kind == 'earlierPython' else cases[1]
    identity = roundName + '/' + arm
    target = private / identity / case['id']
    needsPatch = not target.exists() or roundName == 'tuningTwo'
    if not target.exists():
        archive(case, target)
    if needsPatch:
        patch = root / 'reviews/tuningTwo' / (arm + '.' + case['id'] + '.partial.patch') if roundName == 'tuningTwo' else root / 'runs' / roundName / arm / case['id'] / 'changes.patch'
        subprocess.run(['git', 'apply', '--unsafe-paths', '-p1', '-'], input=patch.read_bytes(), cwd=target, check=True)
    live = root / 'worktrees' / roundName / arm / case['id']
    changed = subprocess.check_output(['git', '-C', live, 'diff', '--name-only']).decode().splitlines()
    changed += subprocess.check_output(['git', '-C', live, 'ls-files', '--others', '--exclude-standard']).decode().splitlines()
    for name in set(changed) - {'node_modules'}:
        assert (target / name).read_bytes() == (live / name).read_bytes(), str(target / name)
    return [runJob(case, identity, target, 'nativeDiagnostic240CorrectMount' if kind == 'earlierPython' else 'lifetimeNativeDiagnostic240', case['nativeCommand'].replace('{root}', str(target)))]

with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    results = list(pool.map(additionalTask, jobs))
(out / 'supplementCommands.json').write_text(json.dumps([item for group in results for item in group], indent=2) + '\n')
print('SUPPLEMENTS DONE', flush=True)
