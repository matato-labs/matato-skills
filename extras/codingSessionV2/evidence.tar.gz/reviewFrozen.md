# Independent review — round four and fixed replication

## Verdict

**Fail to demonstrate the requested win; not a correctness-failure verdict on the frozen implementations.** All four complete arms pass the six frozen task oracles, scheduler additional acceptance, and relevant earlier supplements. Coding is larger in both pairs: **546 vs 380 combined churn** first, **441 vs 388** replication. Production is also larger: **136 vs 117**, then **123 vs 118**. The first coding arm avoids repeated decoding, at a distinct-file memory cost; replication does not reproduce that optimization. There is no supported overall “less code, more efficient, without completeness loss” result.

Do not select the earlier seven-line combined advantage, mix per-case winners, or call the smaller replication difference a win. The observed size outcome favors Ponytail twice, but this small, partly adaptively developed task set does not establish universal superiority of either skill. Acceptance-equivalent implementations also need not have equivalent maintained regression coverage: three CSV suites do not reproduce the parsing bug at all.

This evidence does **not** justify superiority-labelled PR creation or Ponytail removal. No source fixes, profile edits, parent changes, commits, delegation, PRs or removals performed. Added only this report and review artifacts under `research/`. The proposed shorter skill below is untested, not a new winning profile.

## Protocol and scoped integrity

Read `reviewInitial.md`, `reviewRoundTwo.md`, `reviewRoundThree.md`, both current profiles, all 24 saved diffs, corresponding production paths and relevant integration code. Minified snapshots were decoded and checked structurally, not treated as two semantically trivial lines. Used all six `frozenBriefs.json` cases unchanged. The independent holdout preparation and precommitted replication/no-first-metrics-peeking protocol are supplied experiment facts; this review verifies artifacts/results, not the historical blinding timeline independently.

Actual `git diff --binary HEAD` matches all 24 saved patches after diff-prefix normalization; actual numstats match `frozenMetrics.json`. All candidate HEADs match their appropriate clean bases, all whitespace checks pass, no untracked candidate files escape accounting, production changes stay within allowedScope, and no README changes occur. Base commits remain Atlas `64017b7…`, mini-broker `4b1e143…`, scheduler `92ec284…`, pre-script `4f2b75f…` (full HEADs in `hygiene.json`).

The compact **134-file** before/after manifest covers changed candidate files, saved patches, briefs/metrics, profiles and frozen checks, not entire worktrees/dependency trees. Unchanged after acceptance/native/cross/resource diagnostics. Original oracle hashes match `research/cases.json`; all earlier supplemental manifests and `research/finalBaseLogs/frozen.sha256` verify. Evidence: `research/reviewFrozenLogs/{inputHashes.json,immutability.json,integrity.log,hygiene.json,audit.log}`. Audit logs contain handled missing-HEAD-file messages for newly added tests, not failed checks.

## Exact accounting

Churn = additions + deletions against common starting commits; net = additions − deletions. Tests include config tests and coffee fixtures/adapters. Every cell below is **production / tests / combined churn**.

| Case | Ponytail first | coding first | Ponytail replication | coding replication |
|---|---:|---:|---:|---:|
| sourceBatchReads | 26 / 25 / 51 | 41 / 28 / 69 | 30 / 26 / 56 | 30 / 23 / 53 |
| isinCsvRecords | 37 / 13 / 50 | 39 / 45 / 84 | 37 / 18 / 55 | 40 / 34 / 74 |
| scheduleTimeZones | 10 / 35 / 45 | 14 / 35 / 49 | 10 / 27 / 37 | 10 / 31 / 41 |
| pathEarlyExit | 13 / 33 / 46 | 13 / 37 / 50 | 13 / 27 / 40 | 13 / 32 / 45 |
| pollProcessContract | 16 / 70 / 86 | 14 / 110 / 124 | 14 / 90 / 104 | 16 / 105 / 121 |
| preScriptIsolation | 15 / 87 / 102 | 15 / 155 / 170 | 14 / 82 / 96 | 14 / 93 / 107 |
| **Total** | **117 / 263 / 380** | **136 / 410 / 546** | **118 / 270 / 388** | **123 / 318 / 441** |

| Arm | Production added/deleted; net | Tests added/deleted; net | Combined added/deleted; net |
|---|---:|---:|---:|
| Ponytail first | 71/46; +25 | 254/9; +245 | 325/55; +270 |
| coding first | 86/50; +36 | 399/11; +388 | 485/61; +424 |
| Ponytail replication | 73/45; +28 | 267/3; +264 | 340/48; +292 |
| coding replication | 76/47; +29 | 307/11; +296 | 383/58; +325 |

Coding minus Ponytail: first **+19 production, +147 tests, +166 combined churn**; replication **+5, +48, +53**. Summing both pairs gives **987 vs 768 combined churn (+219)** and **259 vs 235 production (+24)**; this is descriptive, not twelve independent task samples.

Ignoring blank/comment-only lines and horizontal whitespace gives production/test/combined churn **109/246/355 vs 124/384/508** first; **106/250/356 vs 108/299/407** replication. This line-normalization proxy retains line boundaries; it is not a semantic complexity metric. It confirms the overall gap is not just whitespace, while much of the small replication production gap is movement/formatting.

Detailed added/deleted/net/normalized counts: `verifiedMetrics.json`; Python structural footprint: `footprint.json`. No complexity was moved into another production module or dependency. Test files contain assertions, fixtures, transports and real pre-script input modules, **not a relocated runtime implementation**. Production does not import these tests.

## Checks actually run

`research/reviewFrozenChecks.py` executed **96 entries, all exit zero**, recording exact command, cwd, environment and output. Entries include observations, not 96 independent test suites. For **each of the four arms**:

| Frozen check | Outcome |
|---|---|
| Original source, 5 methods | pass |
| Original CSV, 13 public embedded-data scenarios | pass |
| Original scheduler, 7 tests | pass |
| Original path, 8 methods | pass |
| New poll/process, 6 scenarios | pass |
| New pre-script, 6 tests | pass |
| New scheduler factory contract, 8 tests | pass |
| Earlier source/CSV/scheduler supplements, 3/12/9 | pass |
| Frozen path supplement, 6 methods including 36-budget grid | pass |
| Real-SQL supplement, 4 cases | pass |

The ninth scheduler supplement observes dependency behavior. SQL uses the existing frozen portable interpreter wrapper, not altered assertions. Prior negative-control failures are documented in the earlier reports and `research/finalBaseLogs/`; the seven task/factory negative controls were **not rerun** here.

| Native checks | P first | C first | P replication | C replication |
|---|---:|---:|---:|---:|
| Source graph-navigation pytest | 47 pass | 48 pass | 48 pass | 48 pass |
| Path graph-navigation pytest | 47 pass | 47 pass | 47 pass | 47 pass |
| Coffee navigation pytest, in each Python case | 14 pass each | 14 pass each | 14 pass each | 14 pass each |
| CSV Go package | pass | pass | pass | pass |
| Poll/process Go package: table scenarios | 3 pass | 7 pass | 6 pass | 6 pass |
| Scheduler + config Bun, each of three local zones | 13 pass | 13 pass | 13 pass | 13 pass |
| Direct pre-script Bun | 4 pass | 5 pass | 4 pass | 4 pass |

Python imports are explicitly selected using `PYTHONPATH=src` or absolute candidate source paths. Scheduler native runs use Asia/Tokyo, UTC and America/Los_Angeles. Go commands disable network resolution. `-vet=off` was used for native Go runs; poll/process has the documented pre-existing unrelated logger-format vet blockers, so these are not vet-clean claims. Resource probes identify their actual candidate module; allocations use CPython **3.11.16** in every Atlas environment. Standalone-oracle launcher is Python **3.14.7**; Go **1.26.1**, Bun **1.4.1** (`environment.log`).

`research/crossFrozen.py` ran **24 native cross invocations**: both directions, both pairs, all six cases. **23 pass; one cannot compile**: coding-first CSV tests reference its private `loadISINs(io.Reader,n)` helper absent in Ponytail. Exact diagnostic: `undefined: loadISINs`. This is a testability-seam mismatch, **not evidence of a Ponytail parsing failure**. No assertion or source was adapted to erase it. Both public-API CSV oracle suites pass all arms. All eight cross invocations for the two new holdouts pass, including coding-first's stronger error-identity checks on Ponytail.

Logs: `research/reviewFrozenLogs/{results.json,runner.log,nativeSummary.log,crossResults.json,crossRunner.log}` and named per-invocation logs. None of the native pass counts is a coverage score.

## Semantic reuse and resource findings

### Source batch: first-only CPU saving, real memory tradeoff

All four use a call-local cache, one indexed verification lookup/local read/hash per distinct eligible path, including failures. External/pathless nodes exit before access. Span/pagination/excerpt outcomes remain per consumer. Single-source public behavior and failure precedence agree. AST comparison confirms unchanged containment, pinned-descriptor access, decoding-coordinate rules, status metadata and excerpt policy in every arm; size limits remain unchanged. Later requests see fresh bytes/index records; duplicate output lists remain independently mutable.

```text
P first + both replications: path -> verified bytes -> full decode/split per node -> excerpt
C first only:               path -> verified lines ----------------------------> excerpt
```

For 100 same-file nodes, all arms do **1 verification / 1 read / 1 hash**; full transformations are **100 / 1 / 100 / 100** in P-first/C-first/P-rep/C-rep order. This holds for valid and unsupported encoding. Two ten-node encoding-failure calls repeat verification twice; decoding counts are **20 / 2 / 20 / 20**. Lifetime is correctly per request.

For a 1,064,960-byte file, 100 duplicates hand **106,496,000 vs 1,064,960 bytes** to the decode helper in the first pair. All arms perform eight decodes for eight distinct files. Per-node slicing, excerpt encoding/size checks, response assembly and node enrichment still occur. This is fewer full transformations, not a measured 100× runtime speedup; failed decoding may stop at its first byte.

| Synthetic traced peak allocations | P first | C first | P replication | C replication |
|---|---:|---:|---:|---:|
| 20,000 ineligible entries | 4,027,664 B | 4,027,664 B | 4,027,664 B | 4,027,664 B |
| Four distinct ~1 MiB files, 64-character lines | 11,595,081 B | 14,363,835 B | 11,595,081 B | 11,595,081 B |
| Eight distinct such files | 15,857,529 B | 22,317,955 B | 15,857,529 B | 15,857,529 B |
| 100 duplicates of one such file | 8,399,171 B | 8,399,171 B | 8,399,171 B | 8,399,171 B |

C-first's eight-file peak is **6,460,426 B (~41%) higher**. The baseline bounded read dominates the duplicate-file peak, so fewer transformations do not reduce that peak here. Current allocations after returning the eight-file response are only 6,840 B in the byte-cache arms and 7,232 B in C-first: no whole-file cache persists. Every cache still retains all distinct successful files for the call; the 8 MiB bound is per file, not a batch memory cap. These are synthetic `tracemalloc` allocations, not RSS or representative latency distributions.

Real SQLite traces remain identical: ten repeated file keys or ten repeated symbol keys cause **42 SELECTs**, including **10 node-enrichment file-metadata queries and 1 verification query**. One node uses six SELECTs. The clarified verification-port bound passes; total database work is not O(distinct paths). Evidence: `resources-*.log`, `sql-*.log`; unchanged probes `sourceResourcesRoundThree.py` and `supplemental/sourceSqlWorkPortable.py`.

### CSV: precise native parsing in every arm; unequal maintained regressions

All use strict `encoding/csv`, unconstrained header width then exactly three data fields, check errors before indexing, and check record limits before the next `Read`. Native quoting, multiline records, CRLF normalization, blank-line skipping and large records replace the custom physical-line parser. No `ReadAll` occurs in production. Reader buffering can prefetch suffix bytes; the guarantee is bounded record parsing, not exact byte consumption.

Ponytail's two production files are identical. C-rep is the same algorithm with local declaration movement. C-first extracts one reader helper for maintained input-injection tests; it opens/closes the embedded file even for nonpositive n, whereas the other three return before opening. That helper is testability scaffolding, not a second parser or broader runtime reuse. C-first's two extra production churn lines do not indicate a slower positive-prefix algorithm.

**Do not classify the first coding CSV test difference as disposable bloat.** Its 45 lines exercise 11 table cases plus embedded-prefix integration: quoted/multiline/large/whitespace data, malformed widths/quotes, nonpositive limits and invalid tails inside/outside the prefix. Ponytail's 13/18 lines exercise only normal production-data limits/content. C-rep's 34 lines parse all 74 physical lines of embedded data with `ReadAll` to compare normal output and bounds; despite more scaffolding, they do not exercise the broken input classes.

A direct independent diagnostic overlays each of P-first, P-rep and C-rep's production loader with the **unchanged original base loader**, retaining its native tests: **all three suites still pass**. Logs: `native-csv-base-source-*.log`. Therefore these suites do not preserve the parsing regression. The external frozen overlays establish present correctness but are **not a substitute for necessary maintained regressions**. C-first's private-helper suite cannot run on the original source without changing the seam; no synthetic helper/fix was inserted. The right lesson is focused durable behavioral examples, not fewer assertions or treating external acceptance as repository coverage.

### Scheduler: shared semantic policy closes the prior gap

All arms add the production optional field, forward it through the existing optional factory argument and Croner option, and validate explicit enabled zones in **buildSchedules**, before either factory. Empty and ordinary bad zones reject with default **and zone-agnostic injected** factories. Already-created candidates stop; old schedules remain usable. Disabled bad jobs remain inert. Existing config spreading preserves stored zones; the real worker uses this scheduler. Duplicate/monitor/cron-mode checks, overlap state across reloads and stop behavior remain intact. Five/six-field DST, fractional offsets, stored config and real timer cleanup pass the original/earlier checks.

The previous injected-factory gap is closed in all four; neither arm has a precise-native-reuse advantage here. Actual default construction costs are identical: **9 Intl formatter constructions** for UTC/Kathmandu, **0** for omitted, **1** before empty/ordinary-invalid rejection. The injected probe uses **1** for explicit valid zones and rejects both bad forms. The extra boundary validation duplicates some default-constructor work but enforces the required extension-point contract; deleting it on default-only evidence would be incomplete. All timezone date arithmetic still belongs to installed Croner 10.0.1, not a new implementation. C-first's additional four production churn lines are expanded call formatting. Evidence: `semantics-*.log`, `factory-*.log`, scheduler supplements.

### Path: same bounded BFS work; fixture adapter is not hidden production

All reuse the existing BFS, admission budgets, deterministic ordering, parent reconstruction and external non-expansion. Only `path` supplies a target; `context` remains a full bounded traversal. Identity succeeds before expansion, and admitted discovery returns before later neighbors/fetch-limit bookkeeping. The frozen 36-budget grid and direction/tie/external/missing-key/exhaustion cases pass. No storage or public-request changes. C-first makes the internal constructor's target required, while `traverse` retains its optional default; all internal callers supply it. Other arms retain that constructor default too. This is plumbing, not less graph work.

The three fixed-snapshot arms have identical revised snapshots. Exactly one successful response per language changes only ordered node/edge prefixes and retained boundaries; routes, metadata, filters and other responses stay unchanged. Aggregate reduction: **45 gathered nodes and 61 edges** across eight languages. P-rep instead adds ten lines projecting expected prefixes from the **old fixture's** target/path-edge positions, never from actual response lengths. Independently applying that adapter to all eight fixtures gives exactly the other arms' fixed expected JSON (`integrity.log`). It is test-side expectation calculation, **not runtime code hidden in tests or deleted assertions**; nevertheless it adds a fixture-maintenance algorithm and assumes a nonempty path-edge list for these fixtures. Its physical-line advantage over minified snapshot replacements is not a six-unit semantic simplification.

### New Go holdout: same existing-client and native-error reuse

All poll through the configured receiver, pass PollRequest unchanged, fill exactly n ID slots by index, preserve order/duplicates, call the processor once, and choose the existing dequeue/mark-failed endpoint. Poll failure/empty polls never process or acknowledge; the original **100 ms** empty backoff remains. Existing HTTP methods preserve poll/dequeue/typed acknowledgement causes. Native `errors.Join` replaces overwritten processor errors, not custom aggregate-error machinery. No new client, transport, retry policy or endpoint implementation in production.

P-first and C-rep join even when marking failed succeeds; C-first and P-rep return the original processor error in that case and join only dual failure. Both satisfy `errors.Is`/`errors.As`; conditional joining avoids a wrapper in the successful-mark branch. This small source/ownership distinction **switches arms in replication**. All use one exact-size ID slice, removing the original append-after-length error and associated growth/wasted slots. No allocation benchmark or HTTP throughput advantage measured.

C-first has seven native scenarios vs P-first's three, adding empty/poll/dequeue failures and transport/error-chain preservation. Those are **distinct required contracts**, not automatically redundant tests. Its transport adapter and separate case type/method contribute scaffolding; P-first's loopback server is shorter but does not directly reproduce the original custom-transport-bypass risk. In replication both have six scenarios; coding's extra 15 lines add explicit processed-message equality, acknowledgement-after-processing, cause identity and typed-cause assertions. Cross-passing proves compatible implementations, not that those assertions should be deleted.

### New TypeScript holdout: identical lifetime fix, variable scaffolding

All retain the existing module-wide mutex and nested finally ownership, await the returned run inside it, preserve `undefined` versus empty-string snapshots, restore both environment views and release the queue after import/run failure. Existing import mtime URL, synchronous results, shell spawning, skip interpretation, logging and exported signatures are untouched. No new lock/queue/import abstraction or per-script process added. Serialized async execution is required correctness, not an optional throughput optimization. Scope is process-local TypeScript callers; unrelated writers/threads are not isolated.

P/C first production differs only in saved-type alias names; replication differs in inline `Record` vs `Partial` types. Runtime algorithms are the same. Native tests create real temporary scripts because the API consumes paths; these are legitimate input fixtures, not substitute implementations. All preserve async values, both environment views, restoration and recovery over sync throw/async rejection/import failure.

C-first's **155 vs 87 test lines** include a typed control module, gate setup, deterministic entry/release observation, original rejection identity, explicit property-presence assertions, and a separate synchronous-result case. Gates/identity and synchronous preservation are meaningful, not 68 proven redundant lines. Some per-test setup creates controls for cases that do not need all controls; smaller shared fixtures could retain those contracts. Its implementation report records test-only deadlock debugging before final passing tests; final source/oracles were not altered by this reviewer. Replication is **93 vs 82**, with compact case generation in both. Coding adds an overlap sentinel and checks all override keys before/after suspension; Ponytail also protects empty/absent restoration. No meaningful platform test-space explosion is demonstrated.

The two new tasks contribute **+108 test churn first, +26 replication** to coding's excess. Much is stronger checking, not less precise runtime reuse. Repeated isolation-case scaffolding is a plausible target for instruction simplification, but the experiment does not causally prove verbose wording induced it or establish a minimal sufficient line count.

## Shorter generalizable skill proposal — not applied

Frozen coding skill independently measures **4,724 UTF-8 bytes / 641 whitespace words / 33 lines**, within **5,121 / 740 / 36**. Replace repeated necessity checklists and overlapping test/completeness prose with one boundary, reuse and verification rule each. Keep native semantic probing and extension-point ownership; require durable regressions without turning each acceptance phrase into a separate fixture/test framework. No task solutions, metric targets, assertion deletion instructions or outsourcing of needed maintained tests.

The complete proposal is:

```markdown
---
name: coding-session
description: Implement and fix code with the smallest readable change that fully meets the request.
disable-model-invocation: true
---

# Coding session

Read the request, repository instructions, affected code and existing tests. Find the shared cause and the callers, types, exports, configuration and fixtures the change must reach. Preserve existing acceptance guarantees. Ask only about ambiguity that changes correctness; do not create an extra specification unless requested.

Change existing code first. Prefer an existing project facility, then a standard library or platform operation, then an installed dependency, before direct implementation. Read the actual contract; when uncertain, probe the production call shape, options and callbacks. Check consumption limits, omission versus explicit values, ordering, partial results, error identity and ownership. Reuse authoritative semantic policy across callers and extension points, not merely similarly named APIs. Keep native values native; count adapters as part of the solution.

Keep trust-boundary validation, security, synchronization, accessibility, data-loss protections and required cleanup. Preserve failure, replacement and recovery behavior. Trust established internal guarantees rather than duplicating them. Do not trade these contracts for a shorter diff.

Add only behavior and integration the request needs. Keep existing layers and readable expressions; extract shared work or clarify genuinely difficult logic, not speculative flexibility. No unrelated cleanup, wrappers, conversions, dependencies or new configuration. Comments explain non-obvious constraints.

For required efficiency work, identify the expensive operation and its unit across the whole caller path. Separate reusable facts from consumer-specific outcomes; bound sharing lifetime. Compare repeated transformations, copies and retained data as well as boundary calls. Fewer lines or a native API alone proves no resource saving.

Read maintained coverage before adding tests. Extend existing fixtures and parameterize equivalent cases. Add focused maintained regressions for real failures and changed contracts, including interactions with distinct risk; use a persistent executable self-check if no test framework exists. Keep meaningful assertions and necessary integration coverage. External probes supplement, never replace, needed repository regressions. Avoid duplicating setup or re-testing platform guarantees that the change does not threaten.

Run relevant checks and inspect the complete source and test diff. Remove only unjustified additions, not coverage or safeguards to improve counts. Stop when the complete requirement is met. Briefly report the change, checks actually run and remaining limits; do not claim unmeasured savings.
```

Exact proposal size: **2,820 UTF-8 bytes / 375 whitespace words / 21 lines**, including frontmatter and final newline: **1,904 bytes / 266 words / 12 lines shorter** than frozen. Measurement: `research/reviewFrozenLogs/skillProposalSize.json`. It is inside every original ceiling. It remains a hypothesis for future fixed-profile evaluation, not evidence of superiority or a guarantee a process can produce universal skill dominance.

## Limits and reproduction

No independently rerun full-project suites, TypeScript typecheck/lint, additive six-patch integration, live broker, long-running worker, filesystem-swap stress, RSS or representative latency benchmark. Implementer reports describe broader Python passes and missing TypeScript/dependency blockers; those are not substituted for independently executed checks. Pre-script shell/skip preservation is checked externally; cache invalidation is structurally unchanged, not independently stress-tested. Cross-suite success is limited by tested contracts and one private-helper compile mismatch. Counts alone cannot resolve regression sufficiency.

From `/tmp/codingSessionV2`:

```sh
python research/reviewFrozenChecks.py
python research/auditFrozen.py
python research/crossFrozen.py
python research/frozenIntegrity.py
```

Cross runner records individual failures in JSON; its own exit is not an all-pass assertion. The three CSV-base diagnostics are additionally retained as exact command logs with temporary overlays; their production input is the original base file, never a hand-edited source variant. All evidence paths above are relative to `research/reviewFrozenLogs/` unless stated otherwise. Both pairs remain intact. The honest disposition is **requested advantage unestablished; no rollout/removal on this evidence**.
