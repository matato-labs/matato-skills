"""Owned, offline mutation experiment; never modifies harness targets."""
from pathlib import Path
import base64
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys

scripts = Path('/home/leon/workspace/projects/matato-pi/extras/codingSessionV5/scripts')
sys.path.insert(0, str(scripts))
from sandboxTrial import Sandbox, environment, execute, sandbox, shell

root = Path(__file__).parent
runs = Path('/home/leon/.cache/codingSessionV5/harness/runs/revisionOne')
tool = Path('/home/leon/.t3/worktrees/atlas/t3-969945f4')
pi = Path('/home/leon/.local/share/mise/installs/pi/1.2.0/pi/pi')
uv = Path(shutil.which('uv')).resolve()
python = '/home/leon/workspace/projects/atlas/atlas/.venv/bin/python'
arms = {'candidateOne': 'SKILL.7f02836af76a.native.b6950eb46f87',
        'ponytail': 'SKILL.ba68ff26239c.native.9d07b1e583f4'}
cases = {'ts': 'workspaceCheckoutRoots', 'py': 'navigationUnseenEdgeBudget'}
rules = ['comparison.strict-not-equal-to-strict-equal',
         'comparison.greater-equal-to-greater', 'arithmetic.add-to-subtract']


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(workspace, *args):
    return subprocess.check_output(['git', '-C', str(workspace), *args],
                                   env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})


def inventory(workspace, names):
    result = {}
    for name in names:
        path = workspace / name
        if path.is_symlink():
            result[name] = {'symlink': str(path.readlink())}
        elif path.exists():
            result[name] = {'sha256': digest(path.read_bytes()), 'mode': path.stat().st_mode}
        else:
            result[name] = {'absent': True}
    return result


def source_names(workspace):
    data = git(workspace, 'ls-files', '-z') + git(workspace, 'ls-files', '--others', '--exclude-standard', '-z')
    return sorted(set(name.decode() for name in data.split(b'\0') if name))


def prepare():
    records = []
    for arm, alias in arms.items():
        for case, caseName in cases.items():
            run = runs / alias / caseName
            source = run / 'workspace'
            destination = root / arm / case
            destination.mkdir(parents=True)
            workspace = destination / 'project'
            workspace.mkdir()
            names = source_names(source)
            before = inventory(source, names)
            for name in names:
                src, dst = source / name, workspace / name
                dst.parent.mkdir(parents=True, exist_ok=True)
                if src.is_symlink():
                    dst.symlink_to(src.readlink())
                elif src.exists():
                    shutil.copy2(src, dst)
            shutil.copytree(source / '.git', workspace / '.git', symlinks=True)
            assert inventory(workspace, names) == before
            config = workspace / 'atlas.json'
            originalConfig = config.read_bytes() if config.exists() else None
            data = json.loads(originalConfig) if originalConfig else {}
            data['mutations'] = {'rules': rules}
            save(config, data)
            result = json.loads((run / 'evidence/result.json').read_text())
            assert result['profileSha256'].startswith('7f02836af76a' if arm == 'candidateOne' else 'ba68ff26239c')
            record = {'arm': arm, 'case': case, 'source': str(source), 'workspace': str(workspace),
                      'base': git(source, 'rev-parse', 'HEAD').decode().strip(),
                      'profileSha256': result['profileSha256'], 'names': names, 'sourceInventory': before,
                      'status': git(source, 'status', '--short').decode(),
                      'patchSha256': digest(git(source, 'diff', '--binary', 'HEAD')),
                      'evidencePatchSha256': digest((run / 'evidence/changes.patch').read_bytes()),
                      'temporaryConfig': {'path': 'atlas.json', 'originalBase64':
                                          base64.b64encode(originalConfig).decode() if originalConfig else None,
                                          'configured': data}}
            records.append(record)
            (destination / 'target.patch').write_bytes(git(source, 'diff', '--binary', 'HEAD'))
            save(destination / 'snapshot.json', record)
    save(root / 'targets.json', records)
    print('Four exact tracked/untracked target copies verified; source untouched.')


def scan(record):
    destination = root / record['arm'] / record['case']
    workspace = Path(record['workspace'])
    stage = destination / 'scanStage'
    env = environment(stage)
    env.update({'UV_OFFLINE': '1', 'UV_NO_SYNC': '1', 'UV_CACHE_DIR': str(stage / 'cache'),
                'PYTHONPATH': str(tool / 'atlas/src'),
                'TREE_SITTER_LANGUAGE_PACK_LIBS_DIR': '/home/leon/.cache/tree-sitter-language-pack/v1.20.0/libs'})
    deps = [Path('/home/leon/.local/share/uv/python/cpython-3.11-linux-x86_64-gnu'),
            Path('/home/leon/.cache/tree-sitter-language-pack/v1.20.0/libs')]
    spec = Sandbox(workspace, tool, destination / 'scanRuntime', pi, deps)
    prefix = sandbox(spec, stage)
    # uv executable is a single read-only tool mount; no credentials/config mounted.
    split = prefix.index('--remount-ro')
    prefix[split:split] = ['--ro-bind', str(uv), '/tools/uv']
    command = ['/tools/uv', 'run', '--no-sync', '--offline', '--project', str(tool / 'atlas'), 'atlas', 'mutations', '-f', str(workspace)]
    save(destination / 'scanTwoCommand.json', {'argv': command, 'cwd': str(workspace), 'env': env})
    result = execute(prefix + command, env, destination, 'scanTwo', 120)
    save(destination / 'scanTwo.json', result)
    print(record['arm'], record['case'], result)
    if result['exit'] == 0:
        report = json.loads(Path(result['stdout']).read_text())
        print('MANIFESTS', len(report['mutations']))
        for item in report['mutations']:
            if item['path'] in ['src/workspaceRepos.ts', 'atlas/src/atlas/services/navigation_walk.py']:
                print(json.dumps(item))


def checks(record, label):
    destination = root / record['arm'] / record['case']
    workspace = Path(record['workspace'])
    manifest = json.loads((Path(record['source']).parent / 'evidence/manifest.json').read_text())['cases'][0]
    spec = Sandbox(workspace, Path(record['source']), destination / 'testRuntime', pi,
                   [Path(p) for p in manifest['dependencyPaths']])
    command = 'bun test src/workspaceRepos.test.ts'
    if record['case'] == 'py':
        command = ('export PYTHONPATH="$PWD/atlas/src:$PWD/atlas" '
                   'TREE_SITTER_LANGUAGE_PACK_LIBS_DIR=/home/leon/.cache/tree-sitter-language-pack/v1.20.0/libs; '
                   f'cd atlas && {python} -B -m pytest -v -p no:cacheprovider --tb=short '
                   'tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py')
    (destination / f'{label}.command.txt').write_text(command + '\n')
    result = shell(spec, label, command, destination, timeout=120)
    result.update({'command': command, 'cwd': str(workspace)})
    save(destination / f'{label}.json', result)
    print(record['arm'], record['case'], label, json.dumps(result))
    return result


if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'scan':
        for record in json.loads((root / 'targets.json').read_text()):
            scan(record)
    elif sys.argv[1] == 'baseline':
        for record in json.loads((root / 'targets.json').read_text()):
            checks(record, 'baseline')
