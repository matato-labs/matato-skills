#!/usr/bin/env python3
"""Run against a repository argument; exercise real source reads, hashes and spans."""
import hashlib
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

repoPath = Path(sys.argv.pop(1)).resolve()
sys.path.insert(0, str(repoPath / "atlas/src"))
from atlas.domain.navigation import GraphSnapshot
from atlas.services.navigation import NavigationService
from atlas.services import navigation_source as sourceModule


class SourceReader:
    def __init__(self, rootPath):
        self.snapshot = GraphSnapshot("repo", "revision", None, str(rootPath))
        self.nodes = {}
        self.fileRows = {}
        self.fileCalls = []

    def node(self, key):
        return self.nodes[key]

    def file(self, path):
        self.fileCalls.append(path)
        return self.fileRows.get(path, [])

    def diagnostics(self, paths, limit):
        return []


class SourceBatchTests(unittest.TestCase):
    def setUp(self):
        self.tempDir = tempfile.TemporaryDirectory()
        self.addCleanup(self.tempDir.cleanup)
        self.rootPath = Path(self.tempDir.name)
        self.reader = SourceReader(self.rootPath)
        self.service = NavigationService(self.reader)

    def addSource(self, path, data, keys):
        (self.rootPath / path).write_bytes(data)
        self.reader.fileRows[path] = [{"sha256": hashlib.sha256(data).hexdigest()}]
        for key, first, last, level in keys:
            self.reader.nodes[key] = {"stableKey": key, "path": path, "level": level,
                                      "startLine": first, "endLine": last}

    def testSharedFileKeepsIndependentSpansAndOrder(self):
        self.addSource("one.py", b"alpha\r\nbeta\ngamma\ndelta\n", [
            ("whole", None, None, "file"), ("first", 1, 2, "symbol"),
            ("second", 3, 4, "symbol")])
        self.addSource("two.py", b"other\n", [("other", 1, 1, "symbol")])
        with patch.object(sourceModule, "local_bytes", wraps=sourceModule.local_bytes) as reads:
            result = self.service.sources(["second", "first", "other", "second", "whole"], 1, None)
        rows = result["sources"]
        self.assertEqual([row["stableKey"] for row in rows], ["second", "first", "other", "second", "whole"])
        self.assertEqual([row["lines"] for row in rows], [["gamma"], ["alpha"], ["other"], ["gamma"], ["alpha"]])
        self.assertEqual(rows[0]["nextStartLine"], 4)
        self.assertTrue(rows[0]["truncated"])
        self.assertFalse(rows[2]["truncated"])
        self.assertEqual(result["graphRevision"], "revision")
        self.assertEqual(reads.call_count, 2, "batch must physically read each distinct eligible path once")
        self.assertEqual(self.reader.fileCalls, ["one.py", "two.py"])

    def testFailureResultsAreSharedButNotRetainedAcrossRequests(self):
        for status in ("changed", "missing", "unsupported_encoding", "unverified"):
            with self.subTest(status=status):
                data = b"\xff" if status == "unsupported_encoding" else b"old\n"
                self.addSource("failure.py", data, [("a", 1, 1, "symbol"), ("b", 1, 1, "symbol")])
                if status == "changed":
                    (self.rootPath / "failure.py").write_bytes(b"new\n")
                elif status == "missing":
                    (self.rootPath / "failure.py").unlink()
                elif status == "unverified":
                    self.reader.fileRows["failure.py"] = []
                self.reader.fileCalls.clear()
                with patch.object(sourceModule, "local_bytes", wraps=sourceModule.local_bytes) as reads:
                    rows = self.service.sources(["a", "b", "a"], 10, None)["sources"]
                self.assertEqual([row["status"] for row in rows], [status] * 3)
                self.assertEqual(reads.call_count, 0 if status == "unverified" else 1)
                self.assertEqual(self.reader.fileCalls, ["failure.py"])
                self.addSource("failure.py", b"fixed\n", [("a", 1, 1, "symbol"), ("b", 1, 1, "symbol")])
                self.assertEqual(self.service.sources(["a", "b"], 10, None)["sources"][0]["lines"], ["fixed"])

    def testCacheIsPerRequestAndNotPerNodeStatus(self):
        self.addSource("fresh.py", b"old\nsecond\n", [("span", 1, 1, "symbol"), ("noSpan", None, None, "symbol")])
        self.reader.nodes["external"] = {"stableKey": "external", "path": "fresh.py", "level": "external"}
        rows = self.service.sources(["external", "noSpan", "span"], 10, None)["sources"]
        self.assertEqual([row["status"] for row in rows], ["unavailable", "span_unavailable", "ok"])
        self.assertEqual(rows[2]["lines"], ["old"])
        (self.rootPath / "fresh.py").write_bytes(b"new\nsecond\n")
        self.assertEqual(self.service.sources(["span"], 10, None)["sources"][0]["status"], "changed")
        self.reader.fileRows["fresh.py"] = [{"sha256": hashlib.sha256(b"new\nsecond\n").hexdigest()}]
        self.assertEqual(self.service.sources(["span"], 10, None)["sources"][0]["lines"], ["new"])

    def testUnsafeAndAmbiguousSourcesDoNotBecomeReadable(self):
        self.reader.nodes["unsafe"] = {"stableKey": "unsafe", "path": "../outside.py", "level": "file", "startLine": None, "endLine": None}
        self.reader.fileRows["../outside.py"] = [{"sha256": "not-a-real-hash"}]
        self.addSource("ambiguous.py", b"body\n", [("ambiguous", 1, 1, "symbol")])
        self.reader.fileRows["ambiguous.py"] *= 2
        rows = self.service.sources(["unsafe", "ambiguous", "unsafe"], 10, None)["sources"]
        self.assertEqual([row["status"] for row in rows], ["unsafe", "unverified", "unsafe"])
        self.assertTrue(all("lines" not in row for row in rows))

    def testSingleSourceAndIneligibleNodesRetainBehavior(self):
        self.addSource("span.py", b"zero\none\ntwo\nthree\n", [("span", 2, 4, "symbol"), ("noSpan", None, None, "symbol")])
        self.reader.nodes["external"] = {"stableKey": "external", "path": "span.py", "level": "external"}
        self.reader.nodes["noPath"] = {"stableKey": "noPath", "path": None, "level": "symbol"}
        single = self.service.source("span", 1, 3)["source"]
        batch = self.service.sources(["span", "noSpan", "external", "noPath"], 1, 3)["sources"]
        self.assertEqual({key: value for key, value in batch[0].items() if key != "stableKey"}, single)
        self.assertEqual(single["lines"], ["two"])
        self.assertEqual([row["status"] for row in batch[1:]], ["span_unavailable", "unavailable", "unavailable"])
        with patch.object(sourceModule, "local_bytes", wraps=sourceModule.local_bytes) as reads:
            self.assertEqual(self.service.sources([], 10, None)["sources"], [])
            self.assertEqual(reads.call_count, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
