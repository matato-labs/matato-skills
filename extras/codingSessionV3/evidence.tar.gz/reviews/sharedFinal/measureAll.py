import json
from pathlib import Path
from auditDriver import root, review, results, excluded, sha, git, changed, save


def category(name):
    if any(part in ('test', 'tests', 'snapshots', 'fixtures') for part in Path(name).parts) or '.test.' in name or name.endswith('_test.exs'):
        return 'tests'
    return 'production' if name.endswith(('.ts', '.tsx', '.js', '.py', '.ex', '.exs')) else 'other'


def stats(data):
    rows = {}
    for entry in data.split(b'\0'):
        if not entry:
            continue
        added, deleted, name = entry.decode().split('\t', 2)
        rows[name] = dict(added=int(added), deleted=int(deleted))
    return rows


def blankTotals():
    return {key: 0 for key in ['added', 'deleted', 'churn', 'net', 'bytesBefore', 'bytesAfter', 'byteNet']}


def add(target, row):
    for key in target:
        target[key] += row[key]


def measure(result):
    folder = Path(result['worktree'])
    saved = root / 'runs' / result['draw'] / result['arm'] / result['case']
    livePatch = git(folder, 'diff', '--no-ext-diff', *excluded)
    savedPatch = (saved / 'changes.patch').read_bytes()
    assert sha(livePatch) == result['patchSha256'] == sha(savedPatch), str(saved)
    live = stats(git(folder, 'diff', '--numstat', '-z', *excluded))
    patch = stats(git(folder, 'apply', '--numstat', '-z', str(saved / 'changes.patch')))
    assert live == patch, str(saved)
    assert set(changed(folder)) == set(live), str(saved)
    files = []
    totals = {kind: blankTotals() for kind in ['production', 'tests', 'other', 'combined']}
    for name, row in live.items():
        try:
            before = git(folder, 'show', result['base'] + ':' + name)
        except Exception:
            before = b''
        path = folder / name
        after = path.read_bytes() if path.exists() else b''
        row = dict(path=name, category=category(name), **row, churn=row['added'] + row['deleted'], net=row['added'] - row['deleted'], bytesBefore=len(before), bytesAfter=len(after), byteNet=len(after) - len(before), beforeSha256=sha(before), afterSha256=sha(after))
        files.append(row)
        add(totals[row['category']], row)
        add(totals['combined'], row)
    recorded = {kind: [0, 0] for kind in ['production', 'tests', 'other']}
    for row in result['files']:
        recorded[row['category']][0] += row['added']
        recorded[row['category']][1] += row['removed']
    assert all(recorded[k] == [totals[k]['added'], totals[k]['deleted']] for k in recorded), str(saved)
    return dict(draw=result['draw'], arm=result['arm'], case=result['case'], base=result['base'], files=files, totals=totals, patchSha256=sha(livePatch), recordedCountsMatch=True, patchMatchesLive=True, acceptanceExit=result['acceptanceExit'], agentExit=result['agentExit'], seconds=result['seconds'])


def main():
    trials = [measure(r) for r in results]
    draws, allArms = {}, {}
    for trial in trials:
        for bucket in [draws.setdefault(trial['draw'], {}), allArms]:
            target = bucket.setdefault(trial['arm'], {kind: blankTotals() for kind in trial['totals']})
            for kind, total in trial['totals'].items():
                add(target[kind], total)
    finalCombined = {}
    for draw in ['finalOne', 'finalTwo']:
        for arm, totals in draws[draw].items():
            target = finalCombined.setdefault(arm, {kind: blankTotals() for kind in totals})
            for kind in totals:
                add(target[kind], totals[kind])
    reviewers = {}
    for draw, roundName in [('tuningOne', 'roundOne'), ('tuningTwo', 'roundTwo'), ('finalOne', 'finalOne')]:
        reference = json.loads((root / 'reviews' / roundName / 'metrics.json').read_text())
        for arm, totals in reference['aggregates'].items():
            for kind in ['production', 'tests']:
                for old, new in [('added', 'added'), ('removed', 'deleted'), ('churn', 'churn'), ('net', 'net'), ('byteNet', 'byteNet')]:
                    assert totals[kind][old] == draws[draw][arm][kind][new], (draw, arm, kind, old)
        reviewers[roundName] = dict(path=str(root / 'reviews' / roundName / 'metrics.json'), sha256=sha((root / 'reviews' / roundName / 'metrics.json').read_bytes()), matches=True)
    reference = json.loads((root / 'reviews/finalTwo/metrics.json').read_text())
    for arm, cases in reference.items():
        for case, rows in cases.items():
            measured = next(t for t in trials if t['draw'] == 'finalTwo' and t['arm'] == arm and t['case'] == case)
            assert sum(r['byteGrowth'] for r in rows) == measured['totals']['combined']['byteNet']
            assert sum(r['churn'] for r in rows) == measured['totals']['combined']['churn']
    reviewers['finalTwo'] = dict(path=str(root / 'reviews/finalTwo/metrics.json'), sha256=sha((root / 'reviews/finalTwo/metrics.json').read_bytes()), matches=True)
    freeze = json.loads((root / 'finalFreeze.json').read_text())
    freezeAudit = {name: dict(expected=value, actual=sha((root / name).read_bytes())) for name, value in freeze['sha256'].items()}
    assert all(item['actual'] == item['expected'] for item in freezeAudit.values())
    profiles = {p.stem: dict(bytes=p.stat().st_size, sha256=sha(p.read_bytes())) for p in (root / 'profiles').glob('*.md')}
    save('metrics.json', dict(method='Read-only git diff --numstat -z plus git apply --numstat -z on saved patches; exact patch hashes verified against result.json and live git. Dependency/build links excluded; no nonignored untracked source omitted. Byte net is exact resulting-minus-base bytes of changed files, not patch-file bytes.', implementations=len(trials), byDraw=draws, allArms=allArms, finalCombined=finalCombined, trials=trials, reviewerMetricAudit=reviewers, freezeAudit=freezeAudit, profiles=profiles))
    print(json.dumps(draws, indent=2))


if __name__ == '__main__':
    main()
