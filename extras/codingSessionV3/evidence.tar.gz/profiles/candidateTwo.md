---
name: coding-session
description: Implement and fix code with the smallest readable change that fully meets the request. Use for implementation, bug fixes and requested refactoring in any language or environment.
disable-model-invocation: true
---

# Coding session

Solve the whole request with the least new machinery. Read repository instructions, affected code and maintained tests. Find the shared cause and every caller, type, export, fixture or configuration the change must reach. Ask only about ambiguity that changes correctness.

Before writing logic, find what already supplies it. Take the first complete option: change an existing expression; reuse a project facility; use a language or platform feature; use an installed dependency; write direct code. Read the actual API and its callers, not just its name. Compose existing operations and native operators before adding control flow or state. Share derived lookups at the common lifetime; reuse contracts. Prefer one readable expression to equivalent control flow; do not compress unrelated work. Do not add a dependency for a few lines.

Fix shared policy once at its existing boundary. Reuse authoritative types, schemas, defaults, presence tracking, validation and transactions rather than recreating them per caller. Preserve omitted versus explicit values, ordering, identity, errors, ownership and public interfaces. Probe uncertain API behavior using the real call shape, options and callbacks. Keep native values native and existing layers intact.

Implement only missing behavior. No speculative options, wrappers, conversions, state or unrelated cleanup. A helper needs actual reuse or genuinely difficult logic to clarify. A comment explains a non-obvious constraint, not the expression. Ask of each addition: what requested behavior or concrete regression needs this?

Never shorten away trust-boundary validation, security, synchronization, accessibility, data-loss protection or cleanup. Recovery and extension points must obey the same precedence and failure policy. Trust established internal guarantees instead of checking them again. For efficiency work, share the reusable result at the required lifetime; compare repeated work, copies and retained memory, not just calls or lines.

Read maintained coverage first. Reuse fixture locations, builders and generators; trace their consumers before adding samples. Cover the bug, distinct contracts and risky interactions with case tables and shared setup, not platform Cartesian checklists. Keep meaningful assertions and integration coverage. External probes supplement regressions; use an executable self-check only without a framework.

Run relevant checks. Inspect the whole source and test diff: can existing code or a native operation remove new machinery without losing behavior or clarity? Remove unjustified additions, never safeguards or meaningful assertions to improve counts. Stop once complete. Briefly report changes, checks actually run and remaining limits; do not claim unmeasured savings.
