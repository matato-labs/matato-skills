"""Independent V4 publication scanner; reports names/patterns only, never matched bytes."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
from typing import TypeAlias, TypedDict, cast

JsonValue: TypeAlias = str | int | float | bool | None | list['JsonValue'] | dict[str, 'JsonValue']


class Member(TypedDict):
    sha256: str
    size: int
    mode: int


root = Path('/tmp/codingSessionV4')
owned = Path('/home/leon/.cache/codingSessionV4Owned')
audit = owned / 'publicationAudit'
prep = owned / 'publicationPrep'
patterns = {
    'providerCredential': rb'(?i)(?:sk-(?:proj-|ant-)?|AIza)[A-Za-z0-9_\-]{25,}',
    'githubCredential': rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})',
    'privateKey': rb'-----BEGIN [A-Z ]*PRIVATE KEY-----',
    'awsCredential': rb'(?:AKIA|ASIA)[A-Z0-9]{16}',
    'slackCredential': rb'xox[baprs]-[A-Za-z0-9-]{20,}',
    'telegramCredential': rb'\b[0-9]{8,12}:[A-Za-z0-9_-]{30,}\b',
    'jwtCredential': rb'eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}',
    'bearerCredential': rb'(?i)bearer\s+[A-Za-z0-9._~+/=-]{20,}',
    'urlCredential': rb'(?i)https?://[^\s/\x22\x27:]{2,}:[^\s/@\x22\x27]{8,}@',
    'assignedCredential': rb'(?i)[\x22\x27]?(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|authorization)[\x22\x27]?\s*[:=]\s*[\x22\x27][^\x22\x27\r\n]{16,}[\x22\x27]',
    'oauthCredential': rb'(?i)(?:ya29\.|1//)[A-Za-z0-9_-]{35,}',
    'npmCredential': rb'npm_[A-Za-z0-9]{30,}',
}
envNames: Counter[str] = Counter()
envValues: dict[str, set[str]] = {}
findings: list[dict[str, str]] = []
jsonErrors: list[str] = []
traceKeys = {'event', 'id', 'name', 'payloadSha256', 'payloadBytes', 'path', 'command',
             'isError', 'durationMs'}
traceTools: Counter[str] = Counter()
traceRecords = 0
allowedEnv = set('PATH HOME TMPDIR XDG_CACHE_HOME XDG_CONFIG_HOME XDG_DATA_HOME LANG LC_ALL '
                 'PYTHONDONTWRITEBYTECODE PYTEST_DISABLE_PLUGIN_AUTOLOAD PI_OFFLINE PI_SKIP_VERSION_CHECK '
                 'PI_TELEMETRY PIP_NO_INDEX npm_config_offline CARGO_NET_OFFLINE GOCACHE GOPATH CI '
                 'GIT_CONFIG_GLOBAL GIT_CONFIG_NOSYSTEM GIT_OPTIONAL_LOCKS GIT_TERMINAL_PROMPT '
                 'TREE_SITTER_LANGUAGE_PACK_LIBS_DIR PI_CODING_AGENT_DIR BUN_RUNTIME_TRANSPILER_CACHE_PATH '
                 'HTTP_PROXY HTTPS_PROXY ALL_PROXY NO_PROXY http_proxy https_proxy all_proxy no_proxy '
                 'NODE_EXTRA_CA_CERTS SSL_CERT_FILE SSL_CERT_DIR PYTHONPATH BUN_INSTALL_CACHE_DIR '
                 'UV_CACHE_DIR TERM SHELL'.split())


def readJson(path: Path) -> JsonValue:
    return cast(JsonValue, json.loads(path.read_text()))


def sourcePath(name: str) -> Path:
    if name.startswith('publicationPrep/'):
        return prep / name.removeprefix('publicationPrep/')
    if name.startswith('relocationEvidence/'):
        return owned / name
    return root / name


def inspectJson(value: JsonValue, name: str) -> None:
    if isinstance(value, list):
        for entry in value:
            inspectJson(entry, name)
        return
    if not isinstance(value, dict):
        return
    for key, entry in value.items():
        if key in {'env', 'environment'} and isinstance(entry, dict):
            inspectEnvironment(entry, name)
        inspectJson(entry, name)


def inspectEnvironment(environment: dict[str, JsonValue], name: str) -> None:
    for envName, envValue in environment.items():
        envNames[envName] += 1
        envValues.setdefault(envName, set()).add(json.dumps(envValue))
        if envName not in allowedEnv:
            findings.append({'path': name, 'pattern': 'unreviewedEnvironmentKey:' + envName})


def inspectTrace(data: bytes, name: str) -> None:
    global traceRecords
    for line in data.splitlines():
        value = cast(dict[str, JsonValue], json.loads(line))
        traceRecords += 1
        if set(value) - traceKeys:
            findings.append({'path': name, 'pattern': 'unallowlistedToolTraceField'})
        tool = cast(str, value.get('name', ''))
        traceTools[tool] += 1
        if tool not in {'read', 'bash', 'edit', 'write'}:
            findings.append({'path': name, 'pattern': 'unallowlistedToolTraceTool'})


def safeMember(name: str) -> bool:
    path = PurePosixPath(name)
    forbidden = {'private', 'ponytail', '.git', 'node_modules', '.venv', 'base', 'copies', 'runtime',
                 'worktrees', '.ssh', '.config', '__pycache__'}
    parts = set(path.parts)
    if path.is_absolute() or '..' in parts or '\\' in name or '\x00' in name:
        return False
    # Ponytail arm logs/patches are allowed; its complete profile and upstream tree are not.
    parts.discard('ponytail')
    if parts & (forbidden - {'ponytail'}):
        return False
    if name.startswith('ponytail/') or path.name.lower() == 'ponytail.md':
        return False
    return not ('/ponytail/' in name and path.name == 'currentProfile.md')


def scan() -> None:
    members = cast(dict[str, Member], readJson(prep / 'candidateMembers.json'))
    total = 0
    records: list[dict[str, str | int | bool]] = []
    compiled = {label: re.compile(pattern) for label, pattern in patterns.items()}
    for name, expected in members.items():
        if not safeMember(name):
            findings.append({'path': name, 'pattern': 'unsafeMemberPath'})
            continue
        path = sourcePath(name)
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        mode = 0o755 if path.stat().st_mode & 0o111 else 0o644
        matches = digest == expected['sha256'] and len(data) == expected['size'] and mode == expected['mode']
        if not matches:
            findings.append({'path': name, 'pattern': 'candidateChanged'})
        total += len(data)
        records.append({'path': name, 'sha256': digest, 'size': len(data), 'mode': mode, 'matches': matches})
        for label, pattern in compiled.items():
            if pattern.search(data):
                findings.append({'path': name, 'pattern': label})
        if path.suffix == '.json':
            try:
                inspectJson(cast(JsonValue, json.loads(data)), name)
            except (ValueError, UnicodeError):
                jsonErrors.append(name)
        if path.name == 'toolTrace.jsonl':
            inspectTrace(data, name)
    report = {'scanner': 'Independent scanInputs.py v1 / Python stdlib; separate from preparer scanner',
              'candidateMembersSha256': hashlib.sha256((prep / 'candidateMembers.json').read_bytes()).hexdigest(),
              'membersRead': len(records), 'bytesRead': total, 'findings': findings,
              'jsonParseFailures': jsonErrors, 'environmentKeys': dict(sorted(envNames.items())),
              'environmentValueVariantCounts': {key: len(value) for key, value in sorted(envValues.items())},
              'safeToolTraceRecords': traceRecords, 'safeToolTraceTools': dict(traceTools),
              'patterns': list(patterns), 'limits': 'Pattern and structured content review, not proof no conceivable secret exists. No excluded contents opened.'}
    (audit / 'scans/independentScan.json').write_text(json.dumps(report, indent=2) + '\n')
    (audit / 'scans/memberReadProof.json').write_text(json.dumps(records, indent=2) + '\n')
    # Kept outside publication: only environment VALUES already admitted as safe candidate evidence.
    (audit / 'scans/environmentReview.json').write_text(json.dumps({k: sorted(v) for k, v in sorted(envValues.items())}, indent=2) + '\n')
    print(json.dumps({'membersRead': len(records), 'bytesRead': total, 'findings': findings, 'jsonParseFailures': jsonErrors}, indent=2))


if __name__ == '__main__':
    scan()
