"""Exactly four frozen tuning runs; no output selection, repair, or retry."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from typing import TypedDict

from ablationPreflight import evidence, hashes, log, manifests
from runTrial import Manifest
from sandboxTrial import root


class Launched(TypedDict):
    manifest: str
    arm: str
    argv: list[str]
    stdout: str
    stderr: str
    pid: int


def snapshot() -> None:
    target = evidence / 'harnessFinal'
    target.mkdir(exist_ok=False)
    files = [*root.glob('*.py'), root / 'dependencyMounts.json', root / 'runnerNotes.md']
    for source in files:
        shutil.copy2(source, target / source.name)
    (target / 'hashes.json').write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in files}, indent=2) + '\n')
    launchers: dict[str, str] = {}
    for name in ['pi', 'bun', 'bwrap', 'bash', 'python3']:
        path = shutil.which(name)
        assert path is not None
        resolved = Path(path).resolve()
        launchers[str(resolved)] = hashlib.sha256(resolved.read_bytes()).hexdigest()
    (evidence / 'launcherHashes.json').write_text(json.dumps(launchers, indent=2) + '\n')
    frozen = evidence / 'frozenTuning'
    for manifest in manifests:
        destination = frozen / ('python' if manifest == manifests[0] else 'typescript')
        destination.mkdir(parents=True, exist_ok=False)
        for path in manifest.parent.iterdir():
            if path.is_file():  # No suffix filter: include extensionless frozen launchers too.
                shutil.copy2(path, destination / path.name)


def launch() -> list[tuple[subprocess.Popen[bytes], Launched]]:
    processes: list[tuple[subprocess.Popen[bytes], Launched]] = []
    for manifest in manifests:
        for arm in ['v3', 'reuseAblation']:
            caseData: Manifest = json.loads(manifest.read_text())
            caseId = caseData['cases'][0]['id']
            label = f'{arm}.{caseId}'
            stdout, stderr = evidence / f'{label}.stdout', evidence / f'{label}.stderr'
            argv = [sys.executable, str(root / 'runTrial.py'), str(manifest), arm, 'ablationOne']
            with stdout.open('xb') as output, stderr.open('xb') as errors:
                process = subprocess.Popen(argv, stdout=output, stderr=errors)
            record: Launched = {'manifest': str(manifest), 'arm': arm, 'argv': argv,
                'stdout': str(stdout), 'stderr': str(stderr), 'pid': process.pid}
            processes.append((process, record))
            log(f'Launched {label} pid={process.pid}; fresh Pi budget=900s, no retries')
    return processes


def main() -> None:
    assert json.loads((evidence / 'preflightComplete.json').read_text())['passed']
    assert json.loads((evidence / 'providerProbe/result.json').read_text())['passed']
    assert hashes() == json.loads((evidence / 'frozenHashes.json').read_text())
    assert not (root / 'runs/ablationOne').exists()
    snapshot()
    log('Prelaunch gates passed; readonly auth READY probe, selfCheck runnerjwy0hw1f; launch exactly four')
    processes = launch()
    (evidence / 'launches.json').write_text(json.dumps([record for _, record in processes], indent=2) + '\n')
    exits: dict[str, int] = {}
    for process, record in processes:
        code = process.wait()
        label = record['arm'] + ':' + record['manifest']
        exits[label] = code
        log(f'Runner exit={code} {label}; outputs retained unchanged')
    assert hashes() == json.loads((evidence / 'frozenHashes.json').read_text())
    (evidence / 'runnerExits.json').write_text(json.dumps(exits, indent=2) + '\n')
    log('All four runner processes returned. Frozen hashes unchanged. No output analysis or selection performed.')


if __name__ == '__main__':
    main()
