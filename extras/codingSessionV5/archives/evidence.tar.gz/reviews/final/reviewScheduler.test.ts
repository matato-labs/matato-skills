import { expect, test } from "bun:test";
import { createScheduler, type SchedulerOptions } from "./scheduler.ts";
import { automation, deferred } from "./testFixtures.ts";

type Callback = () => Promise<void>;

function fixture(run: SchedulerOptions["run"]) {
  const callbacks: Array<Callback> = [];
  const errors: Array<string> = [];
  const scheduler = createScheduler({
    run,
    onError: (message) => errors.push(message),
    createSchedule: (pattern, callback) => {
      callbacks.push(callback);
      if (pattern === "invalid") throw new Error("factory failed");
      return { stop: () => {}, resume: () => {} };
    },
  });
  return { scheduler, callbacks, errors };
}

test("review: construction and cleanup callbacks activate only after commit", async () => {
  const callbacks: Array<Callback> = [];
  const attempts: Array<Promise<void>> = [];
  const started: Array<string> = [];
  const scheduler = createScheduler({
    run: async (job) => { started.push(job.userPrompt); },
    onError: () => {},
    createSchedule: (pattern, callback) => {
      callbacks.push(callback);
      attempts.push(callback());
      if (pattern === "invalid") throw new Error("factory failed");
      return {
        stop: () => { attempts.push(callback()); },
        resume: () => { attempts.push(callback()); },
      };
    },
  });
  try {
    scheduler.replace([automation({ canOverlap: true })]);
    await Promise.all(attempts.splice(0));
    expect(started).toEqual(["Run the job"]);
    expect(() => scheduler.replace([
      automation({ userPrompt: "discarded", canOverlap: true }),
      automation({ jobName: "bad", schedule: "invalid", canOverlap: true }),
    ])).toThrow("factory failed");
    await Promise.all(attempts.splice(0));
    await callbacks[1]();
    await callbacks[2]();
    await callbacks[0]();
    expect(started).toEqual(["Run the job", "Run the job"]);
    scheduler.replace([automation({ userPrompt: "current", canOverlap: true })]);
    await Promise.all(attempts.splice(0));
    expect(started).toEqual(["Run the job", "Run the job", "current"]);
    scheduler.stop();
    await Promise.all(attempts.splice(0));
    for (const callback of callbacks) await callback();
    expect(started).toHaveLength(3);
  } finally { scheduler.stop(); }
});

test("review: failed replacement preserves active runs and retired runs release each guard once", async () => {
  const pending = [deferred(), deferred(), deferred()];
  let count = 0;
  const { scheduler, callbacks, errors } = fixture(async () => {
    const index = count++;
    await pending[index]?.promise;
    if (index === 1) throw new Error("retired failure");
  });
  try {
    scheduler.replace([automation({ canOverlap: true })]);
    const first = callbacks[0]();
    const second = callbacks[0]();
    expect(() => scheduler.replace([
      automation({ canOverlap: true }),
      automation({ jobName: "bad", schedule: "invalid" }),
    ])).toThrow("factory failed");
    await callbacks[1]();
    await callbacks[2]();
    expect(count).toBe(2);
    const third = callbacks[0]();
    expect(count).toBe(3);
    scheduler.replace([]);
    scheduler.replace([automation()]);
    const current = callbacks[3];
    await callbacks[0]();
    await current();
    expect(count).toBe(3);
    pending[0].resolve();
    await first;
    await current();
    expect(count).toBe(3);
    pending[1].resolve();
    await second;
    expect(errors).toEqual(["Job failed: example: Error: retired failure"]);
    await current();
    expect(count).toBe(3);
    pending[2].resolve();
    await third;
    await callbacks[0]();
    await callbacks[1]();
    await callbacks[2]();
    expect(count).toBe(3);
    await current();
    await current();
    expect(count).toBe(5);
    expect(errors).toHaveLength(1);
  } finally {
    pending.forEach((item) => item.resolve());
    scheduler.stop();
  }
});

test("review: queued callbacks are inert after disabling or removal and same-name readdition", async () => {
  let count = 0;
  const { scheduler, callbacks } = fixture(async () => { count += 1; });
  try {
    scheduler.replace([automation({ canOverlap: true })]);
    const queued = Promise.resolve().then(callbacks[0]);
    scheduler.replace([automation({ enabled: false })]);
    await queued;
    expect(count).toBe(0);
    scheduler.replace([automation({ canOverlap: true })]);
    await callbacks[0]();
    await callbacks[1]();
    expect(count).toBe(1);
    const removed = Promise.resolve().then(callbacks[1]);
    scheduler.replace([]);
    await removed;
    await callbacks[1]();
    expect(count).toBe(1);
  } finally { scheduler.stop(); }
});

test("review: stop does not cancel an active run or duplicate its error report", async () => {
  const pending = deferred();
  let count = 0;
  const { scheduler, callbacks, errors } = fixture(async () => {
    count += 1;
    await pending.promise;
    throw new Error("stopped failure");
  });
  try {
    scheduler.replace([automation()]);
    const active = callbacks[0]();
    scheduler.stop();
    await callbacks[0]();
    expect(count).toBe(1);
    pending.resolve();
    await active;
    await callbacks[0]();
    expect(errors).toEqual(["Job failed: example: Error: stopped failure"]);
    expect(count).toBe(1);
  } finally { pending.resolve(); scheduler.stop(); }
});
