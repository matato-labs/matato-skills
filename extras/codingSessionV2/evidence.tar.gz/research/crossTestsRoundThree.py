#!/usr/bin/env python3
"""Run each arm's native regression tests against the other's implementation; temp overlays only."""
import json
import os
from pathlib import Path
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parent.parent
LOGS=ROOT/'research/reviewRoundThreeLogs'
results=[]

def run(name,cmd,cwd,env):
    p=subprocess.run(cmd,cwd=cwd,env={**os.environ,**env},capture_output=True,timeout=180)
    (LOGS/(name+'.log')).write_bytes(('COMMAND '+json.dumps(cmd)+'\nCWD '+str(cwd)+'\nENV '+json.dumps(env)+'\nEXIT '+str(p.returncode)+'\n').encode()+p.stdout+p.stderr)
    print(name,p.returncode,flush=True)
    results.append(dict(name=name,exit=p.returncode))

with tempfile.TemporaryDirectory(prefix='reviewRoundThreeCross') as d:
    scratch=Path(d)
    for tests,implementation in [('ponytailThird','codingThird'),('codingThird','ponytailThird')]:
        for case in ['sourceBatchReads','pathEarlyExit','isinCsvRecords','scheduleTimeZones']:
            origin=ROOT/'runs'/tests/case
            target=ROOT/'runs'/implementation/case
            name=f'cross-{tests}-tests-on-{implementation}-{case}'
            if case in ['sourceBatchReads','pathEarlyExit']:
                run(name,[str(origin/'atlas/.venv/bin/python'),'-m','pytest','tests/test_graph_navigation.py','-q'],origin/'atlas',{'PYTHONPATH':str(target/'atlas/src')})
            elif case=='isinCsvRecords':
                overlay=scratch/'overlay.json'
                overlay.write_text(json.dumps({'Replace':{str(target/'commons/data/isin_loader_test.go'):str(origin/'commons/data/isin_loader_test.go')}}))
                run(name,['go','test','-overlay',str(overlay),'./data','-count=1','-v'],target/'commons',{'GOWORK':'off','GOPROXY':'off','GOSUMDB':'off'})
            else:
                text=(origin/'worker/scheduler.test.ts').read_text()
                text=text.replace('"./scheduler.ts"',json.dumps(str(target/'worker/scheduler.ts'))).replace('"./testFixtures.ts"',json.dumps(str(origin/'worker/testFixtures.ts'))).replace('"croner"',json.dumps(str((target/'node_modules/croner/dist/croner.js').resolve())))
                path=scratch/'scheduler.test.ts'
                path.write_text(text)
                run(name,['bun','test',str(path)],target,{'TZ':'Asia/Tokyo'})
(LOGS/'crossResults.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['exit']==0 for r in results)
