import json
from pathlib import Path
import re
from auditDriver import root, review, results, sha, save


def load(name):
    return json.loads((review / name).read_text())


def observation(command):
    log = Path(command['output']).read_text()
    assert sha(log.encode()) == command['outputSha256']
    passed = int(re.search(r'\n (\d+) pass\n', log)[1])
    failed = int(re.search(r'\n (\d+) fail\n', log)[1])
    data = [json.loads(line) for line in log.splitlines() if line.startswith('{') and line.endswith('}')]
    return dict(status='PASS' if command['exit'] == 0 else 'FAIL', passed=passed, failed=failed, exit=command['exit'], observations=data, commandLabel=command['label'], output=command['output'], outputSha256=command['outputSha256'])


def sourceSnippet(path, start, end):
    lines = path.read_text().splitlines()
    return '\n'.join(f'{i + 1}: {line}' for i, line in enumerate(lines) if start <= i + 1 <= end)


def sourceEvidence(draw, arm):
    sessions = root / 'worktrees' / draw / arm / 'sessionTreeConfinement'
    memory = root / 'worktrees' / draw / arm / 'memoryReferenceResolution'
    sessionPath = sessions / 'src/agent/matatoAgentSessions.ts'
    memoryPath = memory / 'src/storage/memoryBlock.ts'
    workPath = sessions / 'src/storage/work.test.ts'
    lines = workPath.read_text().splitlines()
    index = next(i for i, line in enumerate(lines) if 'const sessionFile' in line)
    return dict(sessionPath=str(sessionPath), sessionSha256=sha(sessionPath.read_bytes()), confinement=sourceSnippet(sessionPath, 170, 210), memoryPath=str(memoryPath), memorySha256=sha(memoryPath.read_bytes()), resolution=sourceSnippet(memoryPath, 85, 135), workPath=str(workPath), workSha256=sha(workPath.read_bytes()), fixture=sourceSnippet(workPath, index + 1, index + 15))


def invocationEvidence():
    records = []
    for result in results:
        folder = root / 'runs' / result['draw'] / result['arm'] / result['case']
        argv = json.loads((folder / 'invocation.json').read_text())
        expected = sha((root / 'profiles' / (result['arm'] + '.md')).read_bytes())
        recorded = (folder / 'profile.sha256').read_text().strip()
        assert expected == recorded
        flags = ['--no-session', '--no-extensions', '--no-skills', '--no-prompt-templates', '--no-context-files', '--no-mcp', '--offline']
        assert all(flag in argv for flag in flags)
        profile = argv[argv.index('--append-system-prompt') + 1]
        assert profile == str(root / 'profiles' / (result['arm'] + '.md'))
        records.append(dict(draw=result['draw'], arm=result['arm'], case=result['case'], invocation=str(folder / 'invocation.json'), invocationSha256=sha((folder / 'invocation.json').read_bytes()), profile=profile, profileSha256=recorded, flagsPresent=flags, originalAcceptanceExit=result['acceptanceExit'], acceptanceLogSha256=sha((folder / 'acceptance.log').read_bytes())))
    return records


def main():
    commands = load('commands.json')
    assert len(commands) == 27 and not any(c['timedOut'] for c in commands)
    observations = {c['label']: observation(c) for c in commands}
    rows = []
    normalized = []
    for draw in ['finalOne', 'finalTwo']:
        for arm in ['main', 'pr', 'ponytail', 'candidateThree']:
            session = draw + arm + 'sessionTreeConfinement'
            memory = draw + arm + 'memoryReferenceResolution'
            row = dict(draw=draw, arm=arm, rootAnchor=observations[session + 'rootAnchor'], zeroIds=observations[memory + 'zeroIds'], workConsumer=observations[session + 'workConsumer'], sourceEvidence=sourceEvidence(draw, arm))
            assert row['rootAnchor']['passed'] + row['rootAnchor']['failed'] == 2
            assert row['zeroIds']['passed'] + row['zeroIds']['failed'] == 2
            assert row['workConsumer']['passed'] + row['workConsumer']['failed'] == 8
            rows.append(row)
    for command in commands:
        if command['label'].endswith('workConsumer'):
            continue
        path = Path(command['argv'][-1])
        text = path.read_text().replace(command['cwd'] + '/', 'candidateRoot/')
        template = 'stableSessionConfirmation.ts' if command['label'].endswith('rootAnchor') else 'observedZeroId.ts'
        assert text == (review / 'probes' / template).read_text()
        normalized.append(dict(path=str(path), sha256=sha(path.read_bytes()), normalizedSha256=sha(text.encode()), template=template))
    original = {suite: observations['originalBase' + suite] for suite in ['rootAnchor', 'zeroIds', 'workConsumer']}
    before, after = load('before.json'), load('after.json')
    assert before == after
    historical = {}
    for folder, name in [('roundOne', 'review.md'), ('roundTwo', 'review.md'), ('finalOne', 'review.md'), ('finalTwo', 'review.md'), ('mutation', 'report.md')]:
        path = root / 'reviews' / folder / name
        historical[folder] = dict(path=str(path), sha256=sha(path.read_bytes()))
    invocations = invocationEvidence()
    finalRecords = [r for r in invocations if r['draw'] in ('finalOne', 'finalTwo')]
    assert len(finalRecords) == 48 and all(r['originalAcceptanceExit'] == 0 for r in finalRecords)
    save('evidence.json', dict(verdict='NOT MET; terminal audit, no new implementation or revision', commands=commands, commonResults=rows, originalBase=dict(base='4f2b75f73087b5f2c60995629c591dc91a591567', appliesTo='All eight final draw/arm pairs share this exact pinned base; one common original-production/original-tests copy supplies each probe control.', results=original), probeFreeze=load('probeFreeze.json'), normalizedProbeAudit=normalized, historicalReviews=historical, invocationAudit=invocations, frozenFinalAcceptance=dict(commands=48, originalExitZero=48, rerunHere=False, changed=False), integrity=dict(originalsUnchanged=True, originalFingerprintFiles=len(before['files']), originalWorktrees=len(before['states']), beforeSha256=sha((review / 'before.json').read_bytes()), afterSha256=sha((review / 'after.json').read_bytes()), copyIntegrity=load('copyIntegrity.json'), note='All writes confined to sharedFinal; git reads use --no-optional-locks; no original index edits.'), limitations=['Root-anchor probe asserts a fixed lexical managed-root policy, not sanctioned canonical-root relocation. Stable fixtures only; no concurrent race claim.', 'Zero is an explicit unresolved sentinel even with schema-valid persisted zero rows; normal creation APIs producing zero is not claimed.', 'No full-suite, service, network, install, app startup or mutation execution. Existing reviewer full-check statements are attributed, not rerun here.', 'Invocation/profile hash consistency does not establish actual tool-use history, absence of contamination or strict reviewer blindness. Earlier reserved TypeScript brief exposure remains disclosed.', 'Failed original controls demonstrate expected pre-fix behavior; current-output failures are not reclassified as expected control passes.']))
    print('verified commands', len(commands), 'nonzero', sum(c['exit'] != 0 for c in commands))
    for row in rows:
        print(row['draw'], row['arm'], *[f'{suite}={row[suite]["status"]}({row[suite]["passed"]}/{row[suite]["passed"] + row[suite]["failed"]})' for suite in ['rootAnchor', 'zeroIds', 'workConsumer']])


if __name__ == '__main__':
    main()
