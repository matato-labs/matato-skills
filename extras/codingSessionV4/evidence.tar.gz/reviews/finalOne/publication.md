# Publication boundary

Review-owned evidence only; publicationReady remains false. No source/profile/README changes or PR made.

Never archive copies/, runtime/, private raw streams, auth/config stores, Ponytail profile/skill source, or original checkout configuration. audit.json is working metadata with full invocations; prefer independentAudit.json's allowlisted facts. Patch text here concerns generated task implementations, not Ponytail skill source.

review.md, metrics.json, findings.json, plans, review scripts, allowlisted audit, command metadata, selected test logs and checksum manifests still need the parent's publication/secret review. Nothing in this folder is automatically approved for public release. Original source/config/private streams are unchanged. No credentials inherited by checks; Bash uses only supplied inert fake fixtures, never live installers/configuration.
