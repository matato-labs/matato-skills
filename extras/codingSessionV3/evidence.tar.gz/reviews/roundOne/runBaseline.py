from pathlib import Path

review = Path('/tmp/codingSessionV3/reviews/roundOne')
source = (review / 'runReview.py').read_text().split('\ncases = {}')[0]
exec(source.replace("'commands.json'", "'baselineCommands.json'"))
for arm in ['pureBase', 'ponytail']:
    folder = review / 'pureBase/pythonUnicodeGraphFind' if arm == 'pureBase' else review / 'copies/ponytail/pythonUnicodeGraphFind'
    tests = 'tests/test_coffee_pipeline.py tests/test_variant_snapshots.py -k "python or each_physical"' if arm == 'pureBase' else 'tests/test_script_member_coffee_snapshots.py -k python'
    command = f'cd "{folder}/atlas" && PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTEST_ADDOPTS= PYTHONPATH="{folder}/atlas/src:{folder}/atlas" /home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B -m pytest -q -p no:cacheprovider --basetemp="{review}/temp/{arm}BaselineExtra" {tests}'
    run(arm + 'FixtureConsumers', command, folder)
