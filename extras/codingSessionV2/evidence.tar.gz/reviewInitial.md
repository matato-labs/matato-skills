# Independent initial review: three implemented cases

## Verdict

No defensible coding-session win in this round. Both variants satisfy the original oracles and the additional checks below. Their Python and Go production algorithms are identical modulo names; scheduler production behavior is equivalent over the checked domain. Ponytail has the smaller observed patch. Coding-session adds some useful test combinations, but no demonstrated production efficiency or dependency-reuse advantage. This evidence does not justify a superiority claim, PR, or Ponytail removal.

No implementation or profile was edited. No commits made. Only review artifacts were added under this experiment directory. All six worktree diffs still match their saved patches exactly (after normalizing diff prefixes). Base and both variant HEADs match the specified starting commits: source `64017b798a75fccff7d6d545172251851fcef615`, CSV `4b1e143abc40f4582d90bfcdc7c55b06d787a934`, scheduler `92ec28467170bb8b520ebe53dea234b7623dec46`.

## Method and exact metrics

Read all six actual patches, allowed task briefs, selected case rationales, the three original oracles, both profiles, relevant existing tests, real GraphReader/config/worker APIs, Go's installed `encoding/csv/reader.go`, and installed Croner 10.0.1 implementation. Recomputed metrics from saved patch contents and checked against each worktree's actual `git diff --numstat HEAD`; new tests are included. Python renamed-AST comparison confirms equality in both production files; replacing the private Go helper name makes those production files byte-identical.

Each cell below is `added/deleted; churn; net`. Churn = additions + deletions; net = additions − deletions, relative to the starting commit. Source excludes all test files, including `src/automationConfig.test.ts`. These are physical lines, not semantic complexity measurements.

| Case / variant | Source | Tests | Combined |
|---|---:|---:|---:|
| sourceBatchReads / Ponytail | 20/8; 28; +12 | 45/0; 45; +45 | 65/8; 73; +57 |
| sourceBatchReads / coding | 20/8; 28; +12 | 47/0; 47; +47 | 67/8; 75; +59 |
| isinCsvRecords / Ponytail | 24/14; 38; +10 | 56/0; 56; +56 | 80/14; 94; +66 |
| isinCsvRecords / coding | 24/14; 38; +10 | 75/0; 75; +75 | 99/14; 113; +85 |
| scheduleTimeZones / Ponytail | 8/3; 11; +5 | 76/2; 78; +74 | 84/5; 89; +79 |
| scheduleTimeZones / coding | 11/3; 14; +8 | 128/2; 130; +126 | 139/5; 144; +134 |
| **Total / Ponytail** | **52/25; 77; +27** | **177/2; 179; +175** | **229/27; 256; +202** |
| **Total / coding** | **55/25; 80; +30** | **250/2; 252; +248** | **305/27; 332; +278** |

Correction to supplied prior findings: raw source churn is **77 vs 80**, not 80 vs 83. The relative +3 remains correct. Machine-readable per-case accounting is `research/reviewLogs/verifiedMetrics.json`.

Coding has +76 combined churn/net lines: +3 source and +73 tests. The source difference is not extra scheduling logic: coding expands the factory call across more lines; Ponytail instead includes an explanatory comment. Neither should be credited with a runtime improvement on that basis.

## Checks actually executed

Original oracle hashes match the selected `research/cases.json` entries: source `5ea2cc05…`, CSV `74c82284…`, scheduler `0b4e4bac…`. Originals were not modified.

| Check | Base | Ponytail | coding |
|---|---|---|---|
| Original source oracle, 5 methods | fails: 5 assertions including subtests | pass | pass |
| Original CSV oracle, 13 scenarios | 7 fail / 6 pass | 13 pass | 13 pass |
| Original scheduler oracle, 7 tests | 4 fail / 3 pass | 7 pass | 7 pass |
| Supplemental source, 3 methods | 2 fail / 1 pass | 3 pass | 3 pass |
| Supplemental CSV, 12 scenarios | 7 fail / 5 pass | 12 pass | 12 pass |
| Supplemental scheduler, 9 tests | 4 fail / 5 pass | 9 pass | 9 pass |
| Supplemental real SQL, 4 cases | 2 fail / 2 pass | 4 pass | 4 pass |

Supplemental Python scripts are frozen read-only under `research/supplemental/`, with SHA-256 manifests verified after execution. All were run on both variants and base. They add checks; they do not replace or relax originals. Scheduler's ninth test reports dependency validation behavior rather than imposing a new requirement.

The SQL harness initially assumed a worktree-local venv, absent on base. That first base invocation could not run. The original frozen script remains unchanged; `sourceSqlWorkPortable.py` adapts only its subprocess interpreter. This portable wrapper was frozen and rerun on all three repositories with identical assertions and one installed test interpreter. Reported SQL results are from these valid reruns.

Focused native checks also pass: each variant's `atlas/.venv/bin/python -m pytest tests/test_graph_navigation.py -q` (50 tests each); `GOWORK=off GOPROXY=off GOSUMDB=off go test ./data -count=1` from `commons`; and `bun test worker/scheduler.test.ts src/automationConfig.test.ts`, adding `worker/schedulerTimeZones.test.ts` for coding. Scheduler native tests were run with `TZ=Asia/Tokyo`, `UTC`, and `America/Los_Angeles`: Ponytail 15 pass, coding 18 pass in every zone. Go JSON reruns also pass; subtest counts are not comparable coverage units because coding loops over limits inside a subtest.

Reproduce originals with `python research/oracles/<case>.py <repo>`, supplements with `python research/supplemental/<case>.py <repo>`. Run the SQL portable script with `runs/codingInitial/sourceBatchReads/atlas/.venv/bin/python`. All logs are in `research/reviewLogs/`; test-run timings are not benchmarks.

## sourceBatchReads: pass, equal implementation, bounded improvement

In `atlas/src/atlas/services/navigation.py:64` both allocate a fresh dictionary inside `sources`. In `navigation_source.py:15–39` both extract verification into `verified_bytes`, caching its status/bytes by the original path string. The optional cache leaves single-source behavior uncached. Ineligible nodes return before cache lookup or verification. Both reuse the existing containment/open/size/hash boundary and existing excerpt machinery; neither duplicates safety policy.

Original checks cover order, duplicates, multiple paths, pagination, metadata, missing spans, changed/missing/unverified/invalid-encoding outcomes, unsafe paths, ambiguity, and request freshness. Supplemental checks additionally combine repeated escaped symlinks, symlink loops, directories, oversized files, empty hashes and ambiguous indexed rows in one batch; then restore every path and verify recovery. They verify size metadata, pathless/external handling, excerpt-too-large versus a readable sibling, and distinct mutable response lists for duplicate entries. All pass in both variants.

Measured verification-boundary work for one repeated eligible path:

| Nodes | Base lookups/reads/hashes/decodes | Either variant |
|---:|---:|---:|
| 1 | 1/1/1/1 | 1/1/1/1 |
| 10 | 10/10/10/10 | 1/1/1/10 |
| 100 | not reached after base's 10-node assertion failure | 1/1/1/100 |

These are actual call counts around real operations, not estimated runtimes. Failed verification is cached too. Unsupported encoding is still detected downstream, so decoding failures can repeat even though bytes and hashes are shared.

Importantly, `atlas/src/atlas/persistence/navigation.py` shows `GraphReader.node` performs four SELECTs per key, including a separate `graph_files` metadata query. `GraphReader.file` performs the path-verification join. Real SQL traces for ten duplicate **file** keys, and separately ten duplicate symbol keys, yield:

| Work during `sources` after reader construction | Base | Either variant |
|---|---:|---:|
| All SELECTs | 51 | 42 |
| File-metadata SELECTs from node enrichment | 10 | 10 |
| Path-verification SELECTs | 10 | 1 |

Thus the intended verification-port bound passes; a stronger literal reading of “only one indexed-file query anywhere in the production call” does **not** hold for either implementation. This is a shared completeness caveat, not a variant discriminator. The original oracle's minimal reader cannot expose node-enrichment SQL. Do not report one total database lookup per path, or claim the batch is now O(distinct files) overall.

```mermaid
flowchart LR
  A[Ordered keys, including duplicates] --> B[Node enrichment per key]
  B --> C[Request-local verification cache per path]
  C --> D[Decode and excerpt per node]
  D --> E[Response metadata and diagnostics]
```

Both still decode/split the full file once per eligible excerpt: for k same-file nodes of B bytes, that CPU work remains O(kB). Both additionally retain successful bytes for every distinct file until this call returns, approximately O(sum of verified byte sizes), rather than only a current file buffer. The 8 MiB limit is per file, not a batch-memory limit. These are real tradeoffs, not newly failed requirements. No peak-memory or latency benchmark was run.

Coding's two extra test lines add more explicit key/pagination assertions; existing tests already exercise those preservation contracts. Both additions meaningfully test verification counts and freshness. No production correctness difference found.

## isinCsvRecords: pass, equal precise stdlib reuse

Both `commons/data/isin_loader.go` implementations are identical apart from the private helper name. `csv.NewReader` supplies strict quoting, escaped quotes, multiline records, blank-line skipping, CRLF normalization and growable record handling. `FieldsPerRecord=-1` for the header, then `3` for data, correctly separates header width from required data width. Default `TrimLeadingSpace=false` preserves fields; default strict quoting rejects malformed records. Errors are checked before indexing the three fields, avoiding partial-record panics.

Both test `len(isins)<n` **before** reading another record, return early for nonpositive limits, and stop after a completed prefix. Supplemental public-API overlays verify a multiline differently sized header with leading blank lines, bare/trailing quotes, whitespace before quotes, whitespace-only records, blank-only files, malformed headers under nonpositive limits, wide rows inside versus outside the prefix, a 100,000-character quoted multiline name followed by a malformed tail, and empty fields without a terminal newline. Both pass; malformed records return actual `*csv.ParseError` values.

Installed Go source confirms there is no Scanner-style 64 KiB token ceiling: `readLine` grows its buffer on `bufio.ErrBufferFull`. It also confirms `csv.Reader` buffers its input, so both bound parsed **records**, not exact underlying bytes fetched. Small suffixes may be prefetched; they are not parsed or allowed to invalidate a completed prefix. Neither reads the entire file into records. Memory still scales with consumed records and the largest consumed record; no bounded-field-size claim is warranted.

Each helper has one production caller and serves input-injection tests; it is a testability extraction, not evidence of greater domain reuse. Both retain embedded-file closing behavior and introduce no dependency. Coding's tests use already installed `testify/require`; Ponytail uses `reflect`/testing. This changes test dependencies used, not production parsing efficiency.

Coding adds 19 test lines. Some improve combined boundary coverage, particularly testing the same bad second record both inside and outside the requested prefix. Repeating zero and negative limits for all six malformed-tail forms is redundant with the shared early-return contract; one deliberately malformed input per nonpositive limit can protect it. Ponytail actually includes malformed-header/nonpositive combinations and whitespace-only-row rejection absent from coding's native tests. Neither native suite strictly dominates; supplements pass both. No production issue found.

## scheduleTimeZones: pass, equivalent dependency delegation

Both add `timezone?: string` to the real `Automation` type, forward it through `ScheduleFactory`, and pass it directly to installed Croner. They preserve `paused:true` and `mode:"5-or-6-parts"`. Stored configuration already spreads each automation, so no new loader schema or translation layer is necessary. Worker construction uses this scheduler; daily-session naming and configuration-wide behavior remain untouched.

Both explicitly validate enabled jobs with `Intl.DateTimeFormat` inside the existing candidate-build try/catch, after disabled-job skipping and before the factory. Duplicates remain checked even for disabled entries. A failed replacement stops collected candidates before any old schedules are stopped. Overlap state remains outside schedule replacement; stop remains terminal.

Do not remove that validation merely because Croner accepts `timezone`. Actual dependency probes show `new Cron(pattern,{paused:true,timezone:bad})` **without a callback** does not validate the zone yet. With the production callback, date calculation rejects an ordinary bad nonempty zone, but accepts `""` as local. Application validation therefore closes a concrete explicit-empty gap and validates at the boundary independently of a lazy factory. It does duplicate validation work for ordinary zones in the real callback constructor, but that is a shared tradeoff, not evidence either variant incorrectly reimplements DST. No additional formatter or per-tick policy was added by either.

Original tests exercise per-job New York/Kathmandu/UTC, both cron widths, DST, Tokyo-local omission, stored Berlin configuration, rollback, disabled invalid settings, duplicates, mode, overlap and stop. Supplemental tests exercise actual timer ownership through empty and ordinary bad-zone rollback, zoned candidates followed by cron/duplicate/monitor failure, disabled bad settings amid a failing replacement, post-stop inertness, removal/readdition while a prior invocation remains active, and Lord Howe's **30-minute DST change** for both cron widths. Both retain exactly one live old timer after rollback and zero after stop. Both pass every combination. This is lifecycle evidence, not just `nextRun` equality.

Coding's extra 52 test churn lines over Ponytail are not all waste: it checks both five/six-field schedules across spring and fall, and takes a stored six-field job through the real scheduler. Ponytail combines different cron widths with different seasons and adds the stored timezone to an existing config round-trip fixture. Coding also changes the existing overlap fixture to reload a different zone. Those are useful stronger combinations, but the separate 100-line timezone test file recreates capture/cleanup and temporary-config scaffolding already present elsewhere. A smaller patch could retain the distinct assertions while extending existing fixtures. Passing counts alone neither prove coding's tests necessary nor prove Ponytail's suite fully sufficient.

## Generalizable skill feedback and bounded rewrite proposal

The current coding profile is exactly **5121 bytes, 740 whitespace-delimited words, 36 lines**; Ponytail is 3492 bytes, 592 words, 52 lines. More instruction volume did not create better production reuse here. Both already found the same facilities. This is one observed run per case, not evidence of profile causality or broad superiority.

Replace repeated anti-scaffolding prose and narrow existing examples with three general requirements: inspect/probe the actual installed API's consumption/error/validation/lifecycle semantics; count expensive work across the whole caller path and account for retained data; compare new tests with existing fixtures, preserving distinct behavioral assertions rather than multiplying equivalent input combinations. None should require extra tooling, a planning document, or speculative optimization on every task.

The following is a **proposal only**, not an edited profile. It preserves completeness, trust-boundary validation and test obligations while giving concrete guidance for precise reuse and resource accounting. Proposed size is measured below; all three ceilings remain respected.

```markdown
---
name: coding-session
description: Write or change code using the least code and complexity that fully satisfies the request, without sacrificing readability. Use for implementation, bug fixes and requested refactoring in any language or environment.
disable-model-invocation: true
---

# Coding session

Implement the whole requirement, not every idea it suggests. Every addition must serve required behavior, necessary integration or a concrete regression risk. Fewer lines count only when correctness and readability survive.

## Establish the boundary

Read the request, affected source and repository instructions. Identify required behavior, behavior that must survive, and affected callers, tests, fixtures, exports and configuration. For a bug, find the shared cause before editing. Ask only about ambiguity that changes correctness; otherwise choose the smallest complete interpretation. Do not create another specification or planning document unless requested. Already-satisfied requirements need no implementation.

## Reuse the actual contract

Try, in order: no change; changing existing code; an existing project facility; a standard library or platform operation; an installed dependency; direct code. Read the relevant implementation, types or documentation before reconstructing behavior. Respect established interfaces and layers. Reuse authoritative contracts, defaults, validation and error handling, not just similarly named functions. Do not add a dependency for a few lines.

Check the semantics correctness depends on: omission versus explicit values, consumption limits, partial results, errors, ownership and eager versus deferred work. Use a small probe when uncertain. Preserve required ordering, copying and public behavior. Keep native values in their existing form. Do not rebuild behavior already supplied by the chosen facility.

Keep validation at untrusted boundaries and all required security, synchronization, accessibility and data-loss protections. Trust established internal guarantees; add checks only for a demonstrated gap. Preserve resource ownership through failure, replacement and cleanup. Reuse recovery and precedence policy rather than inventing a second path.

## Make additions earn their place

First try changing the existing expression or condition. Use guard clauses to reduce nesting, not multiply equivalent exits. Extract only shared work needed now or logic whose separation materially improves understanding. Do not compress several responsibilities into a clever one-liner. Ask of each statement, branch, helper, type, option, file, comment and dependency: what requirement or concrete regression fails without it? Apply this to test scaffolding too. Remove speculative configurability, wrappers, conversions, fallback behavior and nearby cleanup. Comments explain non-obvious constraints, not the code.

Name expensive operations and their unit of work. Check the whole caller path, not just the edited helper. When sharing work, separate reusable facts from consumer-specific outcomes, preserve failure semantics, and bound its lifetime. Account for retained data as well as avoided operations. Do not add caching or optimization without a required benefit. Do not confuse fewer lines, fewer boundary calls and less total work.

## Verify the smallest complete change

Update every required integration. Add a focused regression in the existing framework, or a tiny executable self-check when none exists. Read existing coverage first; reuse fixtures and parameterize equivalent cases instead of duplicating setup. Cover new failures and distinct contracts, including interacting paths where relevant. Retain meaningful assertions; do not exhaust a platform's input space or re-prove covered guarantees merely to enlarge the suite.

Run relevant checks and inspect the whole diff, including callers and tests. Remove additions without a necessity argument. Never claim savings by moving complexity, squeezing formatting or deleting safeguards. Report only checks actually run, the change and remaining limitations briefly. Stop when the requirement is met; no unsolicited audit report.
```

Proposal measurement from the exact fenced text, including frontmatter and final newline: **4154 UTF-8 bytes, 570 whitespace-delimited words, 33 lines**. Headroom: 967 bytes, 170 words, 3 lines. Neither profile file was changed.

## Limitations and experiment hygiene

No broad benchmark, peak-memory measurement, full repository test suite, full TypeScript typecheck/lint, live long-running worker, exhaustive timezone database, concurrent filesystem-swap stress test, or external service was run. The focused Python suite does include existing source-safety tests. Timer and hash instrumentation establishes operation/lifecycle counts, not speed. Supplemental SQL tests reuse the existing graph fixture but assert and observe the actual service/repository calls; they are not an independent persistence fixture.

No holdout implementation, oracle or worktree contents were inspected or executed. One preliminary metadata dump was overbroad: it emitted the nested cases list before filtering its entries; holdout metadata was therefore not perfectly blinded. It was excluded from analysis, proposed guidance and all checks. No holdout behavior is inferred here.

The remaining substantive caveat is shared: verification caching meets the original oracle's read-port interpretation but does not eliminate repeated node-enrichment indexed-file SQL or full-file decoding. Resolve that interpretation before claiming complete end-to-end query deduplication. Under the controlled acceptance checks, both implementations pass; coding-session's requested win remains unestablished.
