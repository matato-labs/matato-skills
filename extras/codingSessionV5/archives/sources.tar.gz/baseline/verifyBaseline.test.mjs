import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = new URL('./', import.meta.url);
const provenance = JSON.parse(readFileSync(new URL('provenance.json', root), 'utf8'));
const digest = (path) => createHash('sha256').update(readFileSync(new URL(path, root))).digest('hex');

test('upstream identity and original skill match the independent pins', () => {
  assert.equal(provenance.source.ref, '84740e3d344b69b4a133201fa519eb37a62a2b2a');
  assert.equal(digest('upstream/skills/ponytail/SKILL.md'), 'ba68ff26239c3c3b05b2a9a47ee0d9a6b93a69639a2555ec87a5d44bffaf2f0c');
});

test('every vendored file is inventoried with its original bytes and mode', () => {
  const files = readdirSync(new URL('upstream/', root), { recursive: true, withFileTypes: true })
    .filter((entry) => entry.isFile())
    .map((entry) => join(entry.parentPath, entry.name));
  assert.deepEqual(files.sort(), provenance.files.map((entry) => fileURLToPath(new URL(entry.path, root))).sort());
  for (const entry of provenance.files) {
    assert.equal(digest(entry.path), entry.sha256, entry.path);
    assert.equal(statSync(new URL(entry.path, root)).size, entry.bytes, entry.path);
    assert.equal((statSync(new URL(entry.path, root)).mode & 0o777).toString(8), entry.gitMode.slice(-3), entry.path);
    assert.equal(entry.path, `upstream/${entry.sourcePath}`);
  }
});

test('Pi manifest exposes the original extension and all six command skills', () => {
  const manifest = JSON.parse(readFileSync(new URL('upstream/package.json', root), 'utf8'));
  assert.deepEqual(manifest.pi, { extensions: ['./pi-extension/index.js'], skills: ['./skills'] });
  for (const name of ['ponytail', 'ponytail-audit', 'ponytail-review', 'ponytail-debt', 'ponytail-gain', 'ponytail-help']) {
    assert.ok(readFileSync(new URL(`upstream/skills/${name}/SKILL.md`, root), 'utf8').includes(`name: ${name}`));
  }
});
