# Independent review — round one

**Do not freeze candidateOne yet.** Its requested production behavior passes the frozen tuning checks, and its maintained regressions detect the original bugs. However, its Python fixture addition breaks an existing integration invariant. Its combined churn also loses to main and PR112. No implementation outputs were repaired.

## Critical findings

**R1 — candidateOne: incomplete fixture integration.** `pythonUnicodeGraphFind/atlas/tests/coffee_navigation.py:88` adds a new top-level `fixtures/coffee/unicode_search` project. The existing `test_coffee_pipeline.py:106` inventory requires every physical coffee project to have registered analysis seams; `test_each_physical_project_has_analysis_seams` fails on that directory. The new Unicode test and frozen native command both pass while this existing test fails. Pure pinned base passes. The new `unicode_search.json` also has no regeneration route through `update_coffee_snapshots.py`; Ponytail did connect its separate snapshot to that generator. This is an integration gap, not a reason to remove or weaken the existing inventory assertion. Evidence: `commands/candidateOnePythonIntegration.log`, `commands/pureBaseFixtureIntegration.log`.

**R2 — main: stale dependent snapshots.** Adding `fixtures/coffee/python/src/coffee/reporting/straße.py:1` changes all eight Python overlay variants, but `snapshots/variants/python.json` was not updated. `test_named_project_variants[python]` fails, while pure pinned base passes. PR112 follows that fixture dependency and updates the variant snapshot; its corresponding check passes. Evidence: `commands/mainPythonIntegration.log`, `commands/pureBaseFixtureConsumers.log`, `commands/prPythonIntegration.log`.

**R3 — candidateOne: no aggregate size win against every baseline.** Production/test churn is 58/629, combined 687, versus main 637, PR112 684 and Ponytail 691 combined. Moreover, the entire two-line production advantage over main comes from omitting two blank separators in `src/storage/memoryBlock.ts`; the implementations otherwise match there exactly. Python production churn ties main at 15; Ecto ties every arm at six. This is not evidence of materially better production reuse than main. See `metrics.json` and `mainCandidateProductionDiff.txt`.

No additional production correctness defect or removed safeguard was found in the affected paths reviewed. That bounded conclusion does not override R1/R2 or imply full-suite correctness.

## Independently recomputed metrics

Computed from current worktree `git diff --numstat -z`, including intent-to-add new files and Unicode paths, excluding dependency symlinks/build trees. This independently matches the preliminary churn numbers. No implementation index was changed. Tests include fixtures, snapshot JSON and test helpers; other churn is zero.

| Arm | Production +/− | Production churn | Tests +/− | Test churn | Combined churn | Combined net |
|---|---:|---:|---:|---:|---:|---:|
| main | 47/13 | 60 | 572/5 | 577 | 637 | +601 |
| PR112 | 50/13 | 63 | 611/10 | 621 | 684 | +638 |
| Ponytail | 53/13 | 66 | 619/6 | 625 | 691 | +653 |
| candidateOne | 45/13 | 58 | 625/4 | 629 | 687 | +653 |

| Case | main prod/tests | PR112 prod/tests | Ponytail prod/tests | candidateOne prod/tests |
|---|---:|---:|---:|---:|
| Python | 15/103 | 18/106 | 21/134 | 15/108 |
| TypeScript | 39/297 | 39/340 | 39/329 | 37/345 |
| Elixir | 6/177 | 6/175 | 6/162 | 6/176 |

Candidate combined per-case losses: Python +5 versus main; TypeScript +46/+3/+14 versus main/PR112/Ponytail; Elixir +1/+14 versus PR112/Ponytail. Aggregate candidate deltas are +50/+3/−4 combined lines respectively. Its generated additions total 670 lines versus 619/661/672, not a win over main or PR112.

Physical lines understate generated snapshot cost: combined source/test byte growth is candidate +35,131, main +54,971, PR112 +209,063 and Ponytail +55,689. Candidate's dedicated sample avoids large shared snapshot updates but is not correctly integrated. PR's variant snapshot integration costs only two physical churn lines while carrying substantial bytes; main's lower count partly reflects an omitted required update. Do not silently repair outputs or normalize these differences away.

Profile bytes independently checked: candidateOne 3,046; PR112 3,161; main 5,121. Candidate meets the size ceiling, not the implementation success gate.

## Real reuse and preserved safeguards

Python uses genuine language/stdlib/dependency composition: `str.casefold`, SQLite `Connection.create_function(..., deterministic=True)`, and the existing SQLAlchemy connection event in `readonly_session`. The function is connection-local and NULL-preserving; it does not replace global SQLite `lower`, rewrite data or change project-name resolution. `GraphReader.find` retains SQL `instr` for literal punctuation, exact raw stable-key matching, SQL rank/tie ordering, repository scope and limits. Candidate reuses three SQL expressions through tuple/generator composition. All arms use the same substantive design; Ponytail additionally names a small NULL-preserving callback. Service and CLI retain their existing boundaries.

TypeScript reuses `withStorageTransaction` and its existing `begin immediate`/commit/rollback wrapper, name Maps from persisted plus newly created records, `mergeNumbers`/`Set` deduplication, and existing create/link stores. Schema unique names make deriving membership from Map values sound. Store conflict handling and foreign keys remain intact. Explicit IDs are authoritative through `id !== undefined`, zero remains rejected, and names stay exact. Errors are thrown inside the transaction, including late topic resolution after creating the item. No parallel transaction, custom rollback, new storage layer or input-shape validation was added. The new per-topic room-ID Set is rebuilt for every topic; sharing derived lookups at an existing common lifetime is a general reuse opportunity, not a measured performance claim or permission for unrelated refactoring.

Elixir is already minimal and idiomatic in every arm: six `Ecto.Changeset.validate_number(field, greater_than_or_equal_to: 0)` calls compose after existing `cast`/`validate_required`. No manual parsing, custom range validator, migrations, DB calls or new upper bound. Defaults, associations, unrelated attributes and state-only updates remain unchanged. There is little honest production size headroom here.

```mermaid
flowchart LR
  sample[Shared sample / fixture] --> readers[Snapshot readers]
  sample --> variants[Overlay variants]
  sample --> inventory[Project / seam inventory]
  sample --> generator[Existing generator]
  readers --> checks[Maintained checks]
  variants --> checks
  inventory --> checks
```

The missed fixture consumers, rather than search implementation complexity, explain the completeness failures.

## Checks actually executed

All commands, working directories, exits, duration and exact combined stdout/stderr are captured under `commands/`; `evidence.json` consolidates 66 command records with output hashes. Every command had a 120-second cap; none timed out. All execution used our own disposable archive copies, never experiment worktrees. Python native `--basetemp` was changed only in the executed command to a unique review-local path per arm; frozen files were not edited.

All twelve frozen acceptance commands and all twelve frozen native commands passed. Every arm's added/changed maintained test files were then explicitly executed, rather than assuming native discovery included them:

| Arm | Python oracle / native / maintained | TS oracle / native / maintained | Ecto oracle / native / maintained |
|---|---|---|---|
| main | 8 / 57 / 64 | 12 / 18 / 30 | 249 / 249 / 6 |
| PR112 | 8 / 69 / 76 | 12 / 18 / 45 | 249 / 249 / 7 |
| Ponytail | 8 / 55 / 62 | 12 / 18 / 37 | 249 / 249 / 6 |
| candidateOne | 8 / 54 / 61 | 12 / 18 / 32 | 249 / 249 / 6 |

Counts are successful test cases, not comparable coverage scores. Python native deselects seven language snapshots; maintained runs include all navigation snapshots. TS maintained runs explicitly add `src/storage/memoryBlock.test.ts` to the two native files. Ecto native is the supplied oracle again: it does **not** discover the new domain tests. Maintained ExUnit was loaded explicitly, service-free, without Mix aliases or the application/database.

Additional existing Python fixture-consumer checks selected 11 cases per arm: candidate and main each failed one with ten passing; PR112 and Ponytail passed all 11. Pure base passed the corresponding 11 checks. Ponytail's existing script-member snapshot consumer also passed. These checks found R1/R2 despite green acceptance/native runs.

All TS native typechecks/source lint and explicit new-test ESLint checks passed. Python Ruff passed for every arm. Initial additional Pyright runs failed because our disposable archives lacked the configured `.venv`; those exits and missing-import output are retained, not counted as correctness passes. Linking the shared venv only into the disposable copies and rerunning produced zero Pyright errors for every arm.

## Maintained negative controls

Candidate source was restored to pinned original production **only in separate disposable copies**, retaining candidate tests/fixtures. No hand-written mutant logic and no experiment worktree restoration was used.

| Maintained candidate suite against original production | Exit | Observed failure |
|---|---:|---|
| Python graph + coffee navigation | 1 | 2 failed, 59 passed: rank list collapses to raw key; Unicode file search returns no matching file |
| Python coffee navigation alone | 1 | 1 failed, 14 passed: new production-indexed Unicode regression fails independently |
| TypeScript explicit three-file suite | 1 | 10 failed, 22 passed: unresolved room/topic variants do not throw |
| Elixir added suite | 2 | 2 failed, 4 passed: individual and simultaneous negative quantities accepted |

Restoring only each original Ecto production file separately also fails the maintained suite: original Order gives one failure, original CpuOrderData one, original Player two. This checks that the first failing comprehension does not hide missing coverage of the CPU validator. These are original-code negative controls, not an Atlas mutation score. Passing original-code tests for already-correct ID precedence or valid inputs is expected; they protect compatibility rather than diagnose the original hole.

## Why test churn differs

TypeScript is the largest candidate loss: 345 added lines versus 297/340/329. All arms already reuse `createTestDatabaseFixture` and test tables rather than inventing a database harness. Candidate's all-five-table rollback comparisons, late errors, recovery, zero IDs, exact names, deduplication, metadata and ID precedence are meaningful. It additionally splits same-block ID resolution and conflicting-ID/name/find/unlink success into separate scenarios; some setup and same-block assertions overlap its earlier success scenario. Main composes new IDs and stale/conflicting names into one success case, but has less explicit maintained unlink coverage. PR's 27 generated cases remain shorter than candidate's 14 because a shared mutation table and fresh/saved parameterization reuse one body. More cases do not necessarily mean more code; fewer assertions are not the target.

Elixir's 162–177 lines are predominantly common case data, insert/update construction, error assertions and compatibility setup around six production lines. Individual fields, negative form strings, zero, an unbounded positive value, simultaneous errors and action rejection are distinct contracts. Multiplying every magnitude across every schema/key/action representation, reasserting invariant schema metadata inside role loops, and repeating constructor setup mostly exercises common Ecto behavior. Keep contractual assertions; compose builders/case tables and reuse one assertion path instead of spreading them over near-identical setup blocks. PR also includes a distinct mixed required/cast/range-error interaction; candidate adds explicit association metadata checks. Neither is automatically bloat.

Python tests combine a real indexed-sample integration with synthetic rows for rank/tie combinations that actual source cannot readily generate. Candidate has meaningful service/CLI, read-only, literal punctuation, Unicode expansion/sigma, normalization negatives, raw-key, limit and diagnostic coverage. Its 108 test churn lines versus main 103/PR106 are not a platform explosion; its failed fixture registration is the important issue. PR's four-script-by-three-column parametrization mostly repeats the shared casefold contract, while exact path/name/qualified rank priorities remain distinct. Shared fixture fan-out, especially variant snapshots, explains the large byte differences. Reuse a suitable existing fixture location and its generators, not necessarily the highest-fan-out sample or a new unregistered root.

## Next bounded skill hypothesis

Do not add a language-by-language checklist or delete meaningful assertions. Test whether stronger composition plus fixture-consumer reuse improves the next isolated draw. Two replacement passages, not appended instructions, would make candidateOne **3,043 bytes** (three bytes smaller; ceiling 3,161):

> Compose existing operations and native operators before adding control flow or state. Share derived lookups at the common lifetime; reuse contracts.

> Read maintained coverage first. Reuse fixture locations, builders and generators; trace their consumers before adding samples. Cover the bug, distinct contracts and risky interactions with case tables and shared setup, not platform Cartesian checklists. Keep meaningful assertions and integration coverage. External probes supplement regressions; use an executable self-check only without a framework.

Exact replacement locations and byte arithmetic are in `evidence.json`. This is a proposed hypothesis only: no skill/profile or implementation was edited, and no improved outcome is claimed.

## Limits and scope deviation

Only one tuning draw and three tasks were examined. No full Python/dashboard/application suite, DB-backed Ecto tests, network or service was run. No optional Atlas mutations were attempted and no mutation adequacy/resource-saving claim is made. Original `agent.log` files are final summaries, not tool histories; their broader reported checks are not independently established by those summaries. Recovered Elixir metadata has null original exit/duration for three arms, as disclosed in `harnessIncident.md`; independent reruns do not recover those missing measurements.

**Holdout-blindness caveat:** while locating tuning files, I inadvertently opened `research/typescript/manifest.json`, an aggregate containing the reserved task entry and brief. Python/Elixir aggregate freeze files also exposed validation names/hashes. I did not open any reserve-specific manifest, oracle, source/rationale file or validation output, or execute reserved checks. The reserve brief exposure is nevertheless a scope deviation and must not be represented as complete holdout blindness. It did not inform the tuning findings or proposed changes; parent should preserve this disclosure for later evaluation.

Large generated snapshot patch lines were parsed completely as JSON and reviewed structurally alongside fixture source, response summaries and native snapshot execution. Every function outside affected paths was not exhaustively audited. Original experiment changed-file fingerprints before/after are identical (`before.json`, `after.json`); all existing tuning source remains unchanged. Shared dependencies were only used read-only; no implementation fixes, installs, commits or user-checkout edits were performed.

Primary machine evidence: `evidence.json`. Detailed per-file additions/deletions/churn/net/bytes: `metrics.json`. Exact command evidence: `commands/*.log`.
