#!/usr/bin/env python3
"""Physical/normalized-line counts and structural snapshot audit; no implementation edits."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent.parent
LOGS = ROOT/'research/reviewFrozenLogs'
LOGS.mkdir(exist_ok=True)
VARIANTS = ['ponytailFrozen','codingFrozen','ponytailReplication','codingReplication']
CASES = ['sourceBatchReads','isinCsvRecords','scheduleTimeZones','pathEarlyExit','pollProcessContract','preScriptIsolation']

def git(repo, *args):
    return subprocess.check_output(['git','-C',str(repo),*args])

def norm_patch(s):
    return s.replace('diff --git i/','diff --git a/').replace('diff --git c/','diff --git a/').replace(' w/',' b/').replace('--- i/','--- a/').replace('--- c/','--- a/').replace('+++ w/','+++ b/')

def semantic_lines(s):
    # An explicit proxy, not an invariant complexity score: ignore blank lines,
    # comment-only lines and horizontal whitespace; retain every other token/line.
    return [re.sub(r'\s+','',line) for line in s.splitlines() if line.strip() and not line.lstrip().startswith(('#','//'))]

def edits(old,new):
    adds = deletes = 0
    for tag,i,j,k,l in difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes():
        if tag != 'equal':
            deletes += j-i
            adds += l-k
    return adds,deletes

def counts(pair):
    a,d = pair
    return dict(added=a,deleted=d,churn=a+d,net=a-d)

expected = {(r['variant'],r['caseName']):r['numstat'] for r in json.loads((ROOT/'frozenMetrics.json').read_text())}
metrics, hygiene, snapshots, footprint = [], [], [], []
for variant in VARIANTS:
    for case in CASES:
        repo = ROOT/'runs'/variant/case
        base = ROOT/'base'/('final' if case in ['pollProcessContract','preScriptIsolation'] else '')/case
        actual = git(repo,'diff','--binary','HEAD').decode()
        assert norm_patch(actual) == norm_patch((ROOT/'patches'/variant/(case+'.patch')).read_text())
        numstat = git(repo,'diff','--numstat','HEAD').decode()
        assert numstat == expected[variant,case]
        assert git(repo,'rev-parse','HEAD') == git(base,'rev-parse','HEAD')
        groups = {g:[0,0] for g in ['source','tests','normalizedSource','normalizedTests']}
        for row in numstat.splitlines():
            a,d,p = row.split('\t')
            test = '/tests/' in p or '.test.' in p or p.endswith('_test.go')
            group = 'tests' if test else 'source'
            groups[group][0] += int(a); groups[group][1] += int(d)
            try: old = git(repo,'show','HEAD:'+p).decode()
            except subprocess.CalledProcessError: old = ''
            new = (repo/p).read_text()
            ng = 'normalizedTests' if test else 'normalizedSource'
            na,nd = edits(semantic_lines(old),semantic_lines(new))
            groups[ng][0] += na; groups[ng][1] += nd
            if p.endswith('.py') and '/snapshots/' not in p:
                ot,nt = ast.parse(old),ast.parse(new)
                functions = lambda tree: {n.name:n.end_lineno-n.lineno+1 for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
                of,nf = functions(ot),functions(nt)
                footprint.append(dict(variant=variant,case=case,path=p,newFunctions=sorted(nf.keys()-of.keys()),removedFunctions=sorted(of.keys()-nf.keys()),testDefinitionsBefore=sum(n.startswith('test_') for n in of),testDefinitionsAfter=sum(n.startswith('test_') for n in nf),astNodesBefore=sum(1 for _ in ast.walk(ot)),astNodesAfter=sum(1 for _ in ast.walk(nt)),longestFunction=max(nf.values(),default=0),lines=len(new.splitlines())))
            if '/snapshots/' not in p: continue
            before,after = json.loads(old),json.loads(new)
            assert before.keys() == after.keys()
            keys = [k for k in before if before[k] != after[k]]
            assert len(keys) == 1
            key, = keys
            b,n = before[key],after[key]
            assert b.keys() == n.keys()
            fields = [k for k in b if b[k] != n[k]]
            assert set(fields) <= {'nodes','edges','boundaries'}
            assert b['status'] == n['status'] == 'found'
            assert n['edges'] == b['edges'][:len(n['edges'])]
            assert n['nodes'] == b['nodes'][:len(n['nodes'])]
            assert n['edges'][-1] == n['pathEdges'][-1]
            external = sorted(node['stableKey'] for node in n['nodes'] if node.get('unresolved'))
            assert n['boundaries'] == [{'stableKey':k,'reason':'unresolved_or_ambiguous','expandable':False} for k in external]
            other = ROOT/'runs'/'codingFrozen'/case/p
            assert (repo/p).read_bytes() == other.read_bytes()
            snapshots.append(dict(variant=variant,path=p,key=key,changedFields=fields,nodesBefore=len(b['nodes']),nodesAfter=len(n['nodes']),edgesBefore=len(b['edges']),edgesAfter=len(n['edges']),external=len(external)))
        groups['combined'] = [groups['source'][i]+groups['tests'][i] for i in [0,1]]
        groups['normalizedCombined'] = [groups['normalizedSource'][i]+groups['normalizedTests'][i] for i in [0,1]]
        metrics.append(dict(variant=variant,case=case,**{k:counts(v) for k,v in groups.items()}))
        untracked = git(repo,'ls-files','--others','--exclude-standard').decode().splitlines()
        check = subprocess.run(['git','-C',str(repo),'diff','--check'],capture_output=True)
        assert check.returncode == 0 and not untracked,(variant,case,untracked,check.stderr)
        assert not git(base,'status','--porcelain')
        hygiene.append(dict(variant=variant,case=case,head=git(repo,'rev-parse','HEAD').decode().strip(),untracked=untracked,diffCheck=check.returncode,patchSha256=hashlib.sha256(actual.encode()).hexdigest()))
for variant in VARIANTS:
    for group in groups:
        total = {key:sum(m[group][key] for m in metrics if m['variant']==variant) for key in ['added','deleted','churn','net']}
        print('TOTAL',variant,group,total)
for name,obj in [('verifiedMetrics',metrics),('hygiene',hygiene),('snapshots',snapshots),('footprint',footprint)]:
    (LOGS/(name+'.json')).write_text(json.dumps(obj,indent=2)+'\n')
for p in (ROOT/'profiles').glob('*.md'):
    data=p.read_bytes()
    print('PROFILE',p.name,len(data),len(data.split()),len(data.splitlines()))
