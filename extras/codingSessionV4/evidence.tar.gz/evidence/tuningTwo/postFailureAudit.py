"""Read-only post-failure operational audit; never relaunch or repair trial outputs."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path

root = Path('/tmp/codingSessionV4')
evidence = root / 'evidence/tuningTwo'
spec = importlib.util.spec_from_file_location('coordinator', evidence / 'execute.py')
coordinator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(coordinator)


def load(path):
    if not path.exists() or not path.stat().st_size:
        return None
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError:
        return None


def save(name, value):
    with (evidence / name).open('x') as output:
        output.write(json.dumps(value, indent=2) + '\n')


def profileProof(raw, profile):
    expected = profile.read_text().strip()
    proof = {'source': 'read-only post-failure raw-stream audit; original outputs untouched',
             'firstToolIsProfileRead': False, 'profileReadSucceeded': False,
             'profileContentsObserved': False, 'malformedRecords': 0,
             'settled': False, 'aborted': False, 'finalStopReason': '',
             'profileExpectedSha256': coordinator.digest(profile)}
    starts, readIds, models, thinking = 0, set(), set(), set()
    with raw.open('rb') as stream:
        for line in stream:
            try:
                event = json.loads(line)
            except (json.JSONDecodeError, UnicodeDecodeError):
                proof['malformedRecords'] += 1
                continue
            kind = event['type']
            if kind == 'tool_execution_start':
                isRead = event['toolName'] == 'read' and event['args'].get('path') == '/tmp/codingSessionV4/currentProfile.md'
                if starts == 0:
                    proof['firstToolIsProfileRead'] = isRead
                starts += 1
                if isRead:
                    readIds.add(event['toolCallId'])
            if kind == 'tool_execution_end' and event['toolCallId'] in readIds and not event.get('isError', False):
                proof['profileReadSucceeded'] = True
                text = '\n'.join(block.get('text', '') for block in event['result']['content'])
                proof['profileContentsObserved'] |= expected in text
            if kind == 'message_end' and event['message']['role'] == 'assistant':
                message = event['message']
                models.add(message.get('provider', '') + '/' + message.get('model', ''))
                thinking.add(message.get('thinkingLevel', message.get('providerThinkingLevel', 'unreported')))
                proof['finalStopReason'] = message.get('stopReason', '')
            if kind == 'thinking_level_changed':
                thinking.add(event['level'])
            if kind == 'agent_settled':
                proof['settled'], proof['aborted'] = True, event.get('aborted', False)
    proof.update({'observedModels': sorted(models), 'observedThinking': sorted(thinking),
                  'rawStreamSha256': coordinator.digest(raw), 'rawStreamBytes': raw.stat().st_size})
    return proof


def stageRecord(folder, name):
    path = folder / f'{name}.json'
    record = load(path)
    if record is None:
        return {'evidence': 'missing or empty; exit and timing unavailable', 'exit': None}
    return {key: record[key] for key in ['argv', 'cwd', 'startedAt', 'finishedAt',
                                        'seconds', 'timeoutSeconds', 'timedOut', 'exit']}


def auditJob(job, ledger):
    folder = root / 'runs' / job['identity']
    label = job['arm'] + '.' + job['case']
    command = load(evidence / f'{label}.command.json')
    launch = load(evidence / f'{label}.launch.json')
    invocation = load(folder / 'invocation.json')
    result = load(folder / 'result.json')
    profile = root / 'profiles' / f"{job['arm']}.md"
    audit = load(folder / 'profileAudit.json')
    raw = None
    if invocation:
        private = Path(invocation['environment']['PI_CODING_AGENT_DIR']).parent
        raw = private / 'agent.stdout'
    if audit is None and raw and raw.exists():
        audit = profileProof(raw, profile)
    row = {**job, 'reserved': job['identity'] in ledger['runs'],
           'argv': (launch or command or {}).get('argv', ['/usr/bin/python', str(root / 'runTrial.py'), job['manifest'], job['arm'], 'tuningTwo']),
           'commandEvidence': command or launch,
           'runnerExit': command.get('exit') if command else None,
           'resultStatus': result['status'] if result else 'missing or empty result.json',
           'profileAudit': audit, 'agent': stageRecord(folder, 'agent'),
           'acceptance': stageRecord(folder, 'acceptance'), 'native': stageRecord(folder, 'native')}
    row['profileSnapshotMatches'] = coordinator.digest(folder / 'currentProfile.md') == coordinator.digest(profile) if (folder / 'currentProfile.md').exists() else None
    row['profileReadPassed'] = all(audit[key] for key in ['firstToolIsProfileRead', 'profileReadSucceeded', 'profileContentsObserved']) if audit else None
    row['runtimeAuditPassed'] = (audit['malformedRecords'] == 0 and audit['settled'] and not audit['aborted'] and audit['finalStopReason'] == 'stop' and audit['observedModels'] == ['openai-codex/gpt-6.1-sol'] and audit['observedThinking'] == ['high']) if audit else None
    if result:
        row['resultError'] = result.get('error')
    return row


def main():
    before = load(evidence / 'before.json')
    after = coordinator.snapshot([Path(path) for path in before['frozenInputs']])
    save('after.json', {'at': datetime.now(timezone.utc).isoformat(), **after})
    ledger = load(root / 'control/budget.json')
    save('ledgerAfter.json', ledger)
    prelaunch = load(evidence / 'prelaunch.json')
    rows = [auditJob(job, ledger) for job in prelaunch['jobs']]
    integrity = {key + 'Unchanged': before[key] == after[key] for key in
                 ['frozenInputs', 'launchers', 'ablationOutputs', 'ablationEvidence', 'tuningOneOutputs', 'tuningOneEvidence']}
    summary = {'completedAt': datetime.now(timezone.utc).isoformat(),
        'status': 'blocked; incomplete draw; no retry or repair',
        'blocker': 'OSError: [Errno 122] Disk quota exceeded; coordinator exit 1',
        'coordinator': load(evidence / 'coordinatorCommand.json'),
        'requestedRunnerIdentities': 8, 'retainedRunDirectories': sum((root / 'runs' / job['identity']).is_dir() for job in prelaunch['jobs']),
        'retainedAgentInvocations': sum((root / 'runs' / job['identity'] / 'invocation.json').is_file() for job in prelaunch['jobs']),
        'lifetimeReservations': ledger['reserved'], 'requestedLifetimeReservations': 20,
        'newReservations': ledger['reserved'] - 12,
        'reservationShortfall': 20 - ledger['reserved'],
        'profileAuditRows': len(rows), 'profileReadsProven': sum(row['profileReadPassed'] is True for row in rows),
        'runtimeAuditsPassed': sum(row['runtimeAuditPassed'] is True for row in rows),
        'maxConcurrentCoordinator': 6, 'harnessGlobalSlots': 6,
        'prior12OutputsUnchanged': integrity['ablationOutputsUnchanged'] and integrity['tuningOneOutputsUnchanged'],
        **integrity, 'runs': rows,
        'missingEvidence': 'Empty original JSON/log files preserved. Null exits/times are unavailable, never assumed zero. Last identity has a run directory but no ledger reservation.',
        'retries': 0, 'repairs': 0, 'connectivityProbes': 0, 'reserveContentOpened': False,
        'outputSelectionOrQualityAnalysis': False, 'publicationReady': False}
    save('failureSummary.json', summary)
    print(json.dumps({key: value for key, value in summary.items() if key != 'runs'}, indent=2))
    for row in rows:
        print(json.dumps({'identity': row['identity'], 'reserved': row['reserved'],
            'profileReadPassed': row['profileReadPassed'], 'runtimeAuditPassed': row['runtimeAuditPassed'],
            'agentExit': row['agent']['exit'], 'acceptanceExit': row['acceptance']['exit'], 'nativeExit': row['native']['exit']}))


if __name__ == '__main__':
    main()
