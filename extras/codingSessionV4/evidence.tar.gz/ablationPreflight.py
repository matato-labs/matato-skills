"""Tuning-only compatibility evidence; no implementation or budget reservation."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

from auditTrial import audit, publishExecution
from runTrial import Case, Manifest, agentArgs, prepareAuth
from sandboxTrial import Sandbox, environment, execute, proxyPath, root, sandbox, shell
from providerProxy import startProxy


manifests = [root / 'research/python/manifest.json',
             root / 'research/typescript/tuning/manifest.json']
evidence = root / 'evidence/ablationOne'


def log(text: str) -> None:
    with (evidence / 'coordinator.log').open('a') as stream:
        stream.write(f'{datetime.now(timezone.utc).isoformat()} {text}\n')
    print(text, flush=True)


def hashes() -> dict[str, str]:
    paths = [root / 'profiles/v3.md', root / 'profiles/reuseAblation.md']
    for manifest in manifests:
        # These supplied tuning folders alone; no recursive phase/task discovery.
        paths.extend(p for p in manifest.parent.iterdir() if p.is_file())
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}


def specFor(case: Case, manifest: Path, folder: Path) -> tuple[Sandbox, Path]:
    worktree = folder / 'owned'
    subprocess.run(['git', '-c', 'core.hooksPath=/dev/null', 'clone', '--shared',
                    '--no-checkout', case['repo'], str(worktree)], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    subprocess.run(['git', '-c', 'core.hooksPath=/dev/null', '-C', str(worktree),
                    'checkout', '--detach', case['base']], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    private = root / 'private' / uuid.uuid4().hex[:16]
    private.mkdir(parents=True, mode=0o700)
    (root / 'private').chmod(0o700)
    for name in ['config', 'runtime']:
        (private / name).mkdir()
    # Synthetic auth for offline setup/acceptance/native only.
    auth = private / 'auth.json'
    auth.write_text('{}\n')
    auth.chmod(0o400)
    pi = shutil.which('pi')
    assert pi is not None
    mounts: dict[str, list[str]] = json.loads((root / 'dependencyMounts.json').read_text())
    spec: Sandbox = {'worktree': worktree, 'repo': Path(case['repo']),
        'common': worktree / '.git', 'oracle': manifest.parent,
        'runtime': private / 'runtime', 'config': private / 'config', 'auth': auth,
        'profile': root / 'profiles/v3.md', 'profileSnapshot': root / 'profiles/v3.md',
        'pi': Path(pi).resolve(), 'dependencies': [Path(p) for p in
            case.get('dependencyPaths', []) + mounts.get(case['repo'], [])]}
    return spec, private


def confinement(spec: Sandbox, private: Path, folder: Path) -> None:
    oracleFile = spec['oracle'] / 'manifest.json'
    command = f'''test ! -w '{spec['repo']}'
test ! -w '{spec['repo']}/.git/index'
test ! -w '{oracleFile}'
test ! -e '{spec['oracle']}/base'
test ! -e '{spec['oracle']}/history'
test ! -e /tmp/codingSessionV4/research/typescript/reserve
test ! -e /tmp/codingSessionV4/profiles/reuseAblation.md
test ! -e /home/leon/.pi/agent/auth.json
for name in AGENTS.md CLAUDE.md; do
 if [ -e "$name" ]; then test -r "$name"; printf 'readable instructions: %s\\n' "$name"; fi
done
! touch '{oracleFile}'
printf scratch > '{spec['oracle']}/scratchProof'
rm '{spec['oracle']}/scratchProof'
git --no-optional-locks status --short
printf 'Source and Git readonly; frozen files immutable; oracle scratch writable\\n'
'''
    record = shell(spec, 'confinement', command, private, 30)
    publishExecution(record, 'confinement', folder, [])
    assert record['exit'] == 0, 'Confinement preflight failed; retained output'


def preflight(case: Case, manifest: Path) -> tuple[Sandbox, Path]:
    folder = evidence / next((arg[2:] for arg in sys.argv if arg.startswith('--preflight')), 'preflight') / case['id']
    folder.mkdir(parents=True, exist_ok=False)
    spec, private = specFor(case, manifest, folder)
    confinement(spec, private, folder)
    for index, command in enumerate(case['setupCommands']):
        label = f'setup{index}'
        record = shell(spec, label, command.replace('{root}', str(spec['worktree'])), private, 120)
        publishExecution(record, label, folder, [])
        assert record['exit'] == 0, f'{case["id"]} {label} failed'
    exits: dict[str, int] = {}
    for label, key in [('acceptance', 'checkCommand'), ('native', 'nativeCommand')]:
        command = case['checkCommand'] if key == 'checkCommand' else case['nativeCommand']
        record = shell(spec, label, command.replace('{root}', str(spec['worktree'])), private, 120)
        publishExecution(record, label, folder, [])
        exits[label] = record['exit']
    assert exits['acceptance'] != 0 and exits['acceptance'] != 124, exits
    assert exits['native'] == 0, exits
    (folder / 'result.json').write_text(json.dumps({'case': case['id'], 'exits': exits,
        'implementationLaunches': 0, 'behavioralFailureReviewRequired': True}, indent=2) + '\n')
    log(f'Preflight {case["id"]}: acceptance={exits["acceptance"]}, native={exits["native"]}')
    return spec, private


def probe(spec: Sandbox, private: Path) -> bool:
    folder = evidence / 'providerProbe'
    folder.mkdir(exist_ok=False)
    spec['auth'].chmod(0o600)  # Replace only this synthetic preflight placeholder.
    auth, secrets = prepareAuth(Path.home() / '.pi/agent/auth.json', private)
    spec['auth'] = auth
    stage = spec['runtime'] / 'providerProbe'
    stage.mkdir()
    endpoint = private / 'p.sock'
    arguments = agentArgs(spec['pi'], spec['profile'])
    index = arguments.index('--tools')
    arguments[index:index + 2] = ['--no-tools']
    argv = sandbox(spec, stage, True, endpoint) + [sys.executable,
        str(root / 'providerProxy.py'), str(proxyPath), *arguments, '--', 'Reply READY']
    env = environment(stage, spec['config'])
    (folder / 'invocation.json').write_text(json.dumps({'argv': argv,
        'cwd': str(spec['worktree']), 'environment': env, 'kind': 'harness provider probe',
        'authMount': 'selected-provider private read-only copy; excluded from publication',
        'implementationLaunches': 0}, indent=2) + '\n')
    server = startProxy(endpoint)
    try:
        record = execute(argv, spec['worktree'], env, private, 'providerProbe', 120)
    finally:
        server.shutdown()
        server.server_close()
    report = audit(Path(record['stdout']), folder, spec['profileSnapshot'].read_bytes(), secrets)
    # Do not archive raw auth or provider JSONL. Only allowlisted audit and scrubbed stderr.
    from auditTrial import scrub
    (folder / 'stderr.txt').write_text(scrub(Path(record['stderr']).read_text(), secrets))
    summary = (folder / 'finalSummary.txt').read_text().strip()
    passed = (record['exit'] == 0 and summary == 'READY' and report['toolStarts'] == 0
              and report['settled'] and not report['aborted']
              and report['finalStopReason'] == 'stop' and not report['finalError']
              and report['observedModels'] == ['openai-codex/gpt-6.1-sol']
              and report['observedThinking'] == ['high'])
    (folder / 'result.json').write_text(json.dumps({'passed': passed, 'exit': record['exit'],
        'seconds': record['seconds'], 'timedOut': record['timedOut'],
        'implementationLaunches': 0, 'authMount': 'read-only private copy'}, indent=2) + '\n')
    log(f'Provider no-task probe passed={passed}, exit={record["exit"]}')
    return passed


def main() -> None:
    evidence.mkdir(parents=True, exist_ok=True)
    log('Started tuning-only ablation compatibility preflight; no model implementations')
    before = hashes()
    frozen = evidence / 'frozenHashes.json'
    if frozen.exists():
        assert json.loads(frozen.read_text()) == before
    else:
        frozen.write_text(json.dumps(before, indent=2) + '\n')
    original = (root / 'profiles/v3.md').read_text()
    ablation = (root / 'profiles/reuseAblation.md').read_text()
    sentence = ' Share reusable results at their common lifetime.'
    assert original.count(sentence) == 1 and original.replace(sentence, '') == ablation
    specs: list[tuple[Sandbox, Path]] = []
    for manifest in manifests:
        data: Manifest = json.loads(manifest.read_text())
        assert len(data['cases']) == 1
        specs.append(preflight(data['cases'][0], manifest))
    assert hashes() == before, 'Frozen tuning file changed'
    (evidence / 'preflightComplete.json').write_text(json.dumps({'passed': True,
        'frozenHashesUnchanged': True, 'implementationLaunches': 0}, indent=2) + '\n')
    # Explicit separate mode keeps behavioral-failure inspection before provider contact.
    if '--probe' in sys.argv:
        sys.exit(0 if probe(*specs[0]) else 1)


if __name__ == '__main__':
    main()
