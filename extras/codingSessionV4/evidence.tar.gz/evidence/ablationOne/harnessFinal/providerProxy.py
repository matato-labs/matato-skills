"""V4 provider-only CONNECT relay. No HTTP bodies, headers, or credentials logged."""
import argparse
import ipaddress
import os
from pathlib import Path
import select
import socket
import socketserver
import subprocess
import sys
import threading


allowedHosts = {'chatgpt.com', 'api.openai.com', 'auth.openai.com'}


def relay(left: socket.socket, right: socket.socket) -> None:
    while True:
        ready, writable, errors = select.select([left, right], [], [left, right], 60)
        if errors or not ready:
            return
        for source in ready:
            data = source.recv(65536)
            if not data:
                return
            (right if source is left else left).sendall(data)


class ProviderHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        client: socket.socket = self.request
        client.settimeout(30)
        header = bytearray()
        while not header.endswith(b'\r\n\r\n') and len(header) < 16384:
            chunk = client.recv(1)
            if not chunk:
                return
            header.extend(chunk)
        first = bytes(header).split(b'\r\n', 1)[0].decode('ascii', errors='replace')
        fields = first.split()
        if len(fields) != 3 or fields[0] != 'CONNECT':
            client.sendall(b'HTTP/1.1 403 Forbidden\r\n\r\n')
            return
        host, separator, port = fields[1].rpartition(':')
        if host not in allowedHosts or port != '443':
            client.sendall(b'HTTP/1.1 403 Forbidden\r\n\r\n')
            return
        try:
            targets = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
            target = next(address for address in targets
                          if ipaddress.ip_address(address[4][0]).is_global)
            with socket.socket(target[0], target[1], target[2]) as upstream:
                upstream.settimeout(30)
                upstream.connect(target[4])
                client.sendall(b'HTTP/1.1 200 Connection Established\r\n\r\n')
                client.settimeout(None)
                upstream.settimeout(None)
                relay(client, upstream)
        except (OSError, StopIteration):
            return


class ProviderServer(socketserver.ThreadingUnixStreamServer):
    daemon_threads = True


class BridgeHandler(socketserver.BaseRequestHandler):
    endpoint = ''

    def handle(self) -> None:
        client: socket.socket = self.request
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as upstream:
                upstream.connect(self.endpoint)
                relay(client, upstream)
        except OSError:
            return


class BridgeServer(socketserver.ThreadingTCPServer):
    daemon_threads = True


def startProxy(path: Path) -> ProviderServer:
    server = ProviderServer(str(path), ProviderHandler)
    os.chmod(path, 0o600)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def inside(endpoint: str, command: list[str]) -> int:
    BridgeHandler.endpoint = endpoint
    with BridgeServer(('127.0.0.1', 0), BridgeHandler) as server:
        threading.Thread(target=server.serve_forever, daemon=True).start()
        proxy = f'http://127.0.0.1:{server.server_address[1]}'
        env = dict(os.environ, HTTPS_PROXY=proxy, HTTP_PROXY=proxy, ALL_PROXY=proxy,
                   https_proxy=proxy, http_proxy=proxy, NO_PROXY='', no_proxy='',
                   NODE_USE_ENV_PROXY='1')
        return subprocess.call(command, env=env, stdin=subprocess.DEVNULL)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('endpoint')
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    sys.exit(inside(args.endpoint, args.command))


if __name__ == '__main__':
    main()
