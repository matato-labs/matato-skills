# Coding-session V3: TypeScript backend research

## Selection and pin

Both cases use `/home/leon/workspace/projects/matato` at current HEAD `4f2b75f73087b5f2c60995629c591dc91a591567`. Matato was feasible with Bun 1.3.11 and its already-installed dependencies; agent-habitat was not needed. The tuning case is `memoryReferenceResolution`; `sessionTreeConfinement` is the reserve validation case. These are phase labels, not a performance claim.

Read Matato's root `AGENTS.md`; no nested source instructions were found. Its Bun, small-function, guard-clause, precise-type, no `any`/`unknown`, no unrelated refactoring, and no README-change conventions informed the briefs. No competitor skills/results were inspected. Neither task concerns CLI flag values, a pre-script environment mutex, or schedule timezones. No frontend/browser work, production patch, dependency installation, or solution implementation was performed.

Atlas discovery returned no registered projects (`atlas projects` returned `[]`), so all findings below use directly inspected current source, not graph-index claims.

## Existing features and bounded change surface

```mermaid
flowchart LR
  A["Agent memory tool"] --> B["createMemoryBlock"]
  B --> C["Existing storage transaction"]
  C --> D["Room/topic/item stores"]
  D --> E["Drizzle + local SQLite"]
  F["Chat session deletion route"] --> G["deleteManagedSessionTree"]
  G --> H["JSONL child reference reader"]
  H --> G
  G --> I["Node filesystem removal"]
```

The memory tool delegates its already-typed parameters directly to `createMemoryBlock` (`src/agent/matatoAgentTools.ts:148–185`). That operation already creates persisted rooms, topics, items and links inside `withStorageTransaction` (`src/storage/memoryBlock.ts:223`; `src/storage/database.ts:38–60`). `resolveRoomIds` maps absent names to zero and filters them out; `resolveItemTopicIds` does the same and correctly gives explicit IDs precedence (`memoryBlock.ts:88–106`). This produces a natural partial-connectivity defect, not a new API. SQLite foreign keys catch nonzero missing numeric IDs, but their generic errors omit the requested reference. Existing `Map`, `Set`, array operations, exact-name lookups, and store helpers already supply the integration points. Keywords are JSON-encoded/decoded by the stores; link stores enforce pair uniqueness. These paths exercise installed `drizzle-orm` 0.45.2, Bun's `bun:sqlite`, production migrations, and JavaScript collections/JSON.

Primary expected tuning edit: `src/storage/memoryBlock.ts`, plus maintained memory regressions. The room/topic/item stores, transaction helper, schema, and agent tool listed in the manifest are reuse/caller context, not a request to rewrite them. Existing read/unlink behavior is observed through `findMemoryRooms`, `findMemoryTopicsById`, and `unlinkMemoryItemTopic` (`memoryBlock.ts:175–220`). All five memory tables are defined at `src/storage/schema.ts:366–433`.

Managed session cleanup is already called by the backend chat deletion route (`src/api/routes/chatRoutes.ts:79`). Its existing JSONL reader follows custom `matatoSubAgent` references, ignoring malformed JSON (`src/agent/matatoAgentSessions.ts:150–170`). The current eligibility check accepts any lexical descendant of the broader agent directory, and recursion tracks lexical paths before calling `rm` (`matatoAgentSessions.ts:172–188`). This is a concrete deletion-confinement defect: agent settings are eligible, and directory symlinks can expose outside targets. The existing session root comes from `getMatatoAgentDir` and `resolveGuiChatSessionDirectory` (`src/agent/matatoAgentPaths.ts:4`; `matatoAgentSessions.ts:115`). Node filesystem/path builtins and the installed `@earendil-works/pi-coding-agent` 0.84.4 `SessionManager` supply the exercised behavior. One oracle test creates and persists a real manager's session header; no agent/model is started.

Primary expected validation edits: `src/agent/matatoAgentSessions.ts` and its maintained regression test. Path helpers and the chat caller are context. No route, session-creation, plan/research directory-deletion, or timezone changes are necessary.

## Frozen acceptance and independent oracles

Each phase directory contains `brief.md`, `manifest.json`, executable `oracle`, TypeScript `behavior.ts`, executable `native`, and baseline logs. The combined `manifest.json` contains exactly the two cases. Its `brief` values are the complete, byte-identical contents of the corresponding brief files, not alternate prompts. `freeze.json` records SHA-256 hashes of the briefs, manifests, oracle launchers, behavioral test templates, and native launchers. Use the same frozen brief for every candidate attempt.

The briefs state observable contracts, not algorithms or code layouts. Oracles assert behavior and state, never implementation structure, function length, source text, or LOC. Maintained candidate regressions are requested in the briefs; the oracle does not inspect test-file contents.

| Case | Acceptance exercised |
| --- | --- |
| Tuning, 12 tests | Exact/case-sensitive persisted and same-block name lookup; unresolved room/topic names; missing numeric room/topic IDs with identifying errors; zero is supplied, not omitted; explicit topic ID precedence without name fallback; mixed ID/name inputs and pair deduplication; late rejection; full five-table before/after rollback snapshots; recovery after rejection; empty creation/link lists; preserved records, metadata, content and Unicode keywords; public find/unlink behavior. |
| Validation, 10 tests | Both lexical and canonical confinement; direct non-session agent files; unsafe child references; outward file/directory symlinks and preserved targets/links; unsafe-file references cannot dispatch safe-child deletion; outside lexical alias into an inside target; prefix lookalikes and dot-dot paths; root/directory no-ops; malformed/irrelevant JSONL entries; shared/repeated/cyclic references; missing children; repeated cleanup; eligible parent/child removal and untouched siblings; a real persisted session header. |

The executable accepts the candidate worktree path as its **sole argument**:

```sh
/tmp/codingSessionV3/research/typescript/tuning/oracle /absolute/candidate/worktree
/tmp/codingSessionV3/research/typescript/validation/oracle /absolute/candidate/worktree
```

Python's standard library creates a temporary runner under its own phase directory and substitutes only static import specifiers in `behavior.ts`. Bun then imports the candidate's actual production modules by absolute path and executes the independent TypeScript assertions. No candidate source or candidate tests are copied or mocked. The templates use directly inferred production types, including `CreateMemoryBlockInput`; neither template introduces `any`/`unknown` or shape-guessing casts. Both generated test programs also passed the repository's strict TypeScript configuration (`logs/oracleTypecheck.log`; no diagnostics).

The child environment is rebuilt from PATH plus private HOME/TMPDIR/storage paths, CI, and a telemetry opt-out. No inherited credentials are passed. Every SQLite database, session, sentinel, symlink and runner is created inside an agent-owned temporary directory under this research tree and cleaned afterward. Tests run against local files only. Each oracle has a 45-second process cap and 5-second per-test timeout; neither depends on external network/services/credentials. The stable-fixture filesystem tests do not claim concurrent symlink-race protection.

## Safe setup and native checks

Use a fresh, caller-owned detached worktree at the pinned SHA, not the user's checkout. The manifest's `setupCommands` verify HEAD and create a `node_modules` symlink only when no entry exists. They reference `/home/leon/workspace/projects/matato/node_modules`; no install, upgrade, chmod, lockfile update, or dependency write command is used. Existing entries are not replaced. This is local-machine feasibility, not a claim that dependencies are bundled with the research artifacts.

`checkCommand` invokes the independent oracle. `nativeCommand` invokes the phase's executable `native` with `{root}`. It runs existing affected Bun tests, full project `tsc --noEmit`, and scoped ESLint with already-installed binaries (no `bunx` downloads). The native launcher also isolates HOME/TMPDIR under this research tree and caps the combined native checks at 55 seconds. Existing native tests' migrations and bootstrap fixtures are local and temporary. These are established regression smoke checks, not a substitute for maintained new tests added by a candidate.

Tuning native tests are `src/agent/matatoAgentTools.test.ts` and `src/storage/database.test.ts` (18 passed). Validation native tests are `src/agent/matatoAgentSessions.test.ts` and `src/agent/matatoAgentPaths.test.ts` (13 passed). All native typecheck/lint commands exited zero on the base. The native launchers ran concurrently in separate fixture directories; even under this contention each completed in about 25 seconds, below the 60-second budget. Oracles completed in under one second on their final recorded runs.

## Negative-control evidence

An agent-owned detached worktree was created at `/tmp/codingSessionV3/research/typescript/negativeControl`, with the shared dependencies linked read-only by usage. No tracked production files were changed. Both independent oracles were run against this unmodified base, not a deliberately broken implementation. Logs are retained:

| Phase | Base oracle | Established native checks |
| --- | --- | --- |
| Tuning | `tuning/baseline.log`: exit 1; 4 pass, 8 assertion failures; 0.415s. Missing names/zero IDs are silently discarded, and nonzero missing IDs produce generic SQLite errors rather than reference-identifying errors. | `tuning/nativeBaseline.log`: exit 0; 18 tests pass; full typecheck and scoped lint pass; 24.917s. |
| Validation | `validation/baseline.log`: exit 1; 2 pass, 8 assertion failures; 0.516s. Protected files/escaping targets are deleted, an escaping file alias is removed, and directory input rejects instead of being ignored. | `validation/nativeBaseline.log`: exit 0; 13 tests pass; full typecheck and scoped lint pass; 24.867s. |

These failures are explicit assertion failures after successful imports and fixture setup, not missing dependencies, unavailable services, or a refused setup. The positive base passes preserve ID precedence, supported empty inputs, mixed-reference deduplication and read/unlink behavior for tuning, and cycle/shared-child cleanup plus real-session deletion for validation. No solution or positive repaired implementation was attempted, consistent with research-only scope.

`evidence.json` summarizes exit codes, counts, durations and cleanup. `logs/worktreeSetup.log` and `logs/worktreeCleanup.log` retain creation/pin/removal evidence. Only the agent-owned negative-control worktree was removed, after checking tracked/staged diffs were empty and unlinking its dependency symlink. The original checkout remained clean at the pinned HEAD. Other worktrees, user dependencies, parent skills and READMEs were not altered.
