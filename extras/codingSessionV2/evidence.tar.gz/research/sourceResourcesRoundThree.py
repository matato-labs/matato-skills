#!/usr/bin/env python3
"""Review-only resource/status observations using real candidate imports and local files."""
import gc
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import tracemalloc
from unittest.mock import patch

repo = Path(sys.argv[1]).resolve()
sys.path.insert(0,str(repo/'atlas/src'))
from atlas.domain.navigation import GraphSnapshot
from atlas.services.navigation import NavigationService
from atlas.services import navigation_source as source
print('MODULE',source.__file__)

class Reader:
    def __init__(self,root):
        self.snapshot = GraphSnapshot('repo','revision',None,str(root))
        self.nodes,self.rows,self.calls = {},{},[]
    def node(self,key): return self.nodes[key]
    def file(self,path):
        self.calls.append(path)
        return self.rows.get(path,[])
    def diagnostics(self,paths,limit): return []

def node(key,path,level='file',start=None,end=None):
    return dict(stableKey=key,path=path,level=level,startLine=start,endLine=end)

def output(label,**values): print(json.dumps(dict(workload=label,**values)),flush=True)

def measure(label,service,keys):
    gc.collect()
    gc.disable()
    tracemalloc.start()
    try:
        result=service.sources(keys,1,None)
        current,peak=tracemalloc.get_traced_memory()
    finally:
        tracemalloc.stop()
        gc.enable()
    assert len(result['sources']) == len(keys)
    output(label,rows=len(keys),current_bytes=current,peak_bytes=peak,statuses=sorted({r['status'] for r in result['sources']}))

with tempfile.TemporaryDirectory() as d:
    root=Path(d)
    reader=Reader(root)
    service=NavigationService(reader)
    def indexed(key,data):
        (root/key).write_bytes(data)
        reader.rows[key]=[{'sha256':hashlib.sha256(data).hexdigest()}]
        reader.nodes[key]=node(key,key)
    for key,data in [('valid',b'one\ntwo\n'),('encoding',b'\xff\n')]:
        indexed(key,data)
        for size in [1,10,100]:
            reader.calls.clear()
            with patch.object(source,'local_bytes',wraps=source.local_bytes) as reads, patch.object(source.hashlib,'sha256',wraps=hashlib.sha256) as hashes, patch.object(source,'source_lines',wraps=source.source_lines) as decodes:
                result=service.sources([key]*size,1,None)
            expected='ok' if key=='valid' else 'unsupported_encoding'
            assert all(row['status']==expected for row in result['sources'])
            assert (len(reader.calls),reads.call_count,hashes.call_count)==(1,1,1)
            output('counts-'+key,rows=size,verification=len(reader.calls),reads=reads.call_count,hashes=hashes.call_count,decodes=decodes.call_count)
    # Precedence probes compare public single and batch behavior without changing frozen checks.
    indexed('badSpan',b'\xff')
    reader.nodes['badSpan']=node('badSpan','badSpan','symbol')
    indexed('changed',b'\xff')
    reader.rows['changed']=[{'sha256':'different'}]
    reader.nodes['changed']=node('changed','changed','symbol')
    indexed('span',b'one\ntwo\n')
    reader.nodes['span']=node('span','span','symbol')
    reader.nodes['unsafe']=node('unsafe','../outside','symbol')
    reader.rows['../outside']=[{'sha256':'indexed'}]
    reader.nodes['unverified']=node('unverified','/unsafe','symbol')
    reader.nodes['external']=node('external','encoding','external')
    reader.nodes['pathless']=node('pathless',None,'symbol')
    expected={'badSpan':'unsupported_encoding','changed':'changed','span':'span_unavailable','unsafe':'unsafe','unverified':'unverified','external':'unavailable','pathless':'unavailable'}
    for key,status in expected.items():
        single=service.source(key,1,None)['source']
        batch=service.sources([key,key],1,None)['sources']
        assert single['status']==status
        assert batch[0]==batch[1]=={'stableKey':key,**single}
        output('precedence',key=key,status=status)
    # Distinct 64-character lines avoid CPython's single-character string sharing.
    data=b''.join(f'{i:016x}'.encode()+b'x'*48+b'\n' for i in range(16384))
    for i in range(8): indexed('large'+str(i),data)
    del data
    for size in [1,4,8]: measure('distinct-1mib-64char-lines',service,['large'+str(i) for i in range(size)])
    for size in [10,100]: measure('repeated-1mib-64char-lines',service,['large0']*size)
    measure('ineligible',service,['external']*20000)
    # Count large-file transformations separately, without distorting allocation measurements.
    for keys in [['large0']*100, ['large'+str(i) for i in range(8)]]:
        reader.calls.clear()
        decode_bytes=[]
        original=source.source_lines
        def decode(data):
            decode_bytes.append(len(data))
            return original(data)
        with patch.object(source,'source_lines',side_effect=decode) as decodes:
            service.sources(keys,1,None)
        output('large-transform-counts',rows=len(keys),distinct_paths=len(set(keys)),verification=len(reader.calls),decodes=decodes.call_count,input_bytes_to_decode=sum(decode_bytes))
    # Output line lists must remain caller-owned even when backing decoded lines are shared.
    rows=service.sources(['large0','large0'],1,None)['sources']
    rows[0]['lines'].append('mutated')
    assert len(rows[1]['lines'])==1
    # A later call must repeat decoding, including failed decoding.
    reader.calls.clear()
    with patch.object(source,'source_lines',wraps=source.source_lines) as decodes:
        service.sources(['encoding']*10,1,None)
        service.sources(['encoding']*10,1,None)
    output('encoding-two-calls',verification=len(reader.calls),decodes=decodes.call_count)
    # Cache scopes do not survive return. Current above keeps only small output excerpts.
    print('OWNERSHIP_OK')
