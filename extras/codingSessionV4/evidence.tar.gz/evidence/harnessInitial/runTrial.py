"""Run frozen V4 cases once: python runTrial.py manifestPath arm draw.

No automatic retries, repairs, resampling, cleanup, credential publication, or installs.
Optional --setup-only consumes that run identity permanently without invoking a model.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from typing import Iterator, NotRequired, TypedDict
import uuid

from auditTrial import Audit, audit, publishExecution, scrub
from measureTrial import FileMeasure, capture, digest, git
from providerProxy import startProxy
from sandboxTrial import Execution, Sandbox, currentProfile, environment, execute, proxyPath, root, sandbox, shell


model = 'openai-codex/gpt-6.1-sol'


class Case(TypedDict):
    id: str
    phase: str
    repo: str
    base: str
    brief: str
    setupCommands: list[str]
    checkCommand: str
    nativeCommand: str
    sourcePaths: list[str]
    dependencyPaths: NotRequired[list[str]]


class Manifest(TypedDict):
    cases: list[Case]


class Credential(TypedDict):
    type: str
    access: NotRequired[str]
    refresh: NotRequired[str]
    key: NotRequired[str]
    expires: NotRequired[int]
    accountId: NotRequired[str]


class Ledger(TypedDict):
    reserved: int
    runs: list[str]


class Invocation(TypedDict):
    argv: list[str]
    cwd: str
    environment: dict[str, str]
    network: str
    authMount: str
    profileAlias: str


class Result(TypedDict):
    case: str
    phase: str
    arm: str
    draw: str
    status: str
    base: str
    requestedBase: str
    repository: str
    worktree: str
    manifestPath: str
    manifestSha256: str
    profilePath: str
    profileSha256: str
    profileBytes: int
    model: str
    thinking: str
    piVersion: str
    startedAt: str
    seconds: float
    setupExit: int | None
    agentExit: int | None
    acceptanceExit: int | None
    nativeExit: int | None
    agentSeconds: float | None
    publicationReady: bool
    error: NotRequired[str]
    profileAudit: NotRequired[Audit]
    patchSha256: NotRequired[str]
    filesPath: NotRequired[str]
    files: NotRequired[list[FileMeasure]]
    excludedDependencyLinks: NotRequired[list[str]]


def save(path: Path, value: Result | Ledger | Invocation) -> None:
    path.write_text(json.dumps(value, indent=2) + '\n')


def identifier(value: str) -> str:
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*', value) or value in {'.', '..'}:
        raise ValueError('Run identifiers must be single safe path components')
    return value


@contextmanager
def slot() -> Iterator[None]:
    control = root / 'control'
    control.mkdir(exist_ok=True)
    while True:
        for number in range(6):
            handle = (control / f'slot{number}.lock').open('a')
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                handle.close()
                continue
            try:
                yield
            finally:
                handle.close()
            return
        time.sleep(1)


def reserve(identity: str) -> None:
    with (root / 'control' / 'budget.lock').open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        path = root / 'control' / 'budget.json'
        ledger: Ledger = json.loads(path.read_text()) if path.exists() else {'reserved': 0, 'runs': []}
        if ledger['reserved'] >= 52:
            raise RuntimeError('V4 budget exhausted: 52 run reservations')
        if identity in ledger['runs']:
            raise RuntimeError('Run already reserved; no repair or resampling permitted')
        ledger['reserved'] += 1
        ledger['runs'].append(identity)
        temporary = path.with_suffix('.pending')
        save(temporary, ledger)
        temporary.replace(path)


def prepareAuth(source: Path, private: Path) -> tuple[Path, list[str]]:
    credentials: dict[str, Credential] = json.loads(source.read_text())
    credential = credentials['openai-codex']
    # Copy only the selected provider, never the user's settings, history, MCP, or models.
    auth = private / 'auth.json'
    auth.write_text(json.dumps({'openai-codex': credential}))
    auth.chmod(0o400)
    secrets = [credential.get('access', ''), credential.get('refresh', ''), credential.get('key', '')]
    return auth, secrets


def promptFor(case: Case, oracle: str, native: str) -> str:
    return f'''Your FIRST tool call must be read with path {currentProfile}, reading the complete file. Follow that profile, which is also appended verbatim to your system prompt.
Implement this task in the current checkout:

{case['brief']}

Add maintained regressions using the repository's framework and run relevant checks.
Independent acceptance command: {oracle}
Existing focused native command: {native}
In these displayed commands, {{root}} denotes the current checkout's absolute path; the runner substitutes it for independent execution.
Setup and dependencies are already prepared. Do not install, modify shared dependencies, use live app services, or start persistent servers. Use offline/service-free checks; these commands are not blanket full-suite coverage.
Edit only the current owned checkout. Do not modify oracle files, profiles, source checkouts, shared dependencies, or README. Do not inspect rival arms/results, reserve tasks, research rationales, earlier trials, global skills/config/history, or parent conversations. Do not load skills, extensions, MCP, or external instructions. No commits, pushes, PRs, branch/worktree management, git add, or index writes. For diffs use git --no-optional-locks diff. Provider networking is available only through a restricted HTTPS proxy; no other network is allowed. Do not read or print credentials. Report changed files, checks actually run and blockers. Stop when complete.
'''


def agentArgs(pi: Path, profile: Path) -> list[str]:
    return [str(pi), '--print', '--mode', 'json', '--no-session', '--no-extensions',
            '--no-skills', '--no-prompt-templates', '--no-context-files', '--no-mcp',
            '--no-approve', '--offline', '--model', model, '--thinking', 'high',
            '--tools', 'read,bash,edit,write', '--append-system-prompt', str(profile)]


def runAgent(spec: Sandbox, prompt: str, private: Path, folder: Path,
             secrets: list[str]) -> tuple[Execution, Audit]:
    stage = spec['runtime'] / 'agent'
    stage.mkdir()
    env = environment(stage, spec['config'])
    endpoint = private / 'p.sock'
    server = startProxy(endpoint)
    argv = sandbox(spec, stage, True, endpoint) + [sys.executable, str(root / 'providerProxy.py'),
            str(proxyPath), *agentArgs(spec['pi'], spec['profile']), '--', prompt]
    invocation: Invocation = {'argv': argv, 'cwd': str(spec['worktree']), 'environment': env,
                  'network': 'unshared; CONNECT 443 only to chatgpt.com/api.openai.com/auth.openai.com',
                  'authMount': 'selected-provider private copy mounted read-only; never evidence',
                  'profileAlias': str(currentProfile)}
    save(folder / 'invocation.json', invocation)
    try:
        record = execute(argv, spec['worktree'], env, private, 'agent', 900)
    finally:
        server.shutdown()
        server.server_close()
    # JSONL is consumed record-by-record; never copy the raw stream to evidence.
    report = audit(Path(record['stdout']), folder, spec['profileSnapshot'].read_bytes(), secrets)
    (folder / 'agent.stderr').write_text(scrub(Path(record['stderr']).read_text(errors='replace'), secrets))
    (folder / 'agent.json').write_text(json.dumps(record, indent=2) + '\n')
    return record, report


def makeWorktree(case: Case, worktree: Path, private: Path, folder: Path) -> tuple[str, Path]:
    base = os.fsdecode(git(Path(case['repo']), ['rev-parse', f"{case['base']}^{{commit}}"])).strip()
    worktree.parent.mkdir(parents=True, exist_ok=True)
    command = ['git', '-c', 'core.hooksPath=/dev/null', '-C', case['repo'],
               'worktree', 'add', '--detach', str(worktree), base]
    record = execute(command, root, environment(private / 'gitRuntime'), private, 'worktree', 120)
    publishExecution(record, 'worktree', folder, [])
    if record['exit']:
        raise RuntimeError(f"Owned worktree creation failed: exit {record['exit']}")
    common = Path(os.fsdecode(git(worktree, ['rev-parse', '--git-common-dir'])).strip())
    return base, (worktree / common).resolve() if not common.is_absolute() else common.resolve()


def trial(case: Case, manifest: Path, arm: str, draw: str, authSource: Path,
          setupOnly: bool) -> bool:
    caseId = identifier(case['id'])
    folder = root / 'runs' / draw / arm / caseId
    worktree = root / 'worktrees' / draw / arm / caseId
    folder.mkdir(parents=True, exist_ok=False)  # Any existing output is permanently immutable.
    os.chmod(folder, 0o700)
    private = root / 'private' / uuid.uuid4().hex[:16]
    private.mkdir(parents=True, mode=0o700)
    (root / 'private').chmod(0o700)
    profile = root / 'profiles' / f'{arm}.md'
    started = time.monotonic()
    result: Result = {'case': caseId, 'phase': case['phase'], 'arm': arm, 'draw': draw,
        'status': 'failed', 'base': '', 'requestedBase': case['base'], 'repository': case['repo'],
        'worktree': str(worktree), 'manifestPath': str(manifest),
        'manifestSha256': digest(manifest.read_bytes()), 'profilePath': str(profile),
        'profileSha256': '', 'profileBytes': 0, 'model': model, 'thinking': 'high',
        'piVersion': '', 'startedAt': datetime.now(timezone.utc).isoformat(), 'seconds': 0,
        'setupExit': None, 'agentExit': None, 'acceptanceExit': None, 'nativeExit': None,
        'agentSeconds': None, 'publicationReady': False}
    secrets: list[str] = []
    try:
        reserve(f'{draw}/{arm}/{caseId}')
        profileBytes = profile.read_bytes()
        result['profileSha256'], result['profileBytes'] = digest(profileBytes), len(profileBytes)
        profileSnapshot = folder / 'currentProfile.md'
        profileSnapshot.write_bytes(profileBytes)
        piFound = shutil.which('pi')
        if piFound is None:
            raise RuntimeError('Pi is not installed')
        pi = Path(piFound).resolve()
        result['piVersion'] = subprocess.check_output([str(pi), '--version'], text=True).strip()
        if result['piVersion'] != '1.1.0':
            raise RuntimeError('Experiment requires installed Pi 1.1.0')
        base, common = makeWorktree(case, worktree, private, folder)
        result['base'] = base
        config = private / 'config'
        config.mkdir()
        auth, secrets = prepareAuth(authSource, private)
        runtime = private / 'runtime'
        runtime.mkdir()
        spec: Sandbox = {'worktree': worktree, 'repo': Path(case['repo']).resolve(),
            'common': common, 'oracle': manifest.parent, 'runtime': runtime,
            'profile': profile, 'profileSnapshot': profileSnapshot,
            'config': config, 'auth': auth, 'pi': pi,
            'dependencies': [Path(path).resolve() for path in case.get('dependencyPaths', [])]}
        for index, command in enumerate(case['setupCommands']):
            label = f'setup{index}'
            record = shell(spec, label, command.replace('{root}', str(worktree)), private, 120)
            publishExecution(record, label, folder, secrets)
            result['setupExit'] = record['exit']
            if record['exit']:
                raise RuntimeError(f'{label} failed, preserved output; no implementation launched')
        result['setupExit'] = 0
        oracle = case['checkCommand'].replace('{root}', str(worktree))
        native = case['nativeCommand'].replace('{root}', str(worktree))
        # Keep task/instruction bytes identical across arms; only the system profile varies.
        prompt = promptFor(case, case['checkCommand'], case['nativeCommand'])
        (folder / 'prompt.txt').write_text(prompt)
        if setupOnly:
            result['status'] = 'setupOnly'
            return True
        record, report = runAgent(spec, prompt, private, folder, secrets)
        result['agentExit'], result['agentSeconds'] = record['exit'], record['seconds']
        result['profileAudit'] = report
        # Both checks run even if Pi fails/times out; each has independent storage and budget.
        for label, command in [('acceptance', oracle), ('native', native)]:
            check = shell(spec, label, command, private, 120)
            publishExecution(check, label, folder, secrets)
            if label == 'acceptance':
                result['acceptanceExit'] = check['exit']
            else:
                result['nativeExit'] = check['exit']
        valid = (record['exit'] == 0 and report['firstToolIsProfileRead'] and
                 report['profileReadSucceeded'] and report['profileContentsObserved'] and
                 report['malformedRecords'] == 0 and report['observedModels'] == [model] and
                 report['observedThinking'] == ['high'] and report['settled'] and
                 not report['aborted'] and report['finalStopReason'] == 'stop')
        result['status'] = 'completed' if valid else 'invalidAgentRun'
        return valid
    except Exception as error:
        result['error'] = scrub(f'{type(error).__name__}: {error}', secrets)
        return False
    finally:
        if result['base'] and worktree.exists():
            try:
                measurement = capture(worktree, folder, private, result['base'], case['sourcePaths'])
                result['patchSha256'] = measurement['patchSha256']
                result['filesPath'] = str(folder / 'fileMetrics.json')
                result['files'] = measurement['files']
                result['excludedDependencyLinks'] = measurement['excludedDependencyLinks']
            except Exception as error:
                result['error'] = result.get('error', '') + scrub(f'; capture failed: {error}', secrets)
                result['status'] = 'captureFailed'
        result['seconds'] = round(time.monotonic() - started, 3)
        save(folder / 'result.json', result)
        print(json.dumps(result), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifestPath', type=Path)
    parser.add_argument('arm', type=identifier)
    parser.add_argument('draw', type=identifier)
    parser.add_argument('--setup-only', action='store_true', help='permanently reserve identity; setup only, never Pi')
    parser.add_argument('--auth-source', type=Path, default=Path.home() / '.pi/agent/auth.json')
    args = parser.parse_args()
    manifest = args.manifestPath.resolve()
    data: Manifest = json.loads(manifest.read_text())
    success = True
    for case in data['cases']:
        with slot():
            success = trial(case, manifest, args.arm, args.draw, args.auth_source, args.setup_only) and success
    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()
