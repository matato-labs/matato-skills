#!/usr/bin/python3
"""Inert command doubles; only executed in the isolated installer fixture."""
import json
import os
from pathlib import Path
import sys

name = Path(sys.argv[0]).name
args = sys.argv[1:]
with Path(os.environ["CASE_EVENTS"]).open("a") as stream:
    stream.write(json.dumps({"command": name, "args": args}) + "\n")


def curl() -> int:
    url = next((arg for arg in args if arg.startswith("https://")), "")
    phase = "sdk" if "sdkman" in url else "devpod"
    fault = os.environ["CASE_FAULT"]
    if fault == f"{phase}Transport":
        return 7
    failed_http = fault == f"{phase}Http"
    fail_flag = any(arg in ("--fail", "--fail-with-body") or (
        arg.startswith("-") and not arg.startswith("--") and "f" in arg[1:]
    ) for arg in args)
    if failed_http and fail_flag:
        return 22
    body = ": # inert HTTP error document\n" if failed_http else "inert devpod payload\n"
    if phase == "sdk" and not failed_http:
        body = '"$CASE_BIN/sdkApplied"\n'
    output = None
    for index, arg in enumerate(args):
        if arg == "--output":
            output = args[index + 1]
        if arg.startswith("--output="):
            output = arg.split("=", 1)[1]
        if arg.startswith("-") and not arg.startswith("--") and "o" in arg[1:]:
            suffix = arg.split("o", 1)[1]
            output = suffix or args[index + 1]
    if output:
        Path(output).write_text(body)
    else:
        sys.stdout.write(body)
    return 0


def main() -> int:
    if name == "uname":
        print("Darwin" if os.environ["CASE_OS"] == "darwin" else "Linux")
    if name == "curl":
        return curl()
    if name == "sudo" and args and args[0] == "install":
        if os.environ["CASE_FAULT"] == "devpodInstall":
            return 19
        if not Path(args[-2]).is_file():
            return 1
    if name == "rm":
        for arg in args:
            if not arg.startswith("-"):
                Path(arg).unlink(missing_ok=True)
    return 0


sys.exit(main())
