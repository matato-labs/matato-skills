#!/home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B
"""Behavioral oracle. Usage: ./oracle.py /absolute/atlas/worktree"""

from contextlib import closing, contextmanager
import json
import os
from pathlib import Path
import sqlite3
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch
import unittest

assert len(sys.argv) == 2, "expected one absolute worktree path"
root = Path(sys.argv.pop())
assert root.is_absolute() and (root / "atlas/src/atlas").is_dir(), root
sys.dont_write_bytecode = True
sys.path.insert(0, str(root / "atlas/src"))

import atlas
from atlas.bootstrap import migrate_database, navigation_service, repository_service
from atlas.cli.commands import main
from atlas.domain.repositories import RepositoryError
from atlas.persistence.database import create_engine
from atlas.persistence.repositories import repository_store
from click.testing import CliRunner
from sqlalchemy import text

assert Path(atlas.__file__).resolve().is_relative_to(root.resolve()), atlas.__file__


def graphArtifact(location: Path):
    return {"schemaVersion": 2,
            "repository": {"name": "Literal paths", "path": str(location),
                           "indexedAt": "2026-10-04T00:00:00+00:00"},
            "nodes": [{"stableKey": "repository", "parentStableKey": None,
                       "type": "repository", "kind": "repository", "level": "repository",
                       "name": "Literal paths", "path": None},
                      {"stableKey": "file:main.py", "parentStableKey": "repository",
                       "type": "file", "kind": "file", "level": "file", "language": "python",
                       "name": "main.py", "path": "main.py",
                       "properties": {"bytes": 9, "sha256": "a" * 64}}],
            "edges": [], "diagnostics": []}


class LiteralDatabasePaths(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = TemporaryDirectory(prefix="runtime", dir=Path(__file__).parent)
        self.location = Path(self.temporary.name)
        self.addCleanup(self.temporary.cleanup)

    @contextmanager
    def successful(self, label: str):
        try:
            yield
        except AssertionError:
            raise
        except Exception as error:
            self.fail(f"{label} must succeed for a literal filesystem path: {error!r}")

    def roundTrip(self, target: Path, argument: str | Path | None) -> None:
        migrate_database(argument)
        self.assertTrue(target.is_file(), f"migration must create exactly {target}")
        migrate_database(argument)
        with repository_service(argument) as service:
            registered = service.register({"name": "Literal project", "location": str(target.parent)})
            self.assertEqual([item.id for item in service.list()], [registered.id])
            with self.assertRaises(RepositoryError) as duplicate:
                service.register({"name": "LITERAL PROJECT", "location": "."})
            self.assertEqual(duplicate.exception.status, 409)
            self.assertEqual([item.id for item in service.list()], [registered.id], "session recovers after conflict")
        with repository_store(argument) as store:
            saved = store.save(registered.id, graphArtifact(target.parent))
        with repository_service(argument) as service:
            stored = service.get_architecture(registered.id)
            self.assertIsNotNone(stored)
            self.assertEqual(stored.graphRevision, saved.graphRevision)
            self.assertEqual(stored.stats.files, 1)
        with navigation_service(registered.id, path=argument) as service:
            found = service.find("main.py", 10)
        self.assertEqual([item["stableKey"] for item in found["nodes"]], ["file:main.py"])
        self.assertEqual(found["graphRevision"], saved.graphRevision)
        runner = CliRunner(env={"DATABASE_PATH": str(target)})
        listed = runner.invoke(main, ["projects"])
        self.assertEqual(listed.exit_code, 0, listed.output)
        self.assertEqual([item["id"] for item in json.loads(listed.stdout)], [registered.id])
        with closing(sqlite3.connect(target)) as connection:
            self.assertEqual(connection.execute("PRAGMA integrity_check").fetchall(), [("ok",)])
            self.assertEqual(connection.execute("PRAGMA foreign_key_check").fetchall(), [])
            self.assertEqual(connection.execute("SELECT count(*) FROM alembic_version").fetchone(), (1,))
            self.assertEqual(connection.execute("SELECT id FROM repositories").fetchall(), [(registered.id,)])
        self.assertOnlyDatabaseFiles(target.parent, target)

    def testPathMatrix(self) -> None:
        names = ["ordinary.sqlite", "sp ace École.sqlite", "hash#literal.sqlite",
                 "literal%3F%23.sqlite", "graph?literal.sqlite",
                 "graph?mode=ro&uri=true.sqlite", "dir?query/data#100% café.sqlite"]
        for index, name in enumerate(names):
            for asString in (False, True):
                with self.subTest(name=name, asString=asString), self.successful(name):
                    caseRoot = self.location / f"case{index}{asString}"
                    target = caseRoot / name
                    argument = str(target) if asString else target
                    self.roundTrip(target, argument)
                    self.assertOnlyDatabaseFiles(caseRoot, target)

    def assertOnlyDatabaseFiles(self, directory: Path, target: Path) -> None:
        actual = {path for path in directory.rglob("*") if path.is_file()}
        allowed = {target.with_name(target.name + ending) for ending in ("", "-wal", "-shm", "-journal")}
        self.assertIn(target, actual)
        self.assertLessEqual(actual, allowed, "no URL-truncated or percent-decoded sibling databases")

    def testEngineUsesLiteralFilename(self) -> None:
        target = self.location / "connection?timeout=0&uri=true.sqlite"
        with self.successful("direct engine"):
            engine = create_engine(target)
            try:
                with engine.begin() as connection:
                    opened = connection.execute(text("PRAGMA database_list")).fetchall()
                    self.assertEqual(Path(opened[0][2]), target.resolve())
                    self.assertEqual(connection.execute(text("PRAGMA foreign_keys")).scalar(), 1)
                    connection.execute(text("CREATE TABLE marker (value TEXT)"))
                    connection.execute(text("INSERT INTO marker VALUES ('literal')"))
            finally:
                engine.dispose()
            self.assertTrue(target.is_file())
            with closing(sqlite3.connect(target)) as connection:
                self.assertEqual(connection.execute("SELECT value FROM marker").fetchall(), [("literal",)])
            self.assertEqual({path.name for path in self.location.iterdir()}, {target.name})

    def testConfiguredDatabasePath(self) -> None:
        target = self.location / "env?database%23.sqlite"
        with patch.dict(os.environ, {"DATABASE_PATH": str(target)}), self.successful("DATABASE_PATH"):
            self.roundTrip(target, None)

    def testDefaultDataDirectory(self) -> None:
        dataHome = self.location / "data?home#100% École"
        target = dataHome / "atlas/atlas.sqlite"
        with patch.dict(os.environ, {"XDG_DATA_HOME": str(dataHome)}), self.successful("XDG_DATA_HOME"):
            with patch.dict(os.environ):
                os.environ.pop("DATABASE_PATH", None)
                self.roundTrip(target, None)
        self.assertOnlyDatabaseFiles(self.location, target)

    def testRelativePaths(self) -> None:
        original = Path.cwd()
        try:
            os.chdir(self.location)
            with self.successful("relative path"):
                self.roundTrip(self.location / "relative?name.sqlite", "relative?name.sqlite")
        finally:
            os.chdir(original)

    def testHomeExpandedPaths(self) -> None:
        home = self.location / "home"
        home.mkdir()
        with patch.dict(os.environ, {"HOME": str(home)}), self.successful("home expansion"):
            self.roundTrip(home / "home?name.sqlite", "~/home?name.sqlite")

    def testSimilarExistingFilesAreUntouched(self) -> None:
        target = self.location / "keep?literal.sqlite"
        sentinel = self.location / "keep"
        sentinel.write_bytes(b"not a database; must remain untouched\n")
        before = sentinel.read_bytes()
        with self.successful("migration beside prefix sentinel"):
            migrate_database(target)
            self.assertTrue(target.is_file(), "do not migrate a URL-truncated prefix")
            self.assertEqual(sentinel.read_bytes(), before)
            with repository_service(target) as service:
                self.assertEqual(service.list(), [])
            self.assertEqual(sentinel.read_bytes(), before)
            allowed = {sentinel.name, *(target.name + ending for ending in ("", "-wal", "-shm", "-journal"))}
            self.assertLessEqual({path.name for path in self.location.iterdir()}, allowed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
