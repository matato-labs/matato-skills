"""Review-only disposable copies; every child check uses harness sandbox functions."""
from pathlib import Path
import json
import shlex
import shutil
import sys

scripts = Path('/home/leon/workspace/projects/matato-pi/extras/codingSessionV5/scripts')
sys.path.insert(0, str(scripts))
from sandboxTrial import Sandbox, shell

root = Path(__file__).parent
inventory = json.loads((root/'inventory.json').read_text())
caseNames = {'ts': 'workspaceCheckoutRoots', 'py': 'navigationUnseenEdgeBudget', 'bash': 'installerDownloadFailures', 'hold': 'holdoutOne'}
caseDirs = {'ts': 'workspaceRoots', 'py': 'unseenEdges', 'bash': 'downloadFailures', 'hold': 'holdout'}
production = {'ts': 'src/workspaceRepos.ts', 'py': 'atlas/src/atlas/services/navigation_walk.py', 'bash': 'manual_deps', 'hold': 'worker/scheduler.ts'}
pi = Path('/home/leon/.local/share/mise/installs/pi/1.2.0/pi/pi')
python = '/home/leon/workspace/projects/atlas/atlas/.venv/bin/python'

def folder(label, case, variant):
    return root/'copies'/label/case/variant

def prepare():
    for row in inventory:
        run = Path(row['path'])
        case = next(k for k, v in caseNames.items() if v == run.name)
        for variant in ['candidate', 'original']:
            target = folder(row['label'], case, variant)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(run/'workspace', target, symlinks=True,
                            ignore=shutil.ignore_patterns('profiles', 'holdout', '__pycache__', '.pytest_cache'))
    print('Created 20 disposable copies; no source workspace writes.')

def check(label, case, variant, action):
    run = Path(next(row['path'] for row in inventory if row['label'] == label and Path(row['path']).name == caseNames[case]))
    manifest = json.loads((run/'evidence'/'manifest.json').read_text())['cases'][0]
    workspace = folder(label, case, variant)
    destination = root/'checks'/label/case/variant
    destination.mkdir(parents=True, exist_ok=True)
    spec = Sandbox(workspace, run/'workspace', destination/'runtime', pi,
                   [Path(p) for p in manifest['dependencyPaths']],
                   [(Path(p), Path(p)) for p in manifest['inputPaths']])
    if action.startswith('external'):
        pythonRun = Path(next(row['path'] for row in inventory if row['label'] == label[0] and Path(row['path']).name == caseNames['py']))
        pythonManifest = json.loads((pythonRun/'evidence'/'manifest.json').read_text())['cases'][0]
        spec.dependencies.extend(Path(path) for path in pythonManifest['dependencyPaths'])
        spec.dependencies.append(folder(label[0], 'py', 'original'))
    commands = []
    if variant == 'original':
        source = production[case]
        commands.append('git show HEAD:'+shlex.quote(source)+' > '+shlex.quote(source))
    if case == 'py':
        commands.append('export PYTHONPATH="$PWD/atlas/src:$PWD/atlas" TREE_SITTER_LANGUAGE_PACK_LIBS_DIR=/home/leon/.cache/tree-sitter-language-pack/v1.20.0/libs')
    if action == 'owned':
        command = {'ts': 'bun test src/workspaceRepos.test.ts', 'hold': 'bun test worker/scheduler.test.ts',
                   'bash': 'python3 -B -m unittest discover -s tests -v',
                   'py': f'cd atlas && {python} -B -m pytest -q -p no:cacheprovider --tb=short tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py'}[case]
    elif action == 'lint':
        command = {'ts': './node_modules/.bin/tsc --noEmit && ./node_modules/.bin/eslint src/workspaceRepos.ts src/workspaceRepos.test.ts',
                   'py': f'cd atlas && {python} -B -m ruff check --no-cache . && {python} -B -m pyright --pythonpath {python}',
                   'bash': 'bash -n manual_deps', 'hold': './node_modules/.bin/tsc --noEmit && ./node_modules/.bin/eslint worker/scheduler.ts worker/scheduler.test.ts'}[case]
    elif action == 'acceptance':
        command = f'python3 {scripts.parent}/cases/{caseDirs[case]}/runCheck.py "$PWD" acceptance'
    elif action == 'related':
        command = '/home/leon/.local/share/mise/installs/bun/1.3.11/bin/bun test '+('src' if case == 'ts' else 'worker/scheduler.test.ts worker/watcher.test.ts')
    elif action == 'affected':
        command = f'cd atlas && {python} -B -m pytest -q -p no:cacheprovider --tb=short tests/test_coffee.py tests/test_coffee_pipeline.py tests/test_coffee_check_snapshots.py tests/test_coffee_report_snapshots.py'
    elif action == 'broader':
        command = f'cd atlas && {python} -B -m pytest -q -p no:cacheprovider --tb=short tests/test_graph_contracts.py tests/test_graph_persistence.py tests/test_graph_schema.py tests/test_database_boundaries.py tests/test_architecture.py tests/test_coffee.py tests/test_coffee_pipeline.py'
    elif action in ['externalWholeCheck2', 'externalBaselineWholeCheck2', 'externalDeliveredWholeCheck']:
        prefix = f'export PYTHONPATH={folder(label[0], "py", "original")}/atlas/src TREE_SITTER_LANGUAGE_PACK_LIBS_DIR=/home/leon/.cache/tree-sitter-language-pack/v1.20.0/libs && '
        if action == 'externalBaselineWholeCheck2':
            prefix += 'mkdir "$TMPDIR/baseline" && git archive HEAD | tar -x -C "$TMPDIR/baseline" && cd "$TMPDIR/baseline" && '
        command = prefix + f'{python} -B -m atlas check --f .'
    elif action == 'wholeCheck':
        command = f'{python} -B -m atlas check --f .'
    elif action == 'baselineWholeCheck':
        command = 'mkdir "$TMPDIR/baseline" && git archive HEAD | tar -x -C "$TMPDIR/baseline" && cd "$TMPDIR/baseline" && export PYTHONPATH="$PWD/atlas/src:$PWD/atlas" && '+f'{python} -B -m atlas check --f .'
    elif action in ['sizes', 'baselineSizes']:
        code = '''const ts = require("typescript"); const fs = require("fs");
for (const path of PATHS) {
 const text = process.env.REVIEW_BASELINE ? require('child_process').execFileSync('git', ['show', 'HEAD:'+path], {encoding: 'utf8'}) : fs.readFileSync(path, "utf8");
 const source = ts.createSourceFile(path, text, ts.ScriptTarget.Latest, true);
 const functions = [];
 function visit(node) {
  if (ts.isFunctionLike(node)) {
   const start = source.getLineAndCharacterOfPosition(node.getStart(source)).line + 1;
   const end = source.getLineAndCharacterOfPosition(node.end).line + 1;
   functions.push({start, end, lines: end-start+1, kind: ts.SyntaxKind[node.kind]});
  }
  ts.forEachChild(node, visit);
 }
 visit(source); console.log(JSON.stringify({path, lines: source.text.split("\\n").length - 1, functions}));
}'''
        code = code.replace('PATHS', json.dumps(['worker/scheduler.ts', 'worker/scheduler.test.ts'] if case == 'hold' else ['src/workspaceRepos.ts', 'src/workspaceRepos.test.ts']))
        command = ('REVIEW_BASELINE=1 ' if action == 'baselineSizes' else '')+'bun --eval '+shlex.quote(code)
    elif action == 'ownedPinned':
        path = 'src/workspaceRepos.test.ts' if case == 'ts' else 'worker/scheduler.test.ts'
        command = '/home/leon/.local/share/mise/installs/bun/1.3.11/bin/bun test '+path
    elif action == 'schedulerSupplement':
        command = '/home/leon/.local/share/mise/installs/bun/1.3.11/bin/bun test worker/reviewScheduler.test.ts'
    elif action == 'fullCollect':
        command = f'cd atlas && {python} -B -m pytest --collect-only -q -p no:cacheprovider'
    elif action == 'fullImporter':
        command = f'cd atlas && {python} -B -m pytest -q -p no:cacheprovider --tb=short'
    elif action == 'dashboardChecks':
        command = 'cd dashboard; set +e; bun run build; build=$?; bun test; tests=$?; bun run typecheck; types=$?; bun lint --fix; lint=$?; printf "REVIEW_STATUS build=%s tests=%s types=%s lint=%s\\n" "$build" "$tests" "$types" "$lint"; test "$build$tests$types$lint" = 0000'
    elif action == 'collect':
        command = f'cd atlas && {python} -B -m pytest --collect-only -q -p no:cacheprovider tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py'
    else:
        raise ValueError(action)
    commands.append(command)
    command = ' && '.join(commands)
    # Exclusive output creation preserves all attempts, including failures.
    (destination/f'{action}.command.txt').write_text(command+'\n')
    result = shell(spec, action, command, destination, timeout=110)
    (destination/f'{action}.json').write_text(json.dumps(result, indent=2)+'\n')
    print(label, case, variant, action, json.dumps(result))

if sys.argv[1] == 'prepare':
    prepare()
else:
    check(*sys.argv[1:])
