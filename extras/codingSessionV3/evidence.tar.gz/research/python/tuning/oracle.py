#!/home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B
"""Behavioral oracle. Usage: ./oracle.py /absolute/atlas/worktree"""

from contextlib import closing
import json
from pathlib import Path
import sqlite3
import sys
from tempfile import TemporaryDirectory
from typing import TypedDict
import unittest

assert len(sys.argv) == 2, "expected one absolute worktree path"
root = Path(sys.argv.pop())
assert root.is_absolute() and (root / "atlas/src/atlas").is_dir(), root
sys.dont_write_bytecode = True
sys.path.insert(0, str(root / "atlas/src"))

import atlas
from atlas.bootstrap import migrate_database, navigation_service
from atlas.cli.commands import main
from atlas.persistence.repositories import repository_store
from click.testing import CliRunner

assert Path(atlas.__file__).resolve().is_relative_to(root.resolve()), atlas.__file__


class NodeRecord(TypedDict):
    stableKey: str
    parentStableKey: str | None
    type: str
    kind: str
    level: str
    language: str | None
    name: str
    qualifiedName: str | None
    path: str | None


def node(key: str, name: str, qualified: str | None = None,
         path: str | None = "neutral.py", level: str = "callable",
         parent: str | None = "file:neutral") -> NodeRecord:
    kind = "function" if level == "callable" else level
    return {"stableKey": key, "parentStableKey": parent, "type": kind,
            "kind": kind, "level": level, "language": "python", "name": name,
            "qualifiedName": qualified, "path": path}


def searchNodes() -> list[NodeRecord]:
    return [
        node("repository", "Search", path=None, level="repository", parent=None),
        node("file:neutral", "neutral.py", path="neutral.py", level="file", parent="repository"),
        node("file:unicode", "Étage.py", path="Straße/Étage.py", level="file", parent="repository"),
        node("path:symbol", "pathWorker", "worker", "Straße/Étage.py", parent="file:unicode"),
        node("name:street", "Straße", "neutral.Straße"),
        node("name:upper", "STRASSE", "neutral.STRASSE"),
        node("qualified:street", "exported", "Straße"),
        node("partial:street", "prefixStraßeSuffix", "neutral.partial"),
        node("external:street", "Straße", "remote.Street", None, "external", "repository"),
        node("name:greek", "τέλος", "neutral.greek"),
        node("name:cyrillic", "имя", "neutral.cyrillic"),
        node("name:accent", "café", "neutral.accent"),
        node("name:literal", "literal_%!\\marker", "neutral.literal"),
        node("StraßeKey", "opaqueKeyHolder", "neutral.opaque"),
        node("STRASSE", "opaqueExactKey", "neutral.exactKey"),
    ]


def databaseDump(path: Path) -> str:
    with closing(sqlite3.connect(path)) as connection:
        return "\n".join(connection.iterdump())


class UnicodeSearch(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.temporary = TemporaryDirectory(prefix="runtime", dir=Path(__file__).parent)
        cls.database = Path(cls.temporary.name) / "search.sqlite"
        migrate_database(cls.database)
        artifact = {"schemaVersion": 2,
                    "repository": {"name": "Search", "path": cls.temporary.name,
                                   "indexedAt": "2026-10-04T00:00:00+00:00"},
                    "nodes": searchNodes(), "edges": [], "diagnostics": [
                        {"severity": "warning", "path": "Straße/Étage.py", "language": "python",
                         "message": "Unicode path diagnostic"},
                        {"severity": "warning", "path": "elsewhere.py", "language": "python",
                         "message": "Unrelated diagnostic"}]}
        with repository_store(cls.database) as store:
            saved = store.save_new("Search", cls.temporary.name, artifact)
            cls.identifier, cls.revision = saved.repositoryId, saved.graphRevision
            artifact["nodes"] = [node("repository", "Other", path=None, level="repository", parent=None),
                                 node("file:neutral", "neutral.py", level="file", parent="repository"),
                                 node("other:secret", "StraßeSecret", "other.secret")]
            artifact["diagnostics"] = []
            store.save_new("Other", cls.temporary.name, artifact)
        cls.before = databaseDump(cls.database)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temporary.cleanup()

    def keys(self, query: str, limit: int = 50) -> list[str]:
        with navigation_service(self.identifier, path=self.database) as service:
            result = service.find(query, limit)
        self.assertEqual(result["repositoryId"], self.identifier)
        self.assertEqual(result["graphRevision"], self.revision)
        self.assertEqual(result["filters"], {"query": query, "limit": limit})
        return [row["stableKey"] for row in result["nodes"]]

    def testUnicodeNames(self) -> None:
        for query, key in [("ΤΈΛΟΣ", "name:greek"), ("τέλοσ", "name:greek"),
                           ("ИМЯ", "name:cyrillic"), ("CAFÉ", "name:accent")]:
            with self.subTest(query=query):
                self.assertEqual(self.keys(query), [key], "Unicode caseless name search")

    def testExpansionAndRanking(self) -> None:
        self.assertEqual(self.keys("STRASSE"), [
            "STRASSE", "name:upper", "name:street", "external:street", "qualified:street",
            "path:symbol", "file:unicode", "partial:street",
        ], "raw key, exact name, exact qualified name, substring ranks and existing tie order")
        folded = self.keys("straße")
        self.assertNotIn("STRASSE", folded, "stable keys are not caseless search fields")
        self.assertEqual(set(folded), {"name:upper", "name:street", "external:street",
                                     "qualified:street", "path:symbol", "file:unicode", "partial:street"})

    def testUnicodePathAndDiagnostics(self) -> None:
        query = "STRASSE/ÉTAGE.PY"
        self.assertEqual(self.keys(query), ["file:unicode", "path:symbol"], "exact file before declarations")
        with navigation_service(self.identifier, path=self.database) as service:
            result = service.find(query, 50)
        self.assertEqual([item["message"] for item in result["diagnostics"]], ["Unicode path diagnostic"])
        self.assertFalse(result["diagnosticsTruncated"])

    def testLimitsAndFreshConnections(self) -> None:
        for limit in (1, 2, 7, 8, 20):
            with self.subTest(limit=limit):
                with navigation_service(self.identifier, path=self.database) as service:
                    result = service.find("STRASSE", limit)
                self.assertEqual(len(result["nodes"]), min(limit, 8))
                self.assertEqual(result["truncated"], limit < 8)
        self.assertEqual(self.keys("CAFÉ"), self.keys("CAFÉ"))

    def testLiteralQueriesAndNoAccentNormalization(self) -> None:
        for query in ("%", "_", "!", "\\", "_%!\\"):
            with self.subTest(query=query):
                self.assertEqual(self.keys(query), ["name:literal"], "query metacharacters remain literal")
        self.assertEqual(self.keys("cafe"), [])
        self.assertEqual(self.keys("cafe\u0301"), [], "case folding does not imply Unicode normalization")
        self.assertEqual(self.keys("not present"), [])
        self.assertEqual(self.keys("StraßeKey"), ["StraßeKey"])
        self.assertEqual(self.keys("STRASSEKEY"), [], "stable keys remain exact")

    def testCliAndRepositoryScope(self) -> None:
        runner = CliRunner(env={"DATABASE_PATH": str(self.database)})
        result = runner.invoke(main, ["graph", "--project", self.identifier, "find", "CAFÉ"])
        self.assertEqual(result.exit_code, 0, result.output)
        payload = json.loads(result.stdout)
        self.assertEqual([item["stableKey"] for item in payload["nodes"]], ["name:accent"])
        self.assertEqual(payload["filters"]["query"], "CAFÉ")

    def testRepositoryScope(self) -> None:
        self.assertEqual(self.keys("STRASSESECRET"), [], "never leak another repository")
        with navigation_service("Other", path=self.database) as service:
            other = service.find("STRASSESECRET", 10)
        self.assertEqual([item["stableKey"] for item in other["nodes"]], ["other:secret"])

    def testReadOnlyAndUnchangedProjectIdentity(self) -> None:
        for query in ("STRASSE", "CAFÉ", "%"):
            self.keys(query)
        self.assertEqual(databaseDump(self.database), self.before, "search must not rewrite graph data or schema")


if __name__ == "__main__":
    unittest.main(verbosity=2)
