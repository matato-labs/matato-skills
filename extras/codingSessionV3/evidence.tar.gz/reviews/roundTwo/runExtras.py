import json
from pathlib import Path

review = Path('/tmp/codingSessionV3/reviews/roundTwo')
source = (review / 'runReview.py').read_text().split('\ncases = {}')[0]
exec(source.replace("'commands.json'", "'extraCommands.json'"))
for arm in ['candidateTwo', 'main', 'pr', 'ponytail']:
    folder = review / 'copies' / arm / 'pythonUnicodeGraphFind'
    run(arm + 'PythonStandaloneConsumer', pytest(folder, arm + 'Standalone', 'tests/test_script_member_coffee_snapshots.py -k python'), folder)
    result = json.loads((root / 'runs/tuningTwo' / arm / 'pythonUnicodeGraphFind/result.json').read_text())
    changed = [name.removeprefix('atlas/') for name in paths(Path(result['worktree'])) if name.endswith('.py') and '/fixtures/' not in name]
    scope = ' '.join('"' + name + '"' for name in changed)
    command = pythonPrefix(folder) + '/home/leon/workspace/projects/atlas/atlas/.venv/bin/pyright ' + scope
    run(arm + 'PythonTypesSourceAndMaintained', command, folder)
