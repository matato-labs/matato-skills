import { test, expect } from 'bun:test'
import { mkdtemp, mkdir, symlink, writeFile, readFile, lstat, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { deleteManagedSessionTree, resolveGuiChatSessionDirectory } from '/tmp/codingSessionV3/reviews/finalOne/copies/main/sessionTreeConfinement/src/agent/matatoAgentSessions'
import { setTestHomePath } from '/tmp/codingSessionV3/reviews/finalOne/copies/main/sessionTreeConfinement/src/test/home'

for (const segment of ['matato', 'sessions']) {
  test(`does not move the confinement boundary through a symlinked ${segment} directory`, async () => {
    const home = await mkdtemp(path.join(tmpdir(), 'stableConfinement'))
    const restore = setTestHomePath(home)
    try {
      const root = path.dirname(resolveGuiChatSessionDirectory())
      const outside = path.join(home, 'nonSessionData')
      const link = segment === 'matato' ? root : path.dirname(root)
      const targetDirectory = segment === 'matato' ? outside : path.join(outside, 'matato')
      await mkdir(targetDirectory, { recursive: true })
      await mkdir(path.dirname(link), { recursive: true })
      await symlink(outside, link)
      const child = path.join(root, 'protectedChild.jsonl')
      const original = JSON.stringify({ type: 'custom', customType: 'matatoSubAgent', data: { reference: { childSessionFile: child } } })
      const target = path.join(targetDirectory, 'protected.jsonl')
      const childTarget = path.join(targetDirectory, 'protectedChild.jsonl')
      await writeFile(target, original)
      await writeFile(childTarget, 'keep')
      await deleteManagedSessionTree(path.join(root, 'protected.jsonl'))
      expect((await lstat(link)).isSymbolicLink()).toBe(true)
      expect(await readFile(target, 'utf8')).toBe(original)
      expect(await readFile(childTarget, 'utf8')).toBe('keep')
    } finally {
      restore()
      await rm(home, { recursive: true, force: true })
    }
  })
}
