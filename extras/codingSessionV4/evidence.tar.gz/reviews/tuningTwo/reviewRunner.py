import concurrent.futures
import difflib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/tmp/codingSessionV4')
out = root / 'reviews/tuningTwo'
private = Path('/dev/shm/codingSessionV4tuningTwoReview')
private.mkdir()
(out / 'logs').mkdir()
specification = importlib.util.spec_from_file_location('reviewSandbox', root / 'sandboxTrial.py')
helper = importlib.util.module_from_spec(specification)
specification.loader.exec_module(helper)
cases = [json.loads((root / path).read_text())['cases'][0] for path in ['research/python/manifest.json', 'research/typescript/tuning/manifest.json']]
metrics = {}
hashes = {}
jobs = []


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def archive(case: dict, target: Path) -> None:
    target.mkdir(parents=True)
    data = subprocess.check_output(['git', '-C', case['repo'], 'archive', case['base']])
    with tarfile.open(fileobj=io.BytesIO(data)) as packed:
        packed.extractall(target, filter='data')
    if case['id'] == 'preScriptEnvironmentLifetime':
        (target / 'node_modules').symlink_to(Path(case['repo']) / 'node_modules')


def category(name: str) -> str:
    if '/snapshots/' in name:
        return 'snapshots'
    if '/fixtures/' in name:
        return 'fixtures'
    return 'tests' if '/tests/' in name or '.test.' in name else 'production'


def runJob(case: dict, arm: str, target: Path, label: str, command: str) -> dict:
    runtime = private / 'runtime' / arm / case['id'] / label
    oracle = root / ('research/python' if case['id'] == 'pythonConfinedIgnoreFiles' else 'research/typescript/tuning')
    repo = Path(case['repo'])
    dependencies = [Path('/home/leon/.local/share/uv/python/cpython-3.11-linux-x86_64-gnu'), Path('/home/leon/.cache/tree-sitter-language-pack/v1.20.0/libs')] if case['id'] == 'pythonConfinedIgnoreFiles' else []
    spec = {'worktree': target, 'repo': repo, 'common': repo / '.git', 'oracle': oracle, 'runtime': runtime, 'profile': out / 'unused', 'profileSnapshot': out / 'unused', 'config': out / 'unused', 'auth': out / 'unused', 'dependencies': dependencies, 'pi': Path('/home/leon/.local/share/mise/installs/pi/1.1.0/pi/pi')}
    log = out / 'logs' / arm / case['id']
    log.mkdir(parents=True, exist_ok=True)
    result = helper.shell(spec, label, command, log, 240)
    print(arm, case['id'], label, result['exit'], result['seconds'], flush=True)
    return {'arm': arm, 'case': case['id'], 'label': label, **result}


for case in cases:
    caseId = case['id']
    original = private / 'original' / caseId
    archive(case, original)
    for arm in ['v3', 'v2', 'ponytail', 'candidateTwo']:
        live = root / 'worktrees/tuningTwo' / arm / caseId
        trial = root / 'runs/tuningTwo' / arm / caseId
        for record in trial.iterdir():
            if record.is_file():
                hashes[str(record)] = digest(record)
        key = f'{arm}/{caseId}'
        if not (live / '.git').exists():
            metrics[key] = {'status': 'no valid retained worktree', 'files': []}
            continue
        changed = subprocess.check_output(['git', '--no-optional-locks', '-C', str(live), 'diff', '--name-only']).decode().splitlines()
        untracked = subprocess.check_output(['git', '--no-optional-locks', '-C', str(live), 'ls-files', '--others', '--exclude-standard']).decode().splitlines()
        changed += [name for name in untracked if name != 'node_modules']
        target = private / arm / caseId
        archive(case, target)
        details = []
        for name in sorted(set(changed)):
            baseFile = original / name
            newFile = live / name
            old = baseFile.read_bytes() if baseFile.exists() else b''
            new = newFile.read_bytes() if newFile.exists() else b''
            destination = target / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            if newFile.exists():
                destination.write_bytes(new)
                hashes[str(newFile)] = digest(newFile)
            else:
                destination.unlink()
            difference = subprocess.run(['git', 'diff', '--no-index', '--numstat', '--', str(baseFile) if baseFile.exists() else '/dev/null', str(newFile) if newFile.exists() else '/dev/null'], stdout=subprocess.PIPE, check=False).stdout.decode()
            added, deleted = map(int, difference.split()[:2])
            normalized = list(difflib.unified_diff([line.strip() for line in old.decode().splitlines() if line.strip()], [line.strip() for line in new.decode().splitlines() if line.strip()], n=0))
            details.append({'path': name, 'category': category(name), 'additions': added, 'deletions': deleted, 'churn': added + deleted, 'baseBytes': len(old), 'resultBytes': len(new), 'byteGrowth': len(new) - len(old), 'nonblankStrippedAdditions': sum(line.startswith('+') and not line.startswith('+++') for line in normalized), 'nonblankStrippedDeletions': sum(line.startswith('-') and not line.startswith('---') for line in normalized)})
        metrics[key] = {'status': 'partial only; not scored', 'base': subprocess.check_output(['git', '-C', str(live), 'rev-parse', 'HEAD']).decode().strip(), 'files': details}
        patch = subprocess.check_output(['git', '--no-optional-locks', '-C', str(live), 'diff', '--binary'])
        (out / f'{arm}.{caseId}.partial.patch').write_bytes(patch)
        for label, commandKey in [('frozenBehavior', 'checkCommand'), ('frozenNative', 'nativeCommand')]:
            jobs.append((case, arm, target, label, case[commandKey].replace('{root}', str(target))))
        negative = private / (arm + 'OriginalProduction') / caseId
        archive(case, negative)
        for item in details:
            if item['category'] != 'production':
                destination = negative / item['path']
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes((target / item['path']).read_bytes())
        if caseId == 'preScriptEnvironmentLifetime':
            if (target / 'src/worker/preScript.test.ts').exists():
                jobs.append((case, arm, target, 'addedMaintained', 'bun test src/worker/preScript.test.ts'))
                jobs.append((case, arm, target, 'changedLint', 'bun node_modules/eslint/bin/eslint.js src/worker/preScript.ts src/worker/preScript.test.ts'))
                jobs.append((case, arm, negative, 'originalProductionMaintained', 'bun test src/worker/preScript.test.ts'))
        else:
            command = f'cd atlas && PYTHONPATH="{negative}/atlas/src" /home/leon/workspace/projects/atlas/atlas/.venv/bin/python -B -m pytest -p no:cacheprovider -q tests/test_discovery.py tests/test_atlasignore.py'
            jobs.append((case, arm, negative, 'originalProductionMaintained', command))
(out / 'partialMetrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
(out / 'originalHashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(lambda args: runJob(*args), jobs))
(out / 'commands.json').write_text(json.dumps(results, indent=2) + '\n')
(out / 'integrityAfter.json').write_text(json.dumps({'checked': len(hashes), 'mismatches': [path for path, expected in hashes.items() if digest(Path(path)) != expected]}, indent=2) + '\n')
