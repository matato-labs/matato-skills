Synthetic runner profile. Not an experimental arm.
