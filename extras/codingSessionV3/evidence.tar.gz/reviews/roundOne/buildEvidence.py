import difflib
import hashlib
import json
from pathlib import Path

root = Path('/tmp/codingSessionV3')
review = root / 'reviews/roundOne'
metrics = json.loads((review / 'metrics.json').read_text())
commands = []
for name in ['commands.json', 'extraCommands.json', 'followupCommands.json', 'typesCommands.json', 'baselineCommands.json']:
    for command in json.loads((review / name).read_text()):
        output = Path(command['output']).read_bytes()
        commands.append({**command, 'budgetSeconds': 120, 'outputSha256': hashlib.sha256(output).hexdigest(), 'outputBytes': len(output)})
findings = [
    dict(id='R1', severity='blocking completeness', arm='candidateOne', case='pythonUnicodeGraphFind',
         paths=['atlas/tests/fixtures/coffee/unicode_search/Straße.py:1', 'atlas/tests/coffee_navigation.py:88', 'atlas/tests/test_coffee_pipeline.py:106'],
         finding='New top-level coffee fixture directory violates the existing exhaustive fixture/seam inventory. Existing test_each_physical_project_has_analysis_seams fails; pure base passes. New snapshot also has no route from update_coffee_snapshots.py.',
         evidence=['candidateOnePythonIntegration', 'pureBaseFixtureIntegration', 'pureBaseFixtureConsumers']),
    dict(id='R2', severity='blocking completeness', arm='main', case='pythonUnicodeGraphFind',
         paths=['atlas/tests/fixtures/coffee/python/src/coffee/reporting/straße.py:1', 'atlas/tests/snapshots/variants/python.json:1', 'atlas/tests/test_variant_snapshots.py:19'],
         finding='Adding source to shared Python coffee fixture changes every overlaid Python variant, but variants/python.json remains unchanged. test_named_project_variants[python] fails. Pure base passes; PR updates this snapshot and passes.',
         evidence=['mainPythonIntegration', 'pureBaseFixtureConsumers', 'prPythonIntegration']),
    dict(id='R3', severity='comparison gate failure', arm='candidateOne',
         finding='Combined production/test churn is 687: worse than main 637 and PR112 684, better than Ponytail 691. Candidate production advantage over main is only two blank separator lines in TypeScript; not evidence of a smaller semantic implementation.',
         evidence=['metrics.json', 'mainCandidateProductionDiff.txt']),
]
oldComposition = 'Look for operations that replace custom loops, parsing, bookkeeping or branches, and existing contracts that replace new declarations.'
newComposition = 'Compose existing operations and native operators before adding control flow or state. Share derived lookups at the common lifetime; reuse contracts.'
oldTests = 'Leave a small maintained regression for non-trivial changes. Extend existing tests and fixtures; parameterize equivalent examples instead of duplicating setup. Cover the failure, distinct affected contracts and their risky interactions, not every input the platform already handles. External probes supplement rather than replace repository coverage. Use a persistent executable self-check if no test framework exists.'
newTests = 'Read maintained coverage first. Reuse fixture locations, builders and generators; trace their consumers before adding samples. Cover the bug, distinct contracts and risky interactions with case tables and shared setup, not platform Cartesian checklists. Keep meaningful assertions and integration coverage. External probes supplement regressions; use an executable self-check only without a framework.'
profile = (root / 'profiles/candidateOne.md').read_text()
hypothesis = profile.replace(oldComposition, newComposition).replace(oldTests, newTests)
assert profile != hypothesis and len(hypothesis.encode()) <= len(profile.encode())
negative = [command for command in commands if 'Negative' in command['label'] or command['label'].startswith('candidateSchemaOriginal')]
worktrees = root / 'worktrees/tuningOne'
sourceDiff = ''.join(difflib.unified_diff((worktrees / 'main/memoryReferenceResolution/src/storage/memoryBlock.ts').read_text().splitlines(keepends=True), (worktrees / 'candidateOne/memoryReferenceResolution/src/storage/memoryBlock.ts').read_text().splitlines(keepends=True), fromfile='main/src/storage/memoryBlock.ts', tofile='candidateOne/src/storage/memoryBlock.ts'))
(review / 'mainCandidateProductionDiff.txt').write_text(sourceDiff)
profiles = {arm: dict(bytes=(root / 'profiles' / (arm + '.md')).stat().st_size, sha256=hashlib.sha256((root / 'profiles' / (arm + '.md')).read_bytes()).hexdigest()) for arm in ['main', 'pr', 'candidateOne']}
inputs = []
for path in sorted((root / 'runs/tuningOne').glob('*/*/*')):
    if path.name in ['agent.log', 'result.json', 'changes.patch']:
        inputs.append(dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
limits = [
    'Tuning-only behavioral execution: no reserved checks, reserved oracle/source/rationale files or validation implementation outputs accessed.',
    'Scope deviation: research/typescript/manifest.json was inadvertently opened while locating tuning manifests; it is an aggregate containing a reserved task entry and brief. Python/Elixir freeze metadata also exposed validation names/hashes. No reserve-specific manifest/oracle/source/rationale file was opened. Reserve brief exposure must be disclosed; this reviewer cannot claim complete holdout blindness.',
    'No implementation or skill edited. All tests run in own archive-based disposable copies. Original production restored only in separate negative copies; no invented mutants.',
    'Shared venv/node_modules used read-only; Python basetemp replaced only in executed native commands. All commands bounded at 120 seconds; no timeouts.',
    'Initial additional Pyright checks could not find the configured local .venv and failed with 398 errors in every arm. Retained these failures; corrected only disposable-copy dependency wiring and reran successfully. Dependency failure is not counted as correctness success.',
    'No full Python/dashboard/Bun application suite, DB-backed ExUnit/Mix aliases, network or services run. Frozen Elixir native command is the same 249-case oracle, not the maintained regression suite.',
    'Atlas mutation testing not attempted (optional); no mutation adequacy claim. Original agent.log files are final summaries, not command histories; independent reruns support only the checks recorded here.',
    'Large generated snapshot patch lines inspected structurally via complete JSON parsing, inventory/stats/response review, and maintained snapshot execution, not by treating giant one-line snapshots as hand-written code.',
    'One tuning draw, three tasks: no repeatability, final-draw success, resource savings or universal superiority inference.',
]
evidence = dict(round='roundOne', decision='Do not freeze candidateOne: integration regression and aggregate gate loss', findings=findings, metrics=metrics, profiles=profiles,
    reusedApis={
        'python': ['str.casefold', 'sqlite3.Connection.create_function(deterministic=True)', 'SQLAlchemy event.listens_for(engine, connect)', 'SQLAlchemy func.instr/case/order_by', 'existing readonly_session/navigation_reader/navigation_service', 'CoffeeNavigation.query/normalize_responses, production CLI index'],
        'typescript': ['withStorageTransaction/runInStorageTransaction rollback', 'listMemoryRooms/listMemoryTopics', 'existing name Maps and MemoryRoomRecord/MemoryTopicRecord', 'mergeNumbers and Set deduplication', 'store create/link methods and onConflictDoUpdate', 'createTestDatabaseFixture/cleanup'],
        'elixir': ['Ecto.Changeset.cast/validate_required/validate_number', 'greater_than_or_equal_to: 0', 'apply_action/put_assoc', 'ExUnit.Case and native comprehensions']},
    maintainedNegativeControls=negative,
    safeguards='No production safeguard removal found in affected paths. Explicit zero/ID precedence, exact-name lookup, rollback, SQL literal matching, ranks/scope/read-only hooks and Ecto casting/required/defaults remain intact.',
    nextSkillHypothesis=dict(status='proposal only; not written or run', originalBytes=len(profile.encode()), proposedBytes=len(hypothesis.encode()), ceilingBytes=3161, replacements=[dict(old=oldComposition, proposed=newComposition), dict(old=oldTests, proposed=newTests)], rationale='Better composition and fixture-consumer integration without adding blanket language/platform test checklists or dropping meaningful assertions.'),
    commands=commands, inputArtifacts=inputs, limits=limits,
    isolation=dict(before=str(review/'before.json'), after=str(review/'after.json'), unchanged=json.loads((review/'before.json').read_text())==json.loads((review/'after.json').read_text()), currentUserWorktree='git status --short empty at inspection'))
(review / 'evidence.json').write_text(json.dumps(evidence, indent=2, ensure_ascii=False)+'\n')
print('Commands:',len(commands),'negative controls:',len(negative),'hypothetical bytes:',len(hypothesis.encode()))
