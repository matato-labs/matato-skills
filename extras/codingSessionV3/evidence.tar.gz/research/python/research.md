# Python Atlas cases for coding-session V3

Research only. Repository `/home/leon/workspace/projects/atlas`, exact base `835be1ac26bfb0b0003a01a741afed21bd550278`. The source checkout was clean before and after research. No production code, README, skills, dependencies, or Atlas index was changed. No competitor skills or results were consulted. Source inspection used ordinary file reading/search; no indexed graph was used as evidence.

## Frozen artifacts

`tuning/manifest.json` contains the tuning case; `validation/manifest.json` contains the reserve case. Each has the requested `cases` array with one entry. Each `brief` is byte-for-byte identical to its sibling `brief.md`, including the final newline. Validation brief, manifest, oracle, and detailed rationale remain in `validation/`; there is deliberately no combined manifest exposing the reserve brief outside that directory. `freeze.json` records artifact SHA-256 digests.

Both directories contain an executable `oracle.py` taking one absolute worktree path as its sole argument, setup/native-baseline/negative-control logs, and a case-specific `research.md`. Oracles import production modules from that argument's `atlas/src`, assert import provenance, and construct their own fixtures; they do not import repository test helpers, read snapshots as expected output, mock production behavior, or assert implementation shape. Temporary oracle files stay beneath the respective artifact directory and are automatically cleaned. Native pytest scratch is retained in each `nativeTemp/` directory.

## Source investigation and scope

Read repository `AGENTS.md` completely and checked for nested AGENTS files; none exist. Inspected discovery, parsing, Python adapters, complexity, cycle/dependency metrics, reporting/checks, storage factories, normalized graph persistence, navigation queries, and corresponding tests. Selected two defects demonstrated on current HEAD rather than invented refactors. Neither concerns quoted imports, sparse limits, source-batch caching, or graph early-exit BFS.

The tuning case is Unicode literal graph search. The reserve case is literal SQLite filesystem-path handling. Detailed language/dependency/reuse opportunities, discriminating combinations, and expected touch points are documented inside each phase's `research.md`, not in the user briefs. These are independent read-query versus write-connection behaviors; neither needs a schema migration or a remote service.

## Environment and commands

The existing `/home/leon/workspace/projects/atlas/atlas/.venv/bin/python` is used read-only, not activated, synchronized, or installed into the worktree. Exact versions are in `environment.log`. Both oracles use this interpreter in their executable shebang, with `-B`, and explicitly put the supplied worktree's source first on `sys.path`. Setup commands verify dependencies and source provenance without invoking `uv run` or package installation. This is a local benchmark bundle, not a machine-independent environment installer; a missing shared interpreter is an explicit setup failure.

Manifest commands use `{root}` for the candidate worktree. Native commands disable bytecode and pytest cache/plugin auto-loading, place pytest scratch under this output tree, and run targeted regressions from the repository's `atlas/` directory. They are not substitutes for all release checks listed in AGENTS.md. Full-project indexing/reporting, dashboard checks, and dependency/tool upgrades are outside this research task.

Example invocation, after substituting an existing absolute candidate worktree:

```sh
/tmp/codingSessionV3/research/python/tuning/oracle.py /absolute/candidate/worktree
```

## Evidence and feasibility

| Phase | Native baseline | Oracle on unchanged base | Wall time, native / oracle |
| --- | --- | --- | --- |
| tuning | 52 passed, 7 deselected | exit 1, 12 assertion failures across 8 tests | 4.627 s / 0.834 s |
| validation | 23 passed | exit 1, 14 assertion failures across 7 tests | 1.948 s / 1.063 s |

Setup took approximately 0.5 seconds per case. All are comfortably below the approximately 60-second post-setup budget. Native baselines and final negative controls ran against the same agent-owned detached worktree at the exact base. See `runEvidence.json` and each phase's `setup.log`, `nativeBaseline.log`, and `negativeControl.log`. Failures are behavioral AssertionErrors, not missing dependencies or services.

An early oracle-development run is preserved as `oracleDraft.log` in each phase. It is not the frozen negative control. Validation's draft incorrectly rejected legitimate SQLite WAL/SHM sidecars; the final oracle allows normal SQLite sidecars, closes its own sqlite3 connections, and retains checks against redirected sibling databases. Ordinary, space/Unicode, and hash-containing filename round trips pass on base; encoded-looking percent and question-mark cases expose the actual defect.

The disposable detached worktree was created only under this output tree, left unmodified, then removed using `git worktree remove` without force. No other worktree was removed or pruned. `worktreeSetup.log` and `worktreeCleanup.log` preserve lifecycle evidence. No candidate implementation or positive patched control was produced: this deliverable deliberately stops at research, baseline feasibility, and proven negative controls.
