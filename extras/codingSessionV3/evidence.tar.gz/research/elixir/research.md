# Elixir V3 benchmark research

## Pin, boundaries and instructions

Repository: `/home/leon/workspace/projects/beer-game-elixir`.
Base: `141c8d40764677e3df348183491fdebe3f5ff3e4`, current HEAD when inspected, clean before and after research. Both cases start independently from this same SHA; do not apply the tuning changes before the reserve case.

No `AGENTS.md` exists in the target repository or its ancestor directories checked through `/`. Read the repository's `README.md`, `PRODUCT.md`, `mix.exs`, `.formatter.exs`, domain modules, callers and relevant existing tests. Existing UI/product preservation boundaries remain intact. No skills, prior results, or V1 task material were read. Neither case concerns identity/orphan recovery. No production files, README, or parent skill were changed.

All retained research artifacts live in this directory. The only temporary checkout was an owned detached worktree at `baseControl/`, now removed. Git worktree registration was also removed; existing unrelated worktrees were left alone.

## Feasibility and dependency reuse

This is an Elixir `~> 1.20` Phoenix application, but the selected production modules under `lib/beer_game/game/` are Ecto schemas with pure `changeset/2` entry points. They need neither Phoenix nor a Repo process. The installed runtime is Elixir 1.20.4 / OTP 29. Both `deps/` and `_build/` are absent in the target checkout.

The offline harness uses real, lock-matching Ecto 3.14.2, Decimal 3.2.0 and Telemetry 1.4.2. Ecto and Telemetry bytecode were copied unchanged from the installed dependencies of local `matato-pi/web-app`; none of that application's modules are loaded. Its installed Decimal was 3.1.1, so the locally cached Hex archive for the target's exact Decimal 3.2.0 was compiled offline instead. No dependency was downloaded. See `runtime/provenance.json`, `runtime/checksums.sha256`, and `logs/decimalCompile.log`.

The retained bytecode snapshot makes subsequent setup independent of the donor project's state. Setup verifies every dependency file and all three application versions. This snapshot was exercised on this machine's runtime; cross-OTP portability is not claimed. Rebuilding Decimal uses the retained Hex archive, extracting its `contents.tar.gz` and invoking `MIX_ENV=prod MIX_BUILD_PATH=<scratch>/decimalBuild mix compile --no-deps-check` in the extracted package. Ecto/Telemetry's retained beams need no build here.

Do not run `mix setup`, `mix deps.get`, or ordinary `mix test` for these checks. The project's test alias creates/migrates PostgreSQL, and `test/test_helper.exs` configures SQL Sandbox. The supplied native commands instead load real schemas directly and run ExUnit, without application startup, network, credentials, database, browser or external services.

## Package structure

```text
elixir/
  research.md, freeze.json, negativeControls.json, artifacts.sha256
  setup.sh, run.exs
  runtime/       exact dependency snapshot, integrity list and provenance
  tuning/        manifest.json, brief.md, oracle.sh, oracleTest.exs
  validation/    manifest.json, brief.md, oracle.sh, oracleTest.exs
  logs/          dependency build, environment, setup, base/native runs, cleanup
```

Only these artifact files were written. Prospective production targets are the three schema files listed for each case below; future regression tests belong under `test/beer_game/`, matching the project's `ExUnit.Case`, aliases, fixtures, `assert` and `apply_action` idioms. The supplied external regression files are service-free ExUnit suites, not production replacements. Existing `BeerGame.GameFixtures` functions call Repo, so the oracle constructs actual schema structs instead of calling database fixtures. Ecto's existing association helpers are still exercised.

```mermaid
flowchart LR
  Params[Form / context attributes] --> Changesets[Real game schema changeset/2]
  Ecto[Ecto cast / changeset helpers] --> Changesets
  Changesets --> Oracle[ExUnit behavioral assertions]
  Changesets -. existing consumers, not started .-> Contexts[Orders / Boards / OrderDelivery]
```

## Tuning: elixirQuantityBoundaries

The frozen assignment is `tuning/brief.md`, byte-identical to the manifest's `brief` string. The prospective production files are:

* `lib/beer_game/game/order.ex`: `BeerGame.Game.Order.changeset/2`.
* `lib/beer_game/game/player.ex`: `BeerGame.Game.Player.changeset/2`.
* `lib/beer_game/game/cpu_orders_data.ex`: `BeerGame.Game.CpuOrderData.changeset/2`.

These schemas already cast quantities and check presence, but accept negative integers and negative integer strings. This is a real inventory-integrity gap: `OrderDelivery` subtracts the order amount from the sender and adds it to the receiver; a negative amount reverses that arithmetic. `Boards.produce_stock/1` adds `weekly_orders` to factory stock. CPU demand starts from a player's weekly order quantity. The task fixes the input-domain boundary, not transaction/concurrency logic or the demand-growth formula. Backlog, stock, weekly orders and last order represent nonnegative unit counts. Zero remains accepted; no minimum of one or arbitrary upper cap is invented.

Language/reuse opportunities: real `%Order{}`, `%Player{}`, `%CpuOrderData{}` structs, changeset pipelines, existing `cast`/required validation, Ecto numeric validation, and an idiomatic Enum reduction over Player's four quantity fields rather than hand-written parsing. Preserve existing field mappings (`lastOrder`, `weeklyOrders`) and association definitions. No custom validator framework or new domain API is needed.

The oracle contains 249 independently named tests. It covers each of six quantity fields with multiple negative values, integers and integer strings, both parameter-key forms, inserts and partial updates; all 15 nonempty subsets of invalid Player quantity fields; zero, positives and large values; cast/required error metadata; all initialized roles; state-only order delivery changes; no-op updates; and Ecto association attachment. Invalid actions must return errors and retain their original input structs. Exact error text or implementation shape is not required.

On base, 126 tests fail because an invalid changeset is expected but `valid?` is true: 96 individual negative cases plus 30 invalid-field-subset cases. All 123 preservation tests pass. This rejects fixes applied only to forms, only one schema, only one field, only integer inputs, or only new records; it also rejects over-restricting zero or breaking partial changesets.

## Reserve validation: elixirGameVocabulary

The frozen assignment is `validation/brief.md`, byte-identical to the manifest's `brief` string. Prospective production files are:

* `lib/beer_game/game/player.ex`: supported player roles.
* `lib/beer_game/game/order.ex`: supported order types/states and explicit state clearing.
* `lib/beer_game/game/players_orders.ex`: supported sending/receiving association kinds.

The supported vocabularies come directly from current consumers, not speculative extensions: `Boards.create_player_by_role/2` handles retailer/wholesaler/factory; `Orders.find_supplier/2` maps supply-chain roles; `OrderDelivery.lock_participants/2` handles PLAYER_ORDER/CPU_ORDER and SENDING/RECEIVING; delivery and rendering use PENDING/DELIVERED. Arbitrary strings are currently accepted at schema boundaries but cannot participate correctly in those workflows. Explicit nil order state also passes today, unlike the schema's intended PENDING default. The brief distinguishes absent state from explicit clearing.

Language/reuse opportunities: Ecto inclusion/required validation and existing string casting, small literal collections, pattern matching on real schema structs, and Map-based partial update parameters. Keep stored strings and existing defaults rather than converting schema fields to a different representation. Do not introduce a terminal-state transition policy; all combinations of supported states remain permitted by this task.

The oracle has 288 independently named tests. Unsupported vocabulary includes unknown strings, wrong case, whitespace-altered names and values borrowed from a different field's vocabulary. Each field is tested on insert/update with atom/string parameter keys. Combined invalid type/state cases must identify both errors. Tests distinguish omitted and explicitly cleared state, cover every supported order type/state combination and state transition, all roles and association kinds, cast/required failures, no-op updates, unrelated attributes, input immutability, and Ecto association helpers.

On base, 197 tests fail with the intended `valid? == true` mismatch; all 91 preservation tests pass. This distinguishes a complete schema-boundary fix from a single-field allowlist, normalization, silently dropping invalid changes, or a fix confined to LiveView. It also prevents an unrelated state-machine policy from masquerading as vocabulary validation. This is held as the reserve case, independent of the quantity case.

## Frozen execution contract

Each phase's `manifest.json` contains exactly one case with `id`, `phase`, `repo`, `base`, `brief`, `setupCommands`, `checkCommand`, `nativeCommand`, and `sourcePaths`. `freeze.json` records brief and manifest SHA-256 values. There are no alternate brief variants; use the manifest brief unchanged for every trial of its case. `sourcePaths` includes the production targets plus existing callers/tests useful for grounding the work, not a request to edit all those files.

Substitute an absolute candidate worktree path for `{root}` in the manifest commands. Setup first confirms the pinned starting HEAD, then verifies the offline dependency snapshot without writing in the candidate. The oracle itself accepts exactly that absolute worktree path as its sole argument and does not require candidate HEAD to remain unchanged after implementation.

```sh
/tmp/codingSessionV3/research/elixir/setup.sh /absolute/candidate
/tmp/codingSessionV3/research/elixir/tuning/oracle.sh /absolute/candidate
/tmp/codingSessionV3/research/elixir/validation/oracle.sh /absolute/candidate
```

Run the two cases on separate clean worktrees. Exit zero means every behavioral assertion passed; ExUnit reports exit 2 for the observed base failures. A usage/runtime error is not a successful negative control. `nativeCommand` is a direct `elixir -pa ... -r ...` ExUnit invocation, independently checked against the same base. It bypasses only Mix/application boot, not production schemas or Ecto behavior.

`run.exs` compiles all actual domain `.ex` files from the supplied worktree in memory. No schema stubs, source-pattern checks, AST matching, source rewriting, LOC checks, timing thresholds, or test selection based on source contents are used. Each schema's public `changeset/2` and real `Ecto.Changeset.apply_action/2`, `apply_changes/1`, `get_field/2`, and `put_assoc/3` behavior is exercised. There are no production changes or claimed post-fix positive-control runs in this research.

## Negative-control evidence

Both cases were run, along with both native commands, in an owned clean detached checkout of the exact pin. The final runs compiled without warnings. Every failure is an assertion expecting an invalid changeset while base returned a valid one; none is a missing dependency, undefined function, compile error, service failure, or source-layout assertion.

| Case | Tests | Preservation passes | Intended failures | Oracle/native exit |
| --- | ---: | ---: | ---: | --- |
| tuning | 249 | 123 | 126 | 2 / 2 |
| reserve validation | 288 | 91 | 197 | 2 / 2 |

Commands, counts, exit codes and log hashes are recorded in `negativeControls.json`. Full output is retained in `logs/tuningBase.log`, `logs/tuningNativeBase.log`, `logs/validationBase.log`, and `logs/validationNativeBase.log`; adjacent `.exit` files retain status codes. `logs/environment.log` records the pin/runtime/clean state, and setup logs record verified dependency versions. `logs/worktreeAdd.log` and `logs/worktreeRemove.log` prove detached creation and successful removal. The candidate worktree directory no longer exists. The source repository remains on the original SHA with an empty porcelain status.
