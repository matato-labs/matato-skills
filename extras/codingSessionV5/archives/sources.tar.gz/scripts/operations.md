# Standalone V5 harness

Only this directory contains implementation. Generated state is confined to
`/home/leon/.cache/codingSessionV5/harness`; `--root` may select a subdirectory
there, not another filesystem. No application imports, live skill changes,
package installation, global settings, automatic sampling, or scheduling.

```mermaid
flowchart LR
  CLI[run / originals] --> Clone[Independent clone at full commit hash]
  Clone --> Setup[Offline setup in bwrap]
  Setup --> Agent[run only: fresh Pi + provider proxy]
  Agent --> Checks[Offline acceptance and native checks]
  Setup --> Checks
  Checks --> Capture[Binary patch + metrics + integrity hashes]
  Capture --> Verify[check: reproduce captured measurement]
```

`runTrial.py` owns orchestration, `sandboxTrial.py` OS/process effects,
`providerProxy.py` provider transport, `auditTrial.py` allowlisted evidence,
`measureTrial.py` Git accounting, `common.py` settings/budget, and
`evidenceTypes.py` the consumed Pi JSON contract. `nativeTrial.py` owns pinned
package snapshots/preflight/activation audit; `nativeTrace.ts` observes actual Pi
injection without changing context; `nativeProbe.mjs` exercises the original
factory and observer offline. `nativeTests.py` is included by `unitTests.py`.
There is no runtime dependency on V4. Its verified proxy design and private-index
accounting were reused.

## Commands

From the repository root (Python 3.11+, Git, Linux bubblewrap, Pi **1.2.0**):

```sh
PYTHONDONTWRITEBYTECODE=1 python3 extras/codingSessionV5/scripts/unitTests.py
PYTHONDONTWRITEBYTECODE=1 python3 extras/codingSessionV5/scripts/selfCheck.py

# No model or auth access: offline checks of independent original-base clones.
python3 extras/codingSessionV5/scripts/runTrial.py originals /absolute/manifest.json

# SPENDS ONE MODEL RUN. Legacy narrative/text-only arm, explicitly labeled textOnly.
# Not executed as part of implementation/preflight.
python3 extras/codingSessionV5/scripts/runTrial.py run \
  /absolute/manifest.json /absolute/candidateOne.md drawOne --case taskOne

# SPENDS ONE MODEL RUN. Authentic pinned native Pi Ponytail arm; NOT executed here.
python3 extras/codingSessionV5/scripts/runTrial.py run \
  /absolute/manifest.json \
  "$PWD/extras/codingSessionV5/baseline/upstream/skills/ponytail/SKILL.md" \
  drawOne --case taskOne --native \
  --package "$PWD/extras/codingSessionV5/baseline/upstream"

# No model/auth access and no test rerun: verify hashes and reproduce patch/metrics.
python3 extras/codingSessionV5/scripts/runTrial.py check \
  /absolute/printed/evidence
```

Optional global `--root /home/leon/.cache/codingSessionV5/harness/subdirectory`
precedes the subcommand. `run --authSource /private/auth.json` overrides the
standard Pi auth source. There is no reserve/setup-only/model-probe command.
`--case` is required when a manifest contains multiple cases. Profile path is a
single exact Markdown **file**, not a discovered skill directory. `--native` and
`--package` must appear together; omission selects the explicitly labeled text-only
arm. Native profile bytes must equal that package's `skills/ponytail/SKILL.md`.
Draw, case ID, and profile filename stem use letters/digits/dots, beginning with a
letter/digit. Text run paths use `draw/profileStem.profileHashPrefix/case/evidence`;
native paths add `.native.packageHashPrefix` to the profile component. Different
mechanisms/packages cannot collide with an existing text arm. Existing run
directories cannot be reused, including failed ones.

Minimal manifest (absolute repository/dependency/input paths):

```json
{
  "cases": [{
    "id": "taskOne",
    "repo": "/absolute/originalRepo",
    "base": "0123456789012345678901234567890123456789",
    "brief": "The frozen implementation task.",
    "setupCommands": ["test -f '{root}/src/main.py'"],
    "checkCommand": "python3 /absolute/checks/acceptance.py '{root}'",
    "nativeCommand": "cd '{root}' && python3 -m unittest",
    "dependencyPaths": ["/absolute/offlineDependency"],
    "inputPaths": ["/absolute/checks"]
  }]
}
```

Setup, native, dependency and input lists are optional; acceptance is required.
All commands are trusted, pre-reviewed **offline/service-free** shell commands;
`{root}` is replaced with the owned checkout path. No automatic installs,
submodule/LFS initialization or service preparation. V4 case metadata is tolerated,
but dependencies must be explicitly supplied (no V4 dependencyMounts lookup).
Input files/directories are copied once and mounted read-only at their original
absolute paths. Launchers needing writable scratch beside themselves must instead
use `$TMPDIR` or the owned workspace; there is no writable oracle overlay.

## Fixed controls and limits

Every generation uses **openai-codex/gpt-6.1-sol**, **high**, and exactly
**read,bash,edit,write**. Pi version is probed with `--version` inside bwrap; no
prompt/catalog/auth probe occurs. Empty per-run configuration disables compaction,
automatic retries, cache warming, telemetry and WebSockets. Discovery of context,
skills, extensions, MCP, templates and themes is disabled; project trust declined.
In text-only mode, only the selected profile is appended verbatim. Native mode
explicitly loads `-e /experiment/package/pi-extension/index.js`,
`--skill /experiment/package/skills`, and the separate observer
`-e /experiment/nativeTrace.ts` despite discovery remaining disabled. It does
**not** append raw SKILL. The original extension injects its full-mode transformed
body on every `before_agent_start`. Both modes require the first tool call to read
the complete mounted profile bytes; the audit requires successful exact-content observation,
reported model/thinking identity, balanced tool executions, final `stop`, and
`agent_settled` without abort/recovery. Missing identity fails the audit, not a guess.
Repository-local instructions must be read explicitly afterward.

The global ledger under `harness/control` allows **30 launch attempts total**,
across subroots, with **3 concurrent harness executions**. Ledger consumption is
immediately before Pi launch, never by originals/check/selfCheck. Launch failure
is conservatively charged; no refunds or automatic retries. Each agent process
has a hard **600-second** cap; each clone/setup/check command has **120 seconds**.
These are per-process limits, not a 600-second whole-pipeline promise. Timeouts
kill the owned process group; private PID namespaces also terminate descendants.
Slots are kernel locks, released on process death. No model runs or real task
reservations were made while implementing this harness.

Original source checkouts and dependencies are read-only, with separate copied
Git objects (no hardlinks/alternates/worktree registration). Only the owned
workspace and per-stage scratch are writable; workspace Git metadata is read-only.
No host root/home/run/socket mount. Checks have neither auth nor proxy. Agent
network is a private namespace bridged to CONNECT port 443 on only chatgpt.com,
api.openai.com and auth.openai.com, resolving only global addresses. No app service
is authorized. This is an OS containment boundary, not proof a task's code is safe.

## Evidence and measurement

Each printed `evidence` directory contains frozen manifest/case/profile/prompt,
input hashes, invocation/settings/Pi binary hash, sanitized tool trace and summary,
completion identities, reported usage, individual check exits/logs, full Git binary
patch (including added files and symlinks), per-file/category metrics, and hashes.
`completed` means valid agent evidence, not passing tests; `run` exits nonzero for
failed checks. Originals preserve negative acceptance exits without treating an
expected failing-original control as a harness failure. Inspect those exits.

Metrics distinguish production, tests, fixtures, snapshots, other and combined.
They cover changed tracked files plus **unignored added files**, never followed
dependency-directory symlinks. Ignored caches/build artifacts are not delivered
patch files. Setup-created unignored links/files are included against the frozen
commit, so setup must not alter production/test source. Files, physical/nonblank/
comment-prefix-code LOC before/after, added/deleted lines and bytes, full before/
after bytes and growth are separate. Binary line/addition metrics are **null**
(including affected aggregate totals), not zero. Compression is level-9 **raw
DEFLATE** over added diff bytes, with no gzip header, analogous to Ponytail's
repository-diff metric; classification is broader and deterministic. This is not
an AST metric or a claim of identical upstream benchmark scoring.

Final reply words and all assistant text words are distinct; turns come from
`turn_end`. Only finalized assistant-message usage is summed: input, output,
cacheRead, cacheWrite, optional cacheWrite1h/reasoning, totalTokens, and every cost
category. Missing categories are null with an unavailable list. Reasoning is
already inside output. Pi-reported costs are retained **as reported**, never
recomputed from token prices; actual provider billing is explicitly unavailable.
Concrete responseModel/responseId and provider thinking are retained when reported;
unreported backend identity remains null. Pi permission-denial counts are
unavailable; sanitized tool error flags are not invented approval-denial counts.

Private auth is read only to create a selected-provider copy, never as a report
input. Raw agent JSONL, raw tool results/thinking, auth and failure details remain
in sibling mode-0700 `private` storage, not evidence. Exact credential strings and
common secret patterns are redacted from publishable text; patches/files containing
them fail publication rather than silently changing the patch. Config/auth are
read-only and must already be usable; no command credentials or global refresh.
Pi and its tools share a principal: the selected auth is technically accessible
inside the agent sandbox, as in V4. This is **not** a credential-vault boundary.
Do not archive/publish the parent run, workspace, private or verification folders.
Even evidence is local, not auto-published; review it before sharing. Pattern
scrubbing is not a universal secret detector or protection against encoded secrets.
Hashes detect accidental changes, not malicious rewriting of both evidence and
hashes. `check` reproduces capture from the retained checkout, not test correctness.

## Native Ponytail, ablations and proof requirements

Native support uses the exact Pi mechanism at upstream commit
`84740e3d344b69b4a133201fa519eb37a62a2b2a`, package 5.2.0, retained under
`baseline/upstream` (see `baseline/integration.md`). Nothing is globally installed.
The optional `--package` selects a local root, not an npm source. Before auth access
or launch accounting, all 49 provenance-listed resources are frozen into private
storage and hashed individually and as a deterministic path/hash inventory. The
snapshot includes **all original hooks and shipped scripts**, manifest, skills,
native tests, license and retained benchmark files. Extra files from a larger source
root are not copied/mounted; this remains the documented pinned Pi subset, not the
complete cross-host distribution. The package snapshot is mounted read-only at a
constant path, retaining relative imports. Upstream install/uninstall or other-host
activation scripts are never invoked.

Only `skills/ponytail/SKILL.md` may differ from the pinned inventory. Every other
resource, including extension, hooks, aliases and scripts, must match provenance
hashes. `package.json` evidence labels exact original bytes `nativePonytail`, or a
changed main skill `nativeVariant`. A missing skill fails rather than accepting the
builder's embedded fallback. Package/profile mismatch and altered runtime scripts
are rejected before credentials or any launch. A native stage gets isolated
HOME/XDG config, `PONYTAIL_DEFAULT_MODE=full`, quiet startup/hidden status, and a
read-only Ponytail config with those same values. This changes no model, thinking,
tool allowlist, Pi settings, discovery/context controls, budgets or proxy rules.

```mermaid
flowchart LR
  Package[Pinned package snapshot + matching profile] --> Mock[Offline original factory + observer proof]
  Mock --> Native[Exact extension + all six skill resources]
  Native --> Before[Every before_agent_start: transformed full body]
  Before --> Context[Every request: replayed Ponytail system section]
  Context --> Gate[Activation AND existing profile/identity/settlement audit]
```

`nativeProof.json` and `nativeInstructions.txt` retain an offline mock proof and
exact expected transformation/hash. `nativeProbe.mjs` calls the **original** factory
with a mock Pi API, restores full mode, observes injection twice, verifies five
aliases/resources and off behavior, and tests the observer against wrong/missing
instructions and redundant raw append. It imports no SDK/model/provider. Node
executes it inside bwrap with no auth mount or network. The observer uses a type-only
Pi API import; the older repository SDK is not substituted for Pi 1.2.0. Its tests
use Node's TypeScript stripping (tested Node 26.12.0), while the actual Pi invocation
loads the observer through Pi's extension loader.

This proof is deliberately labeled `offlineNativeFactoryAndObserverMock`, with
`piRuntimeInjectionProven=false`. No actual Pi prompt, credentials, provider probe,
or model run was used to claim host injection. A live Pi before-agent/context check
without entering the model pipeline was not established here; `--version` alone is
not activation evidence. The mock establishes factory behavior, not Pi loader or
provider-wire equivalence. That limit is not waived by a successful import.

For every later authorized model run, **require** `activation.json.valid=true`
and `audit.json.valid=true`, along with zero agent exit and the independent checks.
The separate observer loads **after** Ponytail and records non-context custom
entries in the Pi JSONL: exact section hash and no append-system-prompt at every
`before_agent_start`, then the exact XML-wrapped Ponytail section replayed from the
full system transcript at every `context_with_system`. The audit requires ordered
run IDs, a before observation per `agent_start`, a context observation per finalized
assistant message, at least one request per run, and matching expected hashes with
no invalid observation. Missing/swallowed handler errors, off/wrong/fallback bodies,
missing later injections or absent observer events cannot produce a completed run.
This observes the pre-provider-conversion transcript, not HTTP payloads, remote
receipt, or semantic compliance. Pi loader/wrapper differences fail closed and need
investigation, not a silent acceptance override. Raw events stay private; hashes
and allowlisted activation entries are publishable evidence.

For a fair procedural/narrative ablation, clone this **same package subset** into
an external retained directory, change only its main skill body, preserving name,
description, frontmatter and all other files, then use the identical native command
with that root/profile:

```sh
# Later authorized spend only; clone/edit preparation is not performed by the runner.
python3 extras/codingSessionV5/scripts/runTrial.py run \
  /absolute/manifest.json /absolute/nativeNarrative/skills/ponytail/SKILL.md \
  drawOne --case taskOne --native --package /absolute/nativeNarrative
```

When prepared as above, both native arms get identical extension/hooks, skill discovery
metadata and mode transformation; no alternative injector or raw narrative append. Review retained
`nativeInstructions.txt` for each arm before interpreting results: filtering mode
rows/examples is intentional. Text-only narrative remains available for legacy
comparisons, **not** a mechanism-controlled procedural/narrative ablation. The
mandatory raw first profile read is unchanged in both native arms; it brings raw
skill content into tool context, not a redundant system append. Neither native arm
reproduces Claude Code map/statusline/subagent hooks or original NO_RUN benchmarks.

## Executed verification and deviations

`PYTHONDONTWRITEBYTECODE=1 python3 extras/codingSessionV5/scripts/unitTests.py`
passes 17 tests, including native CLI pairing, fixed controls, required preflight, exact snapshot/script
hashes, mismatched/missing skill rejection, unchanged mechanism for a narrative
clone, offline variant injection, read-only native mounts/config and mandatory
activation audit with missing/wrong/later-event counterexamples. Model invocation
wiring is tested with synthetic JSONL and mocked execution/budget; no real launch
or auth-source read occurs.

`PYTHONDONTWRITEBYTECODE=1 python3 extras/codingSessionV5/scripts/selfCheck.py`
passes existing isolation/proxy/timeout/originals/capture checks plus offline exact
native factory/observer proof and OS-level read-only package/config/instructions/
observer checks. Its printed synthetic directory retains `evidence/nativeProof.json`,
`evidence/nativeInstructions.txt`, `evidence/package.json` and `preflight.json`.
All generated files stay under the approved harness cache. The final originals
negative acceptance exit is intentional, not an assertion that a task passes.
No files outside `scripts/` were authored; baseline/cases/live skills remain unchanged.
All 49 baseline hashes were independently rechecked against provenance.

The observer also passes `node_modules/.bin/tsc --noEmit --skipLibCheck --module
nodenext --moduleResolution nodenext --target es2022
extras/codingSessionV5/scripts/nativeTrace.ts`. This checks against repository SDK
1.0.4 declarations only; it is not Pi 1.2.0 runtime activation evidence.

Unit/synthetic checks cover new/binary/deleted/no-final-newline patch replay,
index immutability, metric separation, usage/no-double-counting/unavailable fields,
wrong/truncated first reads, identity/settlement rejection, redaction, disk limits,
30-attempt accounting, readonly mounts, private scratch, network/proxy denials,
timeouts, original negative controls and captured-measurement reproduction.
Only synthetic sources and offline native-package activation were checked;
provider reachability, actual auth, model availability/completions, task correctness
and exhaustive hostile-code resistance remain untested. Installed Atlas has no
`mutations` command: zero mutants, not a mutation-testing pass. Frozen manifests/profiles/local dependencies must be retained
separately for replay; dependency binaries are not bundled. No statistical or
quality claims are made by this harness.
