"""Read-only, standard-library verification; never launches models or reads auth."""
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent


def load(path: Path):
    return json.loads(path.read_text())


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def fingerprint(value) -> str:
    return digest(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def git(repo: Path, *args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(repo), *args], env={
        **os.environ, "GIT_OPTIONAL_LOCKS": "0", "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_TERMINAL_PROMPT": "0",
    })


def fileHash(path: Path) -> str:
    return digest(os.readlink(path).encode() if path.is_symlink() else path.read_bytes())


def sourceRecord(repo: Path):
    names = git(repo, "ls-files", "-z").decode().split("\0")
    files = {name: fileHash(repo / name) if (repo / name).exists() or (repo / name).is_symlink()
             else None for name in names if name}
    return {
        "repo": str(repo), "head": git(repo, "rev-parse", "HEAD").decode().strip(),
        "indexSha256": digest((repo / ".git/index").read_bytes()),
        "status": git(repo, "status", "--short").decode(),
        "trackedDiffSha256": digest(git(repo, "diff", "--binary", "HEAD")),
        "trackedFilesSha256": fingerprint(files), "trackedFiles": len(files),
    }


def dependencyRecord(path: Path):
    resolved = path.resolve(strict=True)
    paths = sorted(resolved.rglob("*")) if resolved.is_dir() else [resolved]
    records = [(str(item.relative_to(resolved)) if resolved.is_dir() else item.name,
                "link" if item.is_symlink() else "file", item.stat(follow_symlinks=False).st_mode,
                fileHash(item)) for item in paths if item.is_symlink() or item.is_file()]
    return {"resolved": str(resolved), "files": len(records), "sha256": fingerprint(records)}


def verifySources() -> None:
    pins = load(here / "originalPins.json")
    for record in pins["repositories"].values():
        assert sourceRecord(Path(record["repo"])) == record, record["repo"]
    for name, expected in pins["otherV5Files"].items():
        assert fileHash(here.parent / name) == expected, name
    actual = {str(path.relative_to(here.parent)) for path in here.parent.rglob("*")
              if path.is_file() and not path.is_relative_to(here)}
    assert actual == set(pins["otherV5Files"]), "Other V5 file set changed"


def verifyEvidence(folder: Path, case, pins, report) -> None:
    assert fileHash(folder / "integrity.json") == report["integritySha256"]
    assert fileHash(Path(report["replay"]["log"])) == report["replay"]["sha256"]
    replay = load(Path(report["replay"]["log"]))
    assert replay["integrity"] == "passed" and replay["measurement"] == "reproduced"
    for name, expected in load(folder / "integrity.json").items():
        assert Path(name).name == name
        assert fileHash(folder / name) == expected, name
    result = load(folder / "result.json")
    assert result["status"] == "originalPreflight" and "error" not in result
    assert result["modelLaunched"] is False and result["agent"] is None
    assert result["checks"] == {"acceptance": 1, "native": 0}
    assert result["base"] == pins["base"] == case["base"]
    assert result["manifestSha256"] == pins["artifacts"]["manifest.json"]["sha256"]
    assert fileHash(folder / "manifest.json") == result["manifestSha256"]
    for key, value in load(folder / "case.json").items():
        assert case[key] == value, key
    inputs = load(folder / "inputs.json")
    assert {row["alias"] for row in inputs} == set(case["inputPaths"])
    for row in inputs:
        assert row["sha256"] == pins["artifacts"][Path(row["alias"]).name]["sha256"]
    for label in ["clone", *[f"setup{number}" for number in range(len(case["setupCommands"]))],
                  "acceptance", "native"]:
        execution = load(folder / f"{label}.json")
        assert execution["exit"] == (1 if label == "acceptance" else 0), label
        assert execution["timedOut"] is False, label
    acceptance = (folder / "acceptance.stdout").read_text() + (folder / "acceptance.stderr").read_text()
    for marker in report["assertionMarkers"]:
        assert marker in acceptance, marker
    for marker in ["ERROR collecting", "ModuleNotFoundError", "TIMEOUT after", "bwrap:"]:
        assert marker not in acceptance, marker
    for label, marker in report["passingMarkers"].items():
        output = (folder / f"{label}.stdout").read_text() + (folder / f"{label}.stderr").read_text()
        assert all(line in output for line in marker.splitlines()), label
    assert all(row["path"] == "node_modules" and row["category"] == "other"
               for row in result["measurement"]["files"]), "Original source changed"
    workspace = folder.parent / "workspace"
    assert git(workspace, "diff", "HEAD", "--") == b""
    assert git(workspace, "rev-parse", "HEAD").decode().strip() == case["base"]
    assert not (workspace / ".git/objects/info/alternates").exists()
    assert (workspace / ".git").is_dir()
    for name, expected in pins["files"].items():
        assert fileHash(workspace / name) == expected["sha256"], name


def verifyCase(path: Path) -> str:
    case = load(path / "manifest.json")["cases"][0]
    source = load(path / "sourcePins.json")
    pins = {**source, **load(path / source["preparationPins"])}
    report = load(path / "controlReport.json")
    repo = Path(case["repo"])
    assert case["brief"] == (path / "brief.txt").read_text()
    assert git(repo, "rev-parse", f"{case['base']}^{{tree}}").decode().strip() == pins["tree"]
    for name, expected in pins["files"].items():
        original = git(repo, "show", f"{case['base']}:{name}")
        assert {"sha256": digest(original), "bytes": len(original)} == expected, name
        assert fileHash(repo / name) == expected["sha256"], name
    for name, expected in pins["artifacts"].items():
        data = (path / name).read_bytes()
        assert {"sha256": digest(data), "bytes": len(data)} == expected, name
    assert pins["briefStringUnchanged"] is True
    for name, expected in pins["preservedArtifacts"].items():
        assert fileHash(path / name) == expected, name
    assert set(case["dependencyPaths"]) == set(pins["dependencies"])
    for name, expected in pins["dependencies"].items():
        assert dependencyRecord(Path(name)) == expected, name
    assert set(case["inputPaths"]) == {str(path / name) for name in pins["inputFiles"]}
    assert "controls" in case["setupCommands"][-1]
    assert report["runnerSha256"] == fileHash(Path(report["runner"]))
    assert report["harnessInventorySha256"] == fingerprint(load(here / "originalPins.json")["otherV5Files"])
    assert report["manifestSha256"] == pins["artifacts"]["manifest.json"]["sha256"]
    assert report["sourcePinsSha256"] == fileHash(path / "sourcePins.json")
    assert report["preparationPinsSha256"] == fileHash(path / source["preparationPins"])
    assert report["modelLaunches"] == 0 and report["ready"] is True
    assert "os.environ[\"TMPDIR\"]" in (path / "runCheck.py").read_text()
    assert "APPROVED" not in (path / "runCheck.py").read_text()
    verifyEvidence(Path(report["evidence"]), case, pins, report)
    return case["id"]


def main() -> None:
    verifySources()
    report = load(here / "controlReport.json")
    for name, expected in report["preparationFiles"].items():
        assert fileHash(here / name) == expected, name
    for record in report["selfChecks"].values():
        assert fileHash(Path(record["log"])) == record["sha256"]
        assert record["exit"] == 0
    assert report["modelLaunches"] == 0 and report["actualAuthRead"] is False
    catalog = load(here / "catalog.json")
    entries = [*catalog["development"], catalog["holdout"]]
    for entry in entries:
        assert entry["ready"] is True
        path = (here / entry["manifest"]).parent
        assert entry["manifestSha256"] == fileHash(path / "manifest.json")
        assert entry["sourcePinsSha256"] == fileHash(path / "sourcePins.json")
        assert entry["controlReportSha256"] == fileHash(path / "controlReport.json")
        verifyCase(path)
    for path in here.rglob("*.py"):
        assert len(path.read_text().splitlines()) <= 600, path
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                assert node.end_lineno - node.lineno + 1 <= 100, node.name
    print(json.dumps({"status": "passed", "developmentReady": 3, "holdoutReady": True,
                      "originalSourceHashes": "unchanged", "otherV5Files": "match final external revision pins",
                      "frozenInputs": "verified", "originalControls": "verified",
                      "modelLaunches": 0, "authRead": False}))


if __name__ == "__main__":
    main()
