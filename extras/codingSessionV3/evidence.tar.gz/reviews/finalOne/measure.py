import difflib
import hashlib
import json
from pathlib import Path
import subprocess
from runReview import root, review, results, paths, git

metrics = []
aggregates = {}
snapshotAudit = []

def category(name):
    return 'tests' if any(p in Path(name).parts for p in ['test', 'tests', 'snapshots', 'fixtures']) or '.test.' in name else 'production'

def physical(data):
    return data.count(b'\n') + int(bool(data) and not data.endswith(b'\n'))

def diffCounts(old, new, strip=False):
    a, b = old.decode().splitlines(), new.decode().splitlines()
    if strip:
        a, b = [[line.strip() for line in lines if line.strip()] for lines in [a, b]]
    added = removed = addedBytes = removedBytes = 0
    for tag, start, end, begin, finish in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag == 'equal':
            continue
        if tag in ['replace', 'delete']:
            removed += end - start
            removedBytes += sum(len(x.encode()) + 1 for x in a[start:end])
        if tag in ['replace', 'insert']:
            added += finish - begin
            addedBytes += sum(len(x.encode()) + 1 for x in b[begin:finish])
    return dict(added=added, removed=removed, churn=added + removed, addedBytes=addedBytes, removedBytes=removedBytes)

def leaves(value):
    if isinstance(value, dict):
        return sum(leaves(x) for x in value.values())
    if isinstance(value, list):
        return sum(leaves(x) for x in value)
    return 1

def changes(a, b, prefix=''):
    if type(a) != type(b):
        return [dict(path=prefix, change='type')]
    if isinstance(a, dict):
        entries = [dict(path=prefix + '/' + k, change='added' if k in b else 'removed') for k in sorted(a.keys() ^ b.keys())]
        for k in sorted(a.keys() & b.keys()):
            entries.extend(changes(a[k], b[k], prefix + '/' + k))
        return entries
    if isinstance(a, list):
        entries = [dict(path=prefix, change='length', before=len(a), after=len(b))] if len(a) != len(b) else []
        for i, (x, y) in enumerate(zip(a, b)):
            entries.extend(changes(x, y, prefix + '/' + str(i)))
        return entries
    return [dict(path=prefix, change='value', before=a, after=b)] if a != b else []

for result in results:
    folder = Path(result['worktree'])
    stat = {}
    for line in git(folder, 'diff', 'HEAD', '--numstat', '-z').decode().split('\0'):
        if line:
            added, removed, name = line.split('\t', 2)
            stat[name] = (int(added), int(removed))
    files = []
    for name in paths(folder):
        new = (folder / name).read_bytes() if (folder / name).is_file() else b''
        try:
            old = subprocess.check_output(['git', '-C', str(folder), 'show', result['base'] + ':' + name], stderr=subprocess.DEVNULL)
        except subprocess.CalledProcessError:
            old = b''
        added, removed = stat.get(name, (physical(new), 0))
        file = dict(path=name, category=category(name), added=added, removed=removed, churn=added + removed, net=added - removed, bytesBefore=len(old), bytesAfter=len(new), byteNet=len(new) - len(old), sha256=hashlib.sha256(new).hexdigest(), stripWhitespace=diffCounts(old, new, True), byteDiff=diffCounts(old, new))
        files.append(file)
        if name.endswith('.json'):
            parsed = json.loads(new)
            before = json.loads(old) if old else None
            audit = dict(arm=result['arm'], case=result['case'], path=name, bytes=len(new), leaves=leaves(parsed), canonicalHash=hashlib.sha256(json.dumps(parsed, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest(), differences=changes(before, parsed))
            snapshotAudit.append(audit)
    totals = {kind: {metric: sum(f[metric] for f in files if f['category'] == kind) for metric in ['added', 'removed', 'churn', 'net', 'byteNet']} for kind in ['production', 'tests']}
    for kind in totals:
        totals[kind]['stripWhitespaceChurn'] = sum(f['stripWhitespace']['churn'] for f in files if f['category'] == kind)
        totals[kind]['addedBytes'] = sum(f['byteDiff']['addedBytes'] for f in files if f['category'] == kind)
        totals[kind]['removedBytes'] = sum(f['byteDiff']['removedBytes'] for f in files if f['category'] == kind)
    metrics.append(dict(arm=result['arm'], case=result['case'], base=result['base'], files=files, totals=totals))
    sums = aggregates.setdefault(result['arm'], {kind: {m: 0 for m in totals[kind]} for kind in totals})
    for kind in totals:
        for metric in totals[kind]:
            sums[kind][metric] += totals[kind][metric]
(review / 'metrics.json').write_text(json.dumps(dict(trials=metrics, aggregates=aggregates), ensure_ascii=False, indent=2) + '\n')
(review / 'snapshotAudit.json').write_text(json.dumps(snapshotAudit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(aggregates, indent=2))
for trial in metrics:
    print(trial['arm'], trial['case'], trial['totals'])
