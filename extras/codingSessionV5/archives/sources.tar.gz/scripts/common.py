"""Shared disk boundary and immutable experiment settings; no Pi imports."""
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import time

scratch = Path('/home/leon/.cache/codingSessionV5/harness')
model = 'openai-codex/gpt-6.1-sol'
profileAlias = Path('/experiment/profile.md')
proxyAlias = Path('/experiment/provider.sock')
settings = {'compaction': {'enabled': False}, 'retry': {'enabled': False,
            'provider': {'maxRetries': 0}}, 'cacheWarming': 'off', 'transport': 'sse',
            'enableInstallTelemetry': False, 'enableAnalytics': False,
            'defaultProjectTrust': 'never', 'packages': []}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def save(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n')


def owned(path: Path) -> Path:
    path = path.resolve()
    if not path.is_relative_to(scratch) or path == scratch.parent:
        raise ValueError('Generated storage must be inside ' + str(scratch))
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    path.chmod(0o700)
    return path


def identifier(value: str) -> str:
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.]*', value):
        raise ValueError('Identifiers use letters, digits and dots only')
    return value


@contextmanager
def slot():
    control = owned(scratch / 'control')
    while True:
        for number in range(3):
            handle = (control / f'slot{number}.lock').open('a')
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                handle.close()
                continue
            try:
                yield
            finally:
                handle.close()
            return
        time.sleep(0.2)


def consume(identity: str, control: Path = scratch / 'control') -> None:
    """Called immediately before launching Pi, never by preflights. No refunds."""
    owned(control)
    with (control / 'budget.lock').open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        path = control / 'budget.json'
        runs: list[str] = json.loads(path.read_text()) if path.exists() else []
        if identity in runs or len(runs) >= 30:
            raise RuntimeError('Duplicate identity or 30-model-run budget exhausted')
        temporary = control / 'budget.pending'
        save(temporary, [*runs, identity])
        temporary.replace(path)


def agentArgs(pi: Path, native: bool = False) -> list[str]:
    args = [str(pi), '--print', '--mode', 'json', '--no-session', '--no-extensions',
            '--no-skills', '--no-prompt-templates', '--no-themes', '--no-context-files',
            '--no-mcp', '--no-approve', '--offline', '--provider', 'openai-codex',
            '--model', model, '--thinking', 'high', '--tools', 'read,bash,edit,write']
    return args if native else [*args, '--append-system-prompt', str(profileAlias)]
