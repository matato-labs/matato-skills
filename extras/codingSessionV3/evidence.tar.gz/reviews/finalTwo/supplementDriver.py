import concurrent.futures
import difflib
import json
from pathlib import Path
import shlex
import shutil
from reviewDriver import ROOT, OUT, ARMS, CASES, PYTHON, execute, git, pytests, sha


def testDiffs():
    metrics = json.loads((OUT / 'metrics.json').read_text())
    for case in CASES:
        chunks = []
        for arm in ARMS:
            source = ROOT / 'worktrees/finalTwo' / arm / case
            chunks.append('\n### '+arm+' '+case+'\n')
            for item in metrics[arm][case]:
                name = item['path']
                if item['category'] != 'tests' or not name.endswith(('.py', '.ts', '.exs')):
                    continue
                chunks.append(git(source, 'diff', '--no-ext-diff', '--', name).decode())
        (OUT / (case+'TestDiffs.txt')).write_text(''.join(chunks))


def fullSnapshots(arm):
    target = OUT / 'copies' / arm / 'pythonUnicodeGraphFind'
    execute(arm+'UnicodeFullMaintained', pytests(target, ['tests/test_graph_navigation.py','tests/test_coffee_navigation_snapshots.py']), target / 'atlas')


def generator(arm):
    case = 'pythonUnicodeGraphFind'
    original = OUT / 'copies' / arm / case
    target = OUT / 'generatorCopies' / arm
    shutil.copytree(original, target, symlinks=True, ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache', '.ruff_cache'))
    root = target / 'atlas/tests/snapshots'
    before = {str(p.relative_to(root)): sha(p.read_bytes()) for p in root.rglob('*.json')}
    result = execute(arm+'SnapshotGenerator', shlex.join([PYTHON, '-B', '-m', 'tests.update_coffee_snapshots', '--navigation']), target / 'atlas')
    changes = []
    for p in root.rglob('*.json'):
        name = str(p.relative_to(root))
        data = json.loads(p.read_bytes())
        if sha(p.read_bytes()) != before.get(name):
            changes.append(dict(path=name, existed=name in before, bytes=p.stat().st_size))
    (OUT / (arm+'GeneratorAudit.json')).write_text(json.dumps(dict(exit=result['exit'], changed=changes, jsonFiles=len(before)), indent=2)+'\n')
    print('GENERATOR',arm,changes,flush=True)
    shutil.rmtree(target)


def audit():
    metrics = json.loads((OUT / 'metrics.json').read_text())
    snapshots, totals = [], {}
    for arm, cases in metrics.items():
        totals[arm] = {}
        for case, files in cases.items():
            source = ROOT / 'worktrees/finalTwo' / arm / case
            for item in files:
                path = item['path']
                current = (source / path).read_text()
                original = git(source, 'show', 'HEAD:'+path).decode() if item['beforeBytes'] else ''
                beforeLines, afterLines = original.splitlines(), current.splitlines()
                blocks = list(difflib.SequenceMatcher(None, beforeLines, afterLines).get_opcodes())
                item['addedBlankLines'] = sum(not line.strip() for tag, a, b, c, d in blocks if tag != 'equal' for line in afterLines[c:d])
                item['deletedBlankLines'] = sum(not line.strip() for tag, a, b, c, d in blocks if tag != 'equal' for line in beforeLines[a:b])
                item['maxLineBytes'] = max((len(line.encode()) for line in current.splitlines()), default=0)
                if not path.endswith('.json'):
                    continue
                new = json.loads(current)
                old = json.loads(original) if original else None
                def count(value):
                    if isinstance(value, dict):
                        return 1 + sum(count(v) for v in value.values())
                    if isinstance(value, list):
                        return 1 + sum(count(v) for v in value)
                    return 1
                snapshots.append(dict(arm=arm, case=case, path=path, bytes=item['afterBytes'], values=count(new), oldValues=count(old) if old else 0, topKeys=list(new) if isinstance(new,dict) else None, fullyParsed=True, beforeAfterEqual=old==new))
            totals[arm][case] = {kind: {key:sum(f[key] for f in files if f['category']==kind) for key in ('added','deleted','churn','net','byteGrowth','addedBlankLines','deletedBlankLines')} for kind in ('production','tests','other')}
    (OUT / 'metricDetails.json').write_text(json.dumps(metrics,indent=2)+'\n')
    (OUT / 'metricTotals.json').write_text(json.dumps(totals,indent=2)+'\n')
    (OUT / 'snapshotAudit.json').write_text(json.dumps(snapshots,indent=2)+'\n')


def controlsExtra():
    case = 'pythonUnicodeGraphFind'
    target = OUT / 'controls' / case
    execute(case+'OriginalFullMaintained', pytests(target, ['tests/test_graph_navigation.py', 'tests/test_coffee_navigation_snapshots.py']), target / 'atlas')
    execute(case+'OriginalCoffeeOnly', pytests(target, ['tests/test_coffee_navigation_snapshots.py', '-k', 'python']), target / 'atlas')


if __name__ == '__main__':
    import sys
    mode = sys.argv[1]
    if mode == 'audit':
        testDiffs()
        audit()
    if mode == 'checks':
        for arm in ARMS:
            fullSnapshots(arm)
        for arm in ARMS:
            generator(arm)
    if mode == 'controls':
        controlsExtra()
