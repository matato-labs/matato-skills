# Tuning research: preScriptEnvironmentLifetime

## Observed production behavior

src/worker/preScript.ts owns one module-global mutex and temporarily overlays the supplied keys in Bun.env and process.env. runTypeScriptPreScript returns module.run() from inside nested try/finally blocks without awaiting its settlement. The finally blocks therefore restore keys and release the mutex while an async run is still pending. A second invocation can enter and affect the first invocation's post-await reads. Separately, the snapshot uses the same empty-string value for an absent key and a present empty key, and restoration deletes both. These are observable production defects, not type-shape validation gaps.

The public callers are src/worker/scheduledJobs/preScript.ts and src/worker/bus/preScript.ts. They supply timezone/storage and sequence prompt overlays. Both return the shared runner result; neither caller can repair premature shared restoration. The existing shell branch already supplies cwd and an isolated child env, concurrently drains stdout/stderr, checks exit status and parses JSON. No shell rewrite or subprocess unification is needed.

## Actual existing-language/API opportunities (not brief instructions)

JavaScript await inside try/finally supplies the required settlement boundary; Promise assimilation by an outer return does not delay finally execution. The existing mutex already provides mutual exclusion, queue order and release ownership. There is no need for a second queue, AsyncLocalStorage, custom scheduler, process-per-TypeScript-script architecture or dependency.

An environment snapshot can express absence exactly as string | undefined, unlike the current Record<string, string> sentinel. The native environment APIs already distinguish undefined from an empty string, and deleting only previously absent supplied keys preserves that difference. Existing restoration loops and the existing finally ownership can be retained. This is a small production fix with real promise-lifetime and value-presence interactions, not an opportunity to replace the worker abstraction.

Existing maintained tests generate TypeScript modules with Bun.write and use temporary skill folders. The scheduled pre-script suite also copies and runs the real data/agent/skills/product-manager/shouldRun.sh with fake local gh/matato executables. The sequence pre-script suite covers prompt/timezone propagation; the scheduled runner and bus suites exercise actual orchestration with installed faux providers rather than live models. These are better owned regression seams than duplicating the external six-scenario oracle.

## Independent behavioral evidence

check.py imports the supplied root's runner, writes isolated modules, and uses native deferred promises plus a small shared control module to observe execution order. It checks async environment reads, serial module evaluation, rejection/recovery, exact empty/absent restoration, synchronous/import/stat failure, JSON values, unrelated writes, shell cwd/env/JSON/error behavior and shell independence while TypeScript is suspended. No source text, LOC, private export or function naming is asserted. Generated modules use unique paths to avoid cross-test module-cache collisions.

Final negative.log: original pinned production exits 1, with 0 passing and 6 failing tests. Failures show restoration before async settlement, premature second invocation, cross-invocation values and loss of an existing empty environment value. The final oracle separately typechecks with the installed compiler (oracleTypes.log, exit 0). This is original-code detection, not mutation coverage; no task implementation was written to make the oracle pass.

Final native.log: seven subprocesses all exit 0. Full existing-project TypeScript check and source ESLint pass; maintained scenarios pass 5 scheduled pre-script + 2 sequence pre-script + 6 scheduled runner + 18 bus + 4 prompt/queue = 35 tests. Exactly two scheduled tests using Bun.serve are not selected. This preserves the no-services rule rather than silently running a local server. Both callers, the shipped shell producer, the fixture factory and existing SQLite migration route are exercised. No checked-in snapshots or snapshot-generation route is affected by this task.

## Scope and viability

Expected production seam: src/worker/preScript.ts; owned regressions should extend the established caller test seams or a focused shared-runner suite, with those existing consumers still run. Public signatures, JsonValue policy, hot-import behavior, script error semantics and shell execution should not change. The existing source file is 196 lines, leaving room for a bounded fix well within the 900-second budget. No benchmark recipe or API choice was placed in brief.txt; the brief states observable requirements only.
