from pathlib import Path
import hashlib
import json

root = Path(__file__).parent
rows = json.loads((root / 'inventory.json').read_text())
summary = []
for row in rows:
    evidence = Path(row['path']) / 'evidence'
    audit = json.loads((evidence / 'audit.json').read_text())
    activation = json.loads((evidence / 'activation.json').read_text())
    proof = json.loads((evidence / 'nativeProof.json').read_text())
    invocation = json.loads((evidence / 'invocation.json').read_text())
    package = json.loads((evidence / 'package.json').read_text())
    integrity = json.loads((evidence / 'integrity.json').read_text())
    # Only public non-profile evidence; no profile or transformed instruction bodies read.
    names = ['changes.patch', 'toolTrace.jsonl', 'activation.json', 'measurement.json', 'finalSummary.txt']
    verified = {name: hashlib.sha256((evidence / name).read_bytes()).hexdigest() == integrity.get(name) for name in names}
    summary.append({
        'label': row['label'], 'case': Path(row['path']).name,
        'agent': row['agent'], 'audit': row['audit'], 'usage': audit['usage'],
        'measurement': json.loads((evidence / 'measurement.json').read_text()),
        'finalSummary': (evidence / 'finalSummary.txt').read_text(),
        'native': {'valid': activation['valid'], 'starts': activation['agentStarts'],
                   'before': activation['beforeAgentStartObservations'],
                   'contexts': activation['requestContextObservations'],
                   'messages': activation['assistantMessages'],
                   'hashesAgree': activation['expectedSha256'] == proof['instructionsSha256'],
                   'allObservationsValid': all(item['valid'] and item['sha256'] == activation['expectedSha256' if item['phase'] == 'before' else 'expectedContextSha256'] for item in activation['observations']),
                   'traceHashMatches': proof['traceSha256'] == hashlib.sha256(Path('/home/leon/workspace/projects/matato-pi/extras/codingSessionV5/scripts/nativeTrace.ts').read_bytes()).hexdigest(),
                   'probeHashMatches': proof['probeSha256'] == hashlib.sha256(Path('/home/leon/workspace/projects/matato-pi/extras/codingSessionV5/scripts/nativeProbe.mjs').read_bytes()).hexdigest(),
                   'fullMode': invocation['environment'].get('PONYTAIL_DEFAULT_MODE') == 'full',
                   'extensions': invocation['argv'][-8:-1], 'packageHash': package['sha256'],
                   'nonProfileFiles': {name: item for name, item in package['files'].items() if name != 'skills/ponytail/SKILL.md'},
                   'boundary': activation['boundary']},
        'publicIntegrity': verified})
(root / 'evidenceSummary.json').write_text(json.dumps(summary, indent=2) + '\n')
checks = [{'check': str(path.relative_to(root)), **json.loads(path.read_text())} for path in sorted((root / 'checks').glob('*/*/*/*.json'))]
(root / 'checkResults.json').write_text(json.dumps(checks, indent=2) + '\n')
lines = []
for row in summary:
    lines.append(f"## {row['label']} {row['case']}")
    lines.append(json.dumps({key: row[key] for key in ['agent', 'audit', 'usage', 'publicIntegrity']}))
    lines.append(row['finalSummary'])
    for category, totals in row['measurement']['totals'].items():
        lines.append(category + ': ' + json.dumps(totals))
    native = row['native']
    lines.append('native: ' + json.dumps({key: value for key, value in native.items() if key not in ['nonProfileFiles', 'extensions']}))
(root / 'evidenceSummary.txt').write_text('\n'.join(lines) + '\n')
print('Saved evidenceSummary.json/.txt and checkResults.json')
