import hashlib
import json
from pathlib import Path

root = Path('/tmp/codingSessionV4')
out = root / 'reviews/tuningTwo'
summary = json.loads((root / 'evidence/tuningTwo/failureSummary.json').read_text())
report = {}
for run in summary['runs']:
    trial = root / 'runs' / run['identity']
    invocationPath = trial / 'invocation.json'
    record = {'recordedStatus': run['resultStatus'], 'runtimeValid': False}
    if not invocationPath.exists():
        record['status'] = 'no agent invocation available'
        report[run['identity']] = record
        continue
    invocation = json.loads(invocationPath.read_text())
    runtime = Path(invocation['environment']['TMPDIR']).parent
    raw = runtime.parent.parent / 'agent.stdout'
    profile = (trial / 'currentProfile.md').read_bytes()
    events = []
    malformed = 0
    for line in raw.read_bytes().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            malformed += 1
    starts = [event for event in events if event.get('type') == 'tool_execution_start']
    ends = [event for event in events if event.get('type') == 'tool_execution_end']
    first = starts[0]
    firstEnd = next(event for event in ends if event['toolCallId'] == first['toolCallId'])
    observed = '\n'.join(block.get('text', '') for block in firstEnd['result']['content'])
    messages = [event['message'] for event in events if event.get('type') == 'message_end' and event['message'].get('role') == 'assistant']
    errors = []
    for event in ends:
        for block in event.get('result', {}).get('content', []):
            for line in block.get('text', '').splitlines():
                if 'quota' in line.lower() or 'no space left' in line.lower():
                    errors.append(line[:500])
    record.update({'rawBytes': raw.stat().st_size, 'rawSha256': hashlib.sha256(raw.read_bytes()).hexdigest(), 'rawMatchesFailureAudit': hashlib.sha256(raw.read_bytes()).hexdigest() == run['profileAudit']['rawStreamSha256'], 'malformedRecords': malformed, 'firstTool': first['toolName'], 'firstPath': first['args'].get('path'), 'completeProfileObserved': profile.decode().strip() in observed, 'profileReadError': firstEnd.get('isError', False), 'profileBytes': len(profile), 'profileSha256': hashlib.sha256(profile).hexdigest(), 'profileSnapshotMatchesFrozen': profile == (root / 'profiles' / (run['arm'] + '.md')).read_bytes(), 'settled': any(event.get('type') == 'agent_settled' and not event.get('aborted', False) for event in events), 'finalStopReason': messages[-1].get('stopReason') if messages else None, 'settings': sorted(set((message.get('provider'), message.get('model'), message.get('thinkingLevel', message.get('providerThinkingLevel'))) for message in messages)), 'promptSha256': hashlib.sha256((trial / 'prompt.txt').read_bytes()).hexdigest(), 'instructionReads': [event['args']['path'] for event in starts if event['toolName'] == 'read' and Path(event['args'].get('path', '')).name in ['AGENTS.md', 'CLAUDE.md']], 'flags': {flag: flag in invocation['argv'] for flag in ['--unshare-all', '--no-session', '--no-context-files', '--no-skills', '--no-mcp', '--no-extensions']}, 'quotaMessages': errors, 'toolStarts': len(starts), 'toolEnds': len(ends)})
    report[run['identity']] = record
(out / 'independentAudit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
