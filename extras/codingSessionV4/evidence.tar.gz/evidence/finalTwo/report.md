# finalTwo execution report

Second predeclared draw, not a replacement or resampling of finalOne. Exactly 16 scheduled identities; ledger 35 → 51. STOP: no further implementations or candidate revisions. No repair, retry, model probe, original-source/shared-dependency/README edit, quality scoring or winner selection.

Frozen original-base preflight reused from finalOne. Same disk-owned writable storage and logical symlink scheme; bounded 64 MiB allocation succeeded. Filesystem headroom recorded; effective Btrfs quota remains unavailable. Frozen caps: agent 900s, acceptance/native 120s. No unsandboxed fallback.

Runtime invocation/profile-read audits: 16/16 of 16. Distinct private configs: 16. Maximum simultaneous trials/agents: 6/6. Draw wall seconds: 1350.564.

| Arm | Case | Agent | Acceptance | Native | Status | Agent seconds |
|---|---|---:|---:|---:|---|---:|
| v3 | pythonConfinedIgnoreFiles | 0 | 0 | 124 | completed | 448.777 |
| v3 | preScriptEnvironmentLifetime | 0 | 0 | 0 | completed | 380.008 |
| v3 | sequenceCreateRecovery | 0 | 0 | 124 | completed | 331.635 |
| v3 | shellBootstrapLocation | 0 | 0 | 0 | completed | 44.606 |
| v2 | pythonConfinedIgnoreFiles | 0 | 0 | 124 | completed | 823.876 |
| v2 | preScriptEnvironmentLifetime | 0 | 0 | 0 | completed | 441.154 |
| v2 | sequenceCreateRecovery | 0 | 0 | 124 | completed | 309.172 |
| v2 | shellBootstrapLocation | 0 | 0 | 0 | completed | 50.384 |
| ponytail | pythonConfinedIgnoreFiles | 0 | 0 | 124 | completed | 598.435 |
| ponytail | preScriptEnvironmentLifetime | 0 | 0 | 0 | completed | 277.345 |
| ponytail | sequenceCreateRecovery | 0 | 0 | 124 | completed | 501.457 |
| ponytail | shellBootstrapLocation | 0 | 0 | 0 | completed | 48.712 |
| candidateTwo | pythonConfinedIgnoreFiles | 0 | 0 | 0 | completed | 603.549 |
| candidateTwo | preScriptEnvironmentLifetime | 0 | 0 | 0 | completed | 316.676 |
| candidateTwo | sequenceCreateRecovery | 0 | 0 | 0 | completed | 405.829 |
| candidateTwo | shellBootstrapLocation | 0 | 0 | 0 | completed | 51.177 |

Exact invocation spelling difference: this coordinator used /usr/bin/python3 rather than finalOne /usr/bin/python; both resolve to the same hashed /usr/bin/python3.14. All 16 invocations otherwise match finalOne after normalizing fresh draw/private paths. No launcher bytes or runtime settings changed.

Missing observations remain unavailable, never inferred as exit0. Original timeout/failure records remain authoritative; no longer diagnostics executed here. Agent completion is separate from acceptance/native status. Exact invocations, stage timings/timeouts/exits, snapshotted profile bytes/hashes and successful observed reads are retained in run records and runtimeAudits.json.

Integrity: see integrity.json and before/after inventories for frozen inputs (including extensionless launchers), executables, original source/Git metadata and historical outputs. CandidateTwo remains 2630 bytes / 6efa072c53b7e83aae7a17f4f60a45efd113cd8dc927c1c1ebf815ec3cd25643.

Independent review required. No implementation quality/completeness winner is asserted. Frozen suffix classification labels extensionless setup as other: reviewer must classify setup as production symmetrically, retaining original metrics. Raw credentials/streams stay private; publicationReady false.
