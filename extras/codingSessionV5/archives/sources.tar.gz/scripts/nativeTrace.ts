import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import type { ExtensionAPI } from '@earendil-works/pi-coding-agent';

const hash = (text: string): string => createHash('sha256').update(text).digest('hex');

// Separate observer: never alters instructions, tools, mode, or provider payloads.
export function registerNativeTrace(pi: ExtensionAPI, expected: string): void {
  let run = 0;
  pi.on('before_agent_start', (event) => {
    run += 1;
    const actual = event.systemPromptOptions.sections.ponytail ?? '';
    pi.appendEntry('v5NativeActivation', {
      phase: 'before', run, sha256: hash(actual),
      valid: actual === expected && event.systemPromptOptions.appendSystemPrompt === '',
    });
  });
  pi.on('context_with_system', (event) => {
    let actual = '';
    for (const message of event.messages) {
      if (message.role !== 'system') continue;
      const section = message.sections?.ponytail;
      if (section !== undefined) actual = section ?? '';
    }
    pi.appendEntry('v5NativeActivation', {
      phase: 'context', run, sha256: hash(actual),
      valid: run > 0 && actual === `<ponytail>\n${expected}\n</ponytail>`,
    });
  });
}

export default function nativeTrace(pi: ExtensionAPI): void {
  registerNativeTrace(pi, readFileSync('/experiment/nativeInstructions.txt', 'utf8'));
}
