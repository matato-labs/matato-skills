"""Local runner-only checks. Synthetic repository; no implementation/model requests."""
import json
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile

from auditTrial import audit
from measureTrial import capture, category, digest, git
from providerProxy import startProxy
from runTrial import agentArgs
from sandboxTrial import Sandbox, currentProfile, environment, execute, proxyPath, root, sandbox, shell


def checkMeasurement(repo: Path, worktree: Path, folder: Path, private: Path) -> None:
    (worktree / 'main.go').write_text('package main\n\nfunc main() { }\n')
    (worktree / 'tool.sh').write_text('#!/bin/sh\necho ok\n')
    (worktree / 'sample.rs').write_text('fn sample() {}\n')
    (worktree / 'tests').mkdir()
    (worktree / 'tests/check.py').write_text('assert True\n')
    (worktree / 'tests/fixtures').mkdir()
    (worktree / 'tests/fixtures/file.bin').write_bytes(b'a\0b\n')
    (worktree / 'depLink').symlink_to(repo, target_is_directory=True)
    base = git(repo, ['rev-parse', 'HEAD']).decode().strip()
    result = capture(worktree, folder, private, base, ['main.go'])
    assert len(result['files']) == 5, result
    assert result['excludedDependencyLinks'] == ['depLink'], result
    assert category('lib/new.rs') == 'production'
    assert category('lib/new.go') == 'production'
    assert category('scripts/new.sh') == 'production'
    assert category('tests/fixtures/data.json') == 'fixtures'
    assert category('tests/__snapshots__/a.snap') == 'snapshots'
    main = next(item for item in result['files'] if item['path'] == 'main.go')
    assert main['added'] == 2 and main['deleted'] == 0, main
    assert main['normalizedAdded'] == 1 and main['normalizedDeleted'] == 0, main
    assert 'tool.sh' in (folder / 'changes.patch').read_text()
    assert git(worktree, ['diff', '--cached', '--name-only']) == b''


def checkAudit(folder: Path, private: Path, profile: bytes) -> None:
    raw = private / 'synthetic.jsonl'
    events = [
        {'type': 'tool_execution_start', 'toolCallId': 'r', 'toolName': 'read',
         'args': {'path': str(currentProfile)}},
        {'type': 'tool_execution_end', 'toolCallId': 'r', 'toolName': 'read',
         'result': {'content': [{'type': 'text', 'text': profile.decode()}]}, 'isError': False},
        {'type': 'tool_execution_start', 'toolCallId': 'b', 'toolName': 'bash',
         'args': {'command': 'echo fixtureSecretValue'}},
        {'type': 'message_end', 'message': {'role': 'assistant',
         'content': [{'type': 'text', 'text': 'Done fixtureSecretValue'}],
         'provider': 'openai-codex', 'model': 'gpt-6.1-sol', 'thinkingLevel': 'high',
         'stopReason': 'stop'}}, {'type': 'agent_settled', 'aborted': False}]
    raw.write_text(''.join(json.dumps(event) + '\n' for event in events))
    result = audit(raw, folder, profile, ['fixtureSecretValue'])
    assert result['firstToolIsProfileRead'] and result['profileContentsObserved'], result
    assert result['observedModels'] == ['openai-codex/gpt-6.1-sol']
    assert result['settled'] and not result['aborted'] and result['finalStopReason'] == 'stop'
    assert 'fixtureSecretValue' not in (folder / 'toolTrace.jsonl').read_text()
    assert 'fixtureSecretValue' not in (folder / 'finalSummary.txt').read_text()


def checkProxy(spec: Sandbox, private: Path) -> None:
    endpoint = private / 'proxy.sock'
    server = startProxy(endpoint)
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.connect(str(endpoint))
            client.sendall(b'CONNECT 127.0.0.1:8000 HTTP/1.1\r\n\r\n')
            assert client.recv(1024).startswith(b'HTTP/1.1 403')
        stage = spec['runtime'] / 'proxy'
        stage.mkdir()
        command = 'output=$(curl -sS --connect-timeout 3 https://127.0.0.1:8000 2>&1) && exit 1; printf "%s" "$output" | grep 403'
        argv = sandbox(spec, stage, True, endpoint) + [sys.executable,
            str(root / 'providerProxy.py'), str(proxyPath), '/bin/bash', '--noprofile',
            '--norc', '-euc', command]
        result = execute(argv, spec['worktree'], environment(stage, spec['config']), private, 'proxy', 20)
        assert result['exit'] == 0, Path(result['stderr']).read_text() + Path(result['stdout']).read_text()
    finally:
        server.shutdown()
        server.server_close()


def checkSandbox(spec: Sandbox, private: Path) -> None:
    command = f'''test ! -e /tmp/codingSessionV3
 test ! -e /tmp/codingSessionV4/research
 test ! -e /home/leon/.pi/agent/auth.json
 test ! -e /tmp/codingSessionV4/profiles/v3.md
 ! touch {spec['repo']}/forbidden
 ! touch {spec['common']}/forbidden
 ! touch {spec['oracle']}/forbidden
 ! touch /tmp/forbidden
 printf isolated > "$TMPDIR/testFile"
 printf changed > runnerCheck
 test -r {spec['oracle']}/manifest.json
'''
    result = shell(spec, 'sandbox', command, private, 20)
    assert result['exit'] == 0, Path(result['stderr']).read_text()
    stage = spec['runtime'] / 'piVersion'
    stage.mkdir()
    argv = sandbox(spec, stage, True) + [str(spec['pi']), '--version']
    result = execute(argv, spec['worktree'], environment(stage, spec['config']), private, 'piVersion', 20)
    assert result['exit'] == 0, Path(result['stderr']).read_text()
    assert Path(result['stdout']).read_text().strip() == '1.1.0'
    stage = spec['runtime'] / 'piCatalog'
    stage.mkdir()
    argv = sandbox(spec, stage, True) + agentArgs(spec['pi'], spec['profile']) + [
        '--list-models', 'gpt-6.1-sol']
    result = execute(argv, spec['worktree'], environment(stage, spec['config']), private, 'piCatalog', 20)
    assert result['exit'] == 0, Path(result['stderr']).read_text()
    assert 'gpt-6.1-sol' in Path(result['stdout']).read_text(), Path(result['stdout']).read_text()
    stage = spec['runtime'] / 'profile'
    stage.mkdir()
    argv = sandbox(spec, stage, True) + ['/bin/bash', '--noprofile', '--norc', '-euc',
        f'cmp {currentProfile} {spec["profile"]}; ! touch {spec["config"]}/auth.json']
    result = execute(argv, spec['worktree'], environment(stage, spec['config']), private, 'profile', 20)
    assert result['exit'] == 0, Path(result['stderr']).read_text()


def main() -> None:
    checks = root / 'selfChecks'
    checks.mkdir(exist_ok=True)
    folder = Path(tempfile.mkdtemp(prefix='runner', dir=checks))
    repo, worktree, private = folder / 'source', folder / 'owned', folder / 'private'
    for path in [repo, private, folder / 'oracle', private / 'config', private / 'runtime']:
        path.mkdir(parents=True, exist_ok=True)
    private.chmod(0o700)
    subprocess.run(['git', 'init', '-q', str(repo)], check=True)
    (repo / 'main.go').write_text('package main\n')
    subprocess.run(['git', '-C', str(repo), 'add', '.'], check=True)
    subprocess.run(['git', '-C', str(repo), '-c', 'user.name=Runner Check',
                    '-c', 'user.email=runner@invalid', '-c', 'commit.gpgsign=false',
                    '-c', 'core.hooksPath=/dev/null', 'commit', '-qm', 'Synthetic runner fixture'], check=True)
    subprocess.run(['git', '-C', str(repo), '-c', 'core.hooksPath=/dev/null', 'worktree',
                    'add', '--detach', str(worktree), 'HEAD'], check=True, capture_output=True)
    profile = folder / 'profile.md'
    profile.write_text('Synthetic runner profile. Not an experimental arm.\n')
    (private / 'auth.json').write_text('{"openai-codex":{"type":"oauth","access":"dummy-not-a-credential","refresh":"dummy-not-a-credential","expires":4102444800000}}')
    (private / 'auth.json').chmod(0o400)
    (folder / 'oracle/manifest.json').write_text('{"cases":[]}\n')
    pi = shutil.which('pi')
    assert pi is not None
    spec: Sandbox = {'repo': repo, 'worktree': worktree, 'common': repo / '.git',
        'oracle': folder / 'oracle', 'runtime': private / 'runtime', 'profile': profile,
        'profileSnapshot': profile, 'config': private / 'config', 'auth': private / 'auth.json',
        'dependencies': [], 'pi': Path(pi).resolve()}
    checkSandbox(spec, private)
    (worktree / 'runnerCheck').unlink()
    measurement, trace = folder / 'measurement', folder / 'trace'
    measurement.mkdir()
    trace.mkdir()
    checkMeasurement(repo, worktree, measurement, private)
    checkAudit(trace, private, profile.read_bytes())
    checkProxy(spec, private)
    (folder / 'result.json').write_text(json.dumps({'status': 'passed', 'implementationLaunches': 0,
        'checks': ['sandbox', 'Pi version', 'offline built-in model catalog', 'read-only auth/profile',
                   'metrics/new Go Rust shell sources', 'profile audit/redaction', 'proxy denies local services'],
        'providerNetworkRequestTested': False}, indent=2) + '\n')
    print(folder)


if __name__ == '__main__':
    main()
