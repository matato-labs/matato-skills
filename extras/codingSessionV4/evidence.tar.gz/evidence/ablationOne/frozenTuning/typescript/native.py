import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

caseFolder = Path(__file__).resolve().parent
caseRoot = Path(sys.argv[1]).resolve()
commands = [['bun', 'node_modules/typescript/bin/tsc', '--noEmit'],
 ['bun', 'node_modules/eslint/bin/eslint.js', 'src/worker/preScript.ts'],
 ['bun',
  'test',
  'src/worker/scheduledJobs/preScript.test.ts',
  '-t',
  'runs a TypeScript pre-script module|runs a shell pre-script|runs the product-manager|throws '
  'when a pre-script|throws when a TypeScript'],
 ['bun', 'test', 'src/worker/bus/preScript.test.ts'],
 ['bun', 'test', 'src/worker/scheduledJobs/runner.test.ts'],
 ['bun', 'test', 'src/worker/bus/bus.test.ts'],
 ['bun',
  'test',
  'src/worker/scheduledJobs/prompt.test.ts',
  'src/worker/scheduledJobs/queue.test.ts']]
exitCode = 0
with tempfile.TemporaryDirectory(prefix='nativeRuntime', dir=caseFolder) as scratch:
    environment = {'PATH': os.environ['PATH'], 'HOME': scratch, 'TMPDIR': scratch,
                   'CI': 'true', 'NO_COLOR': '1'}
    for command in commands:
        started = time.monotonic()
        print('cwd:', caseRoot, flush=True)
        print('command:', repr(command), flush=True)
        result = subprocess.run(command, cwd=caseRoot, env=environment, timeout=120)
        print('exit:', result.returncode, 'seconds:', round(time.monotonic() - started, 3), flush=True)
        exitCode = max(exitCode, result.returncode)
sys.exit(exitCode)
