import hashlib
import json
from pathlib import Path

root = Path('/tmp/codingSessionV4')
output = root / 'reviews/ablationOne'
report = {}
profiles = {}
for arm in ['v3', 'reuseAblation']:
    for case in ['pythonConfinedIgnoreFiles', 'preScriptEnvironmentLifetime']:
        trial = root / 'runs/ablationOne' / arm / case
        profile = (trial / 'currentProfile.md').read_bytes()
        profiles[arm] = profile
        invocation = json.loads((trial / 'invocation.json').read_text())
        agent = json.loads((trial / 'agent.json').read_text())
        raw = Path(agent['stdout'])
        events = [json.loads(line) for line in raw.read_bytes().splitlines()]
        starts = [event for event in events if event['type'] == 'tool_execution_start']
        first = starts[0]
        result = next(event for event in events if event['type'] == 'tool_execution_end' and event['toolCallId'] == first['toolCallId'])
        observed = '\n'.join(block.get('text', '') for block in result['result']['content'])
        messages = [event['message'] for event in events if event['type'] == 'message_end' and event['message']['role'] == 'assistant']
        settings = sorted(set((message.get('provider'), message.get('model'), message.get('thinkingLevel', message.get('providerThinkingLevel'))) for message in messages))
        localInstructions = [event['args']['path'] for event in starts if event['toolName'] == 'read' and Path(event['args'].get('path', '')).name in ['AGENTS.md', 'CLAUDE.md']]
        record = {'firstTool': first['toolName'], 'firstPath': first['args'].get('path'), 'completeProfileObserved': profile.decode().strip() in observed, 'profileReadError': result.get('isError', False), 'settings': settings, 'settled': any(event['type'] == 'agent_settled' and not event.get('aborted', False) for event in events), 'finalStopReason': messages[-1].get('stopReason'), 'localInstructionReads': localInstructions, 'rawSha256Matches': hashlib.sha256(raw.read_bytes()).hexdigest() == json.loads((trial / 'profileAudit.json').read_text())['rawStreamSha256'], 'privateConfigurationPath': invocation['environment']['PI_CODING_AGENT_DIR'], 'isolationFlagsPresent': all(flag in invocation['argv'] for flag in ['--unshare-all', '--no-session', '--no-context-files', '--no-skills', '--no-mcp', '--no-extensions'])}
        assert record['completeProfileObserved'] and not record['profileReadError'] and record['rawSha256Matches'] and record['isolationFlagsPresent']
        report[f'{arm}/{case}'] = record
sentence = b'Share reusable results at their common lifetime. '
assert profiles['v3'].count(sentence) == 1
assert profiles['v3'].replace(sentence, b'') == profiles['reuseAblation']
report['profileControl'] = {'onlyChange': sentence.decode(), 'beforeBytes': len(profiles['v3']), 'afterBytes': len(profiles['reuseAblation'])}
(output / 'independentAudit.json').write_text(json.dumps(report, indent=2) + '\n')
print('Four raw streams independently verified; exact single-sentence deletion verified.')
