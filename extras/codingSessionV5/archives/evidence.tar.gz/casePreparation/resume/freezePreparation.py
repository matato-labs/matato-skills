"""Create new preparation reports only; existing briefs and oracles stay unchanged."""
import json
from pathlib import Path
import sys

cases = Path('/home/leon/workspace/projects/matato-pi/extras/codingSessionV5/cases')
cache = Path(__file__).resolve().parent
sys.path.insert(0, str(cases))
from verifyPreparation import dependencyRecord, digest, fileHash, fingerprint, load, sourceRecord


def save(path: Path, value) -> None:
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2) + '\n')


def originalRecords():
    records = {}
    for name, before in load(cache / 'sourceBefore.json').items():
        expected = {key: value for key, value in before.items() if key != 'files'}
        expected.update(trackedFilesSha256=fingerprint(before['files']), trackedFiles=len(before['files']))
        assert sourceRecord(Path(before['repo'])) == expected, name
        records[name] = expected
    other = load(cache / 'otherV5Final.json')
    for name, expected in other.items():
        assert fileHash(cases.parent / name) == expected, name
    return {'repositories': records, 'otherV5Files': other,
            'externalOtherV5Changes': load(cache / 'externalHarnessChanges.json')}


def prepareCase(folder: str, assertionMarkers: list[str], passingMarkers: dict[str, str], counts):
    path = cases / folder
    case = load(path / 'manifest.json')['cases'][0]
    old = load(cache / 'before' / folder / 'manifest.json')['cases'][0]
    assert {key: value for key, value in case.items() if key not in ('setupCommands', 'inputPaths', 'dependencyPaths')} == {
        key: value for key, value in old.items() if key not in ('setupCommands', 'inputPaths', 'dependencyPaths')}
    preserved = {}
    for name in ['brief.txt', 'commands.json', 'research.md', *[Path(name).name for name in case['inputPaths'] if Path(name).name not in ('commands.json', 'runCheck.py')]]:
        assert (path / name).read_bytes() == (cache / 'before' / folder / name).read_bytes(), name
        preserved[name] = fileHash(path / name)
    source = load(path / 'sourcePins.json')
    assert {key: value for key, value in source.items() if key != 'preparationPins'} == load(cache / 'before' / folder / 'sourcePins.json')
    names = ['brief.txt', 'manifest.json', 'research.md', 'sourcePins.json', *[Path(name).name for name in case['inputPaths']]]
    pins = {'artifacts': {name: {'sha256': fileHash(path / name), 'bytes': (path / name).stat().st_size}
                          for name in names},
            'inputFiles': [Path(name).name for name in case['inputPaths']],
            'dependencies': {name: dependencyRecord(Path(name)) for name in case['dependencyPaths']},
            'preservedArtifacts': preserved, 'briefStringUnchanged': case['brief'] == old['brief']}
    save(path / 'preparationPins.json', pins)
    evidence = Path((cache / f'{folder}Harness.log').read_text().strip())
    result = load(evidence / 'result.json')
    assert result['checks'] == {'acceptance': 1, 'native': 0} and not result['modelLaunched']
    replay = load(cache / f'{folder}Replay.log')
    assert replay['integrity'] == 'passed' and replay['measurement'] == 'reproduced'
    report = {'ready': True, 'runner': str(cases.parent / 'scripts/runTrial.py'),
              'command': ['--root', '/home/leon/.cache/codingSessionV5/harness/casePreparation', 'originals', str(path / 'manifest.json')], 'harnessExit': 0,
              'runnerSha256': fileHash(cases.parent / 'scripts/runTrial.py'),
              'harnessInventorySha256': fingerprint(load(cache / 'otherV5Final.json')),
              'manifestSha256': fileHash(path / 'manifest.json'),
              'sourcePinsSha256': fileHash(path / 'sourcePins.json'),
              'preparationPinsSha256': fileHash(path / 'preparationPins.json'),
              'evidence': str(evidence), 'integritySha256': fileHash(evidence / 'integrity.json'),
              'status': result['status'], 'checks': result['checks'],
              'positiveControlLabel': f"setup{len(case['setupCommands']) - 1}", 'positiveControlExit': 0,
              'assertionMarkers': assertionMarkers, 'passingMarkers': passingMarkers,
              'counts': counts, 'modelLaunches': 0, 'actualAuthRead': False,
              'replay': {'log': str(cache / f'{folder}Replay.log'), 'sha256': fileHash(cache / f'{folder}Replay.log'), **replay},
              'sourceChanges': 'none; TypeScript setup adds only the node_modules dependency symlink',
              'limitation': 'Original negative and passing compatibility controls only; no candidate fix or model trial.'}
    save(path / 'controlReport.json', report)
    return {'manifest': f'{folder}/manifest.json', 'ready': True,
            'manifestSha256': report['manifestSha256'], 'sourcePinsSha256': report['sourcePinsSha256'],
            'controlReport': f'{folder}/controlReport.json', 'controlReportSha256': fileHash(path / 'controlReport.json')}


save(cases / 'originalPins.json', originalRecords())
entries = {}
entries['workspaceRoots'] = prepareCase('workspaceRoots', [
    "(fail) does not inherit a parent checkout's origin for ordinary children",
    '(fail) a bare repository is not a usable working checkout', 'error: expect(received).toEqual(expected)',
    ' 2 pass', ' 2 fail'], {'setup5': ' 2 pass\n 0 fail', 'native': ' 2 pass\n 0 fail'},
    {'acceptanceFailed': 2, 'acceptancePassed': 2, 'positivePassed': 2, 'nativePassed': 2})
entries['unseenEdges'] = prepareCase('unseenEdges', [
    'AssertionError: unique-edge budget must preserve deterministic BFS evidence',
    'AssertionError: already included evidence is not an omitted-edge boundary', '4 failed, 1 passed'],
    {'setup4': '1 passed, 4 deselected', 'native': '59 passed'},
    {'acceptanceFailed': 4, 'acceptancePassed': 1, 'positivePassed': 1, 'nativePassed': 59})
entries['downloadFailures'] = prepareCase('downloadFailures', [
    'AssertionError: devpodHttp falsely reported success', 'AssertionError: devpodTransport falsely reported success',
    'AssertionError: devpodInstall falsely reported success', 'AssertionError: sdkHttp falsely reported success',
    '7 failed, 4 passed'], {'setup5': '3 passed, 8 deselected'},
    {'acceptanceFailed': 7, 'acceptancePassed': 4, 'positivePassed': 3, 'nativePassed': None,
     'nativeCoverage': 'Bash syntax only, not a behavioral suite'})
entries['holdout'] = prepareCase('holdout', [
    '(fail) removed and replaced schedule callbacks cannot launch stale work',
    '(fail) a failed replacement leaves current callbacks live and discarded candidates inert',
    'error: expect(received).toEqual(expected)', ' 1 pass', ' 2 fail'],
    {'setup5': ' 1 pass\n 0 fail', 'native': ' 6 pass\n 0 fail'},
    {'acceptanceFailed': 2, 'acceptancePassed': 1, 'positivePassed': 1, 'nativePassed': 6})
proposal = load(cache / 'before/catalog.json')
proposal['schema'] = 'V5 individual manifests: immutable inputPaths and explicit offline dependencyPaths'
for entry, folder in zip(proposal['development'], ['workspaceRoots', 'unseenEdges', 'downloadFailures']):
    entry.update(entries[folder])
proposal['holdout'] = entries['holdout']
save(cache / 'catalogProposal.json', proposal)
print('New pins and per-case controls written; requirements unchanged.')
