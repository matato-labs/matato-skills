#!/usr/bin/env python3
"""Additional immutable embedded-data overlays against public LoadISINs."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

repo = Path(sys.argv[1]).resolve()
first = {"Isin": " ID ", "Name": 'comma, quote"\nname', "Currency": " EUR "}
fixtures = [
    ("recordHeaderAndWhitespace", '\r\n\n"long\r\nheader",two\r\n ID ,"comma, quote""\r\nname", EUR \r\n', 2, [first], False),
    ("bareQuote", 'header\nID,na"me,EUR\n', 1, [], True),
    ("trailingAfterQuote", 'header\nID,"name"extra,EUR\n', 1, [], True),
    ("leadingSpaceBeforeQuote", 'header\nID, "name",EUR\n', 1, [], True),
    ("whitespaceIsAField", 'header\n \n', 1, [], True),
    ("blankOnly", '\r\n\n\r\n', 100, [], False),
    ("zeroMalformedHeader", 'bad"header', 0, [], False),
    ("negativeMalformedHeader", 'bad"header', -1, [], False),
    ("wideSuffixOutsidePrefix", 'header\nID,one,EUR\nID,two,USD,extra\n', 1,
     [{"Isin": "ID", "Name": "one", "Currency": "EUR"}], False),
    ("wideSuffixInsidePrefix", 'header\nID,one,EUR\nID,two,USD,extra\n', 2, [], True),
    ("largeQuotedRecordAndMalformedTail", 'header\nID,"' + 'x' * 100000 + '\nend",EUR\nID,"unterminated', 1,
     [{"Isin": "ID", "Name": 'x' * 100000 + '\nend', "Currency": "EUR"}], False),
    ("emptyFieldsAndNoNewline", 'header\n,,', 1, [{"Isin": "", "Name": "", "Currency": ""}], False),
]
test = '''package data
import ("encoding/json"; "os"; "reflect"; "testing")
func TestSupplementalCSV(t *testing.T) {
 var want struct { Limit int; Rows []Isin; WantError bool }
 if err := json.Unmarshal([]byte(os.Getenv("csvExpectation")), &want); err != nil { t.Fatal(err) }
 got, err := LoadISINs(want.Limit)
 if want.WantError { if err == nil { t.Fatalf("expected error, got %v", got) }; t.Logf("error type=%T: %v", err, err); return }
 if err != nil { t.Fatal(err) }
 if len(got)==0 && len(want.Rows)==0 { return }
 if !reflect.DeepEqual(got,want.Rows) { t.Fatalf("record mismatch: counts=%d/%d",len(got),len(want.Rows)) }
}
'''
failures = []
with tempfile.TemporaryDirectory(prefix="supplementalCSV") as d:
    d = Path(d)
    (d / "supplemental_test.go").write_text(test)
    overlay = d / "overlay.json"
    overlay.write_text(json.dumps({"Replace": {
        str(repo / "commons/data/supplemental_test.go"): str(d / "supplemental_test.go"),
        str(repo / "commons/data/isins.csv"): str(d / "isins.csv"),
    }}))
    for name, text, limit, rows, error in fixtures:
        print("\n===", name, "===", flush=True)
        (d / "isins.csv").write_bytes(text.encode())
        env = {**os.environ, "GOWORK": "off", "GOPROXY": "off", "GOSUMDB": "off",
               "csvExpectation": json.dumps(dict(Limit=limit, Rows=rows, WantError=error))}
        p = subprocess.run(["go", "test", "-overlay", str(overlay), "./data", "-run", "^TestSupplementalCSV$", "-count=1", "-v"],
                           cwd=repo / "commons", env=env, timeout=60)
        if p.returncode:
            failures.append(name)
print("Failed scenarios:", failures)
sys.exit(bool(failures))
