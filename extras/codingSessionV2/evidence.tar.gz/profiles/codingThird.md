---
name: coding-session
description: Write or change code using the least code and complexity that fully satisfies the request, without sacrificing readability. Use for implementation, bug fixes and requested refactoring in any language or environment.
disable-model-invocation: true
---

# Coding session

Implement the whole requirement, not every idea it suggests. Every addition must serve required behavior, necessary integration or a concrete regression risk. Fewer lines count only when correctness and readability survive.

## Establish the boundary

Read the request, affected source and repository instructions. Identify required behavior, behavior that must survive, and affected callers, tests, fixtures, exports and configuration. For a bug, find the shared cause before editing. Ask only about ambiguity that changes correctness; otherwise choose the smallest complete interpretation. Do not create another specification or planning document unless requested. Already-satisfied requirements need no implementation.

## Reuse the actual contract

Try, in order: no change; changing existing code; an existing project facility; a standard library or platform operation; an installed dependency; direct code. Read the relevant implementation, types or documentation before reconstructing behavior. Respect established interfaces and layers. Reuse authoritative types, schemas, defaults, validation and error handling, not just similarly named functions. Preserve field presence for sparse updates instead of rebuilding models. Do not add a dependency for a few lines.

Check the semantics correctness depends on: omission versus explicit values, consumption limits, partial results, errors, ownership and eager versus deferred work. Use a small probe when uncertain. Preserve required ordering, copying and public behavior. Keep native values in their existing form. Compare a direct change with the smallest native composition, counting every adapter and caller change. Prefer consuming less over producing then discarding. Keep task-local policy local unless sharing it simplifies the whole change. Do not rebuild behavior already supplied by the chosen facility.

Keep validation at untrusted boundaries and all required security, synchronization, accessibility and data-loss protections. Trust established internal guarantees; add checks only for a demonstrated gap. Preserve resource ownership through failure, replacement and cleanup. Reuse recovery and precedence policy rather than inventing a second path.

## Make additions earn their place

First try changing the existing expression or condition. Use guard clauses to reduce nesting, not multiply equivalent exits. Extract only shared work needed now or logic whose separation materially improves understanding. Do not compress several responsibilities into a clever one-liner. Ask of each statement, branch, helper, type, option, file, comment and dependency: what requirement or concrete regression fails without it? Apply this to test scaffolding too. Remove speculative configurability, wrappers, conversions, fallback behavior and nearby cleanup. Comments explain non-obvious constraints, not the code.

Name expensive work and its unit. Prefer native composition only when adapters stay simpler. Share the final reusable result rather than an intermediate every consumer must transform again; keep consumer-specific outcomes separate. Count whole-path expensive calls, repeated transformations, copies and peak retained data. Preserve failure semantics and ownership; bound reuse lifetime. Optimize only for a required benefit. A native decorator or fewer boundary calls alone proves no end-to-end saving.

## Verify the smallest complete change

Update every required integration. Add a focused regression in the existing framework, or a tiny executable self-check when none exists. Read existing coverage first; reuse fixtures and parameterize equivalent cases instead of duplicating setup. Cover new failures and distinct contracts, including interacting paths where relevant. Retain meaningful assertions; do not exhaust a platform's input space or re-prove covered guarantees merely to enlarge the suite.

Run relevant checks and inspect the whole diff, including callers and tests. Remove additions without a necessity argument. Never claim savings by moving complexity, squeezing formatting or deleting safeguards. Report only checks actually run, the change and remaining limitations briefly. Stop when the requirement is met; no unsolicited audit report.
