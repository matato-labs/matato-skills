import hashlib
import json
from pathlib import Path
import re

root = Path('/tmp/codingSessionV3')
review = root / 'reviews/roundTwo'
source = (review / 'runReview.py').read_text().split('\ncases = {}')[0]
exec(source)
results = [json.loads(path.read_text()) for path in sorted((root / 'runs/tuningTwo').glob('*/*/result.json'))]
before = json.loads((review / 'before.json').read_text())
current = fingerprint()
assert before == current
integrity = dict(unchangedAfterSupplementalChecks=True, files=len(before), sourceOutputs=len(results))
(review / 'finalIntegrity.json').write_text(json.dumps(integrity, indent=2) + '\n')
commands = []
for name in ['commands.json', 'extraCommands.json', 'maintenanceCommands.json']:
    commands += json.loads((review / name).read_text())
for record in commands:
    output = Path(record['output']).read_bytes()
    assert record['sha256'] == hashlib.sha256(output).hexdigest()
    record['summary'] = [line for line in output.decode().splitlines()
                         if re.search(r'\d+ (passed|failed|pass|fail)|Result:|Ran \d+ tests|errors, \d+ warnings|New unicode_find|generator write targets', line)]
metrics = json.loads((review / 'metrics.json').read_text())
for value in metrics['aggregates'].values():
    value['combined'] = {key: value['production'][key] + value['tests'][key]
                         for key in value['production']}
profiles = {name: dict(bytes=(root / 'profiles' / (name + '.md')).stat().st_size,
                       sha256=hashlib.sha256((root / 'profiles' / (name + '.md')).read_bytes()).hexdigest())
            for name in ['main', 'pr', 'ponytail', 'candidateTwo']}
proposal = review / 'proposedSkill.md'
outputs = []
for result in results:
    patch = root / 'runs/tuningTwo' / result['arm'] / result['case'] / 'changes.patch'
    checksum = hashlib.sha256(patch.read_bytes()).hexdigest()
    assert result['patchSha256'] == checksum
    outputs.append(dict(arm=result['arm'], case=result['case'], base=result['base'], worktree=result['worktree'], patchSha256=checksum))
expectedNegatives = [record['label'] for record in commands if 'BaseNegative' in record['label'] or record['label'].startswith('candidateSchemaOriginal')]
failed = [dict(label=record['label'], exit=record['exit']) for record in commands if record['exit']]
assert len(commands) == 68
assert len(expectedNegatives) == 7
assert len(failed) == 8
assert all(record['exit'] == 0 for record in commands if record['label'].endswith(('Acceptance', 'Native', 'Maintained', 'PythonIntegration', 'PythonStandaloneConsumer', 'PythonTypesSourceAndMaintained', 'PythonLint', 'MaintainedTestLint')))
evidence = dict(
    review='Independent coding-session V3 round two',
    decision='Do not freeze candidateTwo as a demonstrated size winner; all focused executable behavior checks pass, regeneration gap remains.',
    scope=dict(draw='tuningTwo', sourceOutputs=12, languages=3,
               manifestsRead=[str(root / 'research' / language / 'tuning/manifest.json') for language in ['python', 'typescript', 'elixir']],
               aggregateManifestsRead=False, validationOrReserveOrFreezeOpened=False,
               priorReviewerReserveBriefExposureDisclosed=True, reserveImplementationsNotInspected=True,
               implementationRepairs=False, cherryPicking=False, mutationsRun=False,
               noNetworkInstallsServicesOrApplicationStartup=True),
    integrity=integrity,
    historicalIntegrity=json.loads((review / 'historicalIntegrity.json').read_text()),
    outputs=outputs,
    metrics=metrics,
    profileSizes=profiles,
    candidateDeltas={arm: {kind: metrics['aggregates']['candidateTwo'][kind]['churn'] - metrics['aggregates'][arm][kind]['churn']
                            for kind in ['production', 'tests', 'combined']} for arm in ['main', 'pr', 'ponytail']},
    checks=dict(commandCount=len(commands), exitZero=sum(record['exit'] == 0 for record in commands),
                timeouts=sum(record['exit'] == 124 for record in commands),
                frozenAcceptancePassed=12, manifestNativePassed=12, maintainedSuitesPassed=12,
                sharedPythonFixtureConsumerPassed=4, additionalStandalonePythonConsumersPassed=4,
                sharedIntegrationCommandExecutedSeparately=True,
                typesAndLint='Native TS tsc and production ESLint plus new-test ESLint pass all arms. Scoped Python Ruff and source/maintained Pyright pass all arms.',
                retainedNonzeroCommands=failed,
                expectedOriginalProductionNegativeControls=expectedNegatives,
                infrastructureFailure=dict(label='candidateTwoPythonTypes', exit=4,
                                           cause='Pyright converts the literal backslash in the fixture filename to a path separator before analysis.',
                                           resolution='Rechecked all arms with consistent changed production/helper/maintained-test scope, excluding fixture samples; no implementation changes.'),
                commands=commands),
    maintainedCounts=dict(main=dict(python=64, typescript=38, elixir=6), pr=dict(python=65, typescript=39, elixir=6),
                          ponytail=dict(python=67, typescript=31, elixir=6), candidateTwo=dict(python=61, typescript=40, elixir=6)),
    originalProductionControls=dict(python=dict(failed=3, passed=58), pythonCoffeeOnly=dict(failed=1, passed=14),
                                    typescript=dict(failed=14, passed=26), elixir=dict(failed=2, passed=4),
                                    originalOrderOnly=dict(failed=1, passed=5), originalCpuOnly=dict(failed=1, passed=5), originalPlayerOnly=dict(failed=2, passed=4),
                                    mutationAdequacyClaim=False),
    findings=[dict(id='R4', severity='maintenance integration gap', arm='candidateTwo',
                   source='atlas/tests/test_coffee_navigation_snapshots.py:27-72; atlas/tests/update_coffee_snapshots.py:26-33',
                   observation='Existing generator emits navigation.json only; new unicode_find.json scenario is test-local and has no maintained regeneration route.',
                   evidence='commands/candidateSnapshotGeneratorRoute.log', behaviorFailureObserved=False),
              dict(id='R5', severity='size gate failure', arm='candidateTwo',
                   observation='61 production / 647 tests / 708 combined churn; loses production and combined to main and Ponytail.', evidence='metrics.json')],
    historicalFindings=dict(R1='candidateOne broken fixture inventory integration remains a historical failure, unrepaired.',
                            R2='main tuningOne stale variants remain a historical failure, unrepaired.',
                            R3='candidateOne tuningOne apparent production advantage was whitespace-only and combined churn lost.'),
    reuse=[dict(language='Python', apis=['str.casefold', 'sqlite3.Connection.create_function(deterministic=True)', 'SQLAlchemy connection event in readonly_session', 'SQL instr', 'GraphReader.find existing repository-scoped ordering/limit', 'CoffeeNavigation.query', 'normalize_responses'],
                actualComposition='Candidate and Ponytail bind three folded SQL expressions once in Python. PR binds them in separate assignments; main repeats SQL expressions.',
                sizeQualification='Candidate Python -3 lines vs PR is two assignment lines plus an omitted comment, not a new algorithm; source headroom is small.'),
           dict(language='TypeScript', apis=['withStorageTransaction', 'createRoomMap', 'createTopicMap', 'mergeNumbers', 'Set', 'createMemoryRoom', 'createMemoryTopic', 'createMemoryItem', 'linkMemoryTopicToRoom', 'linkMemoryItemToTopic', 'createTestDatabaseFixture'],
                actualComposition='Only candidate constructs validRoomIds before the topic loop and passes it to the existing resolver; comparison arms reconstruct it per topic.',
                sizeQualification='Real derived-result lifetime sharing, not a measured resource saving or aggregate source churn win.'),
           dict(language='Elixir', apis=['Ecto.Changeset.cast', 'validate_required', 'validate_number(greater_than_or_equal_to: 0)', 'apply_action'],
                actualComposition='All production patches identical: six validator pipeline calls.', sizeQualification='No credible production size headroom.')],
    assertionCaveat='Do not combine valid-ID/name tests so broadly that both topics are expected linked regardless of which reference wins; retain exclusive unintended-topic-unlinked assertions.',
    proposedLastHypothesis=dict(path=str(proposal), bytes=proposal.stat().st_size,
                                sha256=hashlib.sha256(proposal.read_bytes()).hexdigest(),
                                deployed=False, tested=False, newRuntimeScriptsOrReferences=False,
                                idea='Choose the maintained test seam before writing tests; extend setup/assertion paths, add separate scenarios only for concrete gaps, preserve independent maintained regressions rather than copy external acceptance matrices.',
                                inspiration='Ponytail first-complete-option decision and stopping rule, not a 1:1 copy.',
                                removableSkillContent=['Repeated necessity/addition-justification rules', 'Separate efficiency paragraph, retaining common-lifetime reuse and honest measurement', 'Repeated authoritative-policy/native-value advice', 'Exhaustive observable-contract catalogue', 'Coverage-checklist wording, replaced with a seam/gap decision']),
    limitations=['Three tuning tasks, one new draw per arm; no universal or causal superiority claim.',
                 'Focused checks only, no full application suite or DB-backed application startup.',
                 'Prior reviewer reserved TypeScript brief exposure remains disclosed; no new reserve inspection.',
                 'Original-production negative controls are not a mutation score.'])
(review / 'evidence.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(commands=len(commands), failed=failed, integrity=integrity, aggregates=metrics['aggregates'], proposalBytes=proposal.stat().st_size), indent=2))
