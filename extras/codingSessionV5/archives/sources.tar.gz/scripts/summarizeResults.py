"""Read-only V5 metric audit. Defaults ONLY to initialReady; explicit --runs selects later draws.

python3 extras/codingSessionV5/scripts/summarizeResults.py --output extras/codingSessionV5/initialResults.json
Later: --runs /absolute/draw --profile candidate=/absolute/frozen.md --output /absolute/results.json
No model, checks, private streams, dependency traversal, or source/reply content in output.
"""
import argparse
from dataclasses import asdict, dataclass
from hashlib import sha256
import json
from pathlib import Path
import re
from subprocess import CalledProcessError
from typing import Literal, NotRequired, TypedDict, cast

from evidenceTypes import FileMeasure, Loc
from measureTrial import category, compressed, git, lineChanges

study = Path(__file__).resolve().parents[1]
defaultRuns = Path('/home/leon/.cache/codingSessionV5/harness/runs/initialReady')
kinds = ('production', 'tests', 'fixtures', 'snapshots', 'other')
Number = int | float | None


class CapturedTotal(TypedDict):
    files: int
    added: int | None
    deleted: int | None
    addedBytes: int | None
    deletedBytes: int | None
    baseBytes: int
    resultBytes: int
    byteGrowth: int
    beforeLoc: Loc
    afterLoc: Loc
    binaryFiles: int
    compressedAddedBytes: int


class Measurement(TypedDict):
    base: str
    patchSha256: str
    patchBytes: int
    files: list[FileMeasure]
    totals: dict[str, CapturedTotal]
    scope: str
    locNote: str
    compressionNote: str


class Process(TypedDict):
    exit: int
    timedOut: bool
    seconds: float
    timeoutSeconds: int


class Audit(TypedDict):
    valid: bool
    profileSha256: str
    turns: int
    toolStarts: int
    toolEnds: int
    replyWords: int
    outputWords: int
    usage: UsageReport
    permissionDenials: int | None


class TokenUsage(TypedDict, total=False):
    input: int | None
    output: int | None
    cacheRead: int | None
    cacheWrite: int | None
    cacheWrite1h: int | None
    reasoning: int | None
    totalTokens: int | None


class UsageReport(TypedDict):
    tokens: TokenUsage
    piReportedCostUsd: dict[str, float | None]
    actualBilledCostUsd: float | None
    unavailable: list[str]
    unavailableCost: list[str]


class Result(TypedDict):
    identity: str
    status: str
    modelLaunched: bool
    base: str
    native: bool
    arm: str
    agent: Process | None
    audit: Audit | None
    measurement: Measurement | None
    checks: dict[str, int | None]
    seconds: float
    profileSha256: NotRequired[str]
    packageSha256: NotRequired[str]
    error: NotRequired[str]


class Case(TypedDict):
    id: str
    repo: str
    base: str
    sourcePaths: NotRequired[list[str]]
    setupCommands: list[str]
    dependencyPaths: list[str]


class Manifest(TypedDict):
    cases: list[Case]


class Activation(TypedDict):
    valid: bool


@dataclass
class Total:
    files: int
    binaryFiles: int
    added: int | None
    deleted: int | None
    churn: int | None
    addedBytes: int | None
    deletedBytes: int | None
    baseBytes: int
    resultBytes: int
    byteGrowth: int
    beforeLoc: Loc | None
    afterLoc: Loc | None
    compressedAddedBytes: int | None


@dataclass
class Profile:
    path: str
    sha256: str
    expectedSha256: str | None
    matchesPlanPin: bool | None


@dataclass
class Correction:
    path: str
    capturedCategory: str
    derivedCategory: str
    reason: str
    baseMode: str | None
    baseSha256: str | None


@dataclass
class Run:
    identity: str
    draw: str
    case: str
    arm: str
    profileSha256: str | None
    packageSha256: str | None
    mechanism: str
    status: str
    modelLaunched: bool
    agent: Process | None
    checks: dict[str, int | None]
    auditValid: bool | None
    activationValid: bool | None
    error: str | None
    evidence: str
    evidenceHashes: dict[str, str]
    integrityProblems: list[str]
    capturedMeasurement: Measurement | None
    derivedDelivered: dict[str, Total] | None
    corrections: list[Correction]
    exclusions: list[str]
    metrics: dict[str, Number]
    validCompletion: bool
    metricComparisonEligible: bool
    qualityGate: str
    qualityUnavailable: list[str]
    gateReasons: list[str]


@dataclass
class Direction:
    candidate: Number
    reference: Number
    observed: str
    qualified: str | None


@dataclass
class Comparison:
    draw: str
    case: str
    candidate: str
    reference: str | None
    status: str
    qualityGate: str
    directions: dict[str, Direction]
    strictSuperiority: bool | None
    boundedParetoImprovement: bool | None


@dataclass
class ArmTotal:
    arm: str
    attempts: int
    statusCounts: dict[str, int]
    validCompletions: int
    metricEligibleIdentities: list[str]
    excludedIdentities: list[str]
    sourceChurnAllAttempts: Number
    sourceChurnMetricEligible: Number
    sourceChurnQualityQualified: Number
    allAttemptResources: dict[str, Number]
    superiority: bool | None


def digest(data: bytes) -> str:
    return sha256(data).hexdigest()


def completeSum(values: list[Number]) -> Number:
    return sum(value for value in values if value is not None) if values and None not in values else None


def baseFile(repo: Path, base: str, path: str) -> tuple[str | None, bytes]:
    entry = git(repo, ['ls-tree', base, '--', path])
    if not entry:
        return None, b''
    mode = entry.split(b' ', 1)[0].decode()
    if mode not in {'100644', '100755'}:
        return mode, b''
    return mode, git(repo, ['show', f'{base}:{path}'])


def gitQuote(path: str) -> bytes:
    data = path.encode('utf-8', errors='surrogateescape')
    escapes = {7: b'\\a', 8: b'\\b', 9: b'\\t', 10: b'\\n', 11: b'\\v', 12: b'\\f',
               13: b'\\r', 34: b'\\"', 92: b'\\\\'}
    if not any(byte in escapes or byte < 32 or byte >= 127 for byte in data):
        return data
    return b'"' + b''.join(escapes.get(byte, (f'\\{byte:03o}'.encode() if byte < 32 or byte >= 127
                                            else bytes([byte]))) for byte in data) + b'"'


def patchSections(patch: bytes, files: list[FileMeasure]) -> dict[str, bytes]:
    sections = {part.split(b'\n', 1)[0]: b'diff --git ' + part
                for part in re.split(rb'(?m)^diff --git ', patch)[1:]}
    return {item['path']: sections[gitQuote('a/' + item['path']) + b' ' + gitQuote('b/' + item['path'])]
            for item in files}


def derivedCategory(item: FileMeasure, sourcePaths: list[str], mode: str | None,
                    before: bytes, section: bytes) -> tuple[str, str]:
    path = item['path']
    captured = item['category']
    if captured != 'other' or item['binary'] or Path(path).suffix:
        return captured, 'captured category retained'
    added, unused = lineChanges(section)
    executable = mode == '100755' or b'new file mode 100755\n' in section
    shebang = before.startswith(b'#!') or (mode is None and added.startswith(b'#!'))
    if (path in sourcePaths or executable) and shebang:
        return category(path + '.sh'), 'extensionless source: base sourcePaths/executable mode and actual shebang'
    return captured, 'captured category retained'


def setupDependency(item: FileMeasure, case: Case, section: bytes) -> bool:
    if case['id'] != 'workspaceCheckoutRoots' or item['path'] != 'node_modules' or item['baseBytes']:
        return False
    if b'new file mode 120000\n' not in section:
        return False
    added, unused = lineChanges(section)
    target = added.decode('utf-8')
    command = f'ln -s "{target}" "{{root}}/node_modules"'
    return target in case['dependencyPaths'] and any(command in text for text in case['setupCommands'])


def sumLines(files: list[FileMeasure], key: Literal['added', 'deleted', 'addedBytes', 'deletedBytes']) -> int | None:
    values = [item[key] for item in files]
    return None if None in values else sum(value for value in values if value is not None)


def total(files: list[FileMeasure], sections: dict[str, bytes]) -> Total:
    binary = sum(item['binary'] for item in files)
    added = None if binary else sumLines(files, 'added')
    deleted = None if binary else sumLines(files, 'deleted')
    before = cast(Loc, {key: sum(item['beforeLoc'][key] for item in files)
                        for key in ('physical', 'nonblank', 'code')})
    after = cast(Loc, {key: sum(item['afterLoc'][key] for item in files)
                       for key in ('physical', 'nonblank', 'code')})
    return Total(len(files), binary, added, deleted, None if added is None or deleted is None else added + deleted,
                 None if binary else sumLines(files, 'addedBytes'),
                 None if binary else sumLines(files, 'deletedBytes'),
                 sum(item['baseBytes'] for item in files), sum(item['resultBytes'] for item in files),
                 sum(item['byteGrowth'] for item in files), None if binary else before, None if binary else after,
                 None if binary else compressed(b''.join(lineChanges(sections[item['path']])[0]
                                                        for item in sorted(files, key=lambda item: item['path']))))


def derive(measurement: Measurement, patch: bytes, case: Case,
           repo: Path) -> tuple[dict[str, Total], list[Correction], list[str]]:
    sections = patchSections(patch, measurement['files'])
    delivered, corrections, exclusions = [], [], []
    for item in measurement['files']:
        path, section = item['path'], sections[item['path']]
        if setupDependency(item, case, section):
            exclusions.append(path)
            continue
        mode, before = baseFile(repo, case['base'], path) if item['category'] == 'other' else (None, b'')
        kind, reason = derivedCategory(item, case.get('sourcePaths', []), mode, before, section)
        if kind != item['category']:
            corrections.append(Correction(path, item['category'], kind, reason, mode, digest(before)))
        delivered.append(cast(FileMeasure, {**item, 'category': kind}))
    totals = {kind: total([item for item in delivered if item['category'] == kind], sections) for kind in kinds}
    totals['combined'] = total(delivered, sections)
    return totals, corrections, exclusions


def profiles(extra: list[str]) -> dict[str, Profile]:
    paths = {'ponytail': study / 'baseline/upstream/skills/ponytail/SKILL.md',
             'ponytailNarrative': study / 'profiles/ponytailNarrative.md',
             'legacyNative': study / 'profiles/legacyNative.md'}
    pins = cast(dict[str, str], json.loads((study / 'plan.json').read_text())['pins'])
    for assignment in extra:
        name, path = assignment.split('=', 1)
        paths[name] = Path(path).resolve()
    result = {}
    for name, path in paths.items():
        relative = str(path.relative_to(study)) if path.is_relative_to(study) else str(path)
        pin = pins.get('profiles/replica.md' if name == 'ponytail' else relative)
        actual = digest(path.read_bytes())
        result[name] = Profile(str(path), actual, pin, actual == pin if pin else None)
    return result


def evidenceIntegrity(folder: Path) -> tuple[dict[str, str], list[str]]:
    inventory = folder / 'integrity.json'
    if not inventory.exists():
        return {}, ['integrity.json unavailable']
    expected = cast(dict[str, str], json.loads(inventory.read_text()))
    actual, problems = {}, []
    for name, value in sorted(expected.items()):
        path = folder / name
        if Path(name).name != name or not path.is_file() or path.is_symlink():
            problems.append(f'{name}: missing/unsafe public artifact')
            continue
        actual[name] = digest(path.read_bytes())
        if actual[name] != value:
            problems.append(f'{name}: hash mismatch')
    return actual, problems


def runMetrics(result: Result, totals: dict[str, Total] | None, reply: bytes | None,
               activation: bool | None) -> dict[str, Number]:
    audit, agent = result.get('audit'), result.get('agent')
    usage = audit['usage'] if audit else None
    values: dict[str, Number] = {'pipelineSeconds': result.get('seconds'),
                                'agentSeconds': agent['seconds'] if agent else None}
    for key in ('input', 'output', 'cacheRead', 'cacheWrite', 'cacheWrite1h', 'reasoning', 'totalTokens'):
        values['tokens.' + key] = usage['tokens'].get(key) if usage else None
    for key in ('input', 'output', 'cacheRead', 'cacheWrite', 'total'):
        values['piCostUsd.' + key] = usage['piReportedCostUsd'].get(key) if usage else None
    values['actualBilledCostUsd'] = usage['actualBilledCostUsd'] if usage else None
    for key in ('turns', 'toolStarts', 'toolEnds', 'replyWords', 'outputWords', 'permissionDenials'):
        values[key] = audit.get(key) if audit else None
    values['lastAssistantTextBytes'] = len(reply) if reply is not None else None
    values['lastAssistantTextRawDeflateBytes'] = compressed(reply) if reply is not None else None
    values['lastAssistantTextDensity'] = compressed(reply) / len(reply) if reply else None
    final = bool(audit and audit['valid'] and agent and agent['exit'] == 0 and not agent['timedOut']
                 and result['status'] == 'completed' and (not result['native'] or activation is True))
    values['finalReplyWords'] = audit['replyWords'] if audit and final else None
    values['finalReplyDensity'] = values['lastAssistantTextDensity'] if final else None
    for kind in (*kinds, 'combined'):
        value = totals[kind] if totals else None
        for key in ('files', 'binaryFiles', 'added', 'deleted', 'churn', 'addedBytes', 'deletedBytes',
                    'baseBytes', 'resultBytes', 'byteGrowth', 'compressedAddedBytes'):
            values[kind + '.' + key] = getattr(value, key) if value else None
        for side in ('beforeLoc', 'afterLoc'):
            counts = getattr(value, side) if value else None
            for key in ('physical', 'nonblank', 'code'):
                values[f'{kind}.{side}.{key}'] = counts[key] if counts else None
    values['upstreamStyleDiff.srcLoc'] = values['production.added']
    values['upstreamStyleDiff.totalLoc'] = values['production.added']
    values['upstreamStyleDiff.testLoc'] = values['tests.added']
    return values


def stageMetrics(folder: Path) -> dict[str, Number]:
    values: dict[str, Number] = {}
    for label in ('clone', 'acceptance', 'native'):
        path = folder / f'{label}.json'
        record = cast(Process, json.loads(path.read_text())) if path.exists() else None
        values[label + 'Seconds'] = record['seconds'] if record else None
    stages = [cast(Process, json.loads(path.read_text())) for path in sorted(folder.glob('setup*.json'))]
    values['setupSeconds'] = completeSum([record['seconds'] for record in stages])
    return values


def readRun(folder: Path, mapping: dict[str, Profile]) -> Run:
    result = cast(Result, json.loads((folder / 'result.json').read_text()))
    caseId = folder.parent.name
    manifestFile = folder / 'manifest.json'
    manifest = cast(Manifest, json.loads(manifestFile.read_text())) if manifestFile.exists() else None
    case = next((case for case in manifest['cases'] if case['id'] == caseId), None) if manifest else None
    hashes, problems = evidenceIntegrity(folder)
    profileFile = folder / 'profile.md'
    profileHash = digest(profileFile.read_bytes()) if profileFile.exists() else result.get('profileSha256')
    if result.get('profileSha256') and profileHash != result['profileSha256']:
        problems.append('captured profile hash mismatch')
    arm = next((name for name, info in mapping.items() if info.sha256 == profileHash),
               'unmapped.' + (profileHash or 'unavailable'))
    measurement = result['measurement']
    totals, corrections, exclusions = None, [], []
    if measurement is not None and case is not None:
        patchFile = folder / 'changes.patch'
        if patchFile.exists() and digest(patchFile.read_bytes()) == measurement['patchSha256']:
            repo = folder.parent / 'workspace'
            try:
                totals, corrections, exclusions = derive(measurement, patchFile.read_bytes(), case,
                                                         repo if (repo / '.git').exists() else Path(case['repo']))
            except (OSError, CalledProcessError, KeyError):
                problems.append('base/patch unavailable for derivation; derived metrics null')
        else:
            problems.append('patch unavailable/mismatched; derived metrics unavailable')
    activationFile = folder / 'activation.json'
    activation = cast(Activation, json.loads(activationFile.read_text()))['valid'] if activationFile.exists() else None
    audit, agent = result['audit'], result['agent']
    valid = bool(result['status'] == 'completed' and audit and audit['valid'] and agent and agent['exit'] == 0
                 and not agent['timedOut'] and (not result['native'] or activation is True))
    reasons = [] if valid else ['invalid or unavailable completion']
    if any(result['checks'].get(label) != 0 for label in ('acceptance', 'native')):
        reasons.append('failed or unavailable acceptance/maintained checks')
    reasons.extend(problems)
    if arm.startswith('unmapped.'):
        reasons.append('profile not mapped by actual full hash')
    if arm in mapping and mapping[arm].matchesPlanPin is False:
        reasons.append('profile differs from frozen plan pin')
    if totals is None:
        reasons.append('derived measurement unavailable')
    eligible = not reasons
    missing = ['owned test meaningfulness', 'owned tests catch original', 'security/scope/contracts review',
               'blinded completeness', 'overengineering', 'reply accuracy', 'coverage', 'clarity']
    replyFile = folder / 'finalSummary.txt'
    metrics = runMetrics(result, totals, replyFile.read_bytes() if replyFile.exists() else None, activation)
    metrics.update(stageMetrics(folder))
    return Run(result['identity'], folder.parents[2].name, caseId, arm, profileHash,
               result.get('packageSha256'), result['arm'], result['status'], result['modelLaunched'], agent,
               result['checks'], audit['valid'] if audit else None, activation, result.get('error'), str(folder),
               hashes, problems, measurement, totals, corrections, exclusions, metrics, valid, eligible,
               'unreviewed' if eligible else 'blocked', missing, reasons)


def direction(candidate: Number, reference: Number) -> str:
    if candidate is None or reference is None:
        return 'unavailable'
    return 'better' if candidate < reference else 'worse' if candidate > reference else 'tie'


def directionalMetrics() -> list[str]:
    return ['production.' + key for key in ('added', 'deleted', 'churn', 'addedBytes', 'deletedBytes',
            'resultBytes', 'byteGrowth', 'files', 'afterLoc.nonblank', 'afterLoc.code', 'compressedAddedBytes')] + [
            'tokens.' + key for key in ('input', 'output', 'cacheRead', 'cacheWrite', 'totalTokens')] + [
            'piCostUsd.' + key for key in ('input', 'output', 'cacheRead', 'cacheWrite', 'total')] + [
            'pipelineSeconds', 'agentSeconds', 'turns', 'toolStarts']


def comparisons(runs: list[Run], referenceArm: str) -> list[Comparison]:
    result = []
    for candidate in runs:
        if candidate.arm == referenceArm:
            continue
        references = [run for run in runs if run.arm == referenceArm and run.draw == candidate.draw
                      and run.case == candidate.case]
        reference = references[0] if len(references) == 1 else None
        eligible = bool(reference and candidate.metricComparisonEligible and reference.metricComparisonEligible)
        eligible = eligible and candidate.capturedMeasurement['base'] == reference.capturedMeasurement['base']
        values = {}
        for key in directionalMetrics():
            baseline = reference.metrics[key] if reference else None
            observed = direction(candidate.metrics[key], baseline)
            values[key] = Direction(candidate.metrics[key], baseline, observed, observed if eligible else None)
        result.append(Comparison(candidate.draw, candidate.case, candidate.identity, reference.identity if reference else None,
                                 'unpaired' if reference is None else 'metricComparable' if eligible else 'invalidOrUnavailable',
                                 'unreviewed' if eligible else 'blocked', values, None, None))
    return result


def armTotals(runs: list[Run]) -> list[ArmTotal]:
    result = []
    for arm in sorted({run.arm for run in runs}):
        rows = [run for run in runs if run.arm == arm]
        eligible = [run for run in rows if run.metricComparisonEligible]
        statuses = {status: sum(run.status == status for run in rows) for status in sorted({run.status for run in rows})}
        resources = {key: completeSum([run.metrics[key] for run in rows]) for key in rows[0].metrics
                     if key.startswith(('tokens.', 'piCostUsd.')) or key.endswith('Seconds') or key in (
                        'turns', 'toolStarts', 'toolEnds', 'actualBilledCostUsd')}
        result.append(ArmTotal(arm, len(rows), statuses, sum(run.validCompletion for run in rows),
                               [run.identity for run in eligible],
                               [run.identity for run in rows if not run.metricComparisonEligible],
                               completeSum([run.metrics['production.churn'] for run in rows]),
                               completeSum([run.metrics['production.churn'] for run in eligible]), None, resources, None))
    return result


notes = {
    'scope': 'All discovered attempts retained. Defaults only to initialReady. Explicit --runs opts into another draw.',
    'initialScope': 'Nine initialReady attempts are not the entire ledger. amendments.md documents an earlier invalid infrastructure launch in initial; outside the default draw, not a zero-cost success.',
    'infrastructure': 'Current infrastructure hashes compared with plan pins, not proof of historical executable bytes. The pre-existing sandboxTrial lock-directory amendment explains its changed pin; reporter does not modify harness.',
    'capture': 'capturedMeasurement and status unchanged; original combined includes setup. Evidence hashes are not a correctness verdict.',
    'correction': 'DERIVED only: extensionless shebang source classified using frozen manifest sourcePaths/base blob/mode; never rewritten captures.',
    'setup': 'DERIVED delivered combined excludes only the declared workspaceCheckoutRoots node_modules setup symlink when patch target/mode/setup match. Same rule every arm.',
    'categories': 'Production, tests, fixtures, snapshots, other distinct. Path classification inherited; e.g. tests/fixture_command.py remains tests, not fixture-directory content.',
    'loc': 'Before/after LOC covers entire CHANGED files, not whole repository or newly authored LOC. Code is line-prefix comment heuristic, not parser. Snapshot JSON can be one huge line.',
    'upstream': 'upstreamStyleDiff srcLoc and totalLoc both alias production added lines, including blanks/comments, as upstream git_diff_stats does; not whole-tree code_stats or exact upstream classifier/compressor equivalence.',
    'compression': 'Level 9 rawDEFLATE over added bytes in sorted paths. Binary affected line/LOC/compression totals null, captured originals retained. Empty text category zero.',
    'usage': 'Finalized captured messages only; interrupted calls may be unreported. Reasoning subset of output; cacheWrite1h subset of cacheWrite. Pi cost is not invoice; actual billing null.',
    'reply': 'Density=rawDEFLATE bytes/UTF8 bytes, descriptive not monotonic. Last captured assistant text can be intermediate on invalid runs. Valid final reply metrics null otherwise. Empty density null.',
    'directions': 'Lower is better only as a size/resource direction, not quality (especially deletions). Tests/fixtures/snapshots, reply length/density descriptive, not superiority objectives.',
    'gate': 'metricComparable requires valid completion, checks, mapped profile, intact evidence, same base. Semantic/owned-test/blinded reviews unavailable; no qualified superiority or aggregate success inferred.',
    'superiority': 'Strict superiority requires every directional metric better, no ties or unavailable metrics, and every quality gate passed. Bounded Pareto (no worse, at least one better) is distinct, never universal proof. Both unevaluated while quality unavailable.',
    'aggregation': 'All-attempt source churn/resources include invalid rows. Metric-eligible churn excludes explicitly listed invalid rows; fully quality-qualified churn null, not zero. No averaging away failures.',
    'limits': 'One initial sample/case/arm, no statistical, universal, causal linguistic or production deployment claim. No holdout read by default; no model/test execution.',
}


def infrastructureAudit() -> dict[str, dict[str, str | bool]]:
    pins = cast(dict[str, str], json.loads((study / 'plan.json').read_text())['infrastructurePins'])
    result = {}
    for name, expected in pins.items():
        if not name.startswith('scripts/'):
            continue
        actual = digest((study / name).read_bytes())
        result[name] = {'expectedSha256': expected, 'currentSha256': actual, 'matchesPlanPin': actual == expected}
    return result


def formatNumber(value: Number, places: int) -> str:
    return 'null' if value is None else f'{value:.{places}f}'


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', type=Path, action='append', help='Explicit draw directory; repeat for later rounds')
    parser.add_argument('--profile', action='append', default=[], help='arm=/absolute/profile.md; map by full actual hash')
    parser.add_argument('--reference', default='ponytail')
    parser.add_argument('--output', type=Path, default=study / 'initialResults.json')
    args = parser.parse_args()
    mapping = profiles(args.profile)
    folders = sorted({folder.resolve() for root in args.runs or [defaultRuns]
                      for folder in root.glob('*/*/evidence') if (folder / 'result.json').exists()})
    runs = [readRun(folder, mapping) for folder in folders]
    totals = armTotals(runs)
    report = {'schemaVersion': 1, 'scriptSha256': digest(Path(__file__).read_bytes()),
              'planSha256': digest((study / 'plan.json').read_bytes()),
              'amendmentsSha256': digest((study / 'amendments.md').read_bytes()),
              'infrastructure': infrastructureAudit(), 'notes': notes,
              'profiles': {name: asdict(info) for name, info in mapping.items()},
              'runs': [asdict(run) for run in runs], 'comparisons': [asdict(item) for item in comparisons(runs, args.reference)],
              'arms': [asdict(item) for item in totals]}
    # Compact generated JSON stays under 600 lines; byte-reproducible, no timestamps.
    args.output.write_text('{\n' + ',\n'.join(json.dumps(key) + ':' + json.dumps(value, separators=(',', ':'))
                                            for key, value in report.items()) + '\n}\n')
    print('arm | attempts/valid | source churn all/eligible | tokens | Pi USD | agent s')
    for item in totals:
        values = item.allAttemptResources
        print(f'{item.arm} | {item.attempts}/{item.validCompletions} | '
              f'{item.sourceChurnAllAttempts}/{item.sourceChurnMetricEligible} | '
              f'{values["tokens.totalTokens"]} | {formatNumber(values["piCostUsd.total"], 6)} | '
              f'{formatNumber(values["agentSeconds"], 3)}')


if __name__ == '__main__':
    main()
