#!/usr/bin/env python3
"""Unchanged-base negative controls and native regression diagnostics; no mutations."""
import concurrent.futures
import json
from pathlib import Path
import sys
import tempfile
import types
from reviewCompactChecks import execute

runner = types.ModuleType('compact_runner')
execute('reviewFrozenChecks.py', runner.__dict__)
ROOT, LOGS, run = runner.ROOT, runner.LOGS, runner.run
variants = runner.VARIANTS
jobs = []
for brief in runner.BRIEFS:
    case = brief['caseName']
    base = ROOT/'base'/('final' if case in ['pollProcessContract', 'preScriptIsolation'] else '')/case
    jobs.append(('base-oracle-'+case, [sys.executable, brief['oraclePath'], str(base)], ROOT, {}))
    if 'additionalAcceptance' in brief:
        jobs.append(('base-factory', [sys.executable, brief['additionalAcceptance'], str(base)], ROOT, {}))
with tempfile.TemporaryDirectory(prefix='compact-native-base-') as folder:
    scratch = Path(folder)
    for variant in variants:
        for case in ['sourceBatchReads', 'pathEarlyExit']:
            origin = ROOT/'runs'/variant/case
            jobs.append((f'native-base-{variant}-{case}', [str(origin/'atlas/.venv/bin/python'), '-m', 'pytest', 'tests/test_graph_navigation.py', '-q'], origin/'atlas', {'PYTHONPATH': str(ROOT/'base'/case/'atlas/src')}))
        origin = ROOT/'runs'/variant/'preScriptIsolation'
        text = (origin/'src/worker/preScript.test.ts').read_text().replace("'./preScript'", json.dumps(str(ROOT/'base/final/preScriptIsolation/src/worker/preScript.ts')))
        test = scratch/(variant+'.test.ts')
        test.write_text(text)
        jobs.append((f'native-base-{variant}-preScriptIsolation', ['bun', 'test', '--timeout', '5000', str(test)], origin, {'OTEL_SDK_DISABLED': 'true', 'MATATO_TEST_STORAGE_PATH': str(scratch/variant)}))
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        results = list(pool.map(run, jobs))
(LOGS/'controlResults.json').write_text(json.dumps(results, indent=2)+'\n')
print('EXPECTED_NONZERO_CONTROLS', json.dumps(results))
