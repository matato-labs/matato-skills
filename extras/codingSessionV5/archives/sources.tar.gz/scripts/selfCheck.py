"""Synthetic isolation/CLI preflight. No auth-source reads, model prompts or provider requests."""
import json
from pathlib import Path
import shlex
import socket
import sys
import tempfile
import time

from common import digest, owned, save, scratch, settings, proxyAlias
from providerProxy import startProxy
from nativeTrial import baseline, nativeEnvironment, prepareNative, primarySkill
from runTrial import Case, checkCaptured, executeCase, installedPi, prepare
from sandboxTrial import Sandbox, environment, execute, sandbox, shell
from unitTests import repository


def checkIsolation(spec: Sandbox, private: Path) -> None:
    quote = shlex.quote
    source = quote(str(spec.source))
    workspace = quote(str(spec.workspace))
    command = f'''test ! -e /home/leon/.pi
 test ! -e {quote(str(private))}/hiddenSentinel
 test ! -e /run/user
 test ! -e /tmp/codingSessionV4
 ! touch {source}/forbidden
 ! touch {source}/.git/forbidden
 ! touch {workspace}/.git/forbidden
 ! touch /tmp/forbidden
 ! touch /experiment/profile.md
 ! touch /experiment/config/auth.json
 ! touch {quote(str(spec.dependencies[0]))}/forbidden
 cmp /experiment/profile.md {quote(str(spec.inputs[0][1]))}
 printf writable > ownedProof
 printf scratch > "$TMPDIR/proof"
 python3 -c 'import socket; s=socket.socket(); s.settimeout(1); assert s.connect_ex(("127.0.0.1", 9)) != 0; assert s.connect_ex(("1.1.1.1", 443)) != 0'
'''
    stage = spec.runtime / 'isolation'
    argv = sandbox(spec, stage, agent=True) + ['/bin/bash', '--noprofile', '--norc', '-euc', command]
    record = execute(argv, environment(stage), private, 'isolation', 20)
    if record['exit']:
        raise AssertionError(Path(record['stderr']).read_text())
    assert not (spec.source / 'forbidden').exists()
    (spec.workspace / 'ownedProof').unlink()


def checkProxy(spec: Sandbox, private: Path) -> None:
    endpoint = private / 'deny.sock'
    server = startProxy(endpoint)
    try:
        for target in ['127.0.0.1:8000', 'example.com:443', 'chatgpt.com:80', 'api.openai.com.evil:443']:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                client.settimeout(3)
                client.connect(str(endpoint))
                client.sendall(f'CONNECT {target} HTTP/1.1\r\n\r\n'.encode())
                assert client.recv(1024).startswith(b'HTTP/1.1 403')
        stage = spec.runtime / 'proxy'
        command = 'curl -sS --connect-timeout 2 https://127.0.0.1:8000 > "$TMPDIR/out" 2> "$TMPDIR/err" && exit 1; grep 403 "$TMPDIR/err"'
        argv = sandbox(spec, stage, endpoint, agent=True) + [sys.executable,
                '/experiment/providerProxy.py', str(proxyAlias), '/bin/bash', '--noprofile', '--norc', '-euc', command]
        record = execute(argv, environment(stage), private, 'proxy', 20)
        assert record['exit'] == 0, Path(record['stderr']).read_text()
    finally:
        server.shutdown()
        server.server_close()


def checkNative(spec: Sandbox, private: Path, evidence: Path) -> None:
    package = baseline / 'upstream'
    prepareNative(spec, package, (package / primarySkill).read_bytes(), private, evidence)
    proof = json.loads((evidence / 'nativeProof.json').read_text())
    assert proof['kind'] == 'offlineNativeFactoryAndObserverMock'
    assert not proof['actualAuthRead'] and not proof['providerRequestTested']
    stage = spec.runtime / 'nativeIsolation'
    env = nativeEnvironment(stage)
    command = '''test -f /experiment/package/scripts/uninstall.js
 ! touch /experiment/package/hooks/forbidden
 ! touch /experiment/nativeInstructions.txt
 ! touch /experiment/nativeTrace.ts
 ! touch "$XDG_CONFIG_HOME/ponytail/config.json"
 test "$PONYTAIL_DEFAULT_MODE" = full
'''
    record = execute(sandbox(spec, stage) + ['/bin/bash', '--noprofile', '--norc', '-euc', command],
                     env, private, 'nativeIsolation', 20)
    assert record['exit'] == 0, Path(record['stderr']).read_text()
    # Later offline checks retain their original mounts and environment.
    spec.package, spec.nativeTrace, spec.nativeInstructions = None, None, None


def main() -> None:
    root = owned(scratch / 'synthetic')
    folder = Path(tempfile.mkdtemp(prefix='preflight', dir=root))
    source, dependency, private, evidence = [folder / name for name in ['source', 'dependency', 'private', 'evidence']]
    for path in [dependency, private, evidence]:
        path.mkdir(mode=0o700)
    base = repository(source)
    (source / 'main.py').write_text('print(999)\n')
    before = digest((source / '.git/index').read_bytes())
    profile = folder / 'selected.md'
    profile.write_text('Synthetic selected profile; not an experiment arm.\n')
    manifest = folder / 'manifest.json'
    case = Case('synthetic', str(source), base, 'Not a model task.', 'grep -q fixed main.py', 'python3 main.py',
                dependencyPaths=[str(dependency)], inputPaths=[str(profile)])
    save(manifest, {'cases': [case.__dict__]})
    pi = installedPi()
    spec = prepare(case, manifest, evidence, private, pi)
    assert (spec.workspace / 'main.py').read_text() == 'print(1)\n'
    spec.profile = profile
    spec.config = private / 'config'
    spec.config.mkdir()
    save(spec.config / 'settings.json', settings)
    (spec.config / 'auth.json').touch()
    spec.auth = private / 'auth.json'
    save(spec.auth, {'openai-codex': {'type': 'api_key', 'key': 'synthetic-not-auth'}})
    (private / 'hiddenSentinel').write_text('must remain invisible')
    checkNative(spec, private, evidence)
    checkIsolation(spec, private)
    checkProxy(spec, private)
    marker = spec.runtime / 'timeout' / 'tmp' / 'escapedChild'
    child = f'import time; from pathlib import Path; time.sleep(2); Path({str(marker)!r}).touch()'
    parent = f'import subprocess,sys,time; subprocess.Popen([sys.executable,"-c",{child!r}], start_new_session=True); time.sleep(10)'
    record = shell(spec, 'timeout', 'python3 -c ' + shlex.quote(parent), private, timeout=1)
    assert record['timedOut'] and record['exit'] == 124
    time.sleep(1.5)
    assert not marker.exists()
    captured = executeCase(case, manifest, folder, pi)
    result = json.loads((captured / 'result.json').read_text())
    assert result['status'] == 'originalPreflight', result
    assert result['checks'] == {'acceptance': 1, 'native': 0}, result
    assert not result['modelLaunched']
    checkCaptured(captured, folder)
    patch = captured / 'changes.patch'
    originalPatch = patch.read_bytes()
    try:
        patch.write_bytes(originalPatch + b'tampered')
        try:
            checkCaptured(captured, folder)
        except ValueError:
            pass
        else:
            raise AssertionError('Tampered evidence was accepted')
    finally:
        patch.write_bytes(originalPatch)
    assert digest((source / '.git/index').read_bytes()) == before
    assert (source / 'main.py').read_text() == 'print(999)\n'
    save(folder / 'preflight.json', {'status': 'passed', 'modelLaunches': 0,
         'checks': ['Pi version only', 'independent frozen clone', 'originals negative control',
                    'filesystem/read-only metadata/dependencies/profile/auth', 'private scratch writable',
                    'direct network denied', 'proxy denies non-provider destinations',
                    'process timeout', 'captured patch/measurement reproduction',
                    'native factory/observer offline injection and alias proof', 'native package/config read-only'],
         'providerRequestTested': False, 'actualAuthRead': False})
    print(folder)


if __name__ == '__main__':
    main()
