# Reserve research (private until freeze)

## Observed production behavior

src/storage/sequenceConfig.ts creates a parent before writeSteps validates models and inserts its steps. createSequenceConfigInStorage opens a connection but owns no transaction. A later model rejection therefore leaves an empty parent; a trigger rejecting a later insert leaves a parent and earlier steps. The failed name cannot be retried. Existing updateSequenceConfigInStorage already replaces mode/steps within runInStorageTransaction and rolls back correctly. Bootstrap already owns an outer transaction while calling createSequenceConfigs. The record-level helper must remain composable there, rather than starting a nested BEGIN.

## Actual existing-language/API opportunities (not brief instructions)

src/storage/database.ts already offers withStorageTransaction for connection-owning synchronous writes and runInStorageTransaction for operations on an existing connection. Both preserve the original error and roll back using SQLite's existing transaction mechanism. No migration, compensating delete, preflight-only workaround, SQLite replacement or new abstraction is necessary. The public creation function's filesystem validation already completes before the synchronous DB-write portion; no asynchronous transaction machinery is needed.

The current writeSteps prevalidates model selections and then inserts ordered rows. Prevalidation alone cannot provide atomicity when a later database write fails. SQLite's native trigger RAISE(ABORT) is already used in the maintained replacement regression and is a real late-write failure seam. The existing mapDefinition, generated parent UUID and stepOrder preserve public ordering and metadata; they need no redesign.

The maintained sequenceConfig suite has a reusable temporary database factory, skill folder setup and a trigger-based replacement regression. Config tests drive initializeBootstrapConfigStorage and persisted reload. CLI index tests create sequences from inline JSON and schedule work; work/workLoop and worker bus tests consume immutable sequence identities and ordered steps. The real fixture route calls createTestDatabaseFixture, migrateTestDatabase and bun run db:migrate with installed drizzle-kit and checked-in migrations. There is no affected snapshot producer or generator requiring new expected snapshots.

## Independent behavioral evidence

The external oracle imports production from the supplied root, uses the existing migrateStorageDatabase and bootstrap factories, and compares complete raw parent/step/config/model rows around failed operations. It checks late missing/disabled model and disallowed thinking-level rejection, a trigger rejecting a later step after an earlier insert, preservation and immediate retry, rich ordered successful creation, empty drafts, duplicate-name preservation, existing replacement rollback, caller-owned bulk transactions and bootstrap rollback/retry/idempotence. SQLite-generated rows are inspected behaviorally, not through source-string or LOC assertions.

negative.log records an actual eight-test original-production run: four passing compatibility scenarios and four failed state-equality expectations. All expected failures are assertion failures, not syntax/import/setup failures. The native baseline passes every subprocess; nativeCounts.json retains exact maintained test counts. The oracle separately typechecks with the installed compiler (oracleTypes.log, exit 0). No task implementation was written, including no test-only production patch or simulated positive implementation.

## Scope and viability

The affected production file has 254 lines; the transaction-owning public creation boundary is already synchronous after file checks. A modest patch can fit comfortably within 900 seconds. Bootstrap, bulk-helper transaction ownership, replacement rollback, unrelated definitions and ordering are explicit regression obligations, not reasons to replace existing storage APIs. Only public creation atomicity is new policy. The brief exposes observable failure/recovery requirements, not the transaction helper or a code recipe. Existing maintained tests stay meaningful rather than being replaced by this oracle.
