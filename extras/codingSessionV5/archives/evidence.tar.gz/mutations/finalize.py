"""Evidence-backed classification and restoration; no new test executions."""
from pathlib import Path
import base64
import json
from experiment import root, save, digest, inventory, source_names, git, tool, rules

reportDir = Path('/home/leon/workspace/projects/matato-pi/extras/codingSessionV5/reviews')


def load(path):
    return json.loads(path.read_text())


def classify(record):
    directory = root / record['arm'] / record['case']
    result = load(directory / 'mutantResult.json')
    execution = result['execution']
    assert execution['exit'] == 1 and not execution['timedOut']
    log = directory / ('mutant.stderr' if record['case'] == 'ts' else 'mutant.stdout')
    text = log.read_text()
    ownedAssertion = 'src/workspaceRepos.test.ts:90' if record['arm'] == 'candidateOne' else 'src/workspaceRepos.test.ts:96'
    ownedTest = 'lists only immediate checkout roots'
    assertion = 'expect(received).toEqual(expected): ordinary folder inherits parent origin instead of valid child row'
    counts = {'passed': 1, 'failed': 4 if record['arm'] == 'candidateOne' else 5, 'skipped': 0}
    if record['case'] == 'py':
        assert '2 failed, 57 passed' in text and 'E   AssertionError' in text
        ownedTest = 'test_coffee_navigation_matches_snapshot[python]'
        ownedAssertion = 'tests/coffee_navigation.py:308' if record['arm'] == 'candidateOne' else 'tests/coffee_navigation.py:334'
        assertion = ('inheritance_budget(1): len(context["edges"]) == budget and path evidence equality'
                     if record['arm'] == 'candidateOne' else
                     'exact_import_budgets(): omitted["truncated"] and len(omitted["edges"]) == budget - 1')
        counts = {'passed': 57, 'failed': 2, 'skipped': 0}
    else:
        assert 'parentOrigin' in text if record['arm'] == 'candidateOne' else 'https://example.com/parent.git' in text
        assert 'error: expect(received).toEqual(expected)' in text
    assert ownedAssertion in text
    result['outcome'] = 'killed'
    result['classification'] = {'basis': 'semantic assertion failure, not syntax/type/compile failure',
                              'ownedTest': ownedTest, 'ownedAssertion': ownedAssertion,
                              'observable': assertion, 'log': str(log), 'tests': counts,
                              'existingCoverageAlsoKills': 'test_context_cutoffs[maxEdges]: assert payload["truncated"] is False'
                              if record['case'] == 'py' else 'requires WORKSPACE and lists only repositories with origin remotes'}
    result['baseline'] = load(directory / 'baseline.json')
    result['baseline']['tests'] = {'passed': 59 if record['case'] == 'py' else (5 if record['arm'] == 'candidateOne' else 6),
                                   'failed': 0, 'skipped': 0}
    save(directory / 'classifiedResult.json', result)
    return result


def restore_config(record):
    workspace = Path(record['workspace'])
    config = workspace / 'atlas.json'
    original = record['temporaryConfig']['originalBase64']
    if original is None:
        config.unlink()
    else:
        config.write_bytes(base64.b64decode(original))
    source = Path(record['source'])
    assert inventory(workspace, record['names']) == record['sourceInventory']
    assert source_names(workspace) == record['names']
    assert inventory(source, record['names']) == record['sourceInventory']
    assert source_names(source) == record['names']
    assert git(source, 'status', '--short').decode() == record['status']
    assert digest(git(source, 'diff', '--binary', 'HEAD')) == record['patchSha256']
    assert digest((source.parent / 'evidence/changes.patch').read_bytes()) == record['evidencePatchSha256']
    return {'arm': record['arm'], 'case': record['case'], 'temporaryConfigRestored': True,
            'disposableInventoryAndFileModesMatchOriginalTarget': True,
            'originalWorkspaceInventoryStatusAndPatchUnchanged': True, 'originalEvidencePatchHashUnchanged': True}


def target_summary(record):
    directory = root / record['arm'] / record['case']
    return {key: record[key] for key in ['arm', 'case', 'source', 'workspace', 'base', 'profileSha256', 'status', 'patchSha256']} | {
        'snapshot': str(directory / 'snapshot.json'), 'targetPatch': str(directory / 'target.patch'),
        'freshScan': load(directory / 'scanTwo.json'),
        'generatedManifests': len(load(directory / 'scanTwo.stdout')['mutations'])}


def unexecuted(records):
    result = []
    for record in records:
        if record['case'] != 'py':
            continue
        directory = root / record['arm'] / record['case']
        manifests = load(directory / 'scanTwo.stdout')['mutations']
        manifest = next(m for m in manifests if m['path'] == 'atlas/src/atlas/services/navigation_walk.py'
                        and m['span']['startLine'] == 50 and m['ruleId'] == 'comparison.greater-equal-to-greater')
        result.append({'arm': record['arm'], 'manifest': manifest, 'outcome': 'skipped',
                       'reason': 'Relevant maxEdges cutoff comparison; not selected because four-mutant total exhausted. '
                                 'Changed adjacency arithmetic received priority over this unchanged guard.'})
    return result


def main():
    records = load(root / 'targets.json')
    results = [classify(record) for record in records]
    restoration = [restore_config(record) for record in records]
    provenance = {'checkout': str(tool), 'head': git(tool, 'rev-parse', 'HEAD').decode().strip(),
                  'status': git(tool, 'status', '--short').decode(),
                  'sourceHashes': {str(p.relative_to(tool)): digest(p.read_bytes())
                                   for p in sorted((tool / 'atlas/src/atlas/mutations').glob('*.py'))}}
    save(root / 'toolProvenance.json', provenance)
    save(root / 'restoration.json', restoration)
    report = {
        'study': 'codingSessionV5', 'comparison': 'candidateOne vs exact Ponytail, revisionOne only',
        'scope': 'Development workspaceRoots and unseenEdges only; no holdout, no models, no installs, no raw private/auth access.',
        'budget': {'maximumRelevantMutantsTotal': 4, 'baselineAndEachMutantTimeoutSeconds': 120,
                   'selected': 4, 'executed': 4, 'selectedButNotExecuted': 0},
        'counts': {'killed': 4, 'survived': 0, 'invalid': 0, 'timeout': 0, 'inconclusive': 0, 'skippedAmongSelected': 0},
        'selectedSampleScore': {'definition': 'killed / (killed + survived); invalid/timeouts/inconclusive/skipped excluded',
                                'numerator': 4, 'denominator': 4, 'value': 1.0,
                                'byArm': {arm: {'killed': 2, 'survived': 0, 'denominator': 2, 'value': 1.0}
                                          for arm in ['candidateOne', 'ponytail']}},
        'interpretation': 'Both arms catch both matched plausible regressions, including newly authored behavioral assertions. '
                          'Tie in this small purposive sample; no superiority, equivalence, full coverage or all-metric claim. '
                          'Existing tests also kill both operators; does not isolate incremental value of added tests.',
        'tool': {'provenance': str(root / 'toolProvenance.json'), 'catalog': str(root / 'atlasRules.json'),
                 'help': str(root / 'atlasHelp.stdout'), 'mode': 'fresh entire disposable project analysis; no --saved/index/DB',
                 'cli': f'uv run --no-sync --offline --project {tool}/atlas atlas mutations -f PROJECT',
                 'temporaryConfig': {'mutations': {'rules': rules}},
                 'scannerSetupAttempts': 'scan.* retain initial failed read-only interpreter-alias mount attempts (exit 2). '
                                         'scanTwo.* succeeded after binding alias and adding --no-sync --offline; not test outcomes.'},
        'executionBoundary': 'Existing sandboxTrial.Sandbox/shell/execute, bubblewrap --unshare-all, explicit read-only '
                             'offline dependency mounts, writable disposable target/runtime only, no auth/config mounts. '
                             'Each command process group killed in finally; each source restored in finally.',
        'reproduction': 'Copied every tracked and nonignored untracked path (including exact uncommitted patches/tests/snapshots '
                        'and TS node_modules symlink), preserved bytes/modes/symlink spelling and copied owned .git. '
                        'No ignored environments copied. Full inventories outside project; temporary atlas.json removed at end.',
        'targets': [target_summary(record) for record in records], 'mutants': results,
        'candidateAccounting': {'generatedManifestsAcrossFourFreshScans': 815, 'selected': 4,
                                'unselectedManifests': 811, 'additionalRecognizedRelevantNotExecuted': 2,
                                'note': 'Unselected is not a test outcome or exhaustive relevance classification. '
                                        'Excluded test/fixture code, unrelated production operators, exit-code/result-filter '
                                        'comparisons and traversal list concatenation/depth/node/distance changes. '
                                        'No arbitrary edits substituted.'},
        'additionalRelevantNotExecuted': unexecuted(records),
        'omitted': {'downloadFailures': 'Bash absent from catalog languages; no supported relevant candidates; no hand mutations.'},
        'limits': ['Only two operator sites per arm, not exhaustive fault coverage.',
                   'No full importer/dashboard/type/lint/policy/acceptance rerun; focused maintained tests only.',
                   'No repeated timing/flakiness study; elapsed times descriptive, not performance metrics.',
                   'Python failure stops each coffee scenario at its first assertion; later assertions not all reached under mutant.',
                   'No original study metrics/gates rewritten or deployment conclusion drawn.'],
        'restoration': restoration, 'evidenceRoot': str(root),
    }
    reportDir.mkdir(parents=True, exist_ok=True)
    save(reportDir / 'mutations.json', report)
    print(json.dumps(report['counts']), 'Restored all four exact targets and temporary configurations.')


if __name__ == '__main__':
    main()
