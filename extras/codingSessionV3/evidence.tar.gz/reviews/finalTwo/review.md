# Independent FINAL review B — V3 finalTwo

**Frozen success gate: NOT MET.** CandidateThree has lower combined physical churn than all three comparators, but not lower production churn than main or Ponytail. An additional maintained integration test also fails in candidate, main and PR. Do not report this experiment as meeting its predeclared production **AND** combined gate or establishing completeness equivalence. No implementation/profile was repaired, revised or selected piecemeal.

This review covers exactly the 24 implementations in `runs/finalTwo/{main,pr,ponytail,candidateThree}` and their corresponding worktrees. No other final review results were read. Historical round-one/round-two reports and parent response were read as requested.

## Critical findings

**R6 — candidate, main and PR: stale work-deletion fixture breaks a maintained consumer.** `sessionTreeConfinement/src/storage/work.test.ts:110–114` still creates `agent/sessions/agent.jsonl`, outside the newly required `agent/sessions/matato` tree. Its `deletes related records and session files` assertion at line 150 now fails: the file correctly survives confinement, but the existing test still expects its deletion. Independently executed `bun test src/storage/work.test.ts` gives **7 pass, 1 fail** in each of these arms. Ponytail adds the missing `matato` path component, retains the deletion assertion, and passes **8/8**; pinned original production with the original work test also passes **8/8**.

This is a concrete integration/maintenance omission, **not** a reason to permit deletion outside the managed root, and not evidence that the new confinement itself is incorrect. Candidate's new session tests and the frozen native command both pass without discovering this caller's test. Preserve the meaningful cleanup assertion with an eligible fixture; no such repair was made here. Evidence: `commands/{main,pr,candidateThree}SessionWorkConsumer.log`, `commands/ponytailSessionWorkConsumer.log`, `commands/pureBaseSessionWorkConsumer.log`.

**Frozen size gate fails independently of R6.** Candidate production/test churn is **105/1,026**, combined **1,131**. Against main/PR/Ponytail, production deltas are **+7/−27/+1** and combined deltas **−79/−218/−103**. Production must be strictly below *each* comparator. The smaller profile and lower combined lines cannot replace that requirement. Candidate also has substantially greater source/test byte growth, mostly generated shared snapshots.

Historical **R1** (candidateOne unregistered fixture), **R2** (main stale variants), **R3** (whitespace-only apparent production advantage), **R4** (candidateTwo missing snapshot generator route), and **R5** (candidateTwo gate loss) remain historical findings, not repaired or retroactively relabelled. In this new draw, all Python fixture consumers pass and every changed navigation/pipeline/variant snapshot has a functioning regeneration route. Candidate's common `CoffeeNavigation.collect` seam now reaches its Unicode assertions through the unchanged existing generator. R6 shows the same consumer-tracing obligation remains relevant outside Python.

No additional production correctness defect or removed safeguard was found in the affected paths inspected. This bounded statement does not establish full-suite correctness or coverage equivalence.

## Independent metrics

Recomputed from live `git diff --numstat -z`, including intent-to-add new files and Unicode/backslash filenames, excluding dependency/build symlinks. No nonignored untracked files were omitted (`untrackedAudit.json` is empty). Fixtures, helpers and snapshots count as tests; other churn is zero. Per-file bytes/hashes and physical-line metrics are in `metrics.json`; blank-line/line-length details are in `metricDetails.json`.

| Arm | Production +/− | Prod churn | Tests +/− | Test churn | Combined churn | Combined net | Output added lines | Combined byte growth |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| main | 74/24 | 98 | 1,105/7 | 1,112 | 1,210 | +1,148 | 1,179 | +64,577 |
| PR112 (`pr`) | 98/34 | 132 | 1,205/12 | 1,217 | 1,349 | +1,257 | 1,303 | +66,851 |
| Ponytail | 78/26 | 104 | 1,123/7 | 1,130 | 1,234 | +1,168 | 1,201 | +61,316 |
| candidateThree | 80/25 | 105 | 1,017/9 | 1,026 | 1,131 | +1,063 | 1,097 | +197,027 |

| Case | main prod/tests | PR prod/tests | Ponytail prod/tests | Candidate prod/tests |
|---|---:|---:|---:|---:|
| Unicode graph search | 14/122 | 23/142 | 15/130 | 17/122 |
| Literal database paths | 4/70 | 5/103 | 4/98 | 4/61 |
| Memory references | 41/329 | 37/347 | 37/314 | 44/330 |
| Session confinement | 23/192 | 51/222 | 32/192 | 24/126 |
| Quantity boundaries | 6/168 | 6/182 | 6/158 | 6/167 |
| Game vocabulary | 10/231 | 10/221 | 10/238 | 10/220 |

Candidate combined per-case losses are Unicode **+3** and memory **+4** versus main; memory **+23** and quantities **+9** versus Ponytail. It beats PR's combined count in every case. These are retained observations, not case-selection criteria.

Profile bytes: candidate **2,642**, main **5,121**, PR **3,161**. Candidate SHA-256 matches `finalFreeze.json`: `57cc21ce6ded5cc772232dfa87225d1880dd533bfa65f02921d8b9c2e656d2b6`. It meets the runtime size ceiling and introduces no runtime script/reference or linked workflow. The freeze predates the reserved implementations; all recorded freeze hashes still match.

Formatting does not rescue the production gate. Added production blank lines are main **2**, PR **3**, Ponytail **0**, candidate **0**, with no deleted production blank lines. Excluding those blanks still leaves candidate **105** versus main **96** and Ponytail **104**. All eight focused TypeScript Prettier checks pass. Python uses the repository's existing permissive Ruff configuration, not a newly imposed reformatter. Candidate uses three separate folded-column assignments; Ponytail uses tuple/generator assignment. Physical-line advantages from comments, wrapping or that layout are not different algorithms.

Generated JSON is especially important here. All **nine** changed/new snapshot files were parsed completely, including the multi-megabyte variant snapshot (`snapshotAudit.json`). Candidate replaces six existing one-line snapshots: six added/six deleted physical lines, **+157,611 bytes**, with **7,324,018 bytes** in their resulting files. Comparator dedicated snapshots add one line each and **22,905/18,428/17,245 bytes** respectively. Candidate's production byte growth is +2,185 versus +2,069/+2,620/+2,037. Its smaller physical combined diff is not a byte-size win over main or Ponytail.

## Real language, project and dependency composition

**Unicode search:** all arms use Python `str.casefold`, a deterministic SQLite connection-local UDF, and the existing SQLAlchemy connection event. The callback preserves NULL and is registered on each fresh reader connection; existing databases need no stored folded columns, migration or reindex. `GraphReader.find` retains SQL `instr` for literal punctuation, exact raw stable keys, rank and tie ordering, repository scope and limits. Candidate/PR share three SQL expression objects; main repeats expressions; Ponytail composes them through generator unpacking. This does not prove SQLite evaluates each expression only once per row. Service/CLI and project-name resolution boundaries remain unchanged.

**Literal paths:** every arm fixes the owning writable-engine constructor with SQLAlchemy `URL.create("sqlite", database=str(target))`. No manual quoting, URL parser, filename sanitizer or new configuration API. Existing `Path.expanduser`/resolution/parent creation remain intact. The read-only reader already composes `Path.as_uri()` with a structured SQLite URI and needs no additional patch. Migration, indexing/saved graph writes, CLI project listing and fresh read-only connections are exercised with option-looking and percent-encoded-looking literal filenames. Existing rollback, foreign keys, WAL and explicit migration facilities remain in place.

**Memory references:** every arm throws inside the existing `withStorageTransaction`/`begin immediate`/commit/rollback boundary; no replacement transaction layer. Existing stores, exact-name Maps, unique-name guarantees, `mergeNumbers` and Sets supply resolution/deduplication. `id !== undefined` keeps explicit IDs authoritative and zero unresolved; invalid IDs cannot fall back to valid names. Errors identify room/topic and missing name/ID. Candidate additionally builds the room-ID Set once in `createTopics`, outside the topic loop, and passes it into resolution; comparators rebuild it per topic. This is real common-lifetime composition, but costs signature/call-site churn and is not a measured throughput/memory claim. Late item-topic resolution still follows earlier writes inside the same transaction.

**Session confinement:** all arms check strict lexical and canonical containment and regular-file status before reading references or deleting. Escaping file/directory symlinks and unsafe sources cannot dispatch eligible children; directories/root/missing paths are ignored. Existing visited traversal handles repeats, shared children and cycles. Candidate centralizes resolution and catches invalid runtime child-path values within that boundary; PR adds a recursive JSON-value/object conversion layer, main/Ponytail add string checks. No parallel recursive deletion API or new dependency is needed. These are stable local-filesystem checks, **not TOCTOU protection**; concurrent filesystem races are explicitly outside the brief and this review.

**Ecto:** quantity patches are identical six `validate_number(..., greater_than_or_equal_to: 0)` compositions after existing cast/required steps. Vocabulary patches use `validate_inclusion`; Order splits state casting with `empty_values: []`, then requires state. Thus explicit nil/empty state cannot fall back to PENDING, omitted state retains the schema default, whitespace/unsupported case stays invalid rather than normalized, and cast errors remain cast errors. No transition policy, quantity change in the vocabulary task, custom parser, upper bound, migration, application or PostgreSQL operation was introduced. Production headroom here is already tiny.

```mermaid
flowchart LR
  Change[Owning production seam] --> Owned[Maintained regressions]
  Change --> Callers[Existing callers and their tests]
  Fixture[Changed fixture] --> Consumers[Snapshot and inventory consumers]
  Fixture --> Generator[Maintained generator]
  Owned --> Gate[Behavior AND completeness AND size gate]
  Callers --> Gate
  Consumers --> Gate
  Generator --> Gate
```

## Test contracts versus setup duplication

Candidate's session suite reduces test churn to 126 versus 192/222/192 by using one line writer, arrays of unsafe paths, and two integrated safety/traversal scenarios. It still asserts protected files/children, symlink survival, eligible sibling cleanup, malformed entries, cycles, missing children and directories. Fewer test cases alone are not evidence of weaker tests. PR/Ponytail additionally own positive internal-directory-symlink cases; candidate does not explicitly own that success case. The decisive demonstrated omission is the unchanged work-deletion consumer, not its case count.

Literal-path candidate selects six source/risk pairs rather than each filename times each argument-source representation. The shared persistence scenario performs idempotent migration, indexing/saved graph round trips, fresh readonly queries, attempted readonly deletion, WAL/foreign-key checks and a sibling sentinel. Existing CLI and production-indexed snapshot fixtures are also moved to hostile literal paths. This is genuine seam reuse, not merely deleting a matrix's assertions. Broader main/PR/Ponytail grids retain additional combinations; focused green checks do not prove all possible failure modes equivalent.

Unicode candidate extends the existing CoffeeNavigation collector and generator, rather than adding a parallel navigation snapshot function. Its high-fan-out fixture costs bytes but is fully integrated in this draw. Synthetic rank tests still separate exact fields, raw keys, ties, diagnostics and repository scope that a source sample alone cannot conveniently arrange. Snapshot and rank assertions are meaningful; they should not be removed for counts.

Memory candidate's 330 test lines nearly tie main's 329 and exceed Ponytail's 314. Shared `expectAtomicFailure`, input builder and sorted five-table reads are useful reuse. Rollback of earlier rows/links, recovery, exact names, zero IDs, metadata and exclusive ID precedence are distinct contracts. The exclusive precedence cases assert the unintended topic stays unlinked; combining a flow where both topics are expected would lose that discrimination. Separate find/unlink setup overlaps the successful creation scenario, but its assertions are not dispensable. Candidate does not explicitly test every same-block numeric-ID/empty-name variation that some comparators test; the frozen oracle supplements, rather than replaces, owned regressions.

Ecto case tables and parameter builders share assertion paths across schemas and representations. Individual negative fields, simultaneous errors, partial updates, cast/required errors, explicit-vs-omitted state, valid values and associations are meaningful. Repeating a common cast/action assertion across every magnitude or role/type/state Cartesian combination is mostly setup/runtime expansion; it is not a coverage score. Candidate's 167 quantity lines still exceed Ponytail's 158, while vocabulary's 220 narrowly beats PR's 221. No removed assertion or whitespace squeeze is credited as a substantive improvement.

## Checks actually executed

There are **157 completed command records**: exact command, cwd, environment, exit, duration and combined-log SHA-256 in `commandEvidence.json` and `evidence.json`; raw logs are under `commands/`. All completed commands had a 120-second cap; none timed out. **135 exits are zero; 19 nonzero original-production controls are expected; three nonzero work-consumer checks are R6.**

All **24 frozen acceptance**, **24 original manifest-native**, and **24 explicitly loaded changed/added maintained-suite** runs pass after recorded reviewer infrastructure retries. Python Unicode also gets a complete graph+coffee suite even where only the helper changed. TypeScript's four combined existing-plus-new memory suites pass. ExUnit native is the supplied oracle again, **not** discovery of added domain tests; all domain test files were explicitly loaded with the offline Ecto runtime, without Mix aliases, app startup or PostgreSQL.

| Arm | Unicode acceptance/native/full maintained | Literal paths acceptance/native/changed maintained | Memory acceptance/native/combined maintained | Session acceptance/native/changed maintained | Quantities acceptance/native/maintained | Vocabulary acceptance/native/maintained |
|---|---|---|---|---|---|---|
| main | 8/54/61 | 7/71/68 | 12/18/39 | 10/25/24 | 249/249/6 | 288/288/7 |
| PR | 8/72/79 | 7/91/94 | 12/18/37 | 10/27/26 | 249/249/15 | 288/288/9 |
| Ponytail | 8/67/74 | 7/74/73 | 12/18/34 | 10/18/25 | 249/249/6 | 288/288/10 |
| Candidate | 8/53/60 | 7/29/29 | 12/18/33 | 10/15/14 | 249/249/6 | 288/288/8 |

Counts describe selections, not comparable coverage scores. Python native Unicode deselects seven non-Python snapshots; complete maintained runs include them. Ponytail's session maintained selection includes its changed work test; other arms' changed selections do not, hence the separate shared consumer check.

All eight shared Python fixture-consumer runs pass (11 selected cases each); all four standalone Python script-member snapshot checks pass. All four **real full snapshot generators** run successfully in additional disposable copies. Separate generator-write interception executes their actual entrypoints and records every emitted snapshot and full JSON comparison: all nine changed/new snapshots are emitted and structurally match. Every arm's generator canonicalizes unrelated `variants/operational.json` bytes while leaving its parsed JSON equal; the original-production baseline operational probe reproduces that same serialization. This is not a changed Unicode snapshot or an implementation defect.

All eight focused Python Ruff and Pyright checks pass; Pyright uses each disposable checkout's `.venv` symlink to the shared environment, read-only by usage. All eight TS native typecheck/source-lint runs, eight explicit changed-file ESLint runs and eight focused Prettier checks pass. No agent-summary-only formatting, repository report, full lint or full-suite claim is counted as independently executed.

### Maintained original-production controls

Candidate production was restored to pinned original **only in separate review-owned copies**, retaining candidate tests/fixtures. This is original-code detection, not a mutation score.

| Candidate maintained suite on original production | Exit | Observed result |
|---|---:|---|
| Unicode graph+complete coffee suite | 1 | 2 failed, 58 passed: Unicode rank and indexed Unicode snapshot |
| Unicode coffee-only selection | 1 | 1 failed, 13 deselected; integration regression independently detects original behavior |
| Literal paths changed suites | 1 | 14 failed, 13 passed, 2 errors: literal target creation/readonly access plus CLI fixture setup |
| Memory block suite | 1 | 10 failed, 5 passed: unresolved room/topic cases fail to throw |
| Session suite | 1 | 2 failed, 12 passed: original traversal attempts to remove directories |
| Quantity suite | 2 | 2 failed, 4 passed |
| Vocabulary suite | 2 | 3 failed, 5 passed |

Literal-path changed test files were also run individually: coffee **8 failures/6 passes**, persistence **6 failures/6 passes**, CLI **1 pass/2 setup errors**. Thus the snapshot/CLI seam is not hidden behind the persistence failure. The session maintained suite's original-code failures occur before its final safety assertions, so they do **not** independently prove detection of every security branch. An additional frozen security-oracle run on original production gives **8 failures/2 passes**, separately demonstrating the original confinement holes.

Because Ecto table loops can stop at the first failure, each affected original production file was also restored **alone**. Quantity Order/CpuOrderData each cause one failure; Player causes two. Vocabulary Order causes three failures; Player and PlayerOrders one each. CPU/association validators are therefore not inferred from an earlier Order/Player failure. Compatibility tests remaining green on original production are expected and useful.

## Reproduction, integrity and limitations

`reviewDriver.py` constructs `git archive HEAD` copies and overlays only the measured changed files, preserving frozen implementations. It prepares read-only-by-usage dependency symlinks and captures command evidence. Native Python basetemps and process HOME/TMPDIR are unique review-local paths. The TS/Python oracle wrappers are **byte-identical local copies** under `checks/`, so their `__file__`-relative temporary directories stay inside `reviews/finalTwo`; Elixir's offline runtime is linked, not modified. `supplementDriver.py` runs full Python suites/generators and audits snapshots; `generatorProbe.py` records real generator write routes in memory. The probes do not repair experiment files.

A reviewer-local disk-quota interruption stopped metadata capture during the first aggregate pass. Seven command logs/empty metadata files and `checkProgress.log` are retained. Their exit metadata is **unavailable**, not guessed from green-looking output. All seven selections were rerun with distinct `Retry` logs and complete successful records after deleting only reviewer disposable HOME/TMPDIR scratch. The initial interruption is not an implementation failure or an all-invocations-pass claim. Final completed checks did not time out; expendable generator copies/scratch were removed after evidence capture, never logs or source outputs.

`before.json` and `after.json` match over **17,209** artifact/source/status entries. All 24 current worktree patches still match both their originally saved patch files and `result.json` patch hashes (`patchAudit.json`). All frozen hashes match (`freezeAudit.json`). No experiment worktree, original repository, profile, shared dependency or historical implementation was edited. All writes/execution scratch were confined to `reviews/finalTwo`; no install, network request, service or application/database server was started. SQLite test files are local disposable fixtures.

Full application/Python/dashboard/DB-backed Ecto suites were not independently run. Preserve implementation-summary limitations without promoting them to reviewer evidence: Ponytail literal-path reports a 240-second full-pytest timeout; candidate literal-path reports a full-suite timeout and fail-fast retry reaching 1,018 passes before a 15-second importer performance test failed. Dashboard dependencies/tools were reported missing (including candidate Unicode attempts). Those broader checks, repository reports and their causes were not reconstructed by this review. They remain unresolved limits, not passes and not a confirmed regression attribution.

The prior reviewer's accidental reserved TypeScript brief exposure remains disclosed; reserve tasks were now unlocked for this review. Neither strict reviewer blindness nor universal/statistical superiority is claimed. No further revision is proposed: the policy freezes candidateThree and every implementation. This complete draw's failed production gate alone prevents claiming the planned two-draw success, regardless of another draw's result; that other final review was not consulted.
