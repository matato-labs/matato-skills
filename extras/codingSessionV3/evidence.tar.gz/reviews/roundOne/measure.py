import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/tmp/codingSessionV3')
review = root / 'reviews/roundOne'
trials = []
aggregates = {}
snapshots = []

def category(name):
    parts = Path(name).parts
    if any(part in parts for part in ['test', 'tests', 'snapshots', 'fixtures']) or '.test.' in name or name.endswith('_test.exs'):
        return 'tests'
    return 'production' if name.endswith(('.ts', '.tsx', '.js', '.py', '.ex', '.exs')) else 'other'

def structure(value):
    if isinstance(value, dict):
        return {key: structure(entry) if isinstance(entry, (dict, list)) else type(entry).__name__ for key, entry in value.items()}
    if isinstance(value, list):
        return {'length': len(value), 'firstEntry': structure(value[0]) if value else None}
    return type(value).__name__

for resultPath in sorted((root / 'runs/tuningOne').glob('*/*/result.json')):
    result = json.loads(resultPath.read_text())
    folder = Path(result['worktree'])
    command = ['git', '-C', str(folder), 'diff', '--numstat', '-z', '--', '.', ':(exclude)node_modules', ':(exclude)atlas/.venv', ':(exclude)_build', ':(exclude)deps']
    entries = subprocess.check_output(command).decode().split('\0')
    files = []
    for entry in entries:
        if not entry:
            continue
        added, removed, name = entry.split('\t', 2)
        content = (folder / name).read_bytes()
        try:
            old = subprocess.check_output(['git', '-C', str(folder), 'show', result['base'] + ':' + name], stderr=subprocess.DEVNULL)
        except subprocess.CalledProcessError:
            old = b''
        files.append(dict(path=name, category=category(name), added=int(added), removed=int(removed), churn=int(added)+int(removed), net=int(added)-int(removed), bytesBefore=len(old), bytesAfter=len(content), byteNet=len(content)-len(old), sha256=hashlib.sha256(content).hexdigest()))
        if 'snapshots' in Path(name).parts:
            parsed = json.loads(content)
            snapshots.append(dict(arm=result['arm'], path=name, structure=structure(parsed)))
    totals = {kind: {metric: sum(entry[metric] for entry in files if entry['category'] == kind) for metric in ['added', 'removed', 'churn', 'net', 'byteNet']} for kind in ['production', 'tests', 'other']}
    trials.append(dict(arm=result['arm'], case=result['case'], files=files, totals=totals))
    aggregate = aggregates.setdefault(result['arm'], {kind: dict(added=0, removed=0, churn=0, net=0, byteNet=0) for kind in totals})
    for kind in totals:
        for metric in totals[kind]:
            aggregate[kind][metric] += totals[kind][metric]
(review / 'metrics.json').write_text(json.dumps(dict(trials=trials, aggregates=aggregates), ensure_ascii=False, indent=2)+'\n')
(review / 'snapshotStructures.json').write_text(json.dumps(snapshots, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(aggregates, indent=2))
for trial in trials:
    print(trial['arm'], trial['case'], trial['totals'])
