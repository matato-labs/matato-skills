# Frozen implementation results

## sourceBatchReads

Changed only the allowed service files and the existing graph-navigation regression tests. A per-sources-call path cache stores verification status and bytes, not node-specific excerpt results; single-source calls remain uncached.

Commands:
- `python /tmp/codingSessionV2/research/oracles/sourceBatchReads.py /tmp/codingSessionV2/runs/ponytailFrozen/sourceBatchReads` — 5 passed.
- `ln -s /home/leon/workspace/projects/atlas/atlas/.venv sourceBatchReads/atlas/.venv` — local interpreter/dependency link only.
- From `sourceBatchReads/atlas`: `PYTHONPATH=src .venv/bin/python -m pytest tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py` — 61 passed; `PYTHONPATH=src .venv/bin/pyright` — clean; `.venv/bin/ruff check .` — clean.

Unrelated dashboard builds, full-project report generation and the full importer suite skipped; no dashboard or indexing changes.

## isinCsvRecords

Replaced physical-line scanning with the standard CSV reader. Header field count is unrestricted; data records require three fields. The loop checks the limit before reading the next record. Production embedded data is unchanged. Added a native limit regression.

Commands:
- `gofmt -w isinCsvRecords/commons/data/isin_loader.go isinCsvRecords/commons/data/isin_loader_test.go` — completed.
- `python /tmp/codingSessionV2/research/oracles/isinCsvRecords.py /tmp/codingSessionV2/runs/ponytailFrozen/isinCsvRecords` — all 13 scenarios passed.
- From `isinCsvRecords/commons`: `go test ./data` — passed.

## scheduleTimeZones

Added the optional production timezone field and a backward-compatible optional factory argument. Enabled-job zones are validated using Intl before any factory call; Croner handles zone-aware calendar calculations. Disabled jobs skip validation. Existing candidate cleanup/replacement and overlap tracking are unchanged. Added an injected-factory rollback regression.

Commands:
- `python /tmp/codingSessionV2/research/oracles/scheduleTimeZones.py /tmp/codingSessionV2/runs/ponytailFrozen/scheduleTimeZones` — 7 passed.
- `python /tmp/codingSessionV2/research/finalOracles/scheduleFactoryContract.py /tmp/codingSessionV2/runs/ponytailFrozen/scheduleTimeZones` — 8 passed (additional acceptance).
- From `scheduleTimeZones`: `bunx prettier --write worker/scheduler.test.ts` — formatted; `bun test` — 100 passed, 3 failed because Pi peer modules are unavailable in the linked dependency tree.
- `bun test worker/scheduler.test.ts worker/watcher.test.ts src/automationConfig.test.ts` — 17 passed.
- `bun run check` and `bun run lint` — blocked: `tsc` and `eslint` executables absent. No dependency/configuration changes made to work around unrelated missing tools.

## pathEarlyExit

Added an optional traversal target used by path only. The BFS loop stops on target admission; expansion returns before later neighbors and fetch-limit bookkeeping. Context retains its original traversal. Added native query-count/depth-zero regressions and updated affected navigation snapshots using the existing generator.

Commands:
- `python /tmp/codingSessionV2/research/oracles/pathEarlyExit.py /tmp/codingSessionV2/runs/ponytailFrozen/pathEarlyExit` — 8 passed.
- `ln -s /home/leon/workspace/projects/atlas/atlas/.venv pathEarlyExit/atlas/.venv` — local dependency link.
- From `pathEarlyExit/atlas`: `PYTHONPATH=src .venv/bin/python -m pytest tests/test_graph_navigation.py tests/test_coffee_navigation_snapshots.py` — initially 53 passed, 8 snapshot failures from intentionally reduced found-path graphs.
- Ran an inline Python snapshot review using `navigation_responses`: asserted that only found-path responses changed, routes/pathEdges stayed identical, retained nodes/edges were ordered prefixes, and only graph/boundary metadata could differ. Reviewed external-boundary reductions: boundaries belong only to admitted external nodes. No context or unsuccessful-path differences.
- Invoked existing `tests.update_coffee_snapshots.write_navigation` for `CORE_LANGUAGES`, not the unrelated full snapshot generator.
- Reran the focused pytest command — 61 passed. `PYTHONPATH=src .venv/bin/pyright` and `.venv/bin/ruff check .` — clean.

Unrelated dashboard, full importer suite and full-project report skipped.

## pollProcessContract

Polling now uses the receiver, the acknowledgement IDs are filled in place (ordered duplicates retained), and errors.Join preserves processor and failed-ack causes. Existing endpoint helpers already preserve HTTP/transport causes and are unchanged. Added HTTP-server native regressions for success, processor failure and dual failure.

Commands:
- `gofmt -w pollProcessContract/commons/sintropy/messages.go pollProcessContract/commons/sintropy/messages_test.go` — completed.
- `python /tmp/codingSessionV2/research/finalOracles/pollProcessContract.py /tmp/codingSessionV2/runs/ponytailFrozen/pollProcessContract` — all 6 scenarios passed.
- From `pollProcessContract/commons`: `go test -vet=off ./sintropy` — passed. Vet disabled as requested for existing unrelated logger-format blockers.

## preScriptIsolation

Awaited run inside the existing mutex/finally scope and stored undefined separately from empty strings for exact environment restoration. No changes to shell execution, cache URLs, skip handling or telemetry. Added direct Bun regressions for async isolation and recovery after sync throw, async rejection and import failure.

Commands:
- `python /tmp/codingSessionV2/research/finalOracles/preScriptIsolation.py /tmp/codingSessionV2/runs/ponytailFrozen/preScriptIsolation` — 6 passed.
- From `preScriptIsolation`: `bun test src/worker/preScript.test.ts src/worker/bus/preScript.test.ts src/worker/scheduledJobs/preScript.test.ts` — 4 passed; 2 integration files blocked by absent croner/drizzle-orm dependencies.
- `bun test src/worker/preScript.test.ts` — 4 passed.
- `bun run typecheck` — blocked by missing Bun type definitions; `bun run lint` — blocked by missing @eslint/js. No project dependency or lockfile changes occurred.
- `bunx prettier --config /dev/null --no-semi --single-quote --trailing-comma all --write src/worker/preScript.ts src/worker/preScript.test.ts` — formatted using project style without unavailable frontend plugins.
- `git diff --check` — clean.

## Final verification

Ran `git -C "$caseName" status --short` and `git -C "$caseName" diff --check` for all six cases in listed order: all whitespace checks clean; production changes limited to each brief's allowedScope, plus focused tests/snapshots. The Python environment links are ignored local links. No README, Git configuration, shared brief/profile/oracle, original repository, or parent-project changes; no commits or pushes.

After formatting, reran `bun test src/worker/preScript.test.ts` (4 passed) and `python /tmp/codingSessionV2/research/finalOracles/preScriptIsolation.py /tmp/codingSessionV2/runs/ponytailFrozen/preScriptIsolation` (6 passed).

All required external oracles, including scheduler additionalAcceptance, passed. Remaining validation risk is the unavailable TypeScript tooling/dependency coverage noted above; unrelated whole-project checks were not substituted for the focused passing checks.
