from datetime import datetime
import hashlib
import json
from pathlib import Path
import re

out = Path('/home/leon/.cache/codingSessionV4Owned/reviews/finalTwo')
root = Path('/tmp/codingSessionV4')
commands = []
summary = []
for path in sorted((out / 'logs').rglob('*.execution.json')):
    execution = json.loads(path.read_text())
    arm, case = path.parts[-3:-1]
    label = path.name.removesuffix('.execution.json')
    record = {'identity': 'finalTwo/' + arm, 'case': case, 'label': label, **execution}
    commands.append(record)
    text = Path(execution['stdout']).read_text() + Path(execution['stderr']).read_text()
    summary.append({key: record[key] for key in ['identity', 'case', 'label', 'exit', 'timedOut', 'seconds', 'timeoutSeconds']} | {
        'pythonSummary': re.findall(r'\d+ (?:failed|passed)[^\n]*', text)[-1:],
        'bunPassCounts': [int(value) for value in re.findall(r'(\d+) pass\b', text)],
        'bunFailCounts': [int(value) for value in re.findall(r'(\d+) fail\b', text)],
        'bunErrorCounts': re.findall(r'\d+ errors?\b', text),
        'snapshots': re.findall(r'PASS: generator[^\n]*', text),
        'fixturePasses': len(re.findall(r'^PASS ', text, re.M)),
        'fixtureFailures': len(re.findall(r'^FAIL ', text, re.M)),
        'stdout': execution['stdout'], 'stderr': execution['stderr'],
    })
(out / 'allCommands.json').write_text(json.dumps(commands, indent=2) + '\n')
(out / 'checkSummary.json').write_text(json.dumps(summary, indent=2) + '\n')
intervals = []
for record in commands:
    intervals += [(datetime.fromisoformat(record['startedAt']).timestamp(), 1), (datetime.fromisoformat(record['finishedAt']).timestamp(), -1)]
active = maximum = 0
for timestamp, change in sorted(intervals):
    active += change
    maximum = max(maximum, active)
limits = {'completedExecutionRecords': len(commands), 'reviewNative120Timeouts': sum(record['timedOut'] for record in commands), 'diagnostic240Timeouts': sum(record['timedOut'] for record in commands if record['timeoutSeconds'] == 240), 'maximumRecordedConcurrency': maximum, 'maximumTimeoutSeconds': max(record['timeoutSeconds'] for record in commands), 'knownCheckSpanSeconds': round(max(timestamp for timestamp, change in intervals) - min(timestamp for timestamp, change in intervals), 3), 'interruptedNativeChecks': 8, 'interruptionTimelineLimit': 'Initial eight native checks lack completed execution records; eight-worker source structure and killing descendants before resumption bound their concurrency. collectionInterruption.json retains process argv. Not scored as passes.'}
assert maximum <= 8 and limits['maximumTimeoutSeconds'] <= 240
(out / 'executionLimits.json').write_text(json.dumps(limits, indent=2) + '\n')
integrity = {}
for name, expected in json.loads((out / 'inputHashes.json').read_text()).items():
    path = Path(name)
    integrity[name] = path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == expected
sourceMatches = {}
for identity, expected in json.loads((out / 'checksums.json').read_text()).items():
    roundName, arm, case, name = identity.split('/', 3)
    live = root / 'worktrees' / roundName / arm / case / name
    copy = out / 'copies' / roundName / arm / case / name
    sourceMatches[identity] = all(hashlib.sha256(path.read_bytes()).hexdigest() == expected for path in [live, copy])
assert all(integrity.values()) and all(sourceMatches.values())
(out / 'finalIntegrity.json').write_text(json.dumps({'frozenInputs': integrity, 'liveAndOwnedChangedFiles': sourceMatches, 'allMatch': True, 'repairs': False, 'modelRuns': 0}, indent=2) + '\n')
print(json.dumps(limits, indent=2))
for item in summary:
    if item['label'] in ['nativeDiagnostic240', 'allMaintained0', 'allMaintained1', 'originalProductionMaintained0', 'originalProductionMaintained1', 'existingApiAndAgentConsumers']:
        print(json.dumps(item))
