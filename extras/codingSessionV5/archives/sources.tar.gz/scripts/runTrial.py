"""Standalone V5 CLI: run, originals, check. Only run can launch a model."""
import argparse
from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import shlex
import shutil
import sys
import time
import uuid

from auditTrial import audit, publish, scrub
from common import agentArgs, consume, digest, identifier, model, owned, save, scratch, settings, slot, proxyAlias
from measureTrial import capture, git
from nativeTrial import auditActivation, nativeArgs, nativeEnvironment, packageFiles, packageHash, prepareNative
from providerProxy import startProxy
from sandboxTrial import Sandbox, environment, execute, sandbox, shell


@dataclass
class Case:
    id: str
    repo: str
    base: str
    brief: str
    checkCommand: str
    nativeCommand: str = ''
    setupCommands: list[str] = field(default_factory=list)
    dependencyPaths: list[str] = field(default_factory=list)
    inputPaths: list[str] = field(default_factory=list)


def casesFrom(manifest: Path) -> list[Case]:
    data = json.loads(manifest.read_text())
    cases = [Case(**{key: value for key, value in item.items() if key in Case.__dataclass_fields__})
             for item in data['cases']]
    for case in cases:
        identifier(case.id)
        if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', case.base):
            raise ValueError('base must be a full immutable commit hash')
        if git(Path(case.repo), ['rev-parse', f'{case.base}^{{commit}}']).decode().strip() != case.base:
            raise ValueError('base does not resolve to the requested commit')
    return cases


def freezeInputs(case: Case, private: Path) -> list[tuple[Path, Path]]:
    frozen = []
    for number, name in enumerate(case.inputPaths):
        source = Path(name).resolve(strict=True)
        target = private / f'input{number}'
        if source.is_dir():
            shutil.copytree(source, target, symlinks=True)
        else:
            shutil.copyfile(source, target)
        frozen.append((target, Path(name)))
    return frozen


def prepare(case: Case, manifest: Path, folder: Path, private: Path, pi: Path) -> Sandbox:
    workspace = folder.parent / 'workspace'
    workspace.mkdir()
    runtime = private / 'runtime'
    runtime.mkdir()
    spec = Sandbox(workspace, Path(case.repo).resolve(), runtime, pi,
                   [Path(path) for path in case.dependencyPaths], freezeInputs(case, private))
    command = (f'git -c core.hooksPath=/dev/null clone --no-hardlinks --no-checkout --local '
               f'{shlex.quote(str(spec.source))} . && git -c core.hooksPath=/dev/null '
               f'checkout --detach {case.base}')
    record = shell(spec, 'clone', command, private, cloning=True)
    publish(record, 'clone', folder, [])
    if record['exit']:
        raise RuntimeError('Frozen clone failed; inspect clone evidence')
    if git(workspace, ['rev-parse', 'HEAD']).decode().strip() != case.base:
        raise RuntimeError('Clone commit mismatch')
    if (workspace / '.git/objects/info/alternates').exists():
        raise RuntimeError('Clone unexpectedly shares an object store')
    (folder / 'manifest.json').write_bytes(manifest.read_bytes())
    save(folder / 'case.json', case.__dict__)
    save(folder / 'inputs.json', inputInventory(spec.inputs))
    for number, command in enumerate(case.setupCommands):
        record = shell(spec, f'setup{number}', command.replace('{root}', str(workspace)), private)
        publish(record, f'setup{number}', folder, [])
        if record['exit']:
            raise RuntimeError('Offline setup failed; model not launched')
    return spec


def inputInventory(inputs: list[tuple[Path, Path]]):
    records = []
    for snapshot, alias in inputs:
        files = sorted(snapshot.rglob('*')) if snapshot.is_dir() else [snapshot]
        for path in files:
            if path.is_symlink():
                records.append({'alias': str(alias), 'path': str(path.relative_to(snapshot.parent)),
                                'symlink': str(path.readlink())})
            elif path.is_file():
                records.append({'alias': str(alias), 'path': str(path.relative_to(snapshot.parent)),
                                'sha256': digest(path.read_bytes())})
    return records


def promptFor(case: Case, native: bool = False) -> str:
    delivery = ('The native Ponytail extension injects its full-mode transformation of that profile; raw SKILL is not appended.'
                if native else 'That exact selected profile is also appended to your system prompt (text-only arm).')
    return f'''Your FIRST tool call must be read with path /experiment/profile.md, reading the COMPLETE file. {delivery} Follow it.
Then explicitly read local repository AGENTS.md/CLAUDE.md and overrides at the root and affected directories. Automatic global/parent context discovery is disabled, not local repository instructions.
Implement in this owned checkout:

{case.brief}

Add maintained regression coverage and run relevant service-free checks.
Independent acceptance: {case.checkCommand}
Focused native check: {case.nativeCommand or 'not supplied'}
Here {{root}} means the absolute current checkout path. Dependencies and setup are already prepared.
Edit only this checkout. No README edits, installs, live application services, persistent servers, network utilities, credentials, commits, staging/index writes, pushes, branches, worktrees, global settings, extra skills/extensions/MCP, prior runs or rival profiles. Originals, dependencies, inputs, profile and Git metadata are read-only. Provider HTTPS alone is available through a restricted proxy. Report files changed, checks actually run and blockers; stop when complete.
'''


def prepareAuth(source: Path, private: Path) -> tuple[Path, list[str]]:
    credential = json.loads(source.read_text())['openai-codex']
    # Never copy settings, other providers or command-based credential resolution.
    selected = {key: credential[key] for key in ['type', 'access', 'refresh', 'expires', 'accountId', 'key']
                if key in credential}
    if selected.get('key', '').startswith('!'):
        raise ValueError('Command-based auth is not supported')
    path = private / 'auth.json'
    save(path, {'openai-codex': selected})
    path.chmod(0o400)
    return path, [selected[key] for key in ['access', 'refresh', 'accountId', 'key'] if selected.get(key)]


def runAgent(spec: Sandbox, case: Case, profile: bytes, private: Path, folder: Path,
             identity: str, secrets: list[str]):
    native = spec.package is not None
    if native and spec.nativeInstructions is None:
        raise ValueError('Native runs require the offline activation preflight')
    spec.profile = private / 'profile.md'
    spec.profile.write_bytes(profile)
    (folder / 'profile.md').write_bytes(spec.profile.read_bytes())
    spec.config = private / 'agentConfig'
    spec.config.mkdir()
    save(spec.config / 'settings.json', settings)
    (spec.config / 'auth.json').touch()
    prompt = promptFor(case, native)
    (folder / 'prompt.txt').write_text(prompt)
    stage = spec.runtime / 'agent'
    env = nativeEnvironment(stage) if native else environment(stage)
    resources = nativeArgs() if native else []
    endpoint = owned(scratch / 'sockets') / f'{uuid.uuid4().hex[:16]}.sock'
    server = startProxy(endpoint)
    try:
        argv = sandbox(spec, stage, endpoint, agent=True) + [sys.executable,
                '/experiment/providerProxy.py', str(proxyAlias), *agentArgs(spec.pi, native), *resources, '--', prompt]
        save(folder / 'invocation.json', {'argv': argv, 'environment': env, 'settings': settings,
             'piSha256': digest(spec.pi.read_bytes()), 'model': model, 'thinking': 'high',
             'tools': ['read', 'bash', 'edit', 'write'], 'timeoutSeconds': 600,
             'network': 'private namespace; CONNECT 443 only to provider allowlist',
             'auth': 'selected-provider private copy, read-only; raw/auth never published',
             'native': native, 'arm': json.loads((folder / 'package.json').read_text())['arm'] if native else 'textOnly'})
        consume(identity)
        save(private / 'launch.json', {'identity': identity, 'timeoutSeconds': 600})
        record = execute(argv, env, private, 'agent', 600)
    finally:
        server.shutdown()
        server.server_close()
        endpoint.unlink(missing_ok=True)
    report = audit(Path(record['stdout']), folder, spec.profile.read_bytes(), secrets)
    if native:
        activation = auditActivation(Path(record['stdout']), spec.nativeInstructions.read_bytes())
        save(folder / 'activation.json', activation)
        report.update(nativeActivation=activation, valid=report['valid'] and activation['valid'])
        save(folder / 'audit.json', report)
    # Never publish raw stdout, nor tool results or hidden thinking. Stderr is sanitized separately.
    (folder / 'agent.stderr').write_text(scrub(Path(record['stderr']).read_text(errors='replace'), secrets))
    public = {key: value for key, value in record.items() if key not in {'stdout', 'stderr'}}
    save(folder / 'agent.json', public)
    return public, report, secrets


def checks(spec: Sandbox, case: Case, private: Path, folder: Path, secrets: list[str]):
    exits = {}
    for label, command in [('acceptance', case.checkCommand), ('native', case.nativeCommand)]:
        if not command:
            exits[label] = None
            continue
        record = shell(spec, label, command.replace('{root}', str(spec.workspace)), private)
        publish(record, label, folder, secrets)
        exits[label] = record['exit']
    return exits


def executeCase(case: Case, manifest: Path, root: Path, pi: Path,
                profile: Path | None = None, draw: str = '', authSource: Path | None = None,
                package: Path | None = None) -> Path:
    profileBytes = profile.read_bytes() if profile else b''
    profileId = f'{profile.stem}.{digest(profileBytes)[:12]}' if profile else ''
    if package:
        profileId += '.native.' + packageHash(packageFiles(package, profileBytes))[:12]
    identity = f'{draw}/{profileId}/{case.id}' if profile else f'original/{case.id}/{uuid.uuid4().hex[:8]}'
    parent = root / ('runs' if profile else 'originals') / identity
    parent.mkdir(parents=True, exist_ok=False, mode=0o700)
    folder, private = parent / 'evidence', parent / 'private'
    folder.mkdir(mode=0o700)
    private.mkdir(mode=0o700)
    started, secrets = time.monotonic(), []
    result = {'identity': identity, 'status': 'failed', 'modelLaunched': False, 'base': case.base,
              'native': package is not None, 'arm': 'nativePendingProof' if package else 'textOnly' if profile else 'original',
              'agent': None, 'audit': None, 'measurement': None,
              'checks': {'acceptance': None, 'native': None},
              'unavailableNote': 'null means not captured/not executed, never a zero or passing result.',
              'manifestSha256': digest(manifest.read_bytes()), 'startedAt': datetime.now(timezone.utc).isoformat(),
              'piVersion': '1.2.0', 'safety': {'filesystem': 'allowlist; originals/dependencies/Git read-only',
              'network': 'unshared; checks have no proxy/auth', 'services': 'no app services authorized',
              'permissionDenials': None, 'safetyOutcome': 'unavailable: not a semantic security review'}}
    spec = None
    try:
        spec = prepare(case, manifest, folder, private, pi)
        if profile:
            if package:
                prepareNative(spec, package, profileBytes, private, folder)
                info = json.loads((folder / 'package.json').read_text())
                result.update(arm=info['arm'], packageSha256=info['sha256'])
            if authSource is None:
                raise ValueError('Auth source required')
            spec.auth, secrets = prepareAuth(authSource, private)
            record, report, secrets = runAgent(spec, case, profileBytes, private, folder, identity, secrets)
            result.update(modelLaunched=True, agent=record, audit=report, profileSource=str(profile),
                          profileSha256=digest(profileBytes))
            result['status'] = 'completed' if record['exit'] == 0 and report['valid'] else 'invalidAgentRun'
        else:
            result['status'] = 'originalPreflight'
        result['checks'] = checks(spec, case, private, folder, secrets)
    except Exception as error:
        # Keep error detail private: exceptions from subprocess/JSON may contain credential bytes.
        (private / 'failure.txt').write_text(str(error))
        result['error'] = type(error).__name__ + '; inspect private failure locally (never publish)'
    finally:
        result['modelLaunched'] = (private / 'launch.json').exists()
        if spec and (spec.workspace / '.git').exists():
            try:
                result['measurement'] = capture(spec.workspace, folder, private, case.base, secrets)
            except Exception as error:
                result.update(status='captureFailed', captureError=type(error).__name__)
        result['seconds'] = round(time.monotonic() - started, 3)
        save(folder / 'result.json', result)
        files = {path.name: digest(path.read_bytes()) for path in folder.iterdir() if path.is_file()}
        save(folder / 'integrity.json', files)
    return folder


def checkCaptured(folder: Path, root: Path) -> None:
    folder = folder.resolve()
    if not folder.is_relative_to(root) or folder.name != 'evidence':
        raise ValueError('check expects an owned evidence directory')
    hashes = json.loads((folder / 'integrity.json').read_text())
    for name, expected in hashes.items():
        if Path(name).name != name or digest((folder / name).read_bytes()) != expected:
            raise ValueError('Evidence hash mismatch')
    result = json.loads((folder / 'result.json').read_text())
    target = owned(root / 'verification' / uuid.uuid4().hex)
    measured = capture(folder.parent / 'workspace', target, target, result['base'], [])
    if measured != result['measurement']:
        raise ValueError('Captured checkout/measurement differs')
    print(json.dumps({'integrity': 'passed', 'measurement': 'reproduced',
                      'status': result['status'], 'checks': result.get('checks'),
                      'note': 'Integrity is not a correctness/safety verdict; checks are not rerun.'}))


def installedPi() -> Path:
    found = shutil.which('pi')
    if not found:
        raise RuntimeError('Pi 1.2.0 is required')
    pi = Path(found).resolve()
    # Version probe only, in a clean namespace; never execute a prompt/catalog/auth command.
    probe = owned(scratch / 'probes' / uuid.uuid4().hex)
    spec = Sandbox(probe, pi.parent, probe / 'runtime', pi)
    stage = spec.runtime / 'version'
    record = execute(sandbox(spec, stage, cloning=True) + [str(pi), '--version'],
                     environment(stage), probe, 'version', 20)
    if record['exit'] or Path(record['stdout']).read_text().strip() != '1.2.0':
        raise RuntimeError('Sandbox Pi version must be exactly 1.2.0')
    return pi


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=scratch)
    commands = parser.add_subparsers(dest='command', required=True)
    run = commands.add_parser('run', help='one selected case, manifest/profile/draw; consumes one model launch')
    run.add_argument('manifest', type=Path)
    run.add_argument('profile', type=Path, help='exact Markdown file; first tool must read it')
    run.add_argument('draw', type=identifier)
    run.add_argument('--case', dest='caseId')
    run.add_argument('--native', action='store_true', help='native Ponytail full-mode runtime, not text-only')
    run.add_argument('--package', type=Path, help='native package root; requires --native and matching profile')
    run.add_argument('--authSource', type=Path, default=Path.home() / '.pi/agent/auth.json')
    originals = commands.add_parser('originals', help='offline setup/checks against cloned original bases; no model/auth')
    originals.add_argument('manifest', type=Path)
    check = commands.add_parser('check', help='verify hashes and reproduce captured metrics; no model/auth')
    check.add_argument('evidence', type=Path)
    args = parser.parse_args()
    if args.command == 'run' and args.native != (args.package is not None):
        parser.error('--native and --package must be supplied together')
    root = owned(args.root)
    if args.command == 'check':
        checkCaptured(args.evidence, root)
        return
    manifest = args.manifest.resolve(strict=True)
    cases = casesFrom(manifest)
    if args.command == 'run':
        package = args.package.resolve(strict=True) if args.package else None
        profile = args.profile.resolve(strict=True)
        identifier(profile.stem)
        if package:
            packageFiles(package, profile.read_bytes())
        cases = [case for case in cases if not args.caseId or case.id == args.caseId]
        if len(cases) != 1:
            parser.error('run requires one case; use --case for a multi-case manifest')
    pi = installedPi()
    failed = False
    for case in cases:
        with slot():
            if args.command == 'run':
                folder = executeCase(case, manifest, root, pi, profile, args.draw, args.authSource, package)
            else:
                folder = executeCase(case, manifest, root, pi)
        print(folder)
        result = json.loads((folder / 'result.json').read_text())
        failed = failed or result['status'] not in {'completed', 'originalPreflight'}
        if args.command == 'run':
            failed = failed or any(code != 0 for code in result.get('checks', {}).values() if code is not None)
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
