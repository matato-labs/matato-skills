"""Complete Git binary patch plus separated delivered-code metrics; private index only."""
import os
from pathlib import Path
import subprocess
import zlib

from common import digest, save
from evidenceTypes import FileMeasure

codeExtensions = {'.py', '.pyi', '.js', '.ts', '.jsx', '.tsx', '.mjs', '.cjs', '.html', '.css',
                  '.scss', '.go', '.rs', '.java', '.rb', '.sh', '.bash', '.ex', '.exs', '.c',
                  '.h', '.cpp', '.hpp', '.kt', '.swift', '.vue', '.svelte', '.sql', '.lua'}


def git(workspace: Path, args: list[str], index: Path | None = None) -> bytes:
    env = {'PATH': '/usr/bin:/bin', 'HOME': '/nonexistent', 'LC_ALL': 'C.UTF-8',
           'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_OPTIONAL_LOCKS': '0'}
    if index:
        env['GIT_INDEX_FILE'] = str(index)
    return subprocess.check_output(['git', '-c', 'core.hooksPath=/dev/null', '--no-optional-locks',
                                    '-C', str(workspace), *args], env=env, stderr=subprocess.PIPE)


def category(path: str) -> str:
    name, parts = Path(path).name.lower(), {part.lower() for part in Path(path).parts}
    if parts & {'fixtures', 'fixture', 'testdata', 'golden', 'goldens', '__fixtures__'}:
        return 'fixtures'
    if parts & {'snapshots', '__snapshots__'} or name.endswith('.snap'):
        return 'snapshots'
    if (parts & {'test', 'tests', '__tests__', 'spec', 'specs'} or name.startswith('test_') or
            name == 'conftest.py' or '.test.' in name or '.spec.' in name or
            name.endswith(('_test.py', '_test.go', '_test.rs', '_test.exs', '_spec.rb'))):
        return 'tests' if Path(path).suffix.lower() in codeExtensions else 'other'
    return 'production' if Path(path).suffix.lower() in codeExtensions else 'other'


def compressed(data: bytes) -> int:
    if not data:
        return 0
    compressor = zlib.compressobj(9, zlib.DEFLATED, -15)
    return len(compressor.compress(data) + compressor.flush())


def loc(data: bytes):
    lines = data.decode('utf-8', errors='replace').splitlines()
    nonblank = [line.strip() for line in lines if line.strip()]
    return {'physical': len(lines), 'nonblank': len(nonblank),
            'code': sum(not line.startswith(('#', '//', '*', '/*', '*/')) for line in nonblank)}


def fileBytes(workspace: Path, path: str) -> bytes:
    target = workspace / path
    # Never follow a model-created parent-directory symlink into host/private storage.
    if any(parent.is_symlink() for parent in target.parents if parent != workspace):
        raise ValueError('Symlink ancestor in captured path')
    if target.is_symlink():
        return os.fsencode(os.readlink(target))
    return target.read_bytes() if target.is_file() else b''


def lineChanges(patch: bytes) -> tuple[bytes, bytes]:
    added, deleted = [], []
    inHunk = False
    previous = b''
    for part in patch.split(b'\n'):
        line = part + b'\n'
        if line.startswith(b'@@ '):
            inHunk = True
            continue
        if line.startswith(b'diff --git '):
            inHunk = False
        if not inHunk:
            continue
        if line.startswith(b'\\ No newline at end of file'):
            if previous == b'+':
                added[-1] = added[-1].removesuffix(b'\n')
            if previous == b'-':
                deleted[-1] = deleted[-1].removesuffix(b'\n')
        if line.startswith(b'+'):
            added.append(line[1:])
        if line.startswith(b'-'):
            deleted.append(line[1:])
        previous = line[:1]
    return b''.join(added), b''.join(deleted)


def capture(workspace: Path, folder: Path, private: Path, base: str, secrets: list[str]):
    from auditTrial import scrub
    index = private / 'measurementIndex'
    git(workspace, ['read-tree', base], index)
    new = git(workspace, ['ls-files', '--others', '--exclude-standard', '-z']).split(b'\0')
    paths = [os.fsdecode(path) for path in new if path]
    for start in range(0, len(paths), 100):
        git(workspace, ['add', '-N', '--', *paths[start:start + 100]], index)
    options = ['--binary', '--no-ext-diff', '--no-textconv', '--no-renames', '--no-color']
    patch = git(workspace, ['diff', *options, base, '--'], index)
    # An exact patch cannot also be redacted. Fail closed rather than publish a secret or fake patch.
    if scrub(patch.decode('utf-8', errors='replace'), secrets) != patch.decode('utf-8', errors='replace'):
        raise ValueError('Patch publication blocked by secret scanner')
    changes = git(workspace, ['diff', '--numstat', '-z', *options[1:], base, '--'], index).split(b'\0')
    files: list[FileMeasure] = []
    additions: dict[str, bytes] = {}
    for entry in changes:
        if not entry:
            continue
        plus, minus, rawPath = entry.split(b'\t', 2)
        path = os.fsdecode(rawPath)
        old = bool(git(workspace, ['ls-tree', base, '--', path]))
        before = git(workspace, ['show', f'{base}:{path}']) if old else b''
        after = fileBytes(workspace, path)
        if any(scrub(data.decode('utf-8', errors='replace'), secrets) !=
               data.decode('utf-8', errors='replace') for data in [before, after]):
            raise ValueError('File publication blocked by secret scanner')
        delta = git(workspace, ['diff', '--unified=0', *options, base, '--', path], index)
        addedBytes, deletedBytes = lineChanges(delta)
        kind = category(path)
        additions[path] = addedBytes
        files.append({'path': path, 'category': kind, 'binary': plus == b'-',
                      'added': int(plus) if plus != b'-' else None,
                      'deleted': int(minus) if minus != b'-' else None,
                      'addedBytes': len(addedBytes) if plus != b'-' else None,
                      'deletedBytes': len(deletedBytes) if minus != b'-' else None,
                      'baseBytes': len(before), 'resultBytes': len(after),
                      'byteGrowth': len(after) - len(before), 'beforeLoc': loc(before), 'afterLoc': loc(after)})
    totals = {kind: aggregate([item for item in files if item['category'] == kind],
                              b''.join(additions[item['path']] for item in files if item['category'] == kind))
              for kind in ['production', 'tests', 'fixtures', 'snapshots', 'other']}
    totals['combined'] = aggregate(files, b''.join(additions.values()))
    result = {'base': base, 'patchSha256': digest(patch), 'patchBytes': len(patch),
              'files': files, 'totals': totals,
              'scope': 'Changed tracked files plus unignored added files; symlinks as links; no dependency traversal.',
              'locNote': 'Physical, nonblank and line-prefix comment heuristic; not a language parser.',
              'compressionNote': 'Raw DEFLATE level 9 over added diff code bytes, sorted paths; not gzip.'}
    (folder / 'changes.patch').write_bytes(patch)
    save(folder / 'measurement.json', result)
    return result


def aggregate(files: list[FileMeasure], added: bytes):
    return {'files': len(files),
            **{key: sum(item[key] for item in files) if all(item[key] is not None for item in files)
               else None for key in ['added', 'deleted', 'addedBytes', 'deletedBytes']},
            'baseBytes': sum(item['baseBytes'] for item in files),
            'resultBytes': sum(item['resultBytes'] for item in files),
            'byteGrowth': sum(item['byteGrowth'] for item in files),
            'beforeLoc': {key: sum(item['beforeLoc'][key] for item in files) for key in loc(b'')},
            'afterLoc': {key: sum(item['afterLoc'][key] for item in files) for key in loc(b'')},
            'binaryFiles': sum(item['binary'] for item in files), 'compressedAddedBytes': compressed(added)}
