import { afterEach, beforeEach, test } from 'bun:test'
import assert from 'node:assert/strict'
import { lstat, mkdir, mkdtemp, readFile, rm, symlink, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { deleteManagedSessionTree, resolveGuiChatSessionDirectory, resolveGuiChatSessionManager } from 'candidateRoot/src/agent/matatoAgentSessions'
import { getMatatoAgentDir } from 'candidateRoot/src/agent/matatoAgentPaths'

let storagePath = ''
let root = ''
const reference = (childSessionFile: string): string => JSON.stringify({
  type: 'custom', customType: 'matatoSubAgent',
  data: { kind: 'subAgentStarted', reference: { childSessionFile } },
})
const write = async (file: string, lines: Array<string> = []): Promise<void> => {
  await mkdir(path.dirname(file), { recursive: true })
  await writeFile(file, `${lines.join('\n')}\n`)
}
const assertPresent = async (file: string, content: string): Promise<void> => {
  assert(existsSync(file), `protected file was deleted: ${file}`)
  assert.equal(await readFile(file, 'utf8'), content)
}

beforeEach(async () => {
  storagePath = await mkdtemp(path.join(tmpdir(), 'sessionFixture'))
  process.env.MATATO_TEST_STORAGE_PATH = storagePath
  root = path.dirname(resolveGuiChatSessionDirectory())
  await mkdir(root, { recursive: true })
})
afterEach(async () => { await rm(storagePath, { recursive: true, force: true }) })

test('direct non-session agent files are not cleanup targets and cannot dispatch references', async () => {
  const child = path.join(root, 'child.jsonl')
  const protectedFile = path.join(getMatatoAgentDir(), 'IDENTITY.md')
  await write(child)
  await write(protectedFile, [reference(child)])
  const content = await readFile(protectedFile, 'utf8')
  await deleteManagedSessionTree(protectedFile)
  await assertPresent(protectedFile, content)
  assert(existsSync(child), 'a rejected file must not be traversed')
})
test('a legitimate parent skips non-session child references without losing valid children', async () => {
  const parent = path.join(root, 'parent.jsonl')
  const child = path.join(root, 'child.jsonl')
  const protectedFile = path.join(getMatatoAgentDir(), 'settings.json')
  await write(protectedFile, ['keep'])
  await write(child)
  await write(parent, [reference(protectedFile), reference(child)])
  await deleteManagedSessionTree(parent)
  await assertPresent(protectedFile, 'keep\n')
  assert(!existsSync(parent) && !existsSync(child))
})
test('directory symlink escape is neither deleted nor traversed', async () => {
  const outside = path.join(storagePath, 'outside')
  const target = path.join(outside, 'target.jsonl')
  const child = path.join(root, 'innocent.jsonl')
  await write(child)
  await write(target, [reference(child)])
  const content = await readFile(target, 'utf8')
  const alias = path.join(root, 'escape')
  await symlink(outside, alias, 'dir')
  await deleteManagedSessionTree(path.join(alias, 'target.jsonl'))
  await assertPresent(target, content)
  assert((await lstat(alias)).isSymbolicLink())
  assert(existsSync(child), 'references in an escaping target must not execute')
})
test('file symlink escape preserves the link, its target, and its referenced child', async () => {
  const target = path.join(storagePath, 'outside.jsonl')
  const child = path.join(root, 'innocent.jsonl')
  await write(child)
  await write(target, [reference(child)])
  const alias = path.join(root, 'alias.jsonl')
  await symlink(target, alias)
  await deleteManagedSessionTree(alias)
  assert(existsSync(alias), 'escaping link must survive')
  assert((await lstat(alias)).isSymbolicLink(), 'escaping link must remain a symlink')
  await assertPresent(target, `${reference(child)}\n`)
  assert(existsSync(child))
})
test('a parent ignores an escaping child alias and still cleans its safe subtree', async () => {
  const target = path.join(storagePath, 'outside', 'target.jsonl')
  const alias = path.join(root, 'escape')
  const parent = path.join(root, 'parent.jsonl')
  const child = path.join(root, 'safe.jsonl')
  await write(target, ['keep'])
  await symlink(path.dirname(target), alias, 'dir')
  await write(child)
  await write(parent, [reference(path.join(alias, 'target.jsonl')), reference(child)])
  await deleteManagedSessionTree(parent)
  await assertPresent(target, 'keep\n')
  assert(!existsSync(parent) && !existsSync(child))
  assert((await lstat(alias)).isSymbolicLink())
})
test('lexical lookalikes, dot-dot escapes, and unrelated outside files survive', async () => {
  const paths = [path.join(`${root}Extra`, 'one.jsonl'), path.join(root, '..', 'other', 'two.jsonl'), path.join(storagePath, 'outside.jsonl')]
  for (const file of paths) await write(file, ['keep'])
  for (const file of paths) await deleteManagedSessionTree(file)
  for (const file of paths) await assertPresent(file, 'keep\n')
})
test('managed root and directory child paths are no-ops, not recursive directory removals or errors', async () => {
  const parent = path.join(root, 'parent.jsonl')
  const directory = path.join(root, 'nested')
  const sentinel = path.join(directory, 'unreferenced.jsonl')
  const child = path.join(root, 'child.jsonl')
  await write(sentinel, ['keep'])
  await write(child)
  await write(parent, [reference(directory), reference(root), reference(child)])
  await assert.doesNotReject(() => deleteManagedSessionTree(root))
  await assert.doesNotReject(() => deleteManagedSessionTree(directory))
  await assert.doesNotReject(() => deleteManagedSessionTree(parent))
  await assertPresent(sentinel, 'keep\n')
  assert(!existsSync(parent) && !existsSync(child))
  assert((await lstat(root)).isDirectory())
})
test('cycle, shared descendant, repeated reference, missing child and malformed line coexist', async () => {
  const parent = path.join(root, 'parent.jsonl')
  const first = path.join(root, 'nested', 'first.jsonl')
  const second = path.join(root, 'second.jsonl')
  const shared = path.join(root, 'shared.jsonl')
  const ignored = path.join(root, 'ignored.jsonl')
  await write(ignored, ['keep'])
  await write(shared, [reference(first)])
  await write(first, [reference(shared), reference(parent)])
  await write(second, [reference(shared)])
  await write(parent, [
    '{broken json', '',
    JSON.stringify({ type: 'message', customType: 'matatoSubAgent', data: { reference: { childSessionFile: ignored } } }),
    JSON.stringify({ type: 'custom', customType: 'other', data: { reference: { childSessionFile: ignored } } }),
    JSON.stringify({ type: 'custom', customType: 'matatoSubAgent', data: {} }),
    reference(path.join(root, 'missing.jsonl')), reference(first), reference(first), reference(second),
  ])
  await deleteManagedSessionTree(parent)
  for (const file of [parent, first, second, shared]) assert(!existsSync(file), `${file} should be removed`)
  await assertPresent(ignored, 'keep\n')
  await deleteManagedSessionTree(parent)
  await deleteManagedSessionTree(path.join(root, 'neverExisted.jsonl'))
})
test('an outside lexical alias into the managed tree cannot dispatch child cleanup', async () => {
  const target = path.join(root, 'target.jsonl')
  const child = path.join(root, 'child.jsonl')
  const alias = path.join(getMatatoAgentDir(), 'alias.jsonl')
  await write(child)
  await write(target, [reference(child)])
  await symlink(target, alias)
  await deleteManagedSessionTree(alias)
  assert(existsSync(alias), 'lexical containment is required even when the target is inside')
  await assertPresent(target, `${reference(child)}\n`)
  assert(existsSync(child))
})
test('a real created session header is deletable and cleanup does not sweep siblings', async () => {
  const manager = resolveGuiChatSessionManager({})
  const file = manager.getSessionFile()
  const header = manager.getHeader()
  assert(file && header)
  await write(file, [JSON.stringify(header)])
  const sibling = path.join(path.dirname(file), 'sibling.jsonl')
  await write(sibling, ['keep'])
  await deleteManagedSessionTree(file)
  assert(!existsSync(file))
  await assertPresent(sibling, 'keep\n')
  await deleteManagedSessionTree(file)
})
