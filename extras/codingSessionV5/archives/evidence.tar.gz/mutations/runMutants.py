"""Execute at most four Atlas-issued independent byte edits."""
from pathlib import Path
import base64
import difflib
import json
from experiment import root, save, digest, inventory, source_names, git, checks


def load(path):
    return json.loads(path.read_text())


def choose(record):
    destination = root / record['arm'] / record['case']
    manifests = load(destination / 'scanTwo.stdout')['mutations']
    path = 'src/workspaceRepos.ts' if record['case'] == 'ts' else 'atlas/src/atlas/services/navigation_walk.py'
    line = 65 if record['case'] == 'ts' else 46
    candidates = [m for m in manifests if m['path'] == path and m['span']['startLine'] == line]
    assert len(candidates) == 1
    manifest = candidates[0]
    save(destination / 'selectedManifest.json', manifest)
    if record['case'] == 'ts':
        rationale = ('Changed physical checkout-root guard: !== to === rejects valid child roots and admits '
                     'ordinary folders inheriting a parent origin. Maintained real Git fixtures should fail '
                     'listWorkspaceRepos().toEqual on incorrect rows, including new checkout/symlink coverage.')
    else:
        rationale = ('Changed finite adjacency request: max_edges + 1 to max_edges - 1 underfetches distinct '
                     'evidence and removes overflow lookahead. Production-indexed coffee navigation assertions '
                     'should detect missing ordered edges or false completion/truncation; bounded graph tests '
                     'may also reject lost evidence. Directly probes the changed expression, not unrelated arithmetic.')
    return {'arm': record['arm'], 'case': record['case'], 'manifest': manifest,
            'relevance': rationale, 'expectedOutcome': 'semantic assertion failure',
            'manifestFile': str(destination / 'selectedManifest.json')}


def verify_pristine(record):
    workspace = Path(record['workspace'])
    assert inventory(workspace, record['names']) == record['sourceInventory']
    assert source_names(workspace) == sorted(set(record['names'] + ['atlas.json']))
    return True


def apply(record, selected):
    workspace = Path(record['workspace'])
    manifest = selected['manifest']
    relative = Path(manifest['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    path = workspace / relative
    assert path.resolve(strict=True).is_relative_to(workspace.resolve(strict=True))
    assert all(not parent.is_symlink() for parent in [path, *path.parents] if parent.is_relative_to(workspace))
    canonical = json.dumps({k: v for k, v in manifest.items() if k != 'id'},
                           sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
    assert digest(canonical) == manifest['id']
    original = path.read_bytes()
    assert digest(original) == manifest['sourceHash']
    before = base64.b64decode(manifest['originalBytes'], validate=True)
    after = base64.b64decode(manifest['replacementBytes'], validate=True)
    start, end = manifest['span']['startByte'], manifest['span']['endByte']
    assert 0 <= start < end <= len(original)
    assert original[start:end] == before
    mutated = original[:start] + after + original[end:]
    destination = root / record['arm'] / record['case']
    (destination / 'pristineSource').write_bytes(original)
    diff = ''.join(difflib.unified_diff(original.decode().splitlines(True), mutated.decode().splitlines(True),
                                       fromfile=manifest['path'], tofile=manifest['path']))
    (destination / 'mutant.diff').write_text(diff)
    path.write_bytes(mutated)
    assert path.read_bytes() == mutated
    selected['verification'] = {'manifestIdentityVerified': True, 'fullHashVerified': True,
                                'spanBytesVerified': True, 'constructedBytesVerified': True,
                                'originalHash': digest(original), 'mutatedHash': digest(mutated),
                                'diff': str(destination / 'mutant.diff')}
    return path, original


def execute_mutant(record, selected):
    destination = root / record['arm'] / record['case']
    baseline = load(destination / 'baseline.json')
    assert baseline['exit'] == 0 and not baseline['timedOut']
    text = Path(baseline['stdout']).read_text() + Path(baseline['stderr']).read_text()
    assert '59 passed' in text if record['case'] == 'py' else ' 0 fail' in text and 'Ran ' in text
    verify_pristine(record)
    path, original = apply(record, selected)
    # Diff is persisted before the command; exactly one operator changed.
    print((destination / 'mutant.diff').read_text(), flush=True)
    try:
        selected['execution'] = checks(record, 'mutant')
        selected['outcome'] = 'pendingOutputInspection'
    finally:
        path.write_bytes(original)
        selected['restoration'] = {'restoredHash': digest(path.read_bytes()),
                                   'sourceHashMatches': digest(path.read_bytes()) == selected['manifest']['sourceHash'],
                                   'entireTargetInventoryMatches': verify_pristine(record)}
        save(destination / 'mutantResult.json', selected)
    return selected


def main():
    records = load(root / 'targets.json')
    selected = [choose(record) for record in records]
    assert len(selected) <= 4
    save(root / 'selection.json', selected)
    results = []
    for record, selection in zip(records, selected, strict=True):
        results.append(execute_mutant(record, selection))
    save(root / 'unclassifiedResults.json', results)


if __name__ == '__main__':
    main()
