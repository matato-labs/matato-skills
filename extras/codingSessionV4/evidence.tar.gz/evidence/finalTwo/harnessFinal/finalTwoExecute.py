"""Second predeclared draw only; no retries, repairs, quality scoring or extra implementations."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from finalOneExecute import arms, digest, launcherHashes, sourceHashes
from finalOnePreflight import hashes, manifests, quota
from sandboxTrial import root

evidence = root / 'evidence/finalTwo'
disk = Path('/home/leon/.cache/codingSessionV4Owned')


def save(name, data):
    (evidence / name).write_text(json.dumps(data, indent=2) + '\n')


def historicalHashes():
    old = json.loads((disk / 'relocationEvidence/oldBefore.json').read_text())
    paths = set(old)
    for category in ['runs', 'evidence', 'worktrees', 'reviews']:
        for draw in (root / category).iterdir():
            if draw.name == 'finalTwo':
                continue
            for path in draw.rglob('*'):
                if path.is_file() and not path.is_symlink():
                    paths.add(str(path))
    return {path: digest(Path(path)) for path in sorted(paths)}


def launch(job):
    manifest, arm = job
    case = json.loads(manifest.read_text())['cases'][0]
    label = arm + '.' + case['id']
    argv = [sys.executable, str(root / 'runTrial.py'), str(manifest), arm, 'finalTwo']
    started = time.monotonic()
    record = {'argv': argv, 'cwd': str(root), 'manifest': str(manifest), 'case': case['id'], 'arm': arm, 'draw': 'finalTwo', 'startedAt': datetime.now(timezone.utc).isoformat(), 'parentEnvironment': {'PYTHONDONTWRITEBYTECODE': '1'}, 'maxConcurrent': 6, 'agentTimeoutSeconds': 900, 'retries': 0}
    save(label + '.command.json', record)
    with (evidence / (label + '.stdout')).open('xb') as output, (evidence / (label + '.stderr')).open('xb') as errors:
        process = subprocess.Popen(argv, cwd=root, stdout=output, stderr=errors, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        record['pid'] = process.pid
        save(label + '.launch.json', record)
        code = process.wait()
    record.update({'runnerExit': code, 'seconds': round(time.monotonic() - started, 3), 'finishedAt': datetime.now(timezone.utc).isoformat()})
    save(label + '.returned.json', record)
    print(json.dumps(record), flush=True)
    return record


def main():
    assert json.loads((evidence / 'prelaunch.json').read_text())['passed']
    assert json.loads((root / 'control/budget.json').read_text())['reserved'] == 35
    assert not list((root / 'runs/finalTwo').iterdir())
    before = hashes()
    frozen = json.loads((root / 'evidence/finalOne/after.json').read_text())
    assert all(before[path] == value for path, value in frozen.items())
    save('before.json', before)
    launchers = launcherHashes()
    assert launchers == json.loads((root / 'evidence/finalOne/launcherAfter.json').read_text())
    save('launcherBefore.json', launchers)
    originals = sourceHashes()
    assert originals == json.loads((root / 'evidence/finalOne/originalAfter.json').read_text())
    save('originalBefore.json', originals)
    historical = historicalHashes()
    old = json.loads((disk / 'relocationEvidence/oldBefore.json').read_text())
    assert all(historical[path] == value for path, value in old.items())
    save('historicalBefore.json', historical)
    snapshot = evidence / 'harnessFinal'
    snapshot.mkdir()
    for path in [*root.glob('*.py'), root / 'dependencyMounts.json', root / 'runnerNotes.md', root / 'finalFreeze.json']:
        shutil.copy2(path, snapshot / path.name)
    for index, manifest in enumerate(manifests):
        target = evidence / 'frozenInputs' / str(index)
        target.mkdir(parents=True)
        for path in manifest.parent.iterdir():
            if path.is_file():
                shutil.copy2(path, target / path.name)
    save('ledgerBefore.json', json.loads((root / 'control/budget.json').read_text()))
    jobs = [(manifest, arm) for arm in arms for manifest in manifests]
    save('schedule.json', {'jobs': [[str(path), arm] for path, arm in jobs], 'count': 16, 'maxConcurrent': 6, 'noRetries': True, 'secondPredeclaredDraw': True, 'stopAfterThisDraw': True})
    with ThreadPoolExecutor(max_workers=6) as pool:
        returned = list(pool.map(launch, jobs))
    save('runnerExits.json', returned)
    after = hashes()
    save('after.json', after)
    launcherAfter = launcherHashes()
    save('launcherAfter.json', launcherAfter)
    originalAfter = sourceHashes()
    save('originalAfter.json', originalAfter)
    historicalAfter = historicalHashes()
    save('historicalAfter.json', historicalAfter)
    ledger = json.loads((root / 'control/budget.json').read_text())
    save('ledgerAfter.json', ledger)
    results = [json.loads(path.read_text()) for path in sorted((root / 'runs/finalTwo').glob('*/*/result.json'))]
    fields = ['case', 'arm', 'status', 'seconds', 'agentSeconds', 'setupExit', 'agentExit', 'acceptanceExit', 'nativeExit', 'profileSha256', 'profileBytes', 'profileAudit', 'error']
    save('executionSummary.json', [{key: result[key] for key in fields if key in result} for result in results])
    checks = {'results': len(results), 'reserved': ledger['reserved'], 'finalTwoReservations': len([identity for identity in ledger['runs'] if identity.startswith('finalTwo/')]), 'frozenUnchanged': after == before, 'launchersUnchanged': launcherAfter == launchers, 'originalsUnchanged': originalAfter == originals, 'historicalOutputsUnchanged': historicalAfter == historical, 'publicationReady': False, 'independentReviewRequired': True, 'qualityScoringPerformed': False, 'stopNoFurtherImplementations': True}
    save('integrity.json', checks)
    save('quotaAfter.json', {'/tmp': quota('/tmp'), str(disk): quota(str(disk)), 'diskUsage': dict(shutil.disk_usage(disk)._asdict())})
    print(json.dumps(checks), flush=True)
    assert len(results) == 16 and ledger['reserved'] == 51 and all(checks[key] for key in ['frozenUnchanged', 'launchersUnchanged', 'originalsUnchanged', 'historicalOutputsUnchanged'])


if __name__ == '__main__':
    main()
